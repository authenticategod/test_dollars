import { pgTable, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const inviteCodesTable = pgTable("invite_codes", {
  code: text("code").primaryKey(),
  label: text("label"),
  createdBy: integer("created_by"),
  maxUses: integer("max_uses").notNull().default(1),
  usesCount: integer("uses_count").notNull().default(0),
  revoked: boolean("revoked").notNull().default(false),
  isOwnerCode: boolean("is_owner_code").notNull().default(false),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertInviteCodeSchema = createInsertSchema(inviteCodesTable).omit({ usesCount: true, createdAt: true });
export type InsertInviteCode = z.infer<typeof insertInviteCodeSchema>;
export type InviteCode = typeof inviteCodesTable.$inferSelect;
