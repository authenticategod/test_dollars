import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { membersTable } from "./members";
import { roomsTable } from "./rooms";

export const messagesTable = pgTable("messages", {
  id: serial("id").primaryKey(),
  roomId: integer("room_id")
    .notNull()
    .references(() => roomsTable.id, { onDelete: "cascade" }),
  memberId: integer("member_id")
    .notNull()
    .references(() => membersTable.id, { onDelete: "cascade" }),
  content: text("content").notNull(),
  type: text("type", { enum: ["text", "sticker", "system"] })
    .notNull()
    .default("text"),
  replyToId: integer("reply_to_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Message = typeof messagesTable.$inferSelect;
