import { pgTable, integer, text, primaryKey } from "drizzle-orm/pg-core";
import { messagesTable } from "./messages";
import { membersTable } from "./members";

export const reactionsTable = pgTable(
  "reactions",
  {
    messageId: integer("message_id")
      .notNull()
      .references(() => messagesTable.id, { onDelete: "cascade" }),
    memberId: integer("member_id")
      .notNull()
      .references(() => membersTable.id, { onDelete: "cascade" }),
    emoji: text("emoji").notNull(),
  },
  (t) => [primaryKey({ columns: [t.messageId, t.memberId, t.emoji] })]
);

export type Reaction = typeof reactionsTable.$inferSelect;
