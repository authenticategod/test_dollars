import { Link } from "wouter";
import { ShieldAlert } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex-1 flex items-center justify-center p-6">
      <div className="text-center space-y-6 max-w-md">
        <ShieldAlert className="w-16 h-16 mx-auto text-muted-foreground/50" />
        <div>
          <h1 className="font-mono text-4xl font-black tracking-widest text-muted-foreground mb-2">
            404
          </h1>
          <p className="font-mono text-sm text-muted-foreground/70 tracking-wider uppercase">
            Signal lost. No route found at this address.
          </p>
        </div>
        <Link
          href="/"
          className="inline-block font-mono text-xs uppercase tracking-widest text-primary hover:text-primary/80 border border-primary/30 px-6 py-3 transition-colors hover:bg-primary/10"
        >
          Return to Origin
        </Link>
      </div>
    </div>
  );
}
