import { useState } from "react";
import { getAnimatedEmojiUrl } from "@/lib/emoji-utils";

type Props = {
  emoji: string;
  size?: number;
  className?: string;
  autoPlay?: boolean;
};

export function AnimatedEmoji({ emoji, size = 64, className = "", autoPlay = true }: Props) {
  const [imgFailed, setImgFailed] = useState(false);
  const url = getAnimatedEmojiUrl(emoji);

  if (imgFailed) {
    return (
      <span className={className} style={{ fontSize: size }}>
        {emoji}
      </span>
    );
  }

  return (
    <span className={`relative inline-block ${className}`} style={{ width: size, height: size }}>
      <span
        className="absolute inset-0 flex items-center justify-center"
        style={{ fontSize: size * 0.8 }}
        aria-hidden
      >
        {emoji}
      </span>
      <img
        src={url}
        alt={emoji}
        width={size}
        height={size}
        loading="lazy"
        onError={() => setImgFailed(true)}
        className={`relative z-10 ${autoPlay ? "" : "hover:opacity-100 opacity-0 hover:scale-110 transition-all"}`}
        style={{ imageRendering: "auto" }}
      />
    </span>
  );
}

type InlineProps = {
  emoji: string;
  className?: string;
};

export function InlineAnimatedEmoji({ emoji, className = "" }: InlineProps) {
  const [hovered, setHovered] = useState(false);
  const [imgFailed, setImgFailed] = useState(false);
  const url = getAnimatedEmojiUrl(emoji);

  return (
    <span
      className={`relative inline-block cursor-default ${className}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {emoji}
      {hovered && !imgFailed && (
        <span className="absolute z-50 pointer-events-none" style={{ bottom: "100%", left: "50%", transform: "translateX(-50%)" }}>
          <img
            src={url}
            alt={emoji}
            width={56}
            height={56}
            onError={() => setImgFailed(true)}
            className="drop-shadow-lg"
          />
        </span>
      )}
    </span>
  );
}
