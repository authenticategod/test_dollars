import { useEffect, useState, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { StickerEffect } from "@/lib/stickers";

type Particle = {
  id: number;
  x: number;
  y: number;
  emoji: string;
  angle: number;
  speed: number;
  size: number;
  rotation: number;
  rotationSpeed: number;
};

const EFFECT_PARTICLES: Record<StickerEffect, string[]> = {
  none: [],
  confetti: ["🎊", "🎉", "✨", "🌟", "💫", "⭐", "🎈", "🎀"],
  hearts: ["❤️", "🧡", "💛", "💚", "💙", "💜", "🩷", "❤️‍🔥"],
  sparkle: ["✨", "⚡", "💫", "🌟", "⭐", "🔆", "💎", "🪩"],
  flames: ["🔥", "💥", "✨", "🌋", "💫", "⚡", "🔆", "🌠"],
  glitch: ["⚠️", "🔴", "🟣", "💀", "☠️", "⚡", "🌀", "👾"],
  snow: ["❄️", "⛄", "🌨️", "💠", "🔷", "🫧", "🌬️", "🤍"],
  matrix: ["0️⃣", "1️⃣", "🟩", "💚", "🖥️", "⚡", "🔢", "✅"],
};

const PARTICLE_COUNT: Record<StickerEffect, number> = {
  none: 0,
  confetti: 20,
  hearts: 16,
  sparkle: 18,
  flames: 16,
  glitch: 12,
  snow: 18,
  matrix: 14,
};

function createParticles(effect: StickerEffect): Particle[] {
  const emojis = EFFECT_PARTICLES[effect];
  const count = PARTICLE_COUNT[effect];
  if (!count || !emojis.length) return [];

  return Array.from({ length: count }, (_, i) => ({
    id: i,
    x: (Math.random() - 0.5) * 300,
    y: (Math.random() - 0.8) * 280,
    emoji: emojis[Math.floor(Math.random() * emojis.length)],
    angle: Math.random() * 360,
    speed: 0.6 + Math.random() * 0.8,
    size: 16 + Math.floor(Math.random() * 20),
    rotation: Math.random() * 360,
    rotationSpeed: (Math.random() - 0.5) * 720,
  }));
}

type Props = {
  effect: StickerEffect;
  trigger: number;
  anchorRef?: React.RefObject<HTMLElement | null>;
};

export function StickerEffectOverlay({ effect, trigger, anchorRef }: Props) {
  const [particles, setParticles] = useState<Particle[]>([]);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!trigger || effect === "none") return;

    if (anchorRef?.current) {
      const rect = anchorRef.current.getBoundingClientRect();
      setPos({ x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 });
    }

    setParticles(createParticles(effect));
    const timer = setTimeout(() => setParticles([]), 2200);
    return () => clearTimeout(timer);
  }, [trigger, effect]);

  if (!particles.length) return null;

  return (
    <div
      ref={containerRef}
      className="pointer-events-none fixed z-[999]"
      style={{ left: pos.x, top: pos.y, transform: "translate(-50%, -50%)" }}
    >
      <AnimatePresence>
        {particles.map((p) => (
          <motion.div
            key={p.id}
            initial={{ x: 0, y: 0, opacity: 1, scale: 0, rotate: p.rotation }}
            animate={{
              x: p.x,
              y: p.y,
              opacity: 0,
              scale: p.speed,
              rotate: p.rotation + p.rotationSpeed,
            }}
            transition={{ duration: 1.6 + p.speed * 0.4, ease: [0.2, 0.8, 0.4, 1] }}
            className="absolute"
            style={{ fontSize: p.size }}
          >
            {p.emoji}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

type InlineProps = {
  effect: StickerEffect;
  trigger: number;
};

export function InlineStickerEffect({ effect, trigger }: InlineProps) {
  const [particles, setParticles] = useState<Particle[]>([]);

  useEffect(() => {
    if (!trigger || effect === "none") return;
    setParticles(createParticles(effect));
    const timer = setTimeout(() => setParticles([]), 2200);
    return () => clearTimeout(timer);
  }, [trigger, effect]);

  if (!particles.length) return null;

  return (
    <div className="pointer-events-none absolute inset-0 overflow-visible z-10">
      <AnimatePresence>
        {particles.map((p) => (
          <motion.div
            key={p.id}
            initial={{ x: 0, y: 0, opacity: 1, scale: 0, rotate: p.rotation }}
            animate={{
              x: p.x,
              y: p.y,
              opacity: 0,
              scale: p.speed,
              rotate: p.rotation + p.rotationSpeed,
            }}
            transition={{ duration: 1.6 + p.speed * 0.4, ease: [0.2, 0.8, 0.4, 1] }}
            className="absolute left-1/2 top-1/2"
            style={{ fontSize: p.size }}
          >
            {p.emoji}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
