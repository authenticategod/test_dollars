import { useState, useEffect } from "react";
import { format } from "date-fns";
import { Shield, Plus, Mail, Copy, Trash2 } from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/auth-context";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListInviteCodes,
  useListMembers,
  useCreateInviteCode,
  useRevokeInviteCode,
  useSendInviteEmail,
  useGetMe,
  getListInviteCodesQueryKey,
  getListMembersQueryKey,
  getGetMeQueryKey,
} from "@workspace/api-client-react";
import type { SendInviteEmailMutationError } from "@workspace/api-client-react";

export default function Admin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { token, adminSecret, setAdminSecret } = useAuth();

  const [inputSecret, setInputSecret] = useState("");
  const [ownerSessionActive, setOwnerSessionActive] = useState(false);
  const [view, setView] = useState<"codes" | "members">("codes");

  const [createOpen, setCreateOpen] = useState(false);
  const [newCodeUses, setNewCodeUses] = useState(1);
  const [newCodeLabel, setNewCodeLabel] = useState("");
  const [newCodeIsOwner, setNewCodeIsOwner] = useState(false);

  const [emailOpen, setEmailOpen] = useState(false);
  const [activeCode, setActiveCode] = useState("");
  const [recipientEmail, setRecipientEmail] = useState("");
  const [personalMessage, setPersonalMessage] = useState("");

  const { data: currentUser } = useGetMe({
    request: { headers: { "X-Session-Token": token || "" } },
    query: {
      queryKey: getGetMeQueryKey(),
      enabled: !!token,
      retry: false,
    },
  });

  const isOwner = currentUser?.role === "owner";
  const isAuthed = !!(adminSecret || (ownerSessionActive && token && isOwner));

  const headerMap: Record<string, string> = adminSecret
    ? { "X-Admin-Secret": adminSecret }
    : { "X-Session-Token": token || "" };
  const adminHeaders = { headers: headerMap };

  const { data: codes, isError: codesError } = useListInviteCodes({
    request: adminHeaders,
    query: {
      queryKey: getListInviteCodesQueryKey(),
      enabled: isAuthed && view === "codes",
      retry: false,
    },
  });
  const { data: members } = useListMembers({
    request: adminHeaders,
    query: {
      queryKey: getListMembersQueryKey(),
      enabled: isAuthed && view === "members",
      retry: false,
    },
  });

  const createCodeMutation = useCreateInviteCode({
    request: adminHeaders,
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({
          queryKey: getListInviteCodesQueryKey(),
        });
        setCreateOpen(false);
        toast({ title: "Code generated" });
      },
    },
  });

  const revokeMutation = useRevokeInviteCode({
    request: adminHeaders,
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({
          queryKey: getListInviteCodesQueryKey(),
        });
        toast({ title: "Code revoked" });
      },
    },
  });

  const sendEmailMutation = useSendInviteEmail({
    request: adminHeaders,
    mutation: {
      onSuccess: () => {
        setEmailOpen(false);
        toast({ title: "Invite dispatched via email" });
      },
      onError: (err: SendInviteEmailMutationError) => {
        toast({
          title: "Email failed",
          description: err?.data?.error || "Unknown error",
          variant: "destructive",
        });
      },
    },
  });

  useEffect(() => {
    if (codesError && adminSecret) {
      setAdminSecret(null);
      toast({ title: "Access denied", variant: "destructive" });
    }
  }, [codesError, adminSecret, setAdminSecret, toast]);

  if (!isAuthed) {
    return (
      <div className="flex-1 flex items-center justify-center p-6">
        <Card className="w-full max-w-md bg-card/80 backdrop-blur border-border">
          <CardHeader className="text-center">
            <Shield className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <CardTitle className="font-mono tracking-widest uppercase">
              Admin Terminal
            </CardTitle>
            <CardDescription>
              {isOwner
                ? "You are the owner. Access granted automatically, or enter the passphrase."
                : "Enter the passphrase to access root controls."}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {isOwner && (
              <Button
                className="w-full font-mono uppercase tracking-widest"
                variant="default"
                onClick={() => setOwnerSessionActive(true)}
              >
                Enter as Owner
              </Button>
            )}
            {isOwner && <div className="text-center text-xs text-muted-foreground font-mono">or</div>}
            <Input
              type="password"
              value={inputSecret}
              onChange={(e) => setInputSecret(e.target.value)}
              placeholder="••••••••"
              className="font-mono text-center tracking-widest"
              onKeyDown={(e) =>
                e.key === "Enter" && setAdminSecret(inputSecret)
              }
            />
            <Button
              className="w-full font-mono uppercase tracking-widest"
              variant="outline"
              onClick={() => setAdminSecret(inputSecret)}
            >
              Authenticate with Passphrase
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const copyToClipboard = (code: string) => {
    const url = `${window.location.origin}${import.meta.env.BASE_URL}?code=${code}`;
    navigator.clipboard.writeText(url);
    toast({ title: "Link copied to clipboard" });
  };

  return (
    <div className="flex-1 flex flex-col p-6 w-full max-w-6xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Root Terminal</h1>
          <p className="text-muted-foreground font-mono text-sm mt-1">
            Authorized access granted.
          </p>
        </div>
        <Button
          variant="outline"
          onClick={() => {
            setAdminSecret(null);
            setOwnerSessionActive(false);
          }}
          className="font-mono text-xs uppercase"
        >
          {adminSecret ? "Terminate Session" : "Exit Admin"}
        </Button>
      </div>

      <div className="flex border-b border-border">
        <button
          onClick={() => setView("codes")}
          className={`px-6 py-3 font-mono text-sm tracking-wider uppercase border-b-2 transition-colors ${view === "codes" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
        >
          Invite Codes
        </button>
        <button
          onClick={() => setView("members")}
          className={`px-6 py-3 font-mono text-sm tracking-wider uppercase border-b-2 transition-colors ${view === "members" ? "border-primary text-primary" : "border-transparent text-muted-foreground hover:text-foreground"}`}
        >
          Member Ledger
        </button>
      </div>

      {view === "codes" && (
        <div className="space-y-4">
          <div className="flex justify-end">
            <Dialog open={createOpen} onOpenChange={setCreateOpen}>
              <DialogTrigger asChild>
                <Button className="font-mono text-xs uppercase tracking-widest">
                  <Plus className="w-4 h-4 mr-2" /> Generate Code
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border">
                <DialogHeader>
                  <DialogTitle>Generate Invitation</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div className="space-y-2">
                    <label className="text-sm font-mono text-muted-foreground">
                      Label / Note
                    </label>
                    <Input
                      value={newCodeLabel}
                      onChange={(e) => setNewCodeLabel(e.target.value)}
                      placeholder="e.g. For John"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-mono text-muted-foreground">
                      Max Uses
                    </label>
                    <Input
                      type="number"
                      min="1"
                      value={newCodeUses}
                      onChange={(e) =>
                        setNewCodeUses(parseInt(e.target.value))
                      }
                    />
                  </div>
                  <div className="flex items-center gap-3 py-1">
                    <button
                      type="button"
                      onClick={() => setNewCodeIsOwner((v) => !v)}
                      className={`relative w-9 h-5 rounded-full transition-colors flex-shrink-0 ${newCodeIsOwner ? "bg-amber-500" : "bg-muted"}`}
                    >
                      <span className={`absolute top-0.5 left-0.5 w-4 h-4 rounded-full bg-white transition-transform ${newCodeIsOwner ? "translate-x-4" : ""}`} />
                    </button>
                    <div>
                      <p className="text-sm font-mono">Owner Code</p>
                      <p className="text-xs text-muted-foreground">Grants owner role to whoever joins with this code</p>
                    </div>
                  </div>
                  <Button
                    className="w-full"
                    onClick={() =>
                      createCodeMutation.mutate({
                        data: {
                          maxUses: newCodeUses,
                          label: newCodeLabel || null,
                          isOwnerCode: newCodeIsOwner,
                        },
                      })
                    }
                  >
                    Generate
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="font-mono">Code</TableHead>
                  <TableHead className="font-mono">Label</TableHead>
                  <TableHead className="font-mono">Usage</TableHead>
                  <TableHead className="font-mono">Status</TableHead>
                  <TableHead className="font-mono text-right">
                    Actions
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {codes?.map((code) => (
                  <TableRow key={code.code} className="border-border group">
                    <TableCell className="font-mono font-bold">
                      {code.code}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {code.label || "\u2014"}
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {code.usesCount} / {code.maxUses}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {code.revoked ? (
                          <Badge variant="destructive">Revoked</Badge>
                        ) : code.usesCount >= code.maxUses ? (
                          <Badge variant="secondary">Depleted</Badge>
                        ) : (
                          <Badge className="bg-green-500/20 text-green-500 hover:bg-green-500/30 border-green-500/50">
                            Active
                          </Badge>
                        )}
                        {code.isOwnerCode && (
                          <Badge className="bg-amber-500/20 text-amber-400 border-amber-500/40">
                            👑 Owner
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => copyToClipboard(code.code)}
                        disabled={
                          code.revoked || code.usesCount >= code.maxUses
                        }
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Dialog
                        open={emailOpen && activeCode === code.code}
                        onOpenChange={(o) => {
                          setEmailOpen(o);
                          setActiveCode(o ? code.code : "");
                        }}
                      >
                        <DialogTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            disabled={
                              code.revoked || code.usesCount >= code.maxUses
                            }
                          >
                            <Mail className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-card border-border">
                          <DialogHeader>
                            <DialogTitle>
                              Dispatch via Secure Email
                            </DialogTitle>
                          </DialogHeader>
                          <div className="space-y-4 pt-4">
                            <div className="space-y-2">
                              <label className="text-sm font-mono text-muted-foreground">
                                Target Email
                              </label>
                              <Input
                                type="email"
                                value={recipientEmail}
                                onChange={(e) =>
                                  setRecipientEmail(e.target.value)
                                }
                                placeholder="target@domain.com"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-mono text-muted-foreground">
                                Message (Optional)
                              </label>
                              <Input
                                value={personalMessage}
                                onChange={(e) =>
                                  setPersonalMessage(e.target.value)
                                }
                                placeholder="You have been selected."
                              />
                            </div>
                            <Button
                              className="w-full"
                              onClick={() =>
                                sendEmailMutation.mutate({
                                  code: code.code,
                                  data: {
                                    recipientEmail,
                                    personalMessage:
                                      personalMessage || null,
                                  },
                                })
                              }
                            >
                              Dispatch Now
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-destructive hover:text-destructive"
                        onClick={() =>
                          revokeMutation.mutate({ code: code.code })
                        }
                        disabled={code.revoked}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {view === "members" && (
        <div className="border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="font-mono">ID</TableHead>
                <TableHead className="font-mono">Handle</TableHead>
                <TableHead className="font-mono">Display Name</TableHead>
                <TableHead className="font-mono">Role</TableHead>
                <TableHead className="font-mono">Inducted</TableHead>
                <TableHead className="font-mono text-right">
                  Origin Code
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {members?.map((m) => (
                <TableRow key={m.id} className="border-border">
                  <TableCell className="font-mono text-muted-foreground">
                    #{m.id}
                  </TableCell>
                  <TableCell className="font-mono font-bold text-primary">
                    @{m.usertag}
                  </TableCell>
                  <TableCell>{m.displayName}</TableCell>
                  <TableCell>
                    {m.role === "owner" ? (
                      <Badge className="bg-amber-500/20 text-amber-500">
                        Owner
                      </Badge>
                    ) : (
                      <Badge variant="secondary">Member</Badge>
                    )}
                  </TableCell>
                  <TableCell className="font-mono text-sm">
                    {format(new Date(m.joinedAt), "yyyy-MM-dd HH:mm")}
                  </TableCell>
                  <TableCell className="font-mono text-sm text-right text-muted-foreground">
                    {m.inviteCode}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
