import { useEffect } from "react";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { Crown, Star, Shield, LogOut, MessageSquare, Megaphone } from "lucide-react";
import {
  useGetMe, useLogout, useListRooms,
  getGetMeQueryKey, getListRoomsQueryKey,
} from "@workspace/api-client-react";
import { useAuth } from "@/contexts/auth-context";

const PIXEL_COLORS = [
  "#ff6b6b","#ffa94d","#ffd43b","#69db7c","#4dabf7",
  "#da77f2","#f783ac","#63e6be","#74c0fc","#ffec99",
  "#a9e34b","#ff8787","#66d9e8","#e599f7","#ff922b",
];

const LETTERS: Record<string, number[][]> = {
  D: [[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,1,1,0]],
  O: [[0,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0]],
  L: [[1,0,0,0],[1,0,0,0],[1,0,0,0],[1,0,0,0],[1,1,1,1]],
  A: [[0,1,1,0],[1,0,0,1],[1,1,1,1],[1,0,0,1],[1,0,0,1]],
  R: [[1,1,1,0],[1,0,0,1],[1,1,1,0],[1,0,1,0],[1,0,0,1]],
  S: [[0,1,1,1],[1,0,0,0],[0,1,1,0],[0,0,0,1],[1,1,1,0]],
};

function MiniPixelLogo({ scale = 1 }: { scale?: number }) {
  const word = ["D","O","L","L","A","R","S"];
  const dotSize = 4 * scale;
  const gap = 1.2 * scale;
  const letterGap = 2.5 * scale;
  const rows = 5;
  const cols = 4;
  const totalW = word.length * (cols * (dotSize + gap) + letterGap) - letterGap;
  const totalH = rows * (dotSize + gap);
  let colorIdx = 0;

  return (
    <svg width={totalW} height={totalH} viewBox={`0 0 ${totalW} ${totalH}`} style={{ display: "block" }}>
      {word.map((letter, li) => {
        const pixels = LETTERS[letter] || [];
        const offsetX = li * (cols * (dotSize + gap) + letterGap);
        return pixels.map((row, ri) =>
          row.map((cell, ci) => {
            if (!cell) return null;
            const color = PIXEL_COLORS[colorIdx++ % PIXEL_COLORS.length];
            return (
              <circle
                key={`${li}-${ri}-${ci}`}
                cx={offsetX + ci * (dotSize + gap) + dotSize / 2}
                cy={ri * (dotSize + gap) + dotSize / 2}
                r={dotSize / 2}
                fill={color}
              />
            );
          })
        );
      })}
    </svg>
  );
}

function SmallCircleLogo() {
  return (
    <div
      className="relative flex items-center justify-center select-none flex-shrink-0"
      style={{
        width: 44,
        height: 44,
        borderRadius: "50%",
        background: "#000",
        border: "3px solid #fff",
      }}
    >
      <div
        style={{ position: "absolute", inset: 4, borderRadius: "50%", border: "1px solid rgba(255,255,255,0.2)" }}
      />
      <div style={{ transform: "scale(0.55)" }}>
        <MiniPixelLogo />
      </div>
    </div>
  );
}

export default function Lobby() {
  const [, setLocation] = useLocation();
  const { token, setToken } = useAuth();

  useEffect(() => { if (!token) setLocation("/"); }, [token, setLocation]);

  const sessionHeaders = { headers: { "X-Session-Token": token || "" } };

  const { data: member, isLoading, isError } = useGetMe({
    request: sessionHeaders,
    query: { queryKey: getGetMeQueryKey(), enabled: !!token, retry: false },
  });

  const { data: rooms = [] } = useListRooms({
    request: sessionHeaders,
    query: { queryKey: getListRoomsQueryKey(), enabled: !!token, retry: false },
  });

  const logoutMutation = useLogout({
    request: sessionHeaders,
    mutation: { onSettled: () => { setToken(null); setLocation("/"); } },
  });

  useEffect(() => {
    if (isError) { setToken(null); setLocation("/"); }
  }, [isError, setToken, setLocation]);

  if (isLoading || !member) {
    return (
      <div className="flex-1 flex items-center justify-center bg-black">
        <span className="font-mono text-xs text-white/30 animate-pulse tracking-widest">Connecting…</span>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col bg-black text-white min-h-0">
      {/* Header */}
      <header
        className="flex items-center gap-4 px-6 py-3 border-b flex-shrink-0"
        style={{ borderColor: "rgba(255,255,255,0.08)", background: "#0a0a0a" }}
      >
        <SmallCircleLogo />
        <div className="flex-1 min-w-0">
          <p className="font-mono text-xs text-white/30 tracking-widest uppercase">Dollars Anonymous — Lounge</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setLocation(`/profile/${member.usertag}`)}
            className="flex items-center gap-2 px-3 py-1.5 border border-white/10 hover:border-white/30 transition-colors"
          >
            <div
              className="w-6 h-6 flex items-center justify-center font-bold text-xs text-white overflow-hidden flex-shrink-0"
              style={{ background: "#334", borderRadius: 2 }}
            >
              {member.avatarUrl
                ? <img src={member.avatarUrl} alt="" className="w-full h-full object-cover" />
                : member.displayName.charAt(0).toUpperCase()}
            </div>
            <span className="font-mono text-xs text-white/70">{member.displayName}</span>
            {member.role === "owner" && <Crown className="w-3 h-3 text-amber-400" />}
          </button>
          <button
            onClick={() => logoutMutation.mutate()}
            className="flex items-center gap-1.5 px-3 py-1.5 font-mono text-xs text-white/40 hover:text-white/70 border border-white/10 hover:border-white/30 transition-colors uppercase tracking-widest"
          >
            <LogOut className="w-3.5 h-3.5" />
            Leave
          </button>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-3xl mx-auto space-y-6">
          {/* Member card */}
          <div className="border border-white/10 p-4 flex items-center gap-4" style={{ background: "#0d0d0d" }}>
            <div
              className="w-16 h-16 flex items-center justify-center font-bold text-2xl text-white overflow-hidden flex-shrink-0"
              style={{ background: "linear-gradient(135deg,#3b5bdb,#2f4ac4)", borderRadius: 4 }}
            >
              {member.avatarUrl
                ? <img src={member.avatarUrl} alt="" className="w-full h-full object-cover" />
                : member.displayName.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex items-center gap-2">
                <h2 className="font-bold text-lg text-white truncate">{member.displayName}</h2>
                {member.role === "owner" && (
                  <span className="flex items-center gap-1 font-mono text-[10px] px-1.5 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    <Crown className="w-2.5 h-2.5" /> Owner
                  </span>
                )}
                {member.isEarlyMember && (
                  <span className="flex items-center gap-1 font-mono text-[10px] px-1.5 py-0.5 bg-blue-500/20 text-blue-400 border border-blue-500/30">
                    <Star className="w-2.5 h-2.5" /> Early
                  </span>
                )}
                {member.role === "member" && (
                  <span className="flex items-center gap-1 font-mono text-[10px] px-1.5 py-0.5 bg-white/5 text-white/40 border border-white/10">
                    <Shield className="w-2.5 h-2.5" /> Member
                  </span>
                )}
              </div>
              <p className="font-mono text-xs text-white/40">@{member.usertag}</p>
              <p className="font-mono text-[10px] text-white/20">
                Joined {format(new Date(member.joinedAt), "MMM dd, yyyy")} · #{member.id.toString().padStart(6, "0")}
              </p>
            </div>
            <button
              onClick={() => setLocation(`/profile/${member.usertag}`)}
              className="font-mono text-xs text-white/40 hover:text-white/70 border border-white/10 hover:border-white/30 px-3 py-1.5 transition-colors uppercase tracking-widest"
            >
              Profile
            </button>
          </div>

          {/* Room list */}
          <div>
            <h3 className="font-mono text-xs text-white/30 uppercase tracking-widest mb-3">Chat Rooms</h3>
            <div className="space-y-px">
              {rooms.map((room) => (
                <button
                  key={room.slug}
                  onClick={() => setLocation("/chat")}
                  className="w-full flex items-center gap-4 p-4 border border-white/8 hover:border-white/20 hover:bg-white/3 transition-all text-left group"
                  style={{ background: "#0d0d0d", borderColor: "rgba(255,255,255,0.07)" }}
                >
                  <div
                    className="w-10 h-10 flex items-center justify-center flex-shrink-0"
                    style={{ background: room.ownerOnlyPost ? "rgba(245,158,11,0.15)" : "rgba(255,255,255,0.05)", borderRadius: 4 }}
                  >
                    {room.ownerOnlyPost
                      ? <Megaphone className="w-5 h-5 text-amber-400" />
                      : <MessageSquare className="w-5 h-5 text-white/30" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm text-white group-hover:text-white font-medium">{room.name}</span>
                      {room.ownerOnlyPost && (
                        <span className="font-mono text-[9px] text-amber-400 border border-amber-400/30 px-1">Announcement</span>
                      )}
                    </div>
                    {room.description && (
                      <p className="font-mono text-xs text-white/30 truncate mt-0.5">{room.description}</p>
                    )}
                  </div>
                  <span className="font-mono text-xs text-white/30 flex-shrink-0 group-hover:text-white/60 transition-colors">
                    Enter →
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
