import React, { createContext, useContext, useState, useEffect } from 'react';

type AuthContextType = {
  token: string | null;
  setToken: (token: string | null) => void;
  adminSecret: string | null;
  setAdminSecret: (secret: string | null) => void;
};

const AuthContext = createContext<AuthContextType>({
  token: null,
  setToken: () => {},
  adminSecret: null,
  setAdminSecret: () => {},
});

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [token, setTokenState] = useState<string | null>(localStorage.getItem('dollars_token'));
  const [adminSecret, setAdminSecretState] = useState<string | null>(sessionStorage.getItem('dollars_admin'));

  const setToken = (t: string | null) => {
    if (t) {
      localStorage.setItem('dollars_token', t);
    } else {
      localStorage.removeItem('dollars_token');
    }
    setTokenState(t);
  };

  const setAdminSecret = (s: string | null) => {
    if (s) {
      sessionStorage.setItem('dollars_admin', s);
    } else {
      sessionStorage.removeItem('dollars_admin');
    }
    setAdminSecretState(s);
  };

  return (
    <AuthContext.Provider value={{ token, setToken, adminSecret, setAdminSecret }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
