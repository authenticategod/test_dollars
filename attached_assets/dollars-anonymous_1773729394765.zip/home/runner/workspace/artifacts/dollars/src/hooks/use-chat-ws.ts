import { useEffect, useRef, useCallback, useState } from "react";

export type WSMember = {
  id: number;
  usertag: string;
  displayName: string;
  avatarUrl: string | null;
  role: "owner" | "member";
  isEarlyMember: boolean;
};

export type WSReaction = {
  emoji: string;
  count: number;
  memberIds: number[];
};

export type WSMessage = {
  id: number;
  roomSlug: string;
  content: string;
  type: "text" | "sticker" | "system";
  member: WSMember;
  replyTo: {
    id: number;
    content: string;
    member: WSMember;
  } | null;
  reactions: WSReaction[];
  createdAt: string;
};

type WSSend =
  | { type: "join_room"; slug: string }
  | { type: "send_message"; roomSlug: string; content: string; msgType?: string; replyToId?: number }
  | { type: "typing"; roomSlug: string }
  | { type: "add_reaction"; messageId: number; emoji: string }
  | { type: "remove_reaction"; messageId: number; emoji: string };

export type ChatHookResult = {
  connected: boolean;
  online: WSMember[];
  typingUsers: string[];
  sendEvent: (event: WSSend) => void;
};

export function useChatWS(
  token: string | null,
  onMessage: (msg: WSMessage) => void,
  onReactionUpdate: (messageId: number, reactions: WSReaction[]) => void,
  onPresence: (online: WSMember[]) => void
): ChatHookResult {
  const wsRef = useRef<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [online, setOnline] = useState<WSMember[]>([]);
  const [typingUsers, setTypingUsers] = useState<string[]>([]);
  const typingTimers = useRef<Map<string, ReturnType<typeof setTimeout>>>(new Map());

  const sendEvent = useCallback((event: WSSend) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(event));
    }
  }, []);

  useEffect(() => {
    if (!token) return;

    const proto = window.location.protocol === "https:" ? "wss" : "ws";
    const host = window.location.host;
    const url = `${proto}://${host}/api/ws?token=${encodeURIComponent(token)}`;

    const ws = new WebSocket(url);
    wsRef.current = ws;

    ws.onopen = () => setConnected(true);
    ws.onclose = () => {
      setConnected(false);
      setOnline([]);
    };
    ws.onerror = () => {
      setConnected(false);
    };

    ws.onmessage = (evt) => {
      let data: { type: string; [k: string]: unknown };
      try {
        data = JSON.parse(evt.data as string);
      } catch {
        return;
      }

      switch (data.type) {
        case "message":
          onMessage(data.message as WSMessage);
          break;
        case "reaction_update":
          onReactionUpdate(data.messageId as number, data.reactions as WSReaction[]);
          break;
        case "presence": {
          const members = data.online as WSMember[];
          setOnline(members);
          onPresence(members);
          break;
        }
        case "typing": {
          const usertag = data.usertag as string;
          setTypingUsers((prev) => {
            if (prev.includes(usertag)) return prev;
            return [...prev, usertag];
          });
          const prev = typingTimers.current.get(usertag);
          if (prev) clearTimeout(prev);
          typingTimers.current.set(
            usertag,
            setTimeout(() => {
              setTypingUsers((u) => u.filter((x) => x !== usertag));
              typingTimers.current.delete(usertag);
            }, 3000)
          );
          break;
        }
      }
    };

    return () => {
      ws.close();
      wsRef.current = null;
    };
  }, [token, onMessage, onReactionUpdate, onPresence]);

  return { connected, online, typingUsers, sendEvent };
}
