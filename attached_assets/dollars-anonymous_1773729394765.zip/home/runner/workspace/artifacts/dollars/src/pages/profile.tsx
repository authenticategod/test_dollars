import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Crown, Star, Shield, ChevronLeft, Edit2, Check, X, MessageSquare, Calendar } from "lucide-react";
import { format } from "date-fns";
import { useGetMemberProfile, useGetMe, useUpdateProfile, getGetMeQueryKey, getGetMemberProfileQueryKey } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/auth-context";
import { useQueryClient } from "@tanstack/react-query";
import { AnimatedEmoji } from "@/components/animated-emoji";

function RoleBadge({ role, isEarlyMember, size = "md" }: { role: string; isEarlyMember: boolean; size?: "sm" | "md" }) {
  const cls = size === "sm" ? "w-4 h-4" : "w-5 h-5";
  if (role === "owner") return (
    <span className="flex items-center gap-1.5 font-mono text-xs text-amber-500 border border-amber-500/30 bg-amber-500/10 px-2 py-0.5">
      <Crown className={cls} /> Owner
    </span>
  );
  if (isEarlyMember) return (
    <span className="flex items-center gap-1.5 font-mono text-xs text-blue-400 border border-blue-400/30 bg-blue-400/10 px-2 py-0.5">
      <Star className={cls} /> Early Member
    </span>
  );
  return (
    <span className="flex items-center gap-1.5 font-mono text-xs text-primary/60 border border-border/50 bg-secondary/50 px-2 py-0.5">
      <Shield className={cls} /> Member
    </span>
  );
}

export default function Profile() {
  const params = useParams<{ usertag: string }>();
  const [, setLocation] = useLocation();
  const { token } = useAuth();
  const qc = useQueryClient();

  const usertag = params.usertag?.toLowerCase() ?? "";

  const sessionHeaders = { headers: { "X-Session-Token": token || "" } };

  const { data: me } = useGetMe({
    request: sessionHeaders,
    query: { queryKey: getGetMeQueryKey(), enabled: !!token },
  });

  const { data: profile, isLoading, isError } = useGetMemberProfile(usertag, {
    query: { queryKey: getGetMemberProfileQueryKey(usertag), enabled: !!usertag },
    request: {},
  });

  const isOwn = !!me && !!profile && me.usertag === profile.usertag;

  const [editing, setEditing] = useState(false);
  const [draftName, setDraftName] = useState("");
  const [draftBio, setDraftBio] = useState("");
  const [draftAvatar, setDraftAvatar] = useState("");
  const [saveError, setSaveError] = useState("");

  const { mutateAsync: updateProfile, isPending: saving } = useUpdateProfile({
    request: sessionHeaders,
  });

  useEffect(() => {
    if (profile && isOwn) {
      setDraftName(profile.displayName);
      setDraftBio(profile.bio ?? "");
      setDraftAvatar(profile.avatarUrl ?? "");
    }
  }, [profile, isOwn]);

  const startEdit = () => {
    setSaveError("");
    setEditing(true);
  };

  const cancelEdit = () => {
    setEditing(false);
    setSaveError("");
    if (profile) {
      setDraftName(profile.displayName);
      setDraftBio(profile.bio ?? "");
      setDraftAvatar(profile.avatarUrl ?? "");
    }
  };

  const saveEdit = async () => {
    setSaveError("");
    try {
      await updateProfile({
        data: {
          displayName: draftName.trim() || undefined,
          bio: draftBio.trim() || null,
          avatarUrl: draftAvatar.trim() || null,
        },
      });
      await qc.invalidateQueries({ queryKey: getGetMeQueryKey() });
      setEditing(false);
    } catch {
      setSaveError("Failed to save. Try again.");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="font-mono text-xs text-muted-foreground/60 animate-pulse tracking-widest uppercase">
          Loading profile…
        </div>
      </div>
    );
  }

  if (isError || !profile) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4">
        <AnimatedEmoji emoji="👤" size={64} autoPlay />
        <p className="font-mono text-sm text-muted-foreground/60">Member not found.</p>
        <button onClick={() => setLocation(-1 as never)} className="font-mono text-xs text-primary hover:underline">
          Go back
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Back bar */}
      <div className="h-12 flex items-center gap-3 px-4 border-b border-border/50 bg-background/50 backdrop-blur-sm sticky top-0 z-10">
        <button
          onClick={() => setLocation(-1 as never)}
          className="text-muted-foreground hover:text-foreground transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <span className="font-mono text-sm text-muted-foreground/60">@{profile.usertag}</span>
      </div>

      <div className="max-w-lg mx-auto px-4 py-10">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          {/* Avatar + name */}
          <div className="flex items-start gap-4">
            <div className="w-20 h-20 flex-shrink-0 bg-secondary border border-border flex items-center justify-center text-3xl font-mono font-bold text-primary overflow-hidden">
              {editing ? (
                draftAvatar ? (
                  <img src={draftAvatar} alt="" className="w-full h-full object-cover" />
                ) : (
                  profile.usertag.charAt(0).toUpperCase()
                )
              ) : profile.avatarUrl ? (
                <img src={profile.avatarUrl} alt="" className="w-full h-full object-cover" />
              ) : (
                profile.usertag.charAt(0).toUpperCase()
              )}
            </div>

            <div className="flex-1 space-y-2">
              {editing ? (
                <input
                  value={draftName}
                  onChange={(e) => setDraftName(e.target.value)}
                  maxLength={50}
                  placeholder="Display name"
                  className="w-full bg-secondary border border-border px-3 py-1.5 font-mono text-sm text-foreground focus:outline-none focus:border-primary/50"
                />
              ) : (
                <h1 className="font-mono text-xl font-bold text-foreground">{profile.displayName}</h1>
              )}
              <p className="font-mono text-xs text-primary/70">@{profile.usertag}</p>
              <RoleBadge role={profile.role} isEarlyMember={profile.isEarlyMember} />
            </div>

            {isOwn && !editing && (
              <button
                onClick={startEdit}
                className="flex items-center gap-1.5 font-mono text-xs text-muted-foreground hover:text-foreground border border-border/50 hover:border-border px-3 py-1.5 transition-colors"
              >
                <Edit2 className="w-3.5 h-3.5" />
                Edit
              </button>
            )}
          </div>

          {/* Avatar URL input (editing only) */}
          {editing && (
            <div>
              <label className="font-mono text-[10px] text-muted-foreground/60 uppercase tracking-wider">
                Avatar URL
              </label>
              <input
                value={draftAvatar}
                onChange={(e) => setDraftAvatar(e.target.value)}
                placeholder="https://example.com/avatar.png"
                className="w-full mt-1 bg-secondary border border-border px-3 py-1.5 font-mono text-xs text-foreground focus:outline-none focus:border-primary/50"
              />
            </div>
          )}

          {/* Bio */}
          <div>
            <p className="font-mono text-[10px] uppercase tracking-widest text-muted-foreground/40 mb-1">Bio</p>
            {editing ? (
              <textarea
                value={draftBio}
                onChange={(e) => setDraftBio(e.target.value)}
                maxLength={160}
                rows={3}
                placeholder="Write something about yourself… (160 chars max)"
                className="w-full bg-secondary border border-border px-3 py-2 font-mono text-sm text-foreground focus:outline-none focus:border-primary/50 resize-none"
              />
            ) : profile.bio ? (
              <p className="text-sm text-muted-foreground leading-relaxed">{profile.bio}</p>
            ) : (
              <p className="text-sm text-muted-foreground/30 italic font-mono">No bio yet.</p>
            )}
            {editing && (
              <p className="font-mono text-[10px] text-muted-foreground/40 mt-1 text-right">{draftBio.length}/160</p>
            )}
          </div>

          {/* Save/cancel */}
          {editing && (
            <div className="flex items-center gap-2">
              <button
                onClick={saveEdit}
                disabled={saving}
                className="flex items-center gap-1.5 font-mono text-xs bg-primary text-primary-foreground px-4 py-1.5 hover:bg-primary/90 transition-colors disabled:opacity-50"
              >
                <Check className="w-3.5 h-3.5" />
                {saving ? "Saving…" : "Save"}
              </button>
              <button
                onClick={cancelEdit}
                className="flex items-center gap-1.5 font-mono text-xs text-muted-foreground border border-border/50 px-4 py-1.5 hover:text-foreground transition-colors"
              >
                <X className="w-3.5 h-3.5" />
                Cancel
              </button>
              {saveError && <p className="font-mono text-xs text-destructive">{saveError}</p>}
            </div>
          )}

          {/* Stats */}
          <div className="grid grid-cols-2 gap-px border border-border/50 bg-border/20">
            <div className="bg-background px-4 py-3 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-muted-foreground/40" />
              <div>
                <p className="font-mono text-lg font-bold text-foreground">{(profile as { messageCount?: number }).messageCount ?? 0}</p>
                <p className="font-mono text-[10px] text-muted-foreground/50 uppercase">Messages</p>
              </div>
            </div>
            <div className="bg-background px-4 py-3 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-muted-foreground/40" />
              <div>
                <p className="font-mono text-sm font-bold text-foreground">
                  {format(new Date(profile.joinedAt), "MMM d, yyyy")}
                </p>
                <p className="font-mono text-[10px] text-muted-foreground/50 uppercase">Joined</p>
              </div>
            </div>
          </div>

          {/* Role description */}
          <div className="border border-border/30 bg-secondary/20 px-4 py-3">
            {profile.role === "owner" ? (
              <p className="font-mono text-xs text-amber-500/70">
                ★ Owner — The one who holds the Dollars together from the shadows.
              </p>
            ) : profile.isEarlyMember ? (
              <p className="font-mono text-xs text-blue-400/70">
                ★ Early Member — Was here when the signal was just a whisper.
              </p>
            ) : (
              <p className="font-mono text-xs text-muted-foreground/50">
                Colorless. Formless. Just another face in the Dollars.
              </p>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
