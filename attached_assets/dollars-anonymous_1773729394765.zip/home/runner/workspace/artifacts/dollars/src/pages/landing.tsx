import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/auth-context";

export default function Landing() {
  const [, setLocation] = useLocation();
  const { token } = useAuth();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("code");
    if (token) {
      setLocation("/lobby");
    } else if (code) {
      setLocation(`/join?code=${encodeURIComponent(code)}`);
    } else {
      setLocation("/join");
    }
  }, [token, setLocation]);

  return null;
}
