export type StickerEffect =
  | "none"
  | "confetti"
  | "hearts"
  | "sparkle"
  | "flames"
  | "glitch"
  | "snow"
  | "matrix";

export type Sticker = {
  id: string;
  label: string;
  emoji: string;
  description: string;
  effect: StickerEffect;
  premium?: boolean;
};

export type StickerPack = {
  id: string;
  name: string;
  icon: string;
  stickers: Sticker[];
};

export const STICKER_PACKS: StickerPack[] = [
  {
    id: "dollars",
    name: "Dollars",
    icon: "💲",
    stickers: [
      { id: "dollars-mark", label: "Dollars Mark", emoji: "💲", description: "The mark of the Dollars", effect: "confetti" },
      { id: "anonymous", label: "Anonymous", emoji: "👤", description: "Faceless entity", effect: "sparkle" },
      { id: "night-city", label: "Night City", emoji: "🌃", description: "Ikebukuro at midnight", effect: "none" },
      { id: "celty", label: "Shadow Rider", emoji: "🏍️", description: "Shadow on the highway", effect: "flames" },
      { id: "phone", label: "Encrypted", emoji: "📱", description: "Untraceable signal", effect: "none" },
      { id: "eye", label: "Watching", emoji: "👁️", description: "They see everything", effect: "sparkle" },
      { id: "ghost", label: "Ghost Protocol", emoji: "👻", description: "You were never here", effect: "none" },
      { id: "katana", label: "Durarara", emoji: "⚔️", description: "Old ways, new city", effect: "none" },
      { id: "chat", label: "Signal", emoji: "💬", description: "Secure channel open", effect: "none" },
      { id: "crown", label: "Crown", emoji: "👑", description: "All hail the Dollars", effect: "confetti" },
      { id: "skull", label: "Memento Mori", emoji: "💀", description: "Colorless, formless", effect: "none" },
      { id: "shrug", label: "Unknown", emoji: "🤷", description: "Could be anyone", effect: "none" },
    ],
  },
  {
    id: "shadow",
    name: "Shadow Protocol",
    icon: "🌑",
    stickers: [
      { id: "shadow-moon", label: "Eclipse", emoji: "🌑", description: "Darkness falls", effect: "sparkle", premium: true },
      { id: "shadow-snake", label: "Serpent", emoji: "🐍", description: "Silent and lethal", effect: "glitch", premium: true },
      { id: "shadow-black-cat", label: "Black Cat", emoji: "🐈‍⬛", description: "Bad omen", effect: "glitch", premium: true },
      { id: "shadow-thunder", label: "Thunder", emoji: "⚡", description: "Strike fast", effect: "sparkle", premium: true },
      { id: "shadow-magic", label: "Hex", emoji: "🔮", description: "See the future", effect: "sparkle", premium: true },
      { id: "shadow-mask", label: "Masquerade", emoji: "🎭", description: "Who are you really?", effect: "glitch", premium: true },
      { id: "shadow-spider", label: "Web", emoji: "🕷️", description: "Caught in the web", effect: "matrix", premium: true },
      { id: "shadow-lock", label: "Sealed", emoji: "🔒", description: "You cannot enter", effect: "none", premium: true },
      { id: "shadow-virus", label: "Virus", emoji: "☣️", description: "Corrupted", effect: "matrix", premium: true },
      { id: "shadow-void", label: "Void", emoji: "🕳️", description: "Into the abyss", effect: "glitch", premium: true },
    ],
  },
  {
    id: "night-rider",
    name: "Night Rider",
    icon: "🌆",
    stickers: [
      { id: "rider-car", label: "Midnight Run", emoji: "🚗", description: "Racing into the dark", effect: "flames", premium: true },
      { id: "rider-city", label: "Skyline", emoji: "🌆", description: "The city never sleeps", effect: "confetti", premium: true },
      { id: "rider-star", label: "Star Crossed", emoji: "⭐", description: "Written in stars", effect: "sparkle", premium: true },
      { id: "rider-rocket", label: "Launch", emoji: "🚀", description: "Break orbit", effect: "flames", premium: true },
      { id: "rider-explosion", label: "Boom", emoji: "💥", description: "Direct hit", effect: "confetti", premium: true },
      { id: "rider-trophy", label: "Champion", emoji: "🏆", description: "Dollars forever", effect: "confetti", premium: true },
      { id: "rider-dice", label: "Roll the Dice", emoji: "🎲", description: "Luck is on our side", effect: "confetti", premium: true },
      { id: "rider-heart-fire", label: "Passion", emoji: "❤️‍🔥", description: "Fire in the heart", effect: "hearts", premium: true },
      { id: "rider-comet", label: "Comet", emoji: "☄️", description: "Unstoppable force", effect: "flames", premium: true },
      { id: "rider-lightning", label: "Blitz", emoji: "🌩️", description: "Storm is coming", effect: "sparkle", premium: true },
    ],
  },
  {
    id: "feelings",
    name: "Feelings",
    icon: "💞",
    stickers: [
      { id: "feel-love", label: "Love", emoji: "❤️", description: "Heart full", effect: "hearts" },
      { id: "feel-party", label: "Celebrate", emoji: "🎉", description: "Let's gooo!", effect: "confetti" },
      { id: "feel-fire", label: "Fire", emoji: "🔥", description: "Too hot", effect: "flames" },
      { id: "feel-100", label: "Perfect", emoji: "💯", description: "No cap", effect: "confetti" },
      { id: "feel-cry-laugh", label: "Dead", emoji: "😭", description: "I'm crying", effect: "none" },
      { id: "feel-shock", label: "No way", emoji: "😱", description: "Absolutely not", effect: "sparkle" },
      { id: "feel-pensive", label: "Thinking", emoji: "🤔", description: "Hmm...", effect: "none" },
      { id: "feel-salute", label: "Respect", emoji: "🫡", description: "Yes sir", effect: "none" },
      { id: "feel-clap", label: "Applause", emoji: "👏", description: "Well done", effect: "confetti" },
      { id: "feel-cool", label: "Cool", emoji: "😎", description: "Effortlessly", effect: "sparkle" },
      { id: "feel-snow", label: "Chill", emoji: "❄️", description: "Ice cold", effect: "snow" },
      { id: "feel-rainbow", label: "Rainbow", emoji: "🌈", description: "Good vibes", effect: "confetti" },
    ],
  },
];

export const DOLLARS_STICKERS = STICKER_PACKS[0].stickers;

export function getStickerById(id: string): Sticker | undefined {
  for (const pack of STICKER_PACKS) {
    const s = pack.stickers.find((s) => s.id === id);
    if (s) return s;
  }
  return undefined;
}

export function getStickerByEmoji(emoji: string): Sticker | undefined {
  for (const pack of STICKER_PACKS) {
    const s = pack.stickers.find((s) => s.emoji === emoji);
    if (s) return s;
  }
  return undefined;
}
