import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Check, X, Loader2, Copy, CheckCheck, KeyRound } from "lucide-react";
import {
  useCheckUsertag,
  useJoinDollars,
  useLoginWithPassphrase,
  getCheckUsertagQueryKey,
} from "@workspace/api-client-react";
import type { JoinDollarsMutationError } from "@workspace/api-client-react";
import { useAuth } from "@/contexts/auth-context";

type Mode = "join" | "login";

const PIXEL_COLORS = [
  "#ff4d6d","#ff6b35","#ffca3a","#8ac926","#1982c4",
  "#6a4c93","#ff595e","#ffca3a","#6a4c93","#43aa8b",
  "#f72585","#4cc9f0","#7209b7","#560bad","#480ca8",
  "#3a0ca3","#3f37c9","#4361ee","#4895ef","#4cc9f0",
];

const LETTERS: Record<string, number[][]> = {
  D: [[1,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[1,1,1,0]],
  O: [[0,1,1,0],[1,0,0,1],[1,0,0,1],[1,0,0,1],[0,1,1,0]],
  L: [[1,0,0,0],[1,0,0,0],[1,0,0,0],[1,0,0,0],[1,1,1,1]],
  A: [[0,1,1,0],[1,0,0,1],[1,1,1,1],[1,0,0,1],[1,0,0,1]],
  R: [[1,1,1,0],[1,0,0,1],[1,1,1,0],[1,0,1,0],[1,0,0,1]],
  S: [[0,1,1,1],[1,0,0,0],[0,1,1,0],[0,0,0,1],[1,1,1,0]],
};

function PixelDollarsLogo() {
  const word = ["D","O","L","L","A","R","S"];
  const dotSize = 9;
  const gap = 3;
  const letterGap = 5;
  const rows = 5;
  const cols = 4;
  const cell = dotSize + gap;
  const totalW = word.length * (cols * cell + letterGap) - letterGap;
  const totalH = rows * cell;

  let colorIdx = 0;

  return (
    <svg
      width={totalW}
      height={totalH}
      viewBox={`0 0 ${totalW} ${totalH}`}
      style={{ display: "block", overflow: "visible" }}
    >
      <defs>
        <filter id="led-glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur in="SourceGraphic" stdDeviation="2.5" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      <g filter="url(#led-glow)">
        {word.map((letter, li) => {
          const pixels = LETTERS[letter] || [];
          const offsetX = li * (cols * cell + letterGap);
          return pixels.map((row, ri) =>
            row.map((active, ci) => {
              if (!active) return null;
              const color = PIXEL_COLORS[colorIdx++ % PIXEL_COLORS.length];
              const cx = offsetX + ci * cell + dotSize / 2;
              const cy = ri * cell + dotSize / 2;
              return (
                <circle
                  key={`${li}-${ri}-${ci}`}
                  cx={cx}
                  cy={cy}
                  r={dotSize / 2}
                  fill={color}
                />
              );
            })
          );
        })}
      </g>
    </svg>
  );
}

function DollarsCircleLogo() {
  const dotSize = 9;
  const gap = 3;
  const letterGap = 5;
  const cols = 4;
  const rows = 5;
  const cell = dotSize + gap;
  const svgW = 7 * (cols * cell + letterGap) - letterGap;
  const svgH = rows * cell;

  const circleSize = Math.max(svgW + 80, 260);

  return (
    <div className="flex flex-col items-center gap-3 mb-6 select-none">
      <div
        className="relative flex items-center justify-center"
        style={{
          width: circleSize,
          height: circleSize,
          borderRadius: "50%",
          background: "#000",
          border: "14px solid #fff",
          boxShadow: "0 0 0 2px #000, 0 0 60px rgba(255,255,255,0.06)",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 10,
            borderRadius: "50%",
            border: "1.5px solid rgba(255,255,255,0.18)",
            pointerEvents: "none",
          }}
        />
        <div style={{ position: "relative", width: svgW, height: svgH }}>
          <PixelDollarsLogo />
        </div>
      </div>
    </div>
  );
}

export default function Join() {
  const [, setLocation] = useLocation();
  const { setToken } = useAuth();

  const [mode, setMode] = useState<Mode>("join");
  const [phase, setPhase] = useState<"form" | "loading" | "passphrase" | "error">("form");

  const [inviteCode, setInviteCode] = useState("");
  const [usertag, setUsertag] = useState("");
  const [debouncedTag, setDebouncedTag] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [joinError, setJoinError] = useState<string | null>(null);
  const [passphrase, setPassphrase] = useState("");
  const [passphraseCopied, setPassphraseCopied] = useState(false);

  const [loginUsertag, setLoginUsertag] = useState("");
  const [loginPassphrase, setLoginPassphrase] = useState("");
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);

  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    if (p.get("code")) setInviteCode(p.get("code")!);
    if (p.get("action") === "login") setMode("login");
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedTag(usertag), 500);
    return () => clearTimeout(t);
  }, [usertag]);

  const { data: tagCheck, isLoading: isChecking } = useCheckUsertag(
    { tag: debouncedTag, code: inviteCode || undefined },
    {
      query: {
        queryKey: getCheckUsertagQueryKey({ tag: debouncedTag, code: inviteCode || undefined }),
        enabled: debouncedTag.length >= 4 && mode === "join",
        retry: false,
      },
    }
  );

  const effectiveMinLength = tagCheck?.minLength ?? 5;
  const isTagValid = debouncedTag.length >= effectiveMinLength && !!tagCheck?.available && !!tagCheck?.valid;

  const joinMutation = useJoinDollars({
    mutation: {
      onSuccess: (data) => {
        setToken(data.token);
        if (data.passphrase) { setPassphrase(data.passphrase); setPhase("passphrase"); }
        else setLocation("/lobby");
      },
      onError: (error: JoinDollarsMutationError) => {
        setJoinError(error?.data?.error || error?.message || "Access denied.");
        setPhase("error");
      },
    },
  });

  const loginMutation = useLoginWithPassphrase({
    mutation: {
      onSuccess: (data) => { setToken(data.token); setLocation("/lobby"); },
      onError: (err: { data?: { error?: string }; message?: string }) => {
        setLoginLoading(false);
        setLoginError(err?.data?.error || err?.message || "Invalid handle or passphrase.");
      },
    },
  });

  const submitJoin = () => {
    if (!inviteCode || !isTagValid || displayName.length < 2) return;
    setPhase("loading");
    joinMutation.mutate({ data: { inviteCode, usertag: usertag.toLowerCase(), displayName, avatarUrl: avatarUrl.trim() || null } });
  };

  const submitLogin = () => {
    if (!loginUsertag || !loginPassphrase) return;
    setLoginError(null);
    setLoginLoading(true);
    loginMutation.mutate({ data: { usertag: loginUsertag.toLowerCase().trim(), passphrase: loginPassphrase.trim() } });
  };

  const copyPassphrase = useCallback(() => {
    navigator.clipboard.writeText(passphrase).then(() => {
      setPassphraseCopied(true);
      setTimeout(() => setPassphraseCopied(false), 2000);
    });
  }, [passphrase]);

  const switchMode = (m: Mode) => {
    setMode(m); setPhase("form"); setJoinError(null); setLoginError(null); setLoginLoading(false);
  };

  const inputCls = "w-full bg-transparent border border-white/25 px-3 py-2 text-white font-mono text-sm placeholder:text-white/20 focus:outline-none focus:border-white/60 rounded-none";

  return (
    <div className="flex-1 flex items-center justify-center p-4 bg-black min-h-0 overflow-auto">
      <div className="w-full max-w-xs flex flex-col items-center py-6">
        <DollarsCircleLogo />

        <AnimatePresence mode="wait">
          {phase === "loading" && (
            <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center gap-3 py-8">
              <Loader2 className="w-8 h-8 animate-spin text-white/40" />
              <p className="font-mono text-xs text-white/30 tracking-widest">Connecting…</p>
            </motion.div>
          )}

          {phase === "passphrase" && (
            <motion.div key="passphrase" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="w-full space-y-4">
              <p className="font-mono text-xs text-green-400 text-center tracking-widest">ACCESS GRANTED</p>
              <p className="text-white/60 text-sm text-center font-mono">Save your recovery passphrase — shown once only.</p>
              <div className="border border-amber-500/40 bg-amber-500/5 p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <code className="flex-1 font-mono text-sm text-white bg-black/60 px-3 py-2 select-all tracking-wide break-all">{passphrase}</code>
                  <button onClick={copyPassphrase} className="p-2 border border-white/10 hover:border-amber-400/40 text-white/40 hover:text-amber-400 transition-colors">
                    {passphraseCopied ? <CheckCheck className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
              <button onClick={() => setLocation("/lobby")} className="w-full py-2 bg-white text-black font-mono font-bold text-sm uppercase tracking-widest hover:bg-white/90 transition-colors">
                I'VE SAVED IT — ENTER
              </button>
            </motion.div>
          )}

          {phase === "error" && (
            <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="w-full space-y-4">
              <p className="font-mono text-xs text-red-400 border-l-2 border-red-500 pl-3">{joinError}</p>
              <button onClick={() => setPhase("form")} className="w-full py-2 border border-white/20 text-white/60 font-mono text-sm uppercase tracking-widest hover:border-white/40 hover:text-white transition-colors">Try Again</button>
            </motion.div>
          )}

          {phase === "form" && (
            <motion.div key="form" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="w-full space-y-3">
              <div className="flex border border-white/20 mb-4">
                <button onClick={() => switchMode("join")} className={`flex-1 py-1.5 font-mono text-xs uppercase tracking-widest transition-colors ${mode === "join" ? "bg-white text-black font-bold" : "text-white/40 hover:text-white/70"}`}>
                  Join
                </button>
                <button onClick={() => switchMode("login")} className={`flex-1 py-1.5 font-mono text-xs uppercase tracking-widest transition-colors ${mode === "login" ? "bg-white text-black font-bold" : "text-white/40 hover:text-white/70"}`}>
                  Sign In
                </button>
              </div>

              <AnimatePresence mode="wait">
                {mode === "join" && (
                  <motion.div key="join-fields" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-2">
                    <input value={inviteCode} onChange={(e) => setInviteCode(e.target.value)} placeholder="Invite Code" className={inputCls} autoFocus />
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono text-white/30 text-sm">@</span>
                      <input value={usertag} onChange={(e) => setUsertag(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))} placeholder="handle" className={`${inputCls} pl-7 pr-8`} />
                      <div className="absolute right-3 top-1/2 -translate-y-1/2">
                        {isChecking && <Loader2 className="w-3.5 h-3.5 animate-spin text-white/30" />}
                        {!isChecking && debouncedTag.length >= 4 && isTagValid && <Check className="w-3.5 h-3.5 text-green-400" />}
                        {!isChecking && debouncedTag.length >= 4 && tagCheck && !isTagValid && <X className="w-3.5 h-3.5 text-red-400" />}
                      </div>
                    </div>
                    {debouncedTag.length >= 4 && !isChecking && tagCheck && !isTagValid && (
                      <p className="font-mono text-[10px] text-red-400/80 px-1">{tagCheck.reason || "Handle unavailable."}</p>
                    )}
                    <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} placeholder="Display Name" className={inputCls} />
                    <input value={avatarUrl} onChange={(e) => setAvatarUrl(e.target.value)} placeholder="Avatar URL (optional)" className={inputCls} />
                  </motion.div>
                )}

                {mode === "login" && (
                  <motion.div key="login-fields" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-2">
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 font-mono text-white/30 text-sm">@</span>
                      <input value={loginUsertag} onChange={(e) => setLoginUsertag(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ""))} placeholder="handle" className={`${inputCls} pl-7`} autoFocus onKeyDown={(e) => e.key === "Enter" && loginPassphrase && submitLogin()} />
                    </div>
                    <div className="relative">
                      <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
                      <input value={loginPassphrase} onChange={(e) => setLoginPassphrase(e.target.value)} placeholder="word-word-word-1234" className={`${inputCls} pl-9`} onKeyDown={(e) => e.key === "Enter" && loginUsertag && submitLogin()} />
                    </div>
                    {loginError && <p className="font-mono text-[10px] text-red-400/80 border-l-2 border-red-500 pl-2">{loginError}</p>}
                  </motion.div>
                )}
              </AnimatePresence>

              <button
                onClick={mode === "join" ? submitJoin : submitLogin}
                disabled={mode === "join" ? (!inviteCode || !isTagValid || displayName.length < 2) : (!loginUsertag || !loginPassphrase || loginLoading)}
                className="w-full py-2.5 mt-2 font-mono font-bold text-sm uppercase tracking-widest transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                style={{ background: "linear-gradient(180deg,#e8e8e8 0%,#c8c8c8 100%)", color: "#000", border: "1px solid rgba(255,255,255,0.4)" }}
              >
                {loginLoading ? <span className="flex items-center justify-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> Connecting</span> : "ENTER"}
              </button>

              <div className="flex items-center justify-center gap-3 pt-1">
                <button className="font-mono text-xs text-white/35 hover:text-white/65 transition-colors">Settings</button>
                <span className="text-white/15">-</span>
                <button className="font-mono text-xs text-white/35 hover:text-white/65 transition-colors">FAQ</button>
                <span className="text-white/15">-</span>
                <button className="font-mono text-xs text-white/35 hover:text-white/65 transition-colors">Rules</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
