const EMOJI_REGEX =
  /(\p{Emoji_Presentation}|\p{Extended_Pictographic})(\u200D(\p{Emoji_Presentation}|\p{Extended_Pictographic})|\uFE0F|\u20E3|\p{Emoji_Modifier})*/gu;

export function getEmojiList(text: string): string[] {
  return text.match(EMOJI_REGEX) ?? [];
}

export function isOnlyEmoji(text: string): boolean {
  const stripped = text.replace(EMOJI_REGEX, "").trim();
  return stripped.length === 0 && getEmojiList(text).length > 0;
}

export function getEmojiCount(text: string): number {
  return getEmojiList(text).length;
}

export function isBigEmoji(text: string): boolean {
  return isOnlyEmoji(text) && getEmojiCount(text) <= 3;
}

export function getAnimatedEmojiUrl(emoji: string): string {
  const codepoints = [...emoji]
    .map((c) => c.codePointAt(0)!.toString(16))
    .filter((cp) => cp !== "fe0f" && cp !== "200d")
    .join("_");
  return `https://fonts.gstatic.com/s/e/notoemoji/latest/${codepoints}/512.webp`;
}

export function getAnimatedEmojiUrlSmall(emoji: string): string {
  const codepoints = [...emoji]
    .map((c) => c.codePointAt(0)!.toString(16))
    .filter((cp) => cp !== "fe0f" && cp !== "200d")
    .join("_");
  return `https://fonts.gstatic.com/s/e/notoemoji/latest/${codepoints}/128.webp`;
}
