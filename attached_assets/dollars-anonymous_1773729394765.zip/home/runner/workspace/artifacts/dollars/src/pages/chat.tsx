import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { format } from "date-fns";
import {
  Megaphone, Send, Smile, Sticker, CornerUpLeft, X,
  Crown, Star, Shield, Mic, Music, Settings, Users, Wifi, WifiOff,
} from "lucide-react";
import {
  useListRooms, useGetRoomHistory, useGetMe,
  getGetMeQueryKey, getListRoomsQueryKey, getGetRoomHistoryQueryKey,
} from "@workspace/api-client-react";
import { useAuth } from "@/contexts/auth-context";
import { useChatWS, type WSMessage, type WSMember, type WSReaction } from "@/hooks/use-chat-ws";
import { STICKER_PACKS, getStickerByEmoji } from "@/lib/stickers";
import { playNotificationSound } from "@/lib/notification-sound";
import { isBigEmoji, getEmojiList } from "@/lib/emoji-utils";
import { AnimatedEmoji, InlineAnimatedEmoji } from "@/components/animated-emoji";
import { InlineStickerEffect } from "@/components/sticker-effect";

const MEMBER_COLORS = [
  "#d6538a",
  "#3da85c",
  "#c04545",
  "#4a7fd4",
  "#9855d4",
  "#d4844a",
  "#3aa8b0",
  "#8a6bbf",
];

function getMemberColor(id: number): string {
  return MEMBER_COLORS[id % MEMBER_COLORS.length];
}

function MemberBadgeIcon({ member, size = "sm" }: { member: WSMember; size?: "sm" | "xs" }) {
  const s = size === "xs" ? "w-3 h-3" : "w-3.5 h-3.5";
  if (member.role === "owner") return <Crown className={`${s} text-amber-400 flex-shrink-0`} />;
  if (member.isEarlyMember) return <Star className={`${s} text-blue-400 flex-shrink-0`} />;
  return null;
}

function BigAvatar({ member, size = 58 }: { member: WSMember; size?: number }) {
  const color = getMemberColor(member.id);
  return (
    <div
      className="flex-shrink-0 flex items-center justify-center font-bold text-white overflow-hidden"
      style={{
        width: size,
        height: size,
        background: color,
        fontSize: size * 0.4,
        borderRadius: 6,
        flexShrink: 0,
      }}
    >
      {member.avatarUrl ? (
        <img src={member.avatarUrl} alt="" className="w-full h-full object-cover" />
      ) : (
        member.displayName.charAt(0).toUpperCase()
      )}
    </div>
  );
}

type MessageWithReactions = WSMessage & { reactions: WSReaction[] };

const QUICK_REACTIONS = ["👍", "❤️", "😂", "😮", "🔥", "👀"];

function MessageBubble({
  message,
  currentMemberId,
  onReply,
  onReactionToggle,
}: {
  message: MessageWithReactions;
  currentMemberId: number;
  onReply: (msg: MessageWithReactions) => void;
  onReactionToggle: (messageId: number, emoji: string, hasReacted: boolean) => void;
}) {
  const [, setLocation] = useLocation();
  const isSticker = message.type === "sticker";
  const isSystem = message.type === "system";
  const isBig = !isSticker && isBigEmoji(message.content);
  const stickerDef = isSticker ? getStickerByEmoji(message.content) : undefined;
  const [effectTrigger, setEffectTrigger] = useState(0);
  const [showReactionPicker, setShowReactionPicker] = useState(false);

  useEffect(() => {
    if (!isSticker || !stickerDef?.effect || stickerDef.effect === "none") return;
    const t = setTimeout(() => setEffectTrigger((v) => v + 1), 80);
    return () => clearTimeout(t);
  }, [message.id]);

  if (isSystem) {
    return (
      <div className="flex justify-center py-1 px-4">
        <span className="font-mono text-xs text-white/25 italic">
          — {message.content} —
        </span>
      </div>
    );
  }

  const color = getMemberColor(message.member.id);

  return (
    <motion.div
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      className="group flex items-start gap-0 px-4 py-2"
    >
      {/* Avatar + name column */}
      <div className="flex flex-col items-center gap-1 flex-shrink-0" style={{ width: 74 }}>
        <button onClick={() => setLocation(`/profile/${message.member.usertag}`)}>
          <BigAvatar member={message.member} size={58} />
        </button>
        <div className="flex items-center gap-0.5">
          <span
            className="font-mono text-[10px] truncate text-center leading-tight"
            style={{ color, maxWidth: 68 }}
          >
            {message.member.displayName}
          </span>
          <MemberBadgeIcon member={message.member} size="xs" />
        </div>
      </div>

      {/* Arrow + pill bubble */}
      <div className="flex items-start flex-1 min-w-0 mt-2">
        {/* Left-pointing arrow */}
        <div
          style={{
            width: 0,
            height: 0,
            borderTop: "9px solid transparent",
            borderBottom: "9px solid transparent",
            borderRight: `11px solid ${color}`,
            marginTop: 10,
            flexShrink: 0,
          }}
        />
        {/* Pill bubble */}
        <div className="flex flex-col min-w-0 max-w-[78%]">
          <div
            style={{
              background: color,
              borderRadius: 22,
              padding: "8px 16px",
            }}
          >
            {/* Reply preview */}
            {message.replyTo && (
              <div
                className="text-xs mb-1.5 pl-2 leading-snug"
                style={{ borderLeft: "2px solid rgba(255,255,255,0.4)", color: "rgba(255,255,255,0.75)" }}
              >
                <span className="font-mono text-[10px] opacity-80">↩ {message.replyTo.member.displayName}</span>
                <p className="truncate max-w-48 opacity-75">{message.replyTo.content}</p>
              </div>
            )}

            {isSticker ? (
              <div className="relative py-1 select-none">
                <AnimatedEmoji emoji={message.content} size={72} autoPlay />
                {stickerDef?.premium && (
                  <span className="absolute -top-1 -right-1 text-[9px] font-mono bg-black/30 text-white/80 px-1 rounded-full">★</span>
                )}
                {stickerDef?.effect && stickerDef.effect !== "none" && (
                  <InlineStickerEffect effect={stickerDef.effect} trigger={effectTrigger} />
                )}
              </div>
            ) : isBig ? (
              <div className="flex gap-1 py-1 select-none">
                {getEmojiList(message.content).map((emoji, i) => (
                  <AnimatedEmoji key={i} emoji={emoji} size={56} autoPlay />
                ))}
              </div>
            ) : (
              <p className="text-sm text-white leading-relaxed break-words" style={{ fontFamily: "sans-serif" }}>
                {message.content}
              </p>
            )}

            <div className="flex items-center justify-end mt-0.5">
              <span className="text-[9px] text-white/50 font-mono">
                {format(new Date(message.createdAt), "HH:mm")}
              </span>
            </div>
          </div>

          {/* Reactions */}
          {message.reactions.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-1 ml-1">
              {message.reactions.map((r) => {
                const hasReacted = r.memberIds.includes(currentMemberId);
                return (
                  <button
                    key={r.emoji}
                    onClick={() => onReactionToggle(message.id, r.emoji, hasReacted)}
                    className={`flex items-center gap-1 text-xs px-1.5 py-0.5 transition-colors ${hasReacted ? "bg-white/20 text-white" : "bg-white/8 text-white/60 hover:bg-white/15"}`}
                    style={{ borderRadius: 10, border: hasReacted ? "1px solid rgba(255,255,255,0.4)" : "1px solid rgba(255,255,255,0.12)" }}
                  >
                    <span>{r.emoji}</span>
                    <span className="font-mono">{r.count}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Hover actions */}
        <div className="flex flex-col gap-1 ml-1.5 opacity-0 group-hover:opacity-100 transition-opacity mt-2">
          <div className="relative">
            <button
              onClick={() => setShowReactionPicker((v) => !v)}
              className="text-white/25 hover:text-white/60 p-0.5"
              title="React"
            >
              <Smile className="w-3.5 h-3.5" />
            </button>
            <AnimatePresence>
              {showReactionPicker && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="absolute left-6 top-0 flex gap-1 bg-black/90 border border-white/10 p-1.5 z-20 shadow-xl"
                  style={{ borderRadius: 12 }}
                >
                  {QUICK_REACTIONS.map((emoji) => (
                    <button
                      key={emoji}
                      className="text-base hover:scale-125 transition-transform p-0.5"
                      onClick={() => {
                        const has = message.reactions.some(r => r.emoji === emoji && r.memberIds.includes(currentMemberId));
                        onReactionToggle(message.id, emoji, has);
                        setShowReactionPicker(false);
                      }}
                    >{emoji}</button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          <button onClick={() => onReply(message)} className="text-white/25 hover:text-white/60 p-0.5" title="Reply">
            <CornerUpLeft className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

export default function Chat() {
  const [, setLocation] = useLocation();
  const { token } = useAuth();

  useEffect(() => { if (!token) setLocation("/"); }, [token, setLocation]);

  const sessionHeaders = { headers: { "X-Session-Token": token || "" } };

  const { data: me } = useGetMe({
    request: sessionHeaders,
    query: { queryKey: getGetMeQueryKey(), enabled: !!token, retry: false },
  });

  const { data: rooms = [] } = useListRooms({
    request: sessionHeaders,
    query: { queryKey: getListRoomsQueryKey(), enabled: !!token, retry: false },
  });

  const [activeRoomSlug, setActiveRoomSlug] = useState("general");
  const [messages, setMessages] = useState<Map<string, MessageWithReactions[]>>(new Map());
  const [input, setInput] = useState("");
  const [replyTo, setReplyTo] = useState<MessageWithReactions | null>(null);
  const [showEmoji, setShowEmoji] = useState(false);
  const [showStickers, setShowStickers] = useState(false);
  const [activePack, setActivePack] = useState("dollars");
  const [unreadCounts, setUnreadCounts] = useState<Map<string, number>>(new Map());
  const feedRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const isFirstLoad = useRef(true);

  const scrollToBottom = useCallback((smooth = true) => {
    if (feedRef.current) feedRef.current.scrollTo({ top: feedRef.current.scrollHeight, behavior: smooth ? "smooth" : "instant" });
  }, []);

  const handleIncomingMessage = useCallback((msg: WSMessage) => {
    setMessages((prev) => {
      const updated = new Map(prev);
      updated.set(msg.roomSlug, [...(updated.get(msg.roomSlug) || []), msg as MessageWithReactions]);
      return updated;
    });
    if (msg.roomSlug === activeRoomSlug) setTimeout(() => scrollToBottom(), 50);
    else if (msg.member.id !== me?.id) {
      playNotificationSound();
      setUnreadCounts((prev) => { const u = new Map(prev); u.set(msg.roomSlug, (u.get(msg.roomSlug) || 0) + 1); return u; });
    }
  }, [activeRoomSlug, me?.id, scrollToBottom]);

  const handleReactionUpdate = useCallback((messageId: number, reactions: WSReaction[]) => {
    setMessages((prev) => {
      const updated = new Map(prev);
      for (const [slug, msgs] of updated) {
        const idx = msgs.findIndex((m) => m.id === messageId);
        if (idx !== -1) {
          const newMsgs = [...msgs];
          newMsgs[idx] = { ...newMsgs[idx], reactions };
          updated.set(slug, newMsgs);
          break;
        }
      }
      return updated;
    });
  }, []);

  const handlePresence = useCallback((_online: WSMember[]) => {}, []);

  const { connected, online, typingUsers, sendEvent } = useChatWS(token, handleIncomingMessage, handleReactionUpdate, handlePresence);

  const activeRoom = rooms.find((r) => r.slug === activeRoomSlug);
  const isOwnerOnlyRoom = activeRoom?.ownerOnlyPost && me?.role !== "owner";

  useEffect(() => {
    if (connected) {
      sendEvent({ type: "join_room", slug: activeRoomSlug });
      setUnreadCounts((prev) => { const u = new Map(prev); u.set(activeRoomSlug, 0); return u; });
    }
  }, [connected, activeRoomSlug, sendEvent]);

  const { data: history } = useGetRoomHistory(activeRoomSlug, undefined, {
    request: sessionHeaders,
    query: { queryKey: getGetRoomHistoryQueryKey(activeRoomSlug), enabled: !!token && !!activeRoomSlug, retry: false },
  });

  useEffect(() => {
    if (!history) return;
    setMessages((prev) => {
      const existing = prev.get(activeRoomSlug) || [];
      if (existing.length > 0) return prev;
      const updated = new Map(prev);
      updated.set(activeRoomSlug, history as MessageWithReactions[]);
      return updated;
    });
    if (isFirstLoad.current) { setTimeout(() => scrollToBottom(false), 100); isFirstLoad.current = false; }
  }, [history, activeRoomSlug, scrollToBottom]);

  const switchRoom = (slug: string) => {
    setActiveRoomSlug(slug);
    setUnreadCounts((prev) => { const u = new Map(prev); u.set(slug, 0); return u; });
    isFirstLoad.current = true;
  };

  const sendMessage = () => {
    const content = input.trim();
    if (!content || isOwnerOnlyRoom) return;
    sendEvent({ type: "send_message", roomSlug: activeRoomSlug, content, replyToId: replyTo?.id });
    setInput("");
    setReplyTo(null);
  };

  const sendSticker = (emoji: string) => {
    if (isOwnerOnlyRoom) return;
    sendEvent({ type: "send_message", roomSlug: activeRoomSlug, content: emoji, msgType: "sticker" });
    setShowStickers(false);
  };

  const handleReactionToggle = (messageId: number, emoji: string, hasReacted: boolean) => {
    sendEvent({ type: hasReacted ? "remove_reaction" : "add_reaction", messageId, emoji });
  };

  const roomMessages = messages.get(activeRoomSlug) || [];
  const COMMON_EMOJIS = ["😀","😂","😍","🤔","😎","🔥","💯","👋","🙌","❤️","💀","👀","⚡","🌙","💫","🎯","🤫","😈","🫡","🫂"];

  return (
    <div className="flex-1 flex overflow-hidden bg-black text-white">
      {/* Left: Users sidebar */}
      <div
        className="flex-shrink-0 border-r flex flex-col overflow-hidden"
        style={{ width: 110, borderColor: "rgba(255,255,255,0.08)", background: "#0a0a0a" }}
      >
        {/* Lobby link */}
        <button
          onClick={() => setLocation("/lobby")}
          className="px-2 py-2 border-b text-[10px] font-mono text-white/30 hover:text-white/60 transition-colors text-left uppercase tracking-widest"
          style={{ borderColor: "rgba(255,255,255,0.06)" }}
        >
          ← Lounge
        </button>

        {/* Room list */}
        <div className="border-b py-1" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
          {rooms.map((room) => {
            const isActive = room.slug === activeRoomSlug;
            const unread = unreadCounts.get(room.slug) || 0;
            return (
              <button
                key={room.slug}
                onClick={() => switchRoom(room.slug)}
                className="w-full px-2 py-1.5 text-left transition-colors flex items-center gap-1.5"
                style={{ background: isActive ? "rgba(255,255,255,0.08)" : "transparent" }}
              >
                {room.ownerOnlyPost ? (
                  <Megaphone className="w-3 h-3 flex-shrink-0 text-amber-500/60" />
                ) : (
                  <span className="text-white/20 text-xs">#</span>
                )}
                <span className={`font-mono text-[10px] truncate ${isActive ? "text-white" : "text-white/40"}`}>{room.name}</span>
                {unread > 0 && (
                  <span className="ml-auto font-mono text-[9px] bg-white/20 text-white px-1 rounded-full flex-shrink-0">{unread}</span>
                )}
              </button>
            );
          })}
        </div>

        {/* Online users */}
        <div className="flex-1 overflow-y-auto py-2" style={{ scrollbarWidth: "none" }}>
          <p className="font-mono text-[9px] text-white/20 uppercase tracking-widest px-2 pb-1">
            {online.length} online
          </p>
          {online.map((member) => {
            const color = getMemberColor(member.id);
            return (
              <div key={member.id} className="flex flex-col items-center gap-1 py-2 px-1 group">
                <div
                  className="w-12 h-12 flex items-center justify-center font-bold text-white overflow-hidden text-lg"
                  style={{ background: color, borderRadius: 5 }}
                >
                  {member.avatarUrl ? (
                    <img src={member.avatarUrl} alt="" className="w-full h-full object-cover" />
                  ) : (
                    member.displayName.charAt(0).toUpperCase()
                  )}
                </div>
                <div className="flex items-center gap-0.5">
                  <span className="font-mono text-[9px] truncate max-w-[56px] text-center" style={{ color }}>{member.displayName}</span>
                  {member.role === "owner" && <Crown className="w-2.5 h-2.5 text-amber-400 flex-shrink-0" />}
                </div>
              </div>
            );
          })}
        </div>

        {/* Connection status */}
        <div className="p-2 border-t flex items-center gap-1.5" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
          {connected ? <Wifi className="w-3 h-3 text-green-400" /> : <WifiOff className="w-3 h-3 text-red-400" />}
          <span className="font-mono text-[9px] text-white/30">{connected ? "ON" : "OFF"}</span>
        </div>
      </div>

      {/* Main area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Room header */}
        <div
          className="flex-shrink-0 flex items-center gap-3 px-4 py-2 border-b"
          style={{ borderColor: "rgba(255,255,255,0.08)", background: "#0d0d0d" }}
        >
          <span className="font-mono text-sm text-white font-bold">
            {activeRoom?.name || activeRoomSlug}
          </span>
          {activeRoom?.description && (
            <span className="font-mono text-xs text-white/30 hidden sm:block truncate">— {activeRoom.description}</span>
          )}
          <div className="ml-auto flex items-center gap-3">
            <button className="text-white/30 hover:text-white/60 transition-colors" title="Voice (coming soon)">
              <Mic className="w-4 h-4" />
            </button>
            <button className="text-white/30 hover:text-white/60 transition-colors" title="Music (coming soon)">
              <Music className="w-4 h-4" />
            </button>
            <button className="text-white/30 hover:text-white/60 transition-colors" title="Members">
              <Users className="w-4 h-4" />
            </button>
            <button onClick={() => setLocation("/lobby")} className="text-white/30 hover:text-white/60 transition-colors" title="Settings">
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Compose box — AT TOP like drrr.com */}
        <div className="flex-shrink-0 border-b" style={{ borderColor: "rgba(255,255,255,0.08)", background: "#0a0a0a" }}>
          <AnimatePresence>
            {replyTo && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="flex items-center gap-2 px-3 py-1.5 border-b"
                style={{ borderColor: "rgba(255,255,255,0.06)", background: "rgba(255,255,255,0.03)" }}
              >
                <CornerUpLeft className="w-3 h-3 text-white/30 flex-shrink-0" />
                <span className="font-mono text-[10px] text-white/50">↩ {replyTo.member.displayName}:</span>
                <span className="text-[10px] text-white/40 truncate flex-1">{replyTo.content}</span>
                <button onClick={() => setReplyTo(null)}><X className="w-3.5 h-3.5 text-white/30 hover:text-white/60" /></button>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Emoji picker */}
          <AnimatePresence>
            {showEmoji && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="px-3 py-2 border-b flex flex-wrap gap-1.5"
                style={{ borderColor: "rgba(255,255,255,0.06)" }}
              >
                {COMMON_EMOJIS.map((e) => (
                  <button key={e} onClick={() => { setInput((v) => v + e); inputRef.current?.focus(); }} className="text-xl hover:scale-125 transition-transform">
                    <InlineAnimatedEmoji emoji={e} />
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          {/* Sticker picker */}
          <AnimatePresence>
            {showStickers && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="border-b"
                style={{ borderColor: "rgba(255,255,255,0.06)" }}
              >
                <div className="flex gap-0 border-b overflow-x-auto" style={{ borderColor: "rgba(255,255,255,0.06)" }}>
                  {STICKER_PACKS.map((pack) => (
                    <button
                      key={pack.id}
                      onClick={() => setActivePack(pack.id)}
                      className={`flex-shrink-0 flex items-center gap-1 px-3 py-1.5 font-mono text-[10px] uppercase tracking-wider transition-colors border-b-2 ${activePack === pack.id ? "border-white/60 text-white" : "border-transparent text-white/30 hover:text-white/60"}`}
                    >
                      <span>{pack.icon}</span>
                      <span>{pack.name}</span>
                    </button>
                  ))}
                </div>
                {STICKER_PACKS.filter((p) => p.id === activePack).map((pack) => (
                  <div key={pack.id} className="px-3 py-2">
                    <div className="grid grid-cols-6 gap-1.5">
                      {pack.stickers.map((sticker) => (
                        <button key={sticker.id} onClick={() => sendSticker(sticker.emoji)} title={sticker.label}
                          className="flex flex-col items-center gap-1 p-1.5 hover:bg-white/5 border border-transparent hover:border-white/10 rounded-sm"
                        >
                          <AnimatedEmoji emoji={sticker.emoji} size={36} autoPlay={false} />
                          <span className="font-mono text-[8px] text-white/30 truncate w-full text-center">{sticker.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          <div className="flex items-start gap-2 px-3 py-2">
            <div className="flex flex-col gap-1 pt-1">
              <button
                onClick={() => { setShowEmoji((v) => !v); setShowStickers(false); }}
                className={`transition-colors ${showEmoji ? "text-white/80" : "text-white/30 hover:text-white/60"}`}
              >
                <Smile className="w-4 h-4" />
              </button>
              <button
                onClick={() => { setShowStickers((v) => !v); setShowEmoji(false); }}
                className={`transition-colors ${showStickers ? "text-white/80" : "text-white/30 hover:text-white/60"}`}
              >
                <Sticker className="w-4 h-4" />
              </button>
            </div>
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => {
                setInput(e.target.value);
                if (e.target.value) sendEvent({ type: "typing", roomSlug: activeRoomSlug });
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
              }}
              placeholder={isOwnerOnlyRoom ? "Read-only channel" : `Message…`}
              disabled={isOwnerOnlyRoom || !connected}
              rows={2}
              className="flex-1 bg-white/5 border border-white/10 px-3 py-2 font-mono text-sm text-white placeholder:text-white/20 focus:outline-none focus:border-white/30 resize-none"
              style={{ borderRadius: 2 }}
            />
            <button
              onClick={sendMessage}
              disabled={!input.trim() || isOwnerOnlyRoom || !connected}
              className="flex-shrink-0 flex items-center gap-1.5 px-4 py-2 font-mono text-sm font-bold uppercase tracking-wider transition-colors disabled:opacity-30"
              style={{ background: "linear-gradient(180deg,#e8e8c8 0%,#d4d4a8 100%)", color: "#1a1a00", borderRadius: 2, alignSelf: "flex-end" }}
            >
              <Send className="w-3.5 h-3.5" />
              POST!
            </button>
          </div>
        </div>

        {/* Messages feed */}
        <div
          ref={feedRef}
          className="flex-1 overflow-y-auto"
          style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.1) transparent" }}
        >
          {roomMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-8">
              <p className="font-mono text-xs text-white/20 uppercase tracking-widest">No messages yet.</p>
            </div>
          ) : (
            <div className="py-2">
              {roomMessages.map((msg) => (
                <MessageBubble
                  key={msg.id}
                  message={msg}
                  currentMemberId={me?.id ?? -1}
                  onReply={setReplyTo}
                  onReactionToggle={handleReactionToggle}
                />
              ))}
            </div>
          )}

          {typingUsers.length > 0 && (
            <div className="px-4 py-1">
              <span className="font-mono text-xs text-white/25 italic">
                {typingUsers.join(", ")} {typingUsers.length === 1 ? "is" : "are"} typing…
              </span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
