import crypto from "crypto";
import { promisify } from "util";

const scrypt = promisify(crypto.scrypt);

/**
 * Generate a cryptographically secure random invite code.
 * 12 uppercase alphanumeric chars — unguessable brute-force wise.
 */
export function generateInviteCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // No ambiguous chars (0/O, 1/I)
  const bytes = crypto.randomBytes(12);
  return Array.from(bytes)
    .map((b) => chars[b % chars.length])
    .join("");
}

/**
 * Generate a cryptographically secure session token.
 * 32 bytes = 64 hex chars. Stored directly — the token IS the secret.
 */
export function generateSessionToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

/**
 * Validate usertag format.
 * Rules: letters, numbers, underscores only. No spaces. No special chars.
 * minLength: 5 for regular members, 4 for owner tier.
 */
export function validateUsertag(
  tag: string,
  minLength = 5
): { valid: boolean; reason?: string } {
  if (!tag || tag.length < minLength) {
    return {
      valid: false,
      reason: `Usertag must be at least ${minLength} characters.`,
    };
  }
  if (tag.length > 30) {
    return { valid: false, reason: "Usertag must be 30 characters or fewer." };
  }
  if (!/^[a-z0-9_]+$/.test(tag)) {
    return {
      valid: false,
      reason: "Only lowercase letters, numbers, and underscores allowed.",
    };
  }
  return { valid: true };
}

/**
 * Sanitize a display name.
 * Strip leading/trailing whitespace, collapse internal whitespace.
 */
export function sanitizeDisplayName(name: string): string {
  return name.trim().replace(/\s+/g, " ");
}

/**
 * Validate email format (basic — real validation happens server-side via Zod).
 */
export function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// ─── Passphrase ───────────────────────────────────────────────────────────────

const WORD_POOL = [
  "amber","azure","blaze","cipher","cobalt","comet","dusk","echo","ember","ghost",
  "glitch","haze","helix","hollow","indigo","jade","karma","lunar","mirage","neon",
  "nexus","noir","nova","onyx","orbit","phantom","pixel","pulse","quartz","raven",
  "relay","rouge","rustle","shade","signal","silver","smoke","static","steel","storm",
  "surge","trace","urban","valor","vapor","vector","veil","violet","vortex","warden",
  "whisper","wire","xenon","zenith","zero","ether","prism","delta","sigma","lambda",
];

/**
 * Generate a memorable passphrase: WORD-WORD-WORD-NNNN
 * e.g. "violet-echo-neon-4827"
 */
export function generatePassphrase(): string {
  const pick = () => WORD_POOL[crypto.randomInt(WORD_POOL.length)];
  const num = crypto.randomInt(1000, 9999);
  return `${pick()}-${pick()}-${pick()}-${num}`;
}

/**
 * Hash a passphrase using scrypt. Returns "salt:hash" hex string.
 */
export async function hashPassphrase(passphrase: string): Promise<string> {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = (await scrypt(passphrase, salt, 64)) as Buffer;
  return `${salt}:${hash.toString("hex")}`;
}

/**
 * Verify a plaintext passphrase against a stored hash.
 */
export async function verifyPassphrase(passphrase: string, stored: string): Promise<boolean> {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  try {
    const derived = (await scrypt(passphrase, salt, 64)) as Buffer;
    const storedBuf = Buffer.from(hash, "hex");
    return derived.length === storedBuf.length && crypto.timingSafeEqual(derived, storedBuf);
  } catch {
    return false;
  }
}
