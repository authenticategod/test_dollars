import { Router, type IRouter } from "express";
import { eq, lt, desc, and } from "drizzle-orm";
import {
  db,
  roomsTable,
  messagesTable,
  membersTable,
  reactionsTable,
} from "@workspace/db";
import { requireAuth } from "../middlewares/auth.js";

const router: IRouter = Router();

/** GET /rooms — list all rooms */
router.get("/rooms", requireAuth, async (_req, res): Promise<void> => {
  const rooms = await db
    .select()
    .from(roomsTable)
    .orderBy(roomsTable.id);

  res.json(
    rooms.map((r) => ({
      id: r.id,
      slug: r.slug,
      name: r.name,
      description: r.description,
      ownerOnlyPost: r.ownerOnlyPost,
    }))
  );
});

/** GET /rooms/:slug/history — last 50 messages (paginated with ?before=id) */
router.get(
  "/rooms/:slug/history",
  requireAuth,
  async (req, res): Promise<void> => {
    const { slug } = req.params as { slug: string };
    const before = req.query["before"] ? Number(req.query["before"]) : null;

    const [room] = await db
      .select()
      .from(roomsTable)
      .where(eq(roomsTable.slug, slug))
      .limit(1);

    if (!room) {
      res.status(404).json({ error: "Room not found." });
      return;
    }

    const msgs = await db
      .select()
      .from(messagesTable)
      .where(
        before
          ? and(eq(messagesTable.roomId, room.id), lt(messagesTable.id, before))
          : eq(messagesTable.roomId, room.id)
      )
      .orderBy(desc(messagesTable.id))
      .limit(50);

    const msgIds = msgs.map((m) => m.id);

    const memberIds = [...new Set(msgs.map((m) => m.memberId))];
    const replyToIds = msgs
      .filter((m) => m.replyToId !== null)
      .map((m) => m.replyToId!);

    const allMemberIds = [...new Set([...memberIds, ...replyToIds])];

    const [membersData, reactionsData, replyMsgs] = await Promise.all([
      allMemberIds.length > 0
        ? db
            .select()
            .from(membersTable)
            .then((rows) => rows.filter((r) => allMemberIds.includes(r.id)))
        : Promise.resolve([]),
      msgIds.length > 0
        ? db
            .select()
            .from(reactionsTable)
            .then((rows) => rows.filter((r) => msgIds.includes(r.messageId)))
        : Promise.resolve([]),
      replyToIds.length > 0
        ? db
            .select()
            .from(messagesTable)
            .then((rows) => rows.filter((r) => replyToIds.includes(r.id)))
        : Promise.resolve([]),
    ]);

    const memberMap = new Map(membersData.map((m) => [m.id, m]));
    const replyMap = new Map(replyMsgs.map((m) => [m.id, m]));

    const reactionsByMsg = new Map<number, { emoji: string; count: number; memberIds: number[] }[]>();
    for (const r of reactionsData) {
      if (!reactionsByMsg.has(r.messageId)) reactionsByMsg.set(r.messageId, []);
      const existing = reactionsByMsg.get(r.messageId)!.find((x) => x.emoji === r.emoji);
      if (existing) {
        existing.count++;
        existing.memberIds.push(r.memberId);
      } else {
        reactionsByMsg.get(r.messageId)!.push({ emoji: r.emoji, count: 1, memberIds: [r.memberId] });
      }
    }

    const result = msgs
      .slice()
      .reverse()
      .map((msg) => {
        const member = memberMap.get(msg.memberId);
        let replyTo = null;
        if (msg.replyToId) {
          const replyMsg = replyMap.get(msg.replyToId);
          if (replyMsg) {
            const replyMember = memberMap.get(replyMsg.memberId);
            replyTo = {
              id: replyMsg.id,
              content: replyMsg.content,
              member: replyMember
                ? {
                    id: replyMember.id,
                    usertag: replyMember.usertag,
                    displayName: replyMember.displayName,
                    avatarUrl: replyMember.avatarUrl,
                    role: replyMember.role,
                    isEarlyMember: replyMember.isEarlyMember,
                  }
                : null,
            };
          }
        }

        return {
          id: msg.id,
          roomSlug: slug,
          content: msg.content,
          type: msg.type,
          member: member
            ? {
                id: member.id,
                usertag: member.usertag,
                displayName: member.displayName,
                avatarUrl: member.avatarUrl,
                role: member.role,
                isEarlyMember: member.isEarlyMember,
              }
            : null,
          replyTo,
          reactions: reactionsByMsg.get(msg.id) || [],
          createdAt: msg.createdAt.toISOString(),
        };
      });

    res.json(result);
  }
);

export default router;
