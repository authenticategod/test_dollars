import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import router from "./routes/index.js";

const app: Express = express();

// Trust the proxy (Replit dev proxy + production reverse proxy both set X-Forwarded-For)
app.set("trust proxy", 1);

// ─── Security headers via Helmet ────────────────────────────────────────────
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'", "wss:", "ws:"],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: [],
      },
    },
    strictTransportSecurity: { maxAge: 31536000, includeSubDomains: true, preload: true },
    frameguard: { action: "deny" },
    noSniff: true,
    hidePoweredBy: true,
  })
);

// ─── CORS ─────────────────────────────────────────────────────────────────────
// Set ALLOWED_ORIGIN env var on your VPS to lock down to your frontend domain
const allowedOrigin = process.env["ALLOWED_ORIGIN"];
app.use(
  cors({
    origin: allowedOrigin
      ? (origin, cb) => {
          if (!origin || origin === allowedOrigin) cb(null, true);
          else cb(new Error("Not allowed by CORS"));
        }
      : true,
    methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "X-Session-Token", "X-Admin-Secret"],
    credentials: false,
  })
);

// ─── Body parsing — limit size to prevent memory exhaustion ─────────────────
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: true, limit: "100kb" }));

// ─── Rate limiting ───────────────────────────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests. Try again later." },
  skip: () => process.env["NODE_ENV"] === "development",
});

const isDev = () => process.env["NODE_ENV"] === "development";

// Prevent brute-force invite code guessing — 10 attempts per 15 min per IP
const joinLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many attempts. Try again later." },
  skip: isDev,
});

// Prevent usertag enumeration — 30 checks per minute per IP
const checkTagLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many requests. Slow down." },
  skip: isDev,
});

// Prevent email spam — 10 emails per hour per IP
const emailLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Email rate limit reached. Try again later." },
  skip: isDev,
});

// Prevent brute-force login — 10 attempts per 15 min per IP
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Too many login attempts. Try again later." },
  skip: isDev,
});

app.use(globalLimiter);
app.use("/api/auth/join", joinLimiter);
app.use("/api/auth/login", loginLimiter);
app.use("/api/auth/check-tag", checkTagLimiter);
app.use("/api/admin/invite-codes", emailLimiter); // covers /send-email sub-path

// ─── Routes ───────────────────────────────────────────────────────────────────
app.use("/api", router);

// ─── 404 ─────────────────────────────────────────────────────────────────────
app.use((_req, res) => {
  res.status(404).json({ error: "Not found." });
});

// ─── Error handler — never leak internals to the client ──────────────────────
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
  console.error("[error]", err.message);
  res.status(500).json({ error: "An unexpected error occurred." });
});

export default app;
