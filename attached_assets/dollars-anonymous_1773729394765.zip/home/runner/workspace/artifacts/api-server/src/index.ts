import http from "http";
import app from "./app.js";
import { createWebSocketServer } from "./lib/ws-server.js";
import { seedRooms } from "./lib/seed-rooms.js";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required but was not provided.");
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const server = http.createServer(app);
const wss = createWebSocketServer();

server.on("upgrade", (req, socket, head) => {
  const url = new URL(req.url || "/", `http://${req.headers.host}`);
  if (url.pathname === "/api/ws" || url.pathname === "/ws") {
    wss.handleUpgrade(req, socket as import("net").Socket, head, (ws) => {
      wss.emit("connection", ws, req);
    });
  } else {
    socket.destroy();
  }
});

await seedRooms();

server.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
