import { db, roomsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const defaultRooms = [
  {
    slug: "general",
    name: "#general",
    description: "Open channel. Talk about anything.",
    ownerOnlyPost: false,
  },
  {
    slug: "random",
    name: "#random",
    description: "Off-topic. Noise welcome.",
    ownerOnlyPost: false,
  },
  {
    slug: "announcements",
    name: "#announcements",
    description: "Official dispatches from the owner.",
    ownerOnlyPost: true,
  },
];

export async function seedRooms() {
  for (const room of defaultRooms) {
    const [existing] = await db
      .select({ id: roomsTable.id })
      .from(roomsTable)
      .where(eq(roomsTable.slug, room.slug))
      .limit(1);

    if (!existing) {
      await db.insert(roomsTable).values(room);
      console.log(`[seed] Created room: ${room.slug}`);
    }
  }
}
