import { Request, Response, NextFunction } from "express";
import { db, sessionsTable, membersTable } from "@workspace/db";
import { eq, and, gt } from "drizzle-orm";

/**
 * Extend Express Request to carry the authenticated member.
 */
declare global {
  namespace Express {
    interface Request {
      memberId?: number;
      memberRole?: string;
    }
  }
}

/**
 * requireAuth middleware — validates X-Session-Token header.
 * Attaches memberId and memberRole to req on success.
 * Returns 401 on any failure. Deliberately vague error messages.
 */
export async function requireAuth(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  const token = req.headers["x-session-token"];

  if (!token || typeof token !== "string" || token.length !== 64) {
    res.status(401).json({ error: "Authentication required." });
    return;
  }

  // Only allow hex characters — reject anything weird
  if (!/^[a-f0-9]{64}$/.test(token)) {
    res.status(401).json({ error: "Authentication required." });
    return;
  }

  const now = new Date();
  const [session] = await db
    .select({ memberId: sessionsTable.memberId })
    .from(sessionsTable)
    .where(
      and(
        eq(sessionsTable.token, token),
        gt(sessionsTable.expiresAt, now)
      )
    )
    .limit(1);

  if (!session) {
    res.status(401).json({ error: "Authentication required." });
    return;
  }

  // Update last_seen on the member asynchronously — don't block the request
  db.update(membersTable)
    .set({ lastSeen: now })
    .where(eq(membersTable.id, session.memberId))
    .catch(() => {}); // Swallow errors — non-critical

  req.memberId = session.memberId;
  next();
}

/**
 * requireAdmin middleware — validates admin access.
 * Accepts either:
 *   1. X-Admin-Secret header (timing-safe comparison)
 *   2. X-Session-Token header from a member with "owner" role
 */
export async function requireAdmin(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  const adminSecret = req.headers["x-admin-secret"];
  const sessionToken = req.headers["x-session-token"];

  if (adminSecret && typeof adminSecret === "string") {
    const expected = process.env["ADMIN_SECRET"];
    if (!expected) {
      res.status(503).json({ error: "Admin access not configured." });
      return;
    }

    const providedBuf = Buffer.from(adminSecret, "utf8");
    const expectedBuf = Buffer.from(expected, "utf8");

    if (
      providedBuf.length === expectedBuf.length &&
      crypto.timingSafeEqual(providedBuf, expectedBuf)
    ) {
      next();
      return;
    }
  }

  if (sessionToken && typeof sessionToken === "string" && /^[a-f0-9]{64}$/.test(sessionToken)) {
    const now = new Date();
    const [session] = await db
      .select({ memberId: sessionsTable.memberId })
      .from(sessionsTable)
      .where(and(eq(sessionsTable.token, sessionToken), gt(sessionsTable.expiresAt, now)))
      .limit(1);

    if (session) {
      const [member] = await db
        .select({ role: membersTable.role })
        .from(membersTable)
        .where(eq(membersTable.id, session.memberId))
        .limit(1);

      if (member?.role === "owner") {
        req.memberId = session.memberId;
        req.memberRole = "owner";
        next();
        return;
      }
    }
  }

  res.status(401).json({ error: "Unauthorized." });
}

import crypto from "crypto";
