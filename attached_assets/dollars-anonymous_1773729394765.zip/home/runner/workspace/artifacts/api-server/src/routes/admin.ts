import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, inviteCodesTable, membersTable } from "@workspace/db";
import { requireAdmin } from "../middlewares/auth.js";
import {
  CreateInviteCodeBody,
  SendInviteEmailBody,
} from "@workspace/api-zod";
import { generateInviteCode } from "../lib/security.js";
import { sendInviteEmail } from "../lib/email.js";

const router: IRouter = Router();

/** GET /admin/invite-codes */
router.get("/admin/invite-codes", requireAdmin, async (_req, res): Promise<void> => {
  const codes = await db
    .select()
    .from(inviteCodesTable)
    .orderBy(inviteCodesTable.createdAt);

  res.json(
    codes.map((c) => ({
      code: c.code,
      label: c.label ?? null,
      maxUses: c.maxUses,
      usesCount: c.usesCount,
      revoked: c.revoked,
      isOwnerCode: c.isOwnerCode,
      expiresAt: c.expiresAt ?? null,
      createdAt: c.createdAt,
    }))
  );
});

/** POST /admin/invite-codes — generate new code */
router.post("/admin/invite-codes", requireAdmin, async (req, res): Promise<void> => {
  const parsed = CreateInviteCodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request." });
    return;
  }

  const { maxUses, expiresInHours, label, isOwnerCode } = parsed.data;

  if (maxUses < 1 || maxUses > 1000) {
    res.status(400).json({ error: "maxUses must be between 1 and 1000." });
    return;
  }

  let expiresAt: Date | undefined = undefined;
  if (expiresInHours != null && expiresInHours > 0) {
    expiresAt = new Date(Date.now() + expiresInHours * 3600 * 1000);
  }

  const code = generateInviteCode();
  const [created] = await db
    .insert(inviteCodesTable)
    .values({
      code,
      label: label ?? null,
      createdBy: req.memberId ?? null,
      maxUses,
      isOwnerCode: isOwnerCode ?? false,
      expiresAt,
    })
    .returning();

  res.status(201).json({
    code: created.code,
    label: created.label ?? null,
    maxUses: created.maxUses,
    usesCount: created.usesCount,
    revoked: created.revoked,
    isOwnerCode: created.isOwnerCode,
    expiresAt: created.expiresAt ?? null,
    createdAt: created.createdAt,
  });
});

/** DELETE /admin/invite-codes/:code — revoke */
router.delete("/admin/invite-codes/:code", requireAdmin, async (req, res): Promise<void> => {
  const rawCode = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;

  const [existing] = await db
    .select({ code: inviteCodesTable.code })
    .from(inviteCodesTable)
    .where(eq(inviteCodesTable.code, rawCode))
    .limit(1);

  if (!existing) {
    res.status(404).json({ error: "Code not found." });
    return;
  }

  await db
    .update(inviteCodesTable)
    .set({ revoked: true })
    .where(eq(inviteCodesTable.code, rawCode));

  res.sendStatus(204);
});

/** POST /admin/invite-codes/:code/send-email — send invite email */
router.post(
  "/admin/invite-codes/:code/send-email",
  requireAdmin,
  async (req, res): Promise<void> => {
    const rawCode = Array.isArray(req.params.code) ? req.params.code[0] : req.params.code;

    const [codeRow] = await db
      .select()
      .from(inviteCodesTable)
      .where(eq(inviteCodesTable.code, rawCode))
      .limit(1);

    if (!codeRow || codeRow.revoked) {
      res.status(404).json({ error: "Code not found or revoked." });
      return;
    }

    const parsed = SendInviteEmailBody.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Invalid request." });
      return;
    }

    const { recipientEmail, personalMessage } = parsed.data;

    const configuredOrigin = process.env["ALLOWED_ORIGIN"] || process.env["SITE_URL"];
    let siteUrl: string;
    if (configuredOrigin) {
      siteUrl = configuredOrigin;
    } else {
      const protocol = req.protocol;
      const host = req.get("host");
      siteUrl = `${protocol}://${host}`;
    }

    const result = await sendInviteEmail({
      recipientEmail,
      inviteCode: codeRow.code,
      personalMessage,
      siteUrl,
    });

    if (!result.sent) {
      res.status(503).json({
        error: result.reason ?? "Email could not be sent.",
      });
      return;
    }

    res.json({ success: true });
  }
);

/** GET /admin/members — list members (handles only, no PII) */
router.get("/admin/members", requireAdmin, async (_req, res): Promise<void> => {
  const members = await db
    .select({
      id: membersTable.id,
      usertag: membersTable.usertag,
      displayName: membersTable.displayName,
      role: membersTable.role,
      joinedAt: membersTable.joinedAt,
      inviteCode: membersTable.inviteCodeUsed,
    })
    .from(membersTable)
    .orderBy(membersTable.joinedAt);

  res.json(members);
});

export default router;
