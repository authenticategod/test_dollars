import { WebSocketServer, WebSocket } from "ws";
import { IncomingMessage } from "http";
import { eq, and } from "drizzle-orm";
import {
  db,
  sessionsTable,
  membersTable,
  roomsTable,
  messagesTable,
  reactionsTable,
} from "@workspace/db";

export type ChatMemberInfo = {
  id: number;
  usertag: string;
  displayName: string;
  avatarUrl: string | null;
  role: "owner" | "member";
  isEarlyMember: boolean;
};

type ConnectedClient = {
  ws: WebSocket;
  member: ChatMemberInfo;
  roomSlug: string | null;
};

const clients = new Map<WebSocket, ConnectedClient>();

function broadcast(roomSlug: string, event: object, exclude?: WebSocket) {
  const payload = JSON.stringify(event);
  for (const [ws, client] of clients) {
    if (ws === exclude) continue;
    if (client.roomSlug !== roomSlug) continue;
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  }
}

function broadcastPresence(roomSlug: string) {
  const online = Array.from(clients.values())
    .filter((c) => c.roomSlug === roomSlug)
    .map((c) => ({
      id: c.member.id,
      usertag: c.member.usertag,
      displayName: c.member.displayName,
      avatarUrl: c.member.avatarUrl,
      role: c.member.role,
      isEarlyMember: c.member.isEarlyMember,
    }));
  broadcast(roomSlug, { type: "presence", online });
}

async function buildMessagePayload(messageId: number, roomSlug: string) {
  const [msg] = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.id, messageId))
    .limit(1);
  if (!msg) return null;

  const [member] = await db
    .select()
    .from(membersTable)
    .where(eq(membersTable.id, msg.memberId))
    .limit(1);
  if (!member) return null;

  let replyTo = null;
  if (msg.replyToId) {
    const [reply] = await db
      .select()
      .from(messagesTable)
      .where(eq(messagesTable.id, msg.replyToId))
      .limit(1);
    if (reply) {
      const [replyMember] = await db
        .select()
        .from(membersTable)
        .where(eq(membersTable.id, reply.memberId))
        .limit(1);
      replyTo = {
        id: reply.id,
        content: reply.content,
        member: replyMember
          ? {
              id: replyMember.id,
              usertag: replyMember.usertag,
              displayName: replyMember.displayName,
              avatarUrl: replyMember.avatarUrl,
              role: replyMember.role,
              isEarlyMember: replyMember.isEarlyMember,
            }
          : null,
      };
    }
  }

  const rawReactions = await db
    .select()
    .from(reactionsTable)
    .where(eq(reactionsTable.messageId, msg.id));

  const reactionMap = new Map<string, number[]>();
  for (const r of rawReactions) {
    if (!reactionMap.has(r.emoji)) reactionMap.set(r.emoji, []);
    reactionMap.get(r.emoji)!.push(r.memberId);
  }
  const reactions = Array.from(reactionMap.entries()).map(([emoji, memberIds]) => ({
    emoji,
    count: memberIds.length,
    memberIds,
  }));

  return {
    id: msg.id,
    roomSlug,
    content: msg.content,
    type: msg.type,
    member: {
      id: member.id,
      usertag: member.usertag,
      displayName: member.displayName,
      avatarUrl: member.avatarUrl,
      role: member.role,
      isEarlyMember: member.isEarlyMember,
    },
    replyTo,
    reactions,
    createdAt: msg.createdAt.toISOString(),
  };
}

async function handleMessage(client: ConnectedClient, raw: string) {
  let data: { type: string; [k: string]: unknown };
  try {
    data = JSON.parse(raw);
  } catch {
    return;
  }

  const send = (payload: object) => {
    if (client.ws.readyState === WebSocket.OPEN) {
      client.ws.send(JSON.stringify(payload));
    }
  };

  switch (data.type) {
    case "join_room": {
      const slug = String(data.slug || "");
      const [room] = await db
        .select()
        .from(roomsTable)
        .where(eq(roomsTable.slug, slug))
        .limit(1);
      if (!room) {
        send({ type: "error", message: "Room not found." });
        return;
      }
      const prevRoom = client.roomSlug;
      client.roomSlug = slug;
      if (prevRoom) broadcastPresence(prevRoom);
      broadcastPresence(slug);
      send({ type: "joined_room", slug });
      break;
    }

    case "send_message": {
      const roomSlug = String(data.roomSlug || client.roomSlug || "");
      const content = String(data.content || "").trim();
      const type = data.msgType === "sticker" ? "sticker" : "text";
      const replyToId = typeof data.replyToId === "number" ? data.replyToId : null;

      if (!roomSlug || !content) return;

      const [room] = await db
        .select()
        .from(roomsTable)
        .where(eq(roomsTable.slug, roomSlug))
        .limit(1);
      if (!room) return;

      if (room.ownerOnlyPost && client.member.role !== "owner") {
        send({ type: "error", message: "Only the owner can post in this room." });
        return;
      }

      if (content.length > 2000) {
        send({ type: "error", message: "Message too long." });
        return;
      }

      const [inserted] = await db
        .insert(messagesTable)
        .values({
          roomId: room.id,
          memberId: client.member.id,
          content,
          type,
          replyToId,
        })
        .returning({ id: messagesTable.id });

      if (!inserted) return;

      const payload = await buildMessagePayload(inserted.id, roomSlug);
      if (payload) {
        const event = { type: "message", message: payload };
        broadcast(roomSlug, event);
        send(event);
      }
      break;
    }

    case "typing": {
      const roomSlug = String(data.roomSlug || client.roomSlug || "");
      if (!roomSlug) return;
      broadcast(roomSlug, { type: "typing", usertag: client.member.usertag, roomSlug }, client.ws);
      break;
    }

    case "add_reaction": {
      const messageId = Number(data.messageId);
      const emoji = String(data.emoji || "").trim();
      if (!messageId || !emoji) return;

      const [msg] = await db
        .select({ roomId: messagesTable.roomId })
        .from(messagesTable)
        .where(eq(messagesTable.id, messageId))
        .limit(1);
      if (!msg) return;

      const [room] = await db
        .select({ slug: roomsTable.slug })
        .from(roomsTable)
        .where(eq(roomsTable.id, msg.roomId))
        .limit(1);
      if (!room) return;

      await db
        .insert(reactionsTable)
        .values({ messageId, memberId: client.member.id, emoji })
        .onConflictDoNothing();

      const rawReactions = await db
        .select()
        .from(reactionsTable)
        .where(eq(reactionsTable.messageId, messageId));

      const reactionMap = new Map<string, number[]>();
      for (const r of rawReactions) {
        if (!reactionMap.has(r.emoji)) reactionMap.set(r.emoji, []);
        reactionMap.get(r.emoji)!.push(r.memberId);
      }
      const reactions = Array.from(reactionMap.entries()).map(([e, memberIds]) => ({
        emoji: e,
        count: memberIds.length,
        memberIds,
      }));

      broadcast(room.slug, { type: "reaction_update", messageId, reactions });
      break;
    }

    case "remove_reaction": {
      const messageId = Number(data.messageId);
      const emoji = String(data.emoji || "").trim();
      if (!messageId || !emoji) return;

      const [msg] = await db
        .select({ roomId: messagesTable.roomId })
        .from(messagesTable)
        .where(eq(messagesTable.id, messageId))
        .limit(1);
      if (!msg) return;

      const [room] = await db
        .select({ slug: roomsTable.slug })
        .from(roomsTable)
        .where(eq(roomsTable.id, msg.roomId))
        .limit(1);
      if (!room) return;

      await db
        .delete(reactionsTable)
        .where(
          and(
            eq(reactionsTable.messageId, messageId),
            eq(reactionsTable.memberId, client.member.id),
            eq(reactionsTable.emoji, emoji)
          )
        );

      const rawReactions = await db
        .select()
        .from(reactionsTable)
        .where(eq(reactionsTable.messageId, messageId));

      const reactionMap = new Map<string, number[]>();
      for (const r of rawReactions) {
        if (!reactionMap.has(r.emoji)) reactionMap.set(r.emoji, []);
        reactionMap.get(r.emoji)!.push(r.memberId);
      }
      const reactions = Array.from(reactionMap.entries()).map(([e, memberIds]) => ({
        emoji: e,
        count: memberIds.length,
        memberIds,
      }));

      broadcast(room.slug, { type: "reaction_update", messageId, reactions });
      break;
    }
  }
}

export function createWebSocketServer() {
  const wss = new WebSocketServer({ noServer: true });

  wss.on("connection", async (ws: WebSocket, req: IncomingMessage) => {
    const url = new URL(req.url || "/", "http://localhost");
    const token = url.searchParams.get("token") || "";

    if (!token) {
      ws.close(1008, "Missing token");
      return;
    }

    const now = new Date();
    const [session] = await db
      .select({ memberId: sessionsTable.memberId })
      .from(sessionsTable)
      .where(eq(sessionsTable.token, token))
      .limit(1);

    if (!session) {
      ws.close(1008, "Invalid token");
      return;
    }

    // Update last_seen
    await db
      .update(membersTable)
      .set({ lastSeen: now })
      .where(eq(membersTable.id, session.memberId));

    const [member] = await db
      .select()
      .from(membersTable)
      .where(eq(membersTable.id, session.memberId))
      .limit(1);

    if (!member) {
      ws.close(1008, "Member not found");
      return;
    }

    const memberInfo: ChatMemberInfo = {
      id: member.id,
      usertag: member.usertag,
      displayName: member.displayName,
      avatarUrl: member.avatarUrl,
      role: member.role as "owner" | "member",
      isEarlyMember: member.isEarlyMember,
    };

    const client: ConnectedClient = { ws, member: memberInfo, roomSlug: null };
    clients.set(ws, client);

    ws.send(JSON.stringify({ type: "welcome", member: memberInfo }));

    ws.on("message", (raw) => handleMessage(client, raw.toString()));

    ws.on("close", () => {
      const prevRoom = client.roomSlug;
      clients.delete(ws);
      if (prevRoom) broadcastPresence(prevRoom);
    });

    ws.on("error", () => {
      clients.delete(ws);
    });
  });

  return wss;
}
