import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, membersTable, messagesTable } from "@workspace/db";

const router: IRouter = Router();

/** GET /members/count — public anonymous member count */
router.get("/members/count", async (_req, res): Promise<void> => {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(membersTable);

  res.json({ count: Number(count) });
});

/** GET /members/:usertag — public profile */
router.get("/members/:usertag", async (req, res): Promise<void> => {
  const tag = req.params.usertag?.toLowerCase().trim();
  if (!tag) {
    res.status(400).json({ error: "Invalid usertag." });
    return;
  }

  const [member] = await db
    .select()
    .from(membersTable)
    .where(eq(membersTable.usertag, tag))
    .limit(1);

  if (!member) {
    res.status(404).json({ error: "Member not found." });
    return;
  }

  const [{ count: messageCount }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(messagesTable)
    .where(eq(messagesTable.memberId, member.id));

  res.json({
    id: member.id,
    usertag: member.usertag,
    displayName: member.displayName,
    avatarUrl: member.avatarUrl ?? null,
    bio: member.bio ?? null,
    role: member.role,
    joinedAt: member.joinedAt,
    isEarlyMember: member.isEarlyMember,
    messageCount: Number(messageCount),
  });
});

export default router;
