import { Router, type IRouter } from "express";
import { eq, and, gt, sql } from "drizzle-orm";
import { db, inviteCodesTable, membersTable, sessionsTable } from "@workspace/db";
import { requireAuth } from "../middlewares/auth.js";
import {
  JoinDollarsBody,
  CheckUsertagQueryParams,
} from "@workspace/api-zod";
import {
  generateSessionToken,
  validateUsertag,
  sanitizeDisplayName,
  generatePassphrase,
  hashPassphrase,
  verifyPassphrase,
} from "../lib/security.js";

const router: IRouter = Router();

const SESSION_DURATION_DAYS = 30;

/** GET /auth/check-tag?tag=xxx&code=xxx — availability check */
router.get("/auth/check-tag", async (req, res): Promise<void> => {
  const parsed = CheckUsertagQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request." });
    return;
  }

  const tag = parsed.data.tag.toLowerCase().trim();
  const inviteCode = (parsed.data.code ?? "").toUpperCase().trim();

  let minLength = 5;
  if (inviteCode) {
    const now = new Date();
    const [codeRow] = await db
      .select()
      .from(inviteCodesTable)
      .where(eq(inviteCodesTable.code, inviteCode))
      .limit(1);

    const codeValid =
      codeRow &&
      !codeRow.revoked &&
      codeRow.usesCount < codeRow.maxUses &&
      (!codeRow.expiresAt || codeRow.expiresAt >= now);

    if (codeValid) {
      // Owner codes always get 4-char minimum
      if (codeRow.isOwnerCode) {
        minLength = 4;
      } else {
        // Non-owner code: only grant 4-char min if this is literally the first member ever
        const [memberCount] = await db
          .select({ count: sql<number>`count(*)::int` })
          .from(membersTable);
        if ((memberCount?.count ?? 0) === 0) minLength = 4;
      }
    }
  }

  const validation = validateUsertag(tag, minLength);

  if (!validation.valid) {
    res.json({ available: false, valid: false, reason: validation.reason ?? null, minLength });
    return;
  }

  const [existing] = await db
    .select({ usertag: membersTable.usertag })
    .from(membersTable)
    .where(eq(membersTable.usertag, tag))
    .limit(1);

  res.json({
    available: !existing,
    valid: true,
    reason: existing ? "This tag is already in use." : null,
    minLength,
  });
});

/** POST /auth/join — join with invite code */
router.post("/auth/join", async (req, res): Promise<void> => {
  const parsed = JoinDollarsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request data." });
    return;
  }

  const { inviteCode, usertag: rawTag, displayName: rawName, avatarUrl } = parsed.data;
  const usertag = rawTag.toLowerCase().trim();
  const displayName = sanitizeDisplayName(rawName);

  if (!displayName || displayName.length < 1 || displayName.length > 50) {
    res.status(400).json({ error: "Display name must be 1–50 characters." });
    return;
  }

  // Validate invite code
  const now = new Date();
  const [code] = await db
    .select()
    .from(inviteCodesTable)
    .where(eq(inviteCodesTable.code, inviteCode.toUpperCase().trim()))
    .limit(1);

  if (
    !code ||
    code.revoked ||
    code.usesCount >= code.maxUses ||
    (code.expiresAt && code.expiresAt < now)
  ) {
    // Deliberate vague message — don't reveal whether code exists or is expired
    res.status(403).json({ error: "The code is incorrect." });
    return;
  }

  // Check usertag uniqueness
  const [existingTag] = await db
    .select({ id: membersTable.id })
    .from(membersTable)
    .where(eq(membersTable.usertag, usertag))
    .limit(1);

  if (existingTag) {
    res.status(409).json({ error: "This tag is already in use." });
    return;
  }

  // Count members for early-member badge and fallback first-join owner logic
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)` })
    .from(membersTable);
  const memberCount = Number(count);

  // Owner role: first member ever, OR if the invite code itself is an owner code
  const role: "owner" | "member" =
    memberCount === 0 || code.isOwnerCode ? "owner" : "member";
  const isEarlyMember = memberCount < 100;

  // Validate usertag — owner gets 4-char minimum privilege, everyone else needs 5
  const minTagLength = role === "owner" ? 4 : 5;
  const tagValidation = validateUsertag(usertag, minTagLength);
  if (!tagValidation.valid) {
    res.status(400).json({ error: tagValidation.reason });
    return;
  }

  // Generate a passphrase for re-login (shown once, never stored in plain)
  const passphrase = generatePassphrase();
  const passphraseHash = await hashPassphrase(passphrase);

  // Create member
  const [member] = await db
    .insert(membersTable)
    .values({
      usertag,
      displayName,
      avatarUrl: avatarUrl ?? null,
      role,
      inviteCodeUsed: code.code,
      isEarlyMember,
      passphraseHash,
    })
    .returning();

  // Increment code uses
  await db
    .update(inviteCodesTable)
    .set({ usesCount: code.usesCount + 1 })
    .where(eq(inviteCodesTable.code, code.code));

  // Create session (30-day expiry)
  const token = generateSessionToken();
  const expiresAt = new Date(now.getTime() + SESSION_DURATION_DAYS * 86400 * 1000);

  await db.insert(sessionsTable).values({
    token,
    memberId: member.id,
    expiresAt,
  });

  res.status(201).json({
    token,
    passphrase,
    member: {
      id: member.id,
      usertag: member.usertag,
      displayName: member.displayName,
      avatarUrl: member.avatarUrl,
      role: member.role,
      joinedAt: member.joinedAt,
      isEarlyMember: member.isEarlyMember,
    },
  });
});

/** PATCH /auth/me — update own profile */
router.patch("/auth/me", requireAuth, async (req, res): Promise<void> => {
  const body = req.body ?? {};
  const { displayName: rawName, bio: rawBio, avatarUrl: rawAvatar } = body;

  const updates: Partial<{ displayName: string; bio: string | null; avatarUrl: string | null }> =
    {};

  if (rawName !== undefined) {
    if (typeof rawName !== "string" || rawName.trim().length < 1 || rawName.trim().length > 50) {
      res.status(400).json({ error: "Display name must be 1–50 characters." });
      return;
    }
    updates.displayName = sanitizeDisplayName(rawName.trim());
  }
  if (rawBio !== undefined) {
    if (rawBio === null || rawBio === "") {
      updates.bio = null;
    } else if (typeof rawBio === "string") {
      if (rawBio.trim().length > 160) {
        res.status(400).json({ error: "Bio must be 160 characters or fewer." });
        return;
      }
      updates.bio = rawBio.trim();
    }
  }
  if (rawAvatar !== undefined) {
    updates.avatarUrl = rawAvatar === null || rawAvatar === "" ? null : String(rawAvatar).trim();
  }

  if (Object.keys(updates).length === 0) {
    res.status(400).json({ error: "No fields to update." });
    return;
  }

  const [member] = await db
    .update(membersTable)
    .set(updates)
    .where(eq(membersTable.id, req.memberId!))
    .returning();

  if (!member) {
    res.status(404).json({ error: "Member not found." });
    return;
  }

  res.json({
    id: member.id,
    usertag: member.usertag,
    displayName: member.displayName,
    avatarUrl: member.avatarUrl ?? null,
    bio: member.bio ?? null,
    role: member.role,
    joinedAt: member.joinedAt,
    isEarlyMember: member.isEarlyMember,
  });
});

/** POST /auth/login — re-login with usertag + passphrase */
router.post("/auth/login", async (req, res): Promise<void> => {
  const { usertag, passphrase } = req.body ?? {};

  if (typeof usertag !== "string" || typeof passphrase !== "string") {
    res.status(400).json({ error: "Invalid request." });
    return;
  }

  const tag = usertag.toLowerCase().trim();

  const [member] = await db
    .select()
    .from(membersTable)
    .where(eq(membersTable.usertag, tag))
    .limit(1);

  // Timing-safe: always attempt verify even if member not found (prevents enumeration)
  const hashToCheck = member?.passphraseHash ?? "none:none";
  const valid = member?.passphraseHash ? await verifyPassphrase(passphrase, hashToCheck) : false;

  if (!valid) {
    // Vague message — don't reveal whether usertag exists
    res.status(401).json({ error: "Invalid usertag or passphrase." });
    return;
  }

  // Create new session (30-day expiry)
  const now = new Date();
  const token = generateSessionToken();
  const expiresAt = new Date(now.getTime() + SESSION_DURATION_DAYS * 86400 * 1000);

  await db.insert(sessionsTable).values({
    token,
    memberId: member.id,
    expiresAt,
  });

  res.json({
    token,
    passphrase: null,
    member: {
      id: member.id,
      usertag: member.usertag,
      displayName: member.displayName,
      avatarUrl: member.avatarUrl,
      role: member.role,
      joinedAt: member.joinedAt,
      isEarlyMember: member.isEarlyMember,
    },
  });
});

/** GET /auth/me — get current member */
router.get("/auth/me", requireAuth, async (req, res): Promise<void> => {
  const [member] = await db
    .select()
    .from(membersTable)
    .where(eq(membersTable.id, req.memberId!))
    .limit(1);

  if (!member) {
    res.status(401).json({ error: "Authentication required." });
    return;
  }

  res.json({
    id: member.id,
    usertag: member.usertag,
    displayName: member.displayName,
    avatarUrl: member.avatarUrl,
    role: member.role,
    joinedAt: member.joinedAt,
    isEarlyMember: member.isEarlyMember,
  });
});

/** POST /auth/logout — invalidate session */
router.post("/auth/logout", requireAuth, async (req, res): Promise<void> => {
  const token = req.headers["x-session-token"] as string;

  await db
    .delete(sessionsTable)
    .where(eq(sessionsTable.token, token));

  res.sendStatus(204);
});

export default router;
