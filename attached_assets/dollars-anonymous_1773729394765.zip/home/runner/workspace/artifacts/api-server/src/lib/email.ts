/**
 * Email sending via Nodemailer (SMTP).
 * Configure via environment variables:
 *   SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM
 *
 * For VPS hosting, use your own SMTP provider (Postfix, Mailgun, SES, etc.)
 * or set SMTP_* env vars to a transactional email service.
 *
 * If SMTP is not configured, email sending is silently skipped
 * (returns a warning so the admin knows).
 */

import nodemailer from "nodemailer";

function getTransporter() {
  const host = process.env["SMTP_HOST"];
  const port = parseInt(process.env["SMTP_PORT"] ?? "587", 10);
  const user = process.env["SMTP_USER"];
  const pass = process.env["SMTP_PASS"];

  if (!host || !user || !pass) {
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
    // Enforce TLS for security
    tls: { rejectUnauthorized: true },
  });
}

export interface SendInviteOptions {
  recipientEmail: string;
  inviteCode: string;
  personalMessage?: string | null;
  siteUrl: string;
}

export async function sendInviteEmail(
  opts: SendInviteOptions
): Promise<{ sent: boolean; reason?: string }> {
  const transporter = getTransporter();

  if (!transporter) {
    return {
      sent: false,
      reason:
        "SMTP not configured. Set SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS env vars.",
    };
  }

  const from = process.env["SMTP_FROM"] ?? process.env["SMTP_USER"];
  const joinUrl = `${opts.siteUrl}/?code=${opts.inviteCode}`;

  const html = buildInviteEmailHtml({
    inviteCode: opts.inviteCode,
    joinUrl,
    personalMessage: opts.personalMessage,
  });

  await transporter.sendMail({
    from: `"The Dollars" <${from}>`,
    to: opts.recipientEmail,
    subject: "You have been invited.",
    text: buildInviteEmailText({ inviteCode: opts.inviteCode, joinUrl, personalMessage: opts.personalMessage }),
    html,
  });

  return { sent: true };
}

function buildInviteEmailText(opts: {
  inviteCode: string;
  joinUrl: string;
  personalMessage?: string | null;
}): string {
  return [
    "THE DOLLARS",
    "",
    "You have been invited.",
    "",
    opts.personalMessage ? opts.personalMessage : "",
    "",
    `Your invite code: ${opts.inviteCode}`,
    "",
    `Join here: ${opts.joinUrl}`,
    "",
    "This message was sent anonymously. There is no reply address.",
    "You are already one of us.",
  ]
    .filter((line) => line !== undefined)
    .join("\n");
}

function buildInviteEmailHtml(opts: {
  inviteCode: string;
  joinUrl: string;
  personalMessage?: string | null;
}): string {
  const personalMsg = opts.personalMessage
    ? `<p style="color:#a0a0a0;font-size:15px;line-height:1.6;border-left:2px solid #333;padding-left:16px;margin:24px 0;">${escapeHtml(opts.personalMessage)}</p>`
    : "";

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>You have been invited.</title>
</head>
<body style="margin:0;padding:0;background-color:#0a0a0a;font-family:'Courier New',Courier,monospace;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#0a0a0a;padding:40px 0;">
    <tr>
      <td align="center">
        <table width="560" cellpadding="0" cellspacing="0" style="background-color:#111111;border:1px solid #222222;border-radius:4px;overflow:hidden;max-width:560px;">

          <!-- Header bar -->
          <tr>
            <td style="background-color:#0d0d0d;border-bottom:1px solid #1a1a1a;padding:20px 32px;">
              <p style="margin:0;font-size:11px;letter-spacing:4px;color:#444444;text-transform:uppercase;">CLASSIFIED TRANSMISSION</p>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:40px 32px;">
              <h1 style="margin:0 0 8px;font-size:28px;font-weight:700;color:#ffffff;letter-spacing:2px;text-transform:uppercase;">THE DOLLARS</h1>
              <p style="margin:0 0 32px;font-size:13px;color:#444444;letter-spacing:1px;">Anonymous. Connected. Everywhere.</p>

              <p style="color:#888888;font-size:14px;line-height:1.7;margin:0 0 16px;">
                You have been selected to join our network.
              </p>

              ${personalMsg}

              <p style="color:#888888;font-size:14px;line-height:1.7;margin:24px 0 8px;">
                Your access code:
              </p>
              <div style="background-color:#0a0a0a;border:1px solid #2a2a2a;border-radius:3px;padding:16px 20px;margin-bottom:32px;">
                <p style="margin:0;font-size:22px;letter-spacing:6px;color:#ffffff;font-weight:700;">${escapeHtml(opts.inviteCode)}</p>
              </div>

              <table cellpadding="0" cellspacing="0" style="margin-bottom:32px;">
                <tr>
                  <td style="background-color:#ffffff;border-radius:3px;padding:0;">
                    <a href="${escapeHtml(opts.joinUrl)}"
                       style="display:inline-block;padding:14px 32px;font-size:13px;font-weight:700;color:#0a0a0a;text-decoration:none;letter-spacing:2px;text-transform:uppercase;">
                      ENTER THE DOLLARS →
                    </a>
                  </td>
                </tr>
              </table>

              <p style="color:#333333;font-size:11px;line-height:1.6;border-top:1px solid #1a1a1a;padding-top:24px;margin:0;">
                This invitation was sent anonymously. There is no reply address.<br/>
                Do not share this code. It is meant only for you.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color:#0d0d0d;border-top:1px solid #1a1a1a;padding:16px 32px;">
              <p style="margin:0;font-size:10px;color:#2a2a2a;letter-spacing:2px;text-transform:uppercase;">YOU ARE ALREADY ONE OF US</p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;");
}
