/*!
 * IMPORTANT NOTE:
 * 
 *   This file is licensed only for the use of Apple developers in providing MusicKit Web Services,
 *   and is subject to the Apple Media Services Terms and Conditions and the Apple Developer Program
 *   License Agreement. You may not copy, modify, re-host, or create derivative works of this file or the
 *   accompanying Documentation, or any part thereof, including any updates, without Apple's written consent.
 * 
 *   ACKNOWLEDGEMENTS:
 *   https://js-cdn.music.apple.com/musickit/v1/acknowledgements.txt
 */
const e = "musickit-components";
let t, n, l, s = !1,
    o = !1,
    i = !1,
    r = !1,
    c = null,
    f = !1;
const a = {
        isDev: !1,
        isBrowser: !0,
        isServer: !1,
        isTesting: !1
    },
    u = e => {
        const t = new URL(e, ge.t);
        return t.origin !== be.location.origin ? t.href : t.pathname
    },
    d = "http://www.w3.org/1999/xlink",
    $ = {},
    p = e => "object" == (e = typeof e) || "function" === e,
    h = (e, t, ...n) => {
        let l = null,
            s = null,
            o = null,
            i = !1,
            r = !1;
        const c = [],
            f = t => {
                for (let n = 0; n < t.length; n++) l = t[n], Array.isArray(l) ? f(l) : null != l && "boolean" != typeof l && ((i = "function" != typeof e && !p(l)) && (l += ""), i && r ? c[c.length - 1].l += l : c.push(i ? m(null, l) : l), r = i)
            };
        if (f(n), t) {
            t.key && (s = t.key), t.name && (o = t.name); {
                const e = t.className || t.class;
                e && (t.class = "object" != typeof e ? e : Object.keys(e).filter((t => e[t])).join(" "))
            }
        }
        if ("function" == typeof e) return e(null === t ? {} : t, c, b);
        const a = m(e, null);
        return a.o = t, c.length > 0 && (a.i = c), a.u = s, a.$ = o, a
    },
    m = (e, t) => ({
        p: 0,
        h: e,
        l: t,
        m: null,
        i: null,
        o: null,
        u: null,
        $: null
    }),
    y = {},
    b = {
        forEach: (e, t) => e.map(w).forEach(t),
        map: (e, t) => e.map(w).map(t).map(g)
    },
    w = e => ({
        vattrs: e.o,
        vchildren: e.i,
        vkey: e.u,
        vname: e.$,
        vtag: e.h,
        vtext: e.l
    }),
    g = e => {
        if ("function" == typeof e.vtag) {
            const t = Object.assign({}, e.vattrs);
            return e.vkey && (t.key = e.vkey), e.vname && (t.name = e.vname), h(e.vtag, t, ...e.vchildren || [])
        }
        const t = m(e.vtag, e.vtext);
        return t.o = e.vattrs, t.i = e.vchildren, t.u = e.vkey, t.$ = e.vname, t
    },
    v = e => ae(e).g,
    k = (e, t, n) => {
        const l = v(e);
        return {
            emit: e => j(l, t, {
                bubbles: !!(4 & n),
                composed: !!(2 & n),
                cancelable: !!(1 & n),
                detail: e
            })
        }
    },
    j = (e, t, n) => {
        const l = ge.ce(t, n);
        return e.dispatchEvent(l), l
    },
    S = new WeakMap,
    O = e => "sc-" + e.v,
    C = (e, t, n, l, s, o) => {
        if (n !== l) {
            let r = $e(e, t),
                c = t.toLowerCase();
            if ("class" === t) {
                const t = e.classList,
                    s = x(n),
                    o = x(l);
                t.remove(...s.filter((e => e && !o.includes(e)))), t.add(...o.filter((e => e && !s.includes(e))))
            } else if ("style" === t) {
                for (const t in n) l && null != l[t] || (t.includes("-") ? e.style.removeProperty(t) : e.style[t] = "");
                for (const t in l) n && l[t] === n[t] || (t.includes("-") ? e.style.setProperty(t, l[t]) : e.style[t] = l[t])
            } else if ("key" === t);
            else if ("ref" === t) l && l(e);
            else if (r || "o" !== t[0] || "n" !== t[1]) {
                const f = p(l);
                if ((r || f && null !== l) && !s) try {
                    if (e.tagName.includes("-")) e[t] = l;
                    else {
                        const s = null == l ? "" : l;
                        "list" === t ? r = !1 : null != n && e[t] == s || (e[t] = s)
                    }
                } catch (i) {}
                let a = !1;
                c !== (c = c.replace(/^xlink\:?/, "")) && (t = c, a = !0), null == l || !1 === l ? !1 === l && "" !== e.getAttribute(t) || (a ? e.removeAttributeNS(d, t) : e.removeAttribute(t)) : (!r || 4 & o || s) && !f && (l = !0 === l ? "" : l, a ? e.setAttributeNS(d, t, l) : e.setAttribute(t, l))
            } else t = "-" === t[2] ? t.slice(3) : $e(be, c) ? c.slice(2) : c[2] + t.slice(3), n && ge.rel(e, t, n, !1), l && ge.ael(e, t, l, !1)
        }
    },
    M = /\s/,
    x = e => e ? e.split(M) : [],
    R = (e, t, n, l) => {
        const s = 11 === t.m.nodeType && t.m.host ? t.m.host : t.m,
            o = e && e.o || $,
            i = t.o || $;
        for (l in o) l in i || C(s, l, o[l], void 0, n, t.p);
        for (l in i) C(s, l, o[l], i[l], n, t.p)
    },
    T = (e, o, c, f) => {
        const a = o.i[c];
        let u, d, $, p = 0;
        if (s || (i = !0, "slot" === a.h && (t && f.classList.add(t + "-s"), a.p |= a.i ? 2 : 1)), null !== a.l) u = a.m = we.createTextNode(a.l);
        else if (1 & a.p) u = a.m = we.createTextNode("");
        else {
            if (r || (r = "svg" === a.h), u = a.m = we.createElementNS(r ? "http://www.w3.org/2000/svg" : "http://www.w3.org/1999/xhtml", 2 & a.p ? "slot-fb" : a.h), r && "foreignObject" === a.h && (r = !1), R(null, a, r), null != t && u["s-si"] !== t && u.classList.add(u["s-si"] = t), a.i)
                for (p = 0; p < a.i.length; ++p) d = T(e, a, p, u), d && u.appendChild(d);
            "svg" === a.h ? r = !1 : "foreignObject" === u.tagName && (r = !0)
        }
        return u["s-hn"] = l, 3 & a.p && (u["s-sr"] = !0, u["s-cr"] = n, u["s-sn"] = a.$ || "", $ = e && e.i && e.i[c], $ && $.h === a.h && e.m && L(e.m, !1)), u
    },
    L = (e, t) => {
        ge.p |= 1;
        const n = e.childNodes;
        for (let s = n.length - 1; s >= 0; s--) {
            const e = n[s];
            e["s-hn"] !== l && e["s-ol"] && (W(e).insertBefore(e, U(e)), e["s-ol"].remove(), e["s-ol"] = void 0, i = !0), t && L(e, t)
        }
        ge.p &= -2
    },
    N = (e, t, n, s, o, i) => {
        let r, c = e["s-cr"] && e["s-cr"].parentNode || e;
        for (c.shadowRoot && c.tagName === l && (c = c.shadowRoot); o <= i; ++o) s[o] && (r = T(null, n, o, e), r && (s[o].m = r, c.insertBefore(r, U(t))))
    },
    P = (e, t, n, l, s) => {
        for (; t <= n; ++t)(l = e[t]) && (s = l.m, q(l), o = !0, s["s-ol"] ? s["s-ol"].remove() : L(s, !0), s.remove())
    },
    E = (e, t) => e.h === t.h && ("slot" === e.h ? e.$ === t.$ : e.u === t.u),
    U = e => e && e["s-ol"] || e,
    W = e => (e["s-ol"] ? e["s-ol"] : e).parentNode,
    D = (e, t) => {
        const n = t.m = e.m,
            l = e.i,
            s = t.i,
            o = t.h,
            i = t.l;
        let c;
        null === i ? (r = "svg" === o || "foreignObject" !== o && r, "slot" === o || R(e, t, r), null !== l && null !== s ? ((e, t, n, l) => {
            let s, o, i = 0,
                r = 0,
                c = 0,
                f = 0,
                a = t.length - 1,
                u = t[0],
                d = t[a],
                $ = l.length - 1,
                p = l[0],
                h = l[$];
            for (; i <= a && r <= $;)
                if (null == u) u = t[++i];
                else if (null == d) d = t[--a];
            else if (null == p) p = l[++r];
            else if (null == h) h = l[--$];
            else if (E(u, p)) D(u, p), u = t[++i], p = l[++r];
            else if (E(d, h)) D(d, h), d = t[--a], h = l[--$];
            else if (E(u, h)) "slot" !== u.h && "slot" !== h.h || L(u.m.parentNode, !1), D(u, h), e.insertBefore(u.m, d.m.nextSibling), u = t[++i], h = l[--$];
            else if (E(d, p)) "slot" !== u.h && "slot" !== h.h || L(d.m.parentNode, !1), D(d, p), e.insertBefore(d.m, u.m), d = t[--a], p = l[++r];
            else {
                for (c = -1, f = i; f <= a; ++f)
                    if (t[f] && null !== t[f].u && t[f].u === p.u) {
                        c = f;
                        break
                    }
                c >= 0 ? (o = t[c], o.h !== p.h ? s = T(t && t[r], n, c, e) : (D(o, p), t[c] = void 0, s = o.m), p = l[++r]) : (s = T(t && t[r], n, r, e), p = l[++r]), s && W(u.m).insertBefore(s, U(u.m))
            }
            i > a ? N(e, null == l[$ + 1] ? null : l[$ + 1].m, n, l, r, $) : r > $ && P(t, i, a)
        })(n, l, t, s) : null !== s ? (null !== e.l && (n.textContent = ""), N(n, null, t, s, 0, s.length - 1)) : null !== l && P(l, 0, l.length - 1), r && "svg" === o && (r = !1)) : (c = n["s-cr"]) ? c.parentNode.textContent = i : e.l !== i && (n.data = i)
    },
    F = e => {
        const t = e.childNodes;
        let n, l, s, o, i, r;
        for (l = 0, s = t.length; l < s; l++)
            if (n = t[l], 1 === n.nodeType) {
                if (n["s-sr"])
                    for (i = n["s-sn"], n.hidden = !1, o = 0; o < s; o++)
                        if (r = t[o].nodeType, t[o]["s-hn"] !== n["s-hn"] || "" !== i) {
                            if (1 === r && i === t[o].getAttribute("slot")) {
                                n.hidden = !0;
                                break
                            }
                        } else if (1 === r || 3 === r && "" !== t[o].textContent.trim()) {
                    n.hidden = !0;
                    break
                }
                F(n)
            }
    },
    A = [],
    B = e => {
        let t, n, l, s, i, r, c = 0;
        const f = e.childNodes,
            a = f.length;
        for (; c < a; c++) {
            if (t = f[c], t["s-sr"] && (n = t["s-cr"]) && n.parentNode)
                for (l = n.parentNode.childNodes, s = t["s-sn"], r = l.length - 1; r >= 0; r--) n = l[r], n["s-cn"] || n["s-nr"] || n["s-hn"] === t["s-hn"] || (H(n, s) ? (i = A.find((e => e.k === n)), o = !0, n["s-sn"] = n["s-sn"] || s, i ? i.j = t : A.push({
                    j: t,
                    k: n
                }), n["s-sr"] && A.map((e => {
                    H(e.k, n["s-sn"]) && (i = A.find((e => e.k === n)), i && !e.j && (e.j = i.j))
                }))) : A.some((e => e.k === n)) || A.push({
                    k: n
                }));
            1 === t.nodeType && B(t)
        }
    },
    H = (e, t) => 1 === e.nodeType ? null === e.getAttribute("slot") && "" === t || e.getAttribute("slot") === t : e["s-sn"] === t || "" === t,
    q = e => {
        e.o && e.o.ref && e.o.ref(null), e.i && e.i.map(q)
    },
    V = (e, t) => {
        t && !e.S && t["s-p"] && t["s-p"].push(new Promise((t => e.S = t)))
    },
    _ = (e, t) => {
        if (e.p |= 16, !(4 & e.p)) return V(e, e.O), Re((() => z(e, t)));
        e.p |= 512
    },
    z = (e, t) => {
        const n = e.C;
        let l;
        return t ? (e.p |= 256, e.M && (e.M.map((([e, t]) => Y(n, e, t))), e.M = null), l = Y(n, "componentWillLoad")) : l = Y(n, "componentWillUpdate"), Z(l, (() => G(e, n, t)))
    },
    G = async (e, t, n) => {
        const l = e.g,
            s = l["s-rc"];
        n && (e => {
            const t = e.R,
                n = e.g,
                l = t.p,
                s = ((e, t) => {
                    let n = O(t);
                    const l = ye.get(n);
                    if (e = 11 === e.nodeType ? e : we, l)
                        if ("string" == typeof l) {
                            let t, s = S.get(e = e.head || e);
                            s || S.set(e, s = new Set), s.has(n) || (t = we.createElement("style"), t.innerHTML = l, e.insertBefore(t, e.querySelector("link")), s && s.add(n))
                        } else e.adoptedStyleSheets.includes(l) || (e.adoptedStyleSheets = [...e.adoptedStyleSheets, l]);
                    return n
                })(n.shadowRoot ? n.shadowRoot : n.getRootNode(), t);
            10 & l && (n["s-sc"] = s, n.classList.add(s + "-h"), 2 & l && n.classList.add(s + "-s"))
        })(e);
        I(e, t), s && (s.map((e => e())), l["s-rc"] = void 0); {
            const t = l["s-p"],
                n = () => K(e);
            0 === t.length ? n() : (Promise.all(t).then(n), e.p |= 4, t.length = 0)
        }
    },
    I = (e, r) => {
        try {
            c = r, r = r.render(), e.p &= -17, e.p |= 2, ((e, r) => {
                const c = e.g,
                    f = e.R,
                    a = e.T || m(null, null),
                    u = (e => e && e.h === y)(r) ? r : h(null, null, r);
                if (l = c.tagName, f.L && (u.o = u.o || {}, f.L.map((([e, t]) => u.o[t] = c[e]))), u.h = null, u.p |= 4, e.T = u, u.m = a.m = c.shadowRoot || c, t = c["s-sc"], n = c["s-cr"], s = 0 != (1 & f.p), o = !1, D(a, u), ge.p |= 1, i) {
                    let e, t, n, l, s, o;
                    B(u.m);
                    let i = 0;
                    for (; i < A.length; i++) e = A[i], t = e.k, t["s-ol"] || (n = we.createTextNode(""), n["s-nr"] = t, t.parentNode.insertBefore(t["s-ol"] = n, t));
                    for (i = 0; i < A.length; i++)
                        if (e = A[i], t = e.k, e.j) {
                            for (l = e.j.parentNode, s = e.j.nextSibling, n = t["s-ol"]; n = n.previousSibling;)
                                if (o = n["s-nr"], o && o["s-sn"] === t["s-sn"] && l === o.parentNode && (o = o.nextSibling, !o || !o["s-nr"])) {
                                    s = o;
                                    break
                                }(!s && l !== t.parentNode || t.nextSibling !== s) && t !== s && (!t["s-hn"] && t["s-ol"] && (t["s-hn"] = t["s-ol"].parentNode.nodeName), l.insertBefore(t, s))
                        } else 1 === t.nodeType && (t.hidden = !0)
                }
                o && F(u.m), ge.p &= -2, A.length = 0
            })(e, r)
        } catch (f) {
            pe(f, e.g)
        }
        return c = null, null
    },
    J = () => c,
    K = e => {
        const t = e.g,
            n = e.C,
            l = e.O;
        Y(n, "componentDidRender"), 64 & e.p || (e.p |= 64, ee(t), Y(n, "componentDidLoad"), e.N(t), l || X()), e.P(t), e.S && (e.S(), e.S = void 0), 512 & e.p && xe((() => _(e, !1))), e.p &= -517
    },
    Q = e => {
        {
            const t = ae(e),
                n = t.g.isConnected;
            return n && 2 == (18 & t.p) && _(t, !1), n
        }
    },
    X = () => {
        ee(we.documentElement), xe((() => j(be, "appload", {
            detail: {
                namespace: e
            }
        })))
    },
    Y = (e, t, n) => {
        if (e && e[t]) try {
            return e[t](n)
        } catch (l) {
            pe(l)
        }
    },
    Z = (e, t) => e && e.then ? e.then(t) : t(),
    ee = e => e.setAttribute("hydrated", ""),
    te = (e, t, n) => {
        if (t.U) {
            e.watchers && (t.W = e.watchers);
            const l = Object.entries(t.U),
                s = e.prototype;
            if (l.map((([e, [l]]) => {
                    31 & l || 2 & n && 32 & l ? Object.defineProperty(s, e, {
                        get() {
                            return ((e, t) => ae(this).D.get(t))(0, e)
                        },
                        set(n) {
                            ((e, t, n, l) => {
                                const s = ae(e),
                                    o = s.g,
                                    i = s.D.get(t),
                                    r = s.p,
                                    c = s.C;
                                if (n = ((e, t) => null == e || p(e) ? e : 4 & t ? "false" !== e && ("" === e || !!e) : 2 & t ? parseFloat(e) : 1 & t ? e + "" : e)(n, l.U[t][0]), (!(8 & r) || void 0 === i) && n !== i && (!Number.isNaN(i) || !Number.isNaN(n)) && (s.D.set(t, n), c)) {
                                    if (l.W && 128 & r) {
                                        const e = l.W[t];
                                        e && e.map((e => {
                                            try {
                                                c[e](n, i, t)
                                            } catch (l) {
                                                pe(l, o)
                                            }
                                        }))
                                    }
                                    if (2 == (18 & r)) {
                                        if (c.componentShouldUpdate && !1 === c.componentShouldUpdate(n, i, t)) return;
                                        _(s, !1)
                                    }
                                }
                            })(this, e, n, t)
                        },
                        configurable: !0,
                        enumerable: !0
                    }) : 1 & n && 64 & l && Object.defineProperty(s, e, {
                        value(...t) {
                            const n = ae(this);
                            return n.F.then((() => n.C[e](...t)))
                        }
                    })
                })), 1 & n) {
                const n = new Map;
                s.attributeChangedCallback = function(e, t, l) {
                    ge.jmp((() => {
                        const t = n.get(e);
                        if (this.hasOwnProperty(t)) l = this[t], delete this[t];
                        else if (s.hasOwnProperty(t) && "number" == typeof this[t] && this[t] == l) return;
                        this[t] = (null !== l || "boolean" != typeof this[t]) && l
                    }))
                }, e.observedAttributes = l.filter((([e, t]) => 15 & t[0])).map((([e, l]) => {
                    const s = l[1] || e;
                    return n.set(s, e), 512 & l[0] && t.L.push([e, s]), s
                }))
            }
        }
        return e
    },
    ne = e => {
        Y(e, "connectedCallback")
    },
    le = (e, t = {}) => {
        const n = [],
            l = t.exclude || [],
            s = be.customElements,
            o = we.head,
            i = o.querySelector("meta[charset]"),
            r = we.createElement("style"),
            c = [];
        let f, a = !0;
        Object.assign(ge, t), ge.t = new URL(t.resourcesUrl || "./", we.baseURI).href, e.map((e => {
            e[1].map((t => {
                const o = {
                    p: t[0],
                    v: t[1],
                    U: t[2],
                    A: t[3]
                };
                o.U = t[2], o.A = t[3], o.L = [], o.W = {};
                const i = o.v,
                    r = class extends HTMLElement {
                        constructor(e) {
                            super(e), de(e = this, o), 1 & o.p && e.attachShadow({
                                mode: "open"
                            })
                        }
                        connectedCallback() {
                            f && (clearTimeout(f), f = null), a ? c.push(this) : ge.jmp((() => (e => {
                                if (0 == (1 & ge.p)) {
                                    const t = ae(e),
                                        n = t.R,
                                        l = () => {};
                                    if (1 & t.p) oe(e, t, n.A), ne(t.C);
                                    else {
                                        t.p |= 1, 12 & n.p && (e => {
                                            const t = e["s-cr"] = we.createComment("");
                                            t["s-cn"] = !0, e.insertBefore(t, e.firstChild)
                                        })(e); {
                                            let n = e;
                                            for (; n = n.parentNode || n.host;)
                                                if (n["s-p"]) {
                                                    V(t, t.O = n);
                                                    break
                                                }
                                        }
                                        n.U && Object.entries(n.U).map((([t, [n]]) => {
                                            if (31 & n && e.hasOwnProperty(t)) {
                                                const n = e[t];
                                                delete e[t], e[t] = n
                                            }
                                        })), (async (e, t, n, l, s) => {
                                            if (0 == (32 & t.p)) {
                                                {
                                                    if (t.p |= 32, (s = me(n)).then) {
                                                        const e = () => {};
                                                        s = await s, e()
                                                    }
                                                    s.isProxied || (n.W = s.watchers, te(s, n, 2), s.isProxied = !0);
                                                    const e = () => {};
                                                    t.p |= 8;
                                                    try {
                                                        new s(t)
                                                    } catch (r) {
                                                        pe(r)
                                                    }
                                                    t.p &= -9, t.p |= 128, e(), ne(t.C)
                                                }
                                                if (s.style) {
                                                    let e = s.style;
                                                    const t = O(n);
                                                    if (!ye.has(t)) {
                                                        const l = () => {};
                                                        ((e, t, n) => {
                                                            let l = ye.get(e);
                                                            ke && n ? (l = l || new CSSStyleSheet, "string" == typeof l ? l = t : l.replaceSync(t)) : l = t, ye.set(e, l)
                                                        })(t, e, !!(1 & n.p)), l()
                                                    }
                                                }
                                            }
                                            const o = t.O,
                                                i = () => _(t, !0);
                                            o && o["s-rc"] ? o["s-rc"].push(i) : i()
                                        })(0, t, n)
                                    }
                                    l()
                                }
                            })(this)))
                        }
                        disconnectedCallback() {
                            ge.jmp((() => (() => {
                                if (0 == (1 & ge.p)) {
                                    const e = ae(this),
                                        t = e.C;
                                    e.B && (e.B.map((e => e())), e.B = void 0), Y(t, "disconnectedCallback")
                                }
                            })()))
                        }
                        componentOnReady() {
                            return ae(this).H
                        }
                    };
                o.q = e[0], l.includes(i) || s.get(i) || (n.push(i), s.define(i, te(r, o, 1)))
            }))
        })), r.innerHTML = n + "{visibility:hidden}[hydrated]{visibility:inherit}", r.setAttribute("data-styles", ""), o.insertBefore(r, i ? i.nextSibling : o.firstChild), a = !1, c.length ? c.map((e => e.connectedCallback())) : ge.jmp((() => f = setTimeout(X, 30)))
    },
    se = (e, t) => t,
    oe = (e, t, n) => {
        n && n.map((([n, l, s]) => {
            const o = re(e, n),
                i = ie(t, s),
                r = ce(n);
            ge.ael(o, l, i, r), (t.B = t.B || []).push((() => ge.rel(o, l, i, r)))
        }))
    },
    ie = (e, t) => n => {
        try {
            256 & e.p ? e.C[t](n) : (e.M = e.M || []).push([t, n])
        } catch (l) {
            pe(l)
        }
    },
    re = (e, t) => 8 & t ? be : e,
    ce = e => 0 != (2 & e),
    fe = new WeakMap,
    ae = e => fe.get(e),
    ue = (e, t) => fe.set(t.C = e, t),
    de = (e, t) => {
        const n = {
            p: 0,
            g: e,
            R: t,
            D: new Map
        };
        return n.F = new Promise((e => n.P = e)), n.H = new Promise((e => n.N = e)), e["s-p"] = [], e["s-rc"] = [], oe(e, n, t.A), fe.set(e, n)
    },
    $e = (e, t) => t in e,
    pe = (e, t) => (0, console.error)(e, t),
    he = new Map,
    me = e => {
        const t = e.v.replace(/-/g, "_"),
            n = e.q,
            l = he.get(n);
        return l ? l[t] : import (`./${n}.entry.js`).then((e => (he.set(n, e), e[t])), pe)
        /*!__STENCIL_STATIC_IMPORT_SWITCH__*/
    },
    ye = new Map,
    be = "undefined" != typeof window ? window : {},
    we = be.document || {
        head: {}
    },
    ge = {
        p: 0,
        t: "",
        jmp: e => e(),
        raf: e => requestAnimationFrame(e),
        ael: (e, t, n, l) => e.addEventListener(t, n, l),
        rel: (e, t, n, l) => e.removeEventListener(t, n, l),
        ce: (e, t) => new CustomEvent(e, t)
    },
    ve = e => Promise.resolve(e),
    ke = (() => {
        try {
            return new CSSStyleSheet, "function" == typeof(new CSSStyleSheet).replaceSync
        } catch (e) {}
        return !1
    })(),
    je = [],
    Se = [],
    Oe = (e, t) => n => {
        e.push(n), f || (f = !0, t && 4 & ge.p ? xe(Me) : ge.raf(Me))
    },
    Ce = e => {
        for (let n = 0; n < e.length; n++) try {
            e[n](performance.now())
        } catch (t) {
            pe(t)
        }
        e.length = 0
    },
    Me = () => {
        Ce(je), Ce(Se), (f = je.length > 0) && ge.raf(Me)
    },
    xe = e => ve().then(e),
    Re = Oe(Se, !0);
export {
    a as B, se as F, y as H, e as N, u as a, le as b, v as c, we as d, k as e, Q as f, J as g, h, ve as p, ue as r, be as w
}