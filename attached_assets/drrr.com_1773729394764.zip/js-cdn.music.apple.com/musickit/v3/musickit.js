/**
 * IMPORTANT NOTE:
 *
 * This file is licensed only for the use of Apple developers in providing MusicKit Web Services,
 * and is subject to the Apple Media Services Terms and Conditions and the Apple Developer Program
 * License Agreement. You may not copy, modify, re-host, or create derivative works of this file or the
 * accompanying Documentation, or any part thereof, including any updates, without Apple's written consent.
 *
 * ACKNOWLEDGEMENTS:
 * https://js-cdn.music.apple.com/musickit/v1/acknowledgements.txt
 */

! function(e, n) {
    "object" == typeof exports && "undefined" != typeof module ? n(exports) : "function" == typeof define && define.amd ? define(["exports"], n) : n((e = "undefined" != typeof globalThis ? globalThis : e || self).MusicKit = {})
}(this, (function(e) {
    "use strict";
    void 0 !== typeof self && self;

    function formatArtworkURL(e, n, s) {
        return n = n || e.height || 100, s = s || e.width || 100, window.devicePixelRatio >= 1.5 && (s *= 2, n *= 2), e.url.replace("{h}", "" + n).replace("{w}", "" + s).replace("{f}", "jpeg")
    }
    const K = () => {},
        asAsync = e => {
            e.then(K, K)
        },
        n = /\/(?:([a-z]{2})\/)?(album|artist|episode|movie|music-video|playlist|podcast|post|season|show|song|station)\/(?:[^/]*\/)?(?:id)?(\d+|[a-z]{2}\.[a-z0-9-]+|umc.cmc.[a-zA-Z0-9]+)(?:.*(?:[?|&]i=(\d+)).*)?.*$/i;

    function parseMediaURL(e) {
        const s = e.match(n) || [];
        let [, d, p, h, y] = s;
        "music-video" === p && (p = "musicVideo"), -1 !== ["album", "playlist"].indexOf(p) && y ? (p = "song", h = y) : "podcast" === p && y && (p = "episode", h = y);
        return {
            storefrontId: d,
            kind: p,
            contentId: h,
            itemId: y
        }
    }

    function formattedMediaURL(e) {
        const n = parseMediaURL(e),
            {
                storefrontId: s,
                kind: d,
                contentId: p
            } = n;
        if ([s, d, p].some(e => void 0 === e)) throw new TypeError("Invalid Media URL: " + e);
        const h = !!p && p.startsWith("umc.");
        return {
            storefrontId: s,
            kind: d,
            contentId: p,
            isUTS: h
        }
    }
    const s = /^http(?:s)?\:\/\/(?:itunes|(embed\.)?(music|podcasts|tv))\.apple\.com/i,
        d = ["allow-forms", "allow-popups", "allow-same-origin", "allow-scripts", "allow-storage-access-by-user-activation", "allow-top-navigation-by-user-activation"],
        p = ["autoplay *", "encrypted-media *", "fullscreen *", "clipboard-write"];

    function dasherize(e) {
        return e.replace(/([A-Z])/g, "-$1").replace(/[-_\s]+/g, "-").replace(/(^-+)|(-+$)/, "").toLowerCase()
    }
    const h = new Map;

    function pluralizeMediaType(e) {
        if (h.has(e)) return h.get(e);
        let n = dasherize(e);
        return e.endsWith("y") ? n = n.substring(0, n.length - 1) + "ies" : n.endsWith("s") || (n += "s"), h.set(e, n), n
    }

    function normalizeMediaType(e) {
        return pluralizeMediaType(e)
    }
    const y = ["contributors", "modalities", "movie", "musicVideo", "musicMovie", "trailer", "tvEpisode", "uploadedVideo", "uploaded-videos", "music-videos", "music-movies", "tv-episodes", "workouts"];

    function isVideo(e) {
        var n;
        return null != e && (!0 === e.isUTS || y.includes(e.type) || "video" === (null === (n = e.attributes) || void 0 === n ? void 0 : n.mediaKind))
    }

    function isLive(e) {
        var n;
        return !!(null == e || null === (n = e.attributes) || void 0 === n ? void 0 : n.isLive)
    }

    function isStream$1(e) {
        var n, s;
        return "stream" === (null == e || null === (s = e.attributes) || void 0 === s || null === (n = s.playParams) || void 0 === n ? void 0 : n.format)
    }

    function isTracksRadioStation(e) {
        var n, s;
        return "tracks" === (null == e || null === (s = e.attributes) || void 0 === s || null === (n = s.playParams) || void 0 === n ? void 0 : n.format)
    }

    function isAlgoStation(e) {
        return function(...e) {
            return isTracksRadioStation(...e)
        }(e)
    }

    function isRadioStation(e, n) {
        var s, d, p;
        return "radioStation" === (null == e || null === (d = e.attributes) || void 0 === d || null === (s = d.playParams) || void 0 === s ? void 0 : s.kind) && (void 0 === n || (null === (p = e.attributes) || void 0 === p ? void 0 : p.mediaKind) === n)
    }

    function isRadioEpisode(e, n) {
        var s;
        return isRadioStation(e, n) && isStream$1(e) && !isLive(e) && "Episode" === (null == e || null === (s = e.attributes) || void 0 === s ? void 0 : s.streamingRadioSubType)
    }

    function isLiveRadioStation(e, n) {
        return isRadioStation(e, n) && isLive(e) && isStream$1(e)
    }

    function isLiveRadioKind(e, n) {
        return isLiveRadioStation(e, n)
    }

    function _define_property$1Y(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const _ = {
            INVALID_ERROR_ID: "INVALID_ERROR_ID",
            INVALID_ERROR_REASON: "INVALID_ERROR_REASON",
            ACCESS_DENIED: "ACCESS_DENIED",
            AGE_GATE: "AGE_GATE",
            AUTHORIZATION_ERROR: "AUTHORIZATION_ERROR",
            BUFFER_STALLED_ERROR: "BUFFER_STALLED_ERROR",
            CONFIGURATION_ERROR: "CONFIGURATION_ERROR",
            CONTENT_EQUIVALENT: "CONTENT_EQUIVALENT",
            CONTENT_RESTRICTED: "CONTENT_RESTRICTED",
            CONTENT_UNAVAILABLE: "CONTENT_UNAVAILABLE",
            CONTENT_UNSUPPORTED: "CONTENT_UNSUPPORTED",
            DEVICE_LIMIT: "DEVICE_LIMIT",
            GEO_BLOCK: "GEO_BLOCK",
            INVALID_ARGUMENTS: "INVALID_ARGUMENTS",
            PLAYREADY_CBC_ENCRYPTION_ERROR: "PLAYREADY_CBC_ENCRYPTION_ERROR",
            MEDIA_CERTIFICATE: "MEDIA_CERTIFICATE",
            MEDIA_DESCRIPTOR: "MEDIA_DESCRIPTOR",
            MEDIA_LICENSE: "MEDIA_LICENSE",
            MEDIA_KEY: "MEDIA_KEY",
            MEDIA_PLAYBACK: "MEDIA_PLAYBACK",
            MEDIA_SESSION: "MEDIA_SESSION",
            NETWORK_ERROR: "NETWORK_ERROR",
            NOT_FOUND: "NOT_FOUND",
            NOT_IMPLEMENTED: "NOT_IMPLEMENTED",
            PARSE_ERROR: "PARSE_ERROR",
            PLAY_ACTIVITY: "PLAY_ACTIVITY",
            REQUEST_ERROR: "REQUEST_ERROR",
            QUOTA_EXCEEDED: "QUOTA_EXCEEDED",
            SERVER_ERROR: "SERVER_ERROR",
            SERVICE_UNAVAILABLE: "SERVICE_UNAVAILABLE",
            STREAM_UPSELL: "STREAM_UPSELL",
            SUBSCRIPTION_ERROR: "SUBSCRIPTION_ERROR",
            TOKEN_EXPIRED: "TOKEN_EXPIRED",
            UNAUTHORIZED_ERROR: "UNAUTHORIZED_ERROR",
            UNKNOWN_ERROR: "UNKNOWN_ERROR",
            UNSUPPORTED_ERROR: "UNSUPPORTED_ERROR",
            USER_INTERACTION_REQUIRED: "USER_INTERACTION_REQUIRED",
            INTERNAL_ERROR: "INTERNAL_ERROR",
            OUTPUT_RESTRICTED: "OUTPUT_RESTRICTED",
            WIDEVINE_CDM_EXPIRED: "WIDEVINE_CDM_EXPIRED"
        },
        m = {
            400: _.REQUEST_ERROR,
            401: _.UNAUTHORIZED_ERROR,
            403: _.ACCESS_DENIED,
            404: _.NOT_FOUND,
            405: _.NOT_FOUND,
            413: _.REQUEST_ERROR,
            414: _.REQUEST_ERROR,
            429: _.QUOTA_EXCEEDED,
            500: _.SERVER_ERROR,
            501: _.NOT_FOUND,
            503: _.SERVICE_UNAVAILABLE
        },
        v = {
            "-1003": _.MEDIA_LICENSE,
            "-1004": _.DEVICE_LIMIT,
            "-1017": _.GEO_BLOCK,
            1010: _.NOT_FOUND,
            2002: _.AUTHORIZATION_ERROR,
            2034: _.TOKEN_EXPIRED,
            3059: _.DEVICE_LIMIT,
            3063: _.SUBSCRIPTION_ERROR,
            3076: _.CONTENT_UNAVAILABLE,
            3082: _.CONTENT_RESTRICTED,
            3084: _.STREAM_UPSELL,
            5002: _.SERVER_ERROR,
            180202: _.PLAYREADY_CBC_ENCRYPTION_ERROR,
            190121: _.WIDEVINE_CDM_EXPIRED
        },
        g = new Set([_.CONTENT_EQUIVALENT, _.CONTENT_UNAVAILABLE, _.CONTENT_UNSUPPORTED, _.SERVER_ERROR, _.SUBSCRIPTION_ERROR, _.UNSUPPORTED_ERROR, _.USER_INTERACTION_REQUIRED]);
    class MKError extends Error {
        static isMKError(e) {
            return function(e) {
                return void 0 !== e && e instanceof MKError
            }(e)
        }
        get errorCode() {
            return this.reason
        }
        static playActivityError(e) {
            return new this(_.PLAY_ACTIVITY, e)
        }
        static parseError(e) {
            return new this(_.PARSE_ERROR, e)
        }
        static responseError(e) {
            const {
                status: n,
                statusText: s
            } = e, d = new this(m[n] || _.NETWORK_ERROR, s || "" + n);
            return d.data = e, d
        }
        static serverError(e, n = _.UNKNOWN_ERROR) {
            let {
                status: s,
                dialog: d,
                failureType: p,
                customerMessage: h,
                errorMessage: y,
                message: m
            } = e;
            d && (m = d.message || d.customerMessage || d.errorMessage, d.message = m);
            const g = v[p] || v[s] || n,
                b = new this(g, m || h || y);
            return g === _.STREAM_UPSELL && d && d.okButtonAction && d.okButtonAction.url && (d.okButtonAction.url = d.okButtonAction.url.replace(/\&(?:challenge|key-system|uri|user-initiated)=[^\&]+/gim, "")), b.dialog = d, b
        }
        static internalError(e) {
            return new this(_.INTERNAL_ERROR, e)
        }
        constructor(e, n) {
            super(), _define_property$1Y(this, "isMKError", !0), _define_property$1Y(this, "reason", _.UNKNOWN_ERROR), _define_property$1Y(this, "description", void 0), _define_property$1Y(this, "dialog", void 0), _define_property$1Y(this, "data", void 0), e && g.has(e) ? (this.name = this.reason = e, this.message = this.description = n || e) : n || "string" != typeof e ? (this.name = this.reason = e || _.UNKNOWN_ERROR, n && (this.message = this.description = n)) : (this.name = this.reason = _.UNKNOWN_ERROR, this.message = this.description = e), Error.captureStackTrace && Error.captureStackTrace(this, MKError)
        }
    }
    _define_property$1Y(MKError, "Reason", _), Object.assign(MKError, _);
    class GenericStorage {
        get data() {
            return this._data
        }
        set data(e) {
            this._data = e
        }
        get length() {
            return this.keys.length
        }
        get keys() {
            return Object.keys(this.data)
        }
        getItem(e) {
            return this.data[e] || null
        }
        setItem(e, n) {
            this.data[e] = n
        }
        removeItem(e) {
            delete this.data[e]
        }
        clear() {
            this.keys.forEach(e => this.removeItem(e))
        }
        key(e) {
            return this.keys[e] || null
        }
        constructor(e = {}) {
            var n, s, d;
            d = void 0, (s = "_data") in (n = this) ? Object.defineProperty(n, s, {
                value: d,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : n[s] = d, this.data = e
        }
    }

    function getCookie(e = "", n = document.cookie) {
        const s = n.match(new RegExp(`(?:^|;\\s*)${e}=([^;]*)`));
        if (s) return s[1]
    }

    function setCookie(e, n, s = "", d = 14, p, h) {
        const y = new Date;
        p = null != p ? p : window;
        const _ = (h = null != h ? h : /\./.test(p.location.hostname) ? p.location.hostname : "").length > 0 ? `domain=${h}; ` : "";
        y.setTime(y.getTime() + 24 * d * 60 * 60 * 1e3);
        let m = "";
        "https:" === p.location.protocol && (m = "; secure"), p.document.cookie = `${e}=${n}; expires=${y.toUTCString()}; ${_}path=${s}${m}`
    }

    function removeCookie(e, n, s) {
        setCookie(e, "", "/", 0, n, s)
    }

    function hasSessionStorage() {
        let e = !1;
        try {
            e = "undefined" != typeof sessionStorage
        } catch (Rt) {}
        return e
    }

    function getSessionStorage() {
        let e;
        return hasSessionStorage() && (e = sessionStorage), e
    }

    function hasLocalStorage() {
        let e = !1;
        try {
            e = "undefined" != typeof localStorage
        } catch (Rt) {}
        return e
    }

    function getLocalStorage() {
        let e;
        return hasLocalStorage() && (e = localStorage), e
    }

    function getJsonFromLocalStorage(e) {
        const n = function(e) {
            if (!hasLocalStorage()) return;
            const n = getLocalStorage().getItem(e);
            return null !== n ? n : void 0
        }(e);
        if (n) try {
            return JSON.parse(n)
        } catch (Rt) {
            return
        }
    }

    function _define_property$1W(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class Notifications {
        get shouldStorageDispatch() {
            return "undefined" != typeof window && hasSessionStorage() && this.dispatchNamespace
        }
        addEventListener(e, n) {
            Array.isArray(this._eventRegistry[e]) && this._eventRegistry[e].push(n)
        }
        dispatchEvent(e, n) {
            Array.isArray(this._eventRegistry[e]) && this._eventRegistry[e].forEach(e => e(n))
        }
        dispatchDistributedEvent(e, n) {
            if (this.dispatchEvent(e, n), this.shouldStorageDispatch) {
                var s;
                const d = `${this.dispatchNamespace}:${e}`;
                null === (s = getSessionStorage()) || void 0 === s || s.setItem(d, JSON.stringify(n))
            }
        }
        removeEventListener(e, n) {
            if (Array.isArray(this._eventRegistry[e])) {
                const s = this._eventRegistry[e].indexOf(n);
                this._eventRegistry[e].splice(s, 1)
            }
        }
        _handleGlobalStorageEvent(e) {
            var n;
            if (this.dispatchNamespace && (null === (n = e.key) || void 0 === n ? void 0 : n.startsWith(this.dispatchNamespace + ":"))) {
                const n = e.key.substring(this.dispatchNamespace.length + 1);
                this.dispatchEvent(n, JSON.parse(e.newValue))
            }
        }
        constructor(e = [], n) {
            _define_property$1W(this, "dispatchNamespace", void 0), _define_property$1W(this, "_eventRegistry", {}), e.forEach(e => {
                this._eventRegistry[e] = []
            }), n && n.namespace && (this.dispatchNamespace = "com.apple." + n.namespace), this.shouldStorageDispatch && (this._handleGlobalStorageEvent = this._handleGlobalStorageEvent.bind(this), window.addEventListener("storage", this._handleGlobalStorageEvent))
        }
    }
    var b = "undefined" != typeof FastBoot ? FastBoot.require("buffer").Buffer : "undefined" != typeof process && null !== process.versions && null !== process.versions.node ? Buffer : window.Buffer;

    function memoize(e) {
        return function(...n) {
            let s = "",
                d = n.length;
            for (e._memoized = e._memoized || {}; d--;) {
                const e = n[d];
                s += e === Object(e) ? JSON.stringify(e) : e
            }
            return s in e._memoized ? e._memoized[s] : e._memoized[s] = e(...n)
        }
    }

    function generateUUID() {
        let e = strRandomizer() + strRandomizer();
        for (; e.length < 16;) e += strRandomizer();
        return e.slice(0, 16)
    }

    function strRandomizer() {
        return Math.random().toString(16).substring(2)
    }

    function isLibraryType(e) {
        if (void 0 === e) return !1;
        const n = "string" == typeof e ? e : e.id;
        return /^[a|i|l|p]{1}\.[a-zA-Z0-9]+$/.test(n)
    }
    const S = memoize(e => /^(a\.)?[a-zA-Z0-9]+$/.test(e));

    function detectNodeEnvironment() {
        var e, n, s, d;
        return void 0 !== (null === (s = globalThis) || void 0 === s || null === (n = s.process) || void 0 === n || null === (e = n.versions) || void 0 === e ? void 0 : e.node) || void 0 !== (null === (d = globalThis) || void 0 === d ? void 0 : d.FastBoot)
    }

    function isNodeEnvironment$1() {
        return detectNodeEnvironment()
    }
    const P = memoize(detectNodeEnvironment() ? e => b.from(e, "base64").toString("binary") : e => window.atob(e));
    memoize(detectNodeEnvironment() ? e => b.from(e).toString("base64") : e => window.btoa(e));
    const debounce = (e, n = 250, s = {
            isImmediate: !1
        }) => {
            let d;
            return function(...p) {
                const h = this,
                    y = s.isImmediate && void 0 === d;
                void 0 !== d && clearTimeout(d), d = setTimeout((function() {
                    d = void 0, s.isImmediate || e.apply(h, p)
                }), n), y && e.apply(h, p)
            }
        },
        arrayEquals = (e, n) => !!e && !!n && [].every.call(e, (e, s) => e === n[s]);

    function hasOwn(e, n) {
        return Object.prototype.hasOwnProperty.call(Object(e), n)
    }

    function deepClone(e) {
        const n = Object.prototype.toString.call(e).toLowerCase().slice(8, -1);
        switch (n) {
            case "set":
                return new Set([...e].map(e => deepClone(e)));
            case "map":
                return new Map([...e].map(([e, n]) => [deepClone(e), deepClone(n)]));
            case "date":
                return new Date(e.getTime());
            case "regexp":
                {
                    const n = e,
                        s = "string" == typeof n.flags ? n.flags : [n.global ? "g" : void 0, n.ignoreCase ? "i" : void 0, n.multiline ? "m" : void 0, n.sticky ? "y" : void 0, n.unicode ? "u" : void 0].filter(e => void 0 !== e).join("");
                    return RegExp(e.source, s)
                }
            case "arraybuffer":
                {
                    const n = e;
                    if ("function" == typeof n.slice) return n.slice(0); {
                        const s = new e.constructor(n.byteLength);
                        return new Uint8Array(s).set(new Uint8Array(n)), s
                    }
                }
            case "dataview":
            case "int8array":
            case "uint8array":
            case "uint8clampedarray":
            case "int16array":
            case "uint16array":
            case "int32array":
            case "uint32array":
            case "float32array":
            case "float64array":
            case "bigint64array":
            case "biguint64array":
                {
                    const s = e;
                    return new(0, s.constructor)(deepClone(s.buffer), s.byteOffset, "dataview" === n ? s.byteLength : s.length)
                }
            case "array":
            case "object":
                {
                    const n = Array.isArray(e) ? [] : {};
                    for (const s in e) hasOwn(e, s) && (n[s] = deepClone(e[s]));
                    return n
                }
            default:
                return e
        }
    }

    function isEmpty(e) {
        if ("object" != typeof e) throw new TypeError("Source is not an Object");
        for (const n in e)
            if (hasOwn(e, n)) return !1;
        return !0
    }

    function transform$a(e, n, s = !1) {
        return s && (e = Object.keys(e).reduce((n, s) => (n[e[s]] = s, n), {})), Object.keys(e).reduce((s, d) => {
            const p = e[d],
                h = "function" == typeof p ? p() : function(e, n) {
                    return n.split(".").reduce((e, n) => {
                        if (void 0 !== e) return e[n]
                    }, e)
                }(n, p);
            return h && function(e, n, s) {
                n.split(".").reduce((n, d, p, h) => {
                    const y = p === h.length - 1,
                        _ = hasOwn(n, d),
                        m = n[d] instanceof Object,
                        v = null === n[d];
                    if (!y && _ && (!m || v)) throw new TypeError(`Value at ${h.slice(0,p+1).join(".")} in keypath is not an Object.`);
                    return y ? (n[d] = s, e) : _ ? n[d] : n[d] = {}
                }, e)
            }(s, d, h), s
        }, {})
    }
    const k = {};

    function findOrCreate(e, n) {
        const s = e.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, (e, n) => n.toUpperCase());
        if (hasOwn(k, s)) {
            const d = k[s];
            if (n !== d.constructor) throw new Error(`DevFlag ${e} was already registered with a different type (${d.constructor.name})`);
            return d
        }
        const d = new n(e);
        return Object.defineProperty(k, s, {
            configurable: !0,
            enumerable: !0,
            get: function() {
                return d
            },
            set: function(e) {
                d.set(e)
            }
        }), d
    }
    class LocalStorageDevFlag {
        get value() {
            return this.get()
        }
        get configured() {
            return void 0 !== this.value
        }
        read() {
            var e, n;
            const s = null !== (n = null === (e = getLocalStorage()) || void 0 === e ? void 0 : e.getItem(this.key)) && void 0 !== n ? n : null;
            return null !== s ? s : void 0
        }
        write(e) {
            var n;
            null === (n = getLocalStorage()) || void 0 === n || n.setItem(this.key, e)
        }
        clear() {
            var e;
            null === (e = getLocalStorage()) || void 0 === e || e.removeItem(this.key)
        }
        constructor(e) {
            if (function(e, n, s) {
                    n in e ? Object.defineProperty(e, n, {
                        value: s,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[n] = s
                }(this, "key", void 0), "string" != typeof e || "" === e.trim()) throw new Error("DevFlag requires a non-empty string key");
            this.key = e
        }
    }
    class StringDevFlag extends LocalStorageDevFlag {
        static register(e) {
            return findOrCreate(e, this)
        }
        static get(e) {
            return this.register(e).get()
        }
        static set(e, n) {
            this.register(e).set(n)
        }
        get() {
            return this.read()
        }
        set(e) {
            "string" != typeof e && console.warn("Value for StringDevFlag should be a string"), this.write(e)
        }
    }
    class BooleanDevFlag extends LocalStorageDevFlag {
        static register(e) {
            return findOrCreate(e, this)
        }
        static get(e) {
            return this.register(e).get()
        }
        static set(e, n) {
            this.register(e).set(n)
        }
        get() {
            const e = this.read();
            if (void 0 !== e) return "1" === e || "true" === e.toLowerCase()
        }
        set(e) {
            "boolean" == typeof e ? this.write(!0 === e ? "1" : "0") : console.warn("Value for BooleanDevFlag should be a boolean")
        }
        get enabled() {
            return !0 === this.get()
        }
        enable() {
            this.set(!0)
        }
        disable() {
            this.set(!1)
        }
        toggle() {
            this.set(!this.get())
        }
    }
    class JsonDevFlag extends LocalStorageDevFlag {
        static register(e) {
            return findOrCreate(e, this)
        }
        static get(e) {
            return this.register(e).get()
        }
        static set(e, n) {
            this.register(e).set(n)
        }
        get() {
            const e = this.read();
            if (void 0 !== e) try {
                return JSON.parse(e)
            } catch (ce) {
                return
            }
        }
        set(e) {
            this.write(JSON.stringify(e))
        }
        prop(e) {
            if (void 0 !== this.value) return this.value[e]
        }
    }
    const T = ["contributors", "modalities", "musicVideo", "podcast-episodes", "radioStation", "song", "uploaded-audios", "uploadedAudio", "uploaded-videos", "uploadedVideo", "workouts", "workout-programs"],
        E = {
            mediaItemStateDidChange: "mediaItemStateDidChange",
            mediaItemStateWillChange: "mediaItemStateWillChange"
        },
        w = {
            CRITICAL: 50,
            ERROR: 40,
            WARNING: 30,
            NOTICE: 20,
            INFO: 10,
            DEBUG: 2,
            TRACE: 1,
            NONE: 0
        };
    const I = {
        OFF: "NONE",
        0: "NONE",
        "+": "INFO",
        "++": "DEBUG",
        V: "DEBUG",
        D: "DEBUG",
        VERBOSE: "DEBUG",
        VV: "TRACE",
        SILLY: "TRACE",
        "*": "TRACE"
    };

    function getLoggingLevel(e, n = {}) {
        if ("number" == typeof e) return function(e) {
            return "number" == typeof e && Object.values(w).includes(e)
        }(e) ? e : void 0;
        let s = e.toUpperCase();
        return n.allowShorthands && void 0 !== I[s] && (s = I[s]),
            function(e) {
                return "string" == typeof e && void 0 !== w[e.toUpperCase()]
            }(s) ? w[s] : void 0
    }

    function getLoggingLevelName(e) {
        for (const [n, s] of Object.entries(w))
            if (e === s) return n
    }

    function walk(e, n) {
        const s = [e];
        for (; s.length > 0;) {
            const e = s.shift();
            void 0 !== e && (s.push(...e.children), n(e))
        }
    }

    function _define_property$1U(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$Q(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1U(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$x(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function _define_property1(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const O = w.ERROR,
        DEFAULT_POLICY = (e, n) => e !== w.NONE && n >= e;
    class Logger {
        get parent() {
            return this._parent
        }
        get children() {
            return Array.from(this._children.values())
        }
        get namespace() {
            return void 0 === this._parent ? this.name : this._parent.namespace + "/" + this.name
        }
        get enabled() {
            return this.level !== w.NONE
        }
        get level() {
            var e, n, s;
            return null !== (s = null !== (n = this._level) && void 0 !== n ? n : null === (e = this.parent) || void 0 === e ? void 0 : e.level) && void 0 !== s ? s : O
        }
        get levelName() {
            var e;
            return null !== (e = getLoggingLevelName(this.level)) && void 0 !== e ? e : "UNKNOWN"
        }
        get levelPolicy() {
            var e, n, s;
            return null !== (s = null !== (n = this._levelPolicy) && void 0 !== n ? n : null === (e = this.parent) || void 0 === e ? void 0 : e.levelPolicy) && void 0 !== s ? s : DEFAULT_POLICY
        }
        get handlers() {
            var e, n, s;
            return null !== (s = null !== (n = this._handlers) && void 0 !== n ? n : null === (e = this.parent) || void 0 === e ? void 0 : e.handlers) && void 0 !== s ? s : {}
        }
        isEnabledFor(e) {
            return this.levelPolicy(this.level, e)
        }
        setLevel(e) {
            const n = getLoggingLevel(e);
            void 0 !== n && (this._level = n)
        }
        clearLevel() {
            this._level = void 0
        }
        setLevelPolicy(e) {
            this._levelPolicy = e
        }
        clearLevelPolicy() {
            this._levelPolicy = void 0
        }
        addHandler(e, n) {
            this._handlers || (this._handlers = {}), this._handlers[e] = n
        }
        hasHandler(e) {
            var n;
            return void 0 !== (null === (n = this._handlers) || void 0 === n ? void 0 : n[e])
        }
        removeHandler(e) {
            void 0 !== this._handlers && (delete this._handlers[e], 0 === Object.keys(this._handlers).length && this.clearHandlers())
        }
        clearHandlers() {
            this._handlers = void 0
        }
        createChild(e, n) {
            const s = this._children.get(e);
            return void 0 !== s ? s : new Logger(e, _object_spread_props$x(_object_spread$Q({}, n), {
                parent: this
            }))
        }
        linkChild(e) {
            if (void 0 !== e.parent && e.parent !== this) throw new Error(`Logger '${e.name}' is already a child of a different parent ('${e.parent.name}')`);
            const n = this._children.get(e.name);
            if (void 0 !== n && n !== e) throw new Error(`A child with name '${e.name}' is already registered`);
            return void 0 === n && (this._children.set(e.name, e), e.linkParent(this)), e
        }
        unlinkChild(e) {
            const n = this._children.get(e.name);
            return n === e && (this._children.delete(e.name), n.unlinkParent()), e
        }
        getByName(e) {
            return this._children.get(e)
        }
        getByNamespace(e) {
            return function(e, n, s = "/") {
                if ("" === (n = n.trim()) || "*" === n) return e;
                const d = n.split(s);
                d[0].trim() === e.name && d.shift();
                if (0 === d.length) return e;
                let p = e;
                for (; void 0 !== p && d.length > 0;) {
                    const e = d.shift();
                    p = p.getByName(e.trim())
                }
                return p
            }(this, e)
        }
        linkParent(e) {
            return this.parent !== e && (this.unlinkParent(), this._parent = e, e.linkChild(this)), this
        }
        unlinkParent() {
            return void 0 !== this._parent && (this._parent.unlinkChild(this), this._parent = void 0), this
        }
        log(e, n, ...s) {
            const d = getLoggingLevel(e);
            void 0 !== d && this.logRecord({
                time: Date.now(),
                namespace: this.namespace,
                level: d,
                message: n,
                args: s
            })
        }
        logRecord(e) {
            if (!this.levelPolicy(this.level, e.level)) return;
            const n = _object_spread$Q({
                namespace: this.namespace
            }, e);
            for (const s of Object.values(this.handlers)) s.process(n)
        }
        error(e, ...n) {
            this.log(w.ERROR, e, ...n)
        }
        warning(e, ...n) {
            this.log(w.WARNING, e, ...n)
        }
        warn(e, ...n) {
            this.warning(e, ...n)
        }
        info(e, ...n) {
            this.log(w.INFO, e, ...n)
        }
        debug(e, ...n) {
            this.log(w.DEBUG, e, ...n)
        }
        trace(e, ...n) {
            this.log(w.TRACE, e, ...n)
        }
        constructor(e, n) {
            _define_property1(this, "name", void 0), _define_property1(this, "_parent", void 0), _define_property1(this, "_children", new Map), _define_property1(this, "_level", void 0), _define_property1(this, "_levelPolicy", void 0), _define_property1(this, "_handlers", void 0), this.name = e, this._levelPolicy = null == n ? void 0 : n.levelPolicy, this._handlers = null == n ? void 0 : n.handlers, void 0 !== (null == n ? void 0 : n.parent) && this.linkParent(n.parent), void 0 !== (null == n ? void 0 : n.level) && this.setLevel(n.level)
        }
    }

    function _define_property$1T(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class CallbackHandler {
        process(e) {
            this.enabled && void 0 !== this.callback && this.callback(e)
        }
        constructor(e, n = {}) {
            var s;
            _define_property$1T(this, "enabled", void 0), _define_property$1T(this, "callback", void 0), this.callback = e, this.enabled = null === (s = n.enabled) || void 0 === s || s
        }
    }
    const R = /%{([^}]+)}/gi,
        A = {
            timestamp: e => String(e.time),
            time: e => String(e.time),
            datetime: e => new Date(e.time).toISOString(),
            date: e => new Date(e.time).toISOString(),
            level: e => String(e.level),
            levelname: e => {
                var n;
                return null !== (n = getLoggingLevelName(e.level)) && void 0 !== n ? n : "UNKNOWN"
            },
            message: e => e.message,
            name: e => e.namespace.split("/").pop(),
            namespace: e => e.namespace
        };

    function _define_property$1S(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const $ = new Map([
            [w.CRITICAL, "error"],
            [w.ERROR, "error"],
            [w.WARNING, "warn"],
            [w.NOTICE, "warn"],
            [w.INFO, "log"],
            [w.DEBUG, "debug"]
        ]),
        M = (C = "%{datetime} %{levelname} - [%{namespace}] %{message}", function(e) {
            return C.replace(R, (function(n, s) {
                return s = s.toLowerCase(), void 0 !== A[s] ? A[s](e) : n
            }))
        });
    var C;
    const D = memoize(e => {
        const n = P(e);
        return L(n)
    });

    function ensureArray(e = []) {
        return Array.isArray(e) ? e : [e]
    }
    const L = memoize(e => {
            const n = e.length,
                s = new ArrayBuffer(n),
                d = new Uint8Array(s);
            for (let p = 0; p < n; p++) d[p] = e.charCodeAt(p);
            return d
        }),
        x = memoize(e => {
            const n = e.length,
                s = new ArrayBuffer(2 * n),
                d = new Uint16Array(s);
            for (let p = 0; p < n; p++) d[p] = e.charCodeAt(p);
            return d
        }),
        j = memoize(e => {
            let n, s, d, p, h, y, _, m = 0;
            const v = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
            let g = "";
            for (; m < e.length;) n = e[m++], s = m < e.length ? e[m++] : Number.NaN, d = m < e.length ? e[m++] : Number.NaN, p = n >> 2, h = (3 & n) << 4 | s >> 4, y = (15 & s) << 2 | d >> 6, _ = 63 & d, isNaN(s) ? y = _ = 64 : isNaN(d) && (_ = 64), g += v.charAt(p) + v.charAt(h) + v.charAt(y) + v.charAt(_);
            return g
        });
    let isMergeableObject = function(e) {
        return function(e) {
            return !!e && "object" == typeof e
        }(e) && ! function(e) {
            let n = Object.prototype.toString.call(e);
            return "[object RegExp]" === n || "[object Date]" === n || function(e) {
                return e.$$typeof === N
            }(e)
        }(e)
    };
    let N = "function" == typeof Symbol && Symbol.for ? Symbol.for("react.element") : 60103;

    function cloneUnlessOtherwiseSpecified(e, n) {
        return !1 !== n.clone && n.isMergeableObject(e) ? deepmerge((s = e, Array.isArray(s) ? [] : {}), e, n) : e;
        var s
    }

    function defaultArrayMerge(e, n, s) {
        return e.concat(n).map((function(e) {
            return cloneUnlessOtherwiseSpecified(e, s)
        }))
    }

    function getKeys(e) {
        return Object.keys(e).concat(function(e) {
            return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(e).filter((function(n) {
                return e.propertyIsEnumerable(n)
            })) : []
        }(e))
    }

    function mergeObject(e, n, s) {
        let d = {};
        return s.isMergeableObject(e) && getKeys(e).forEach((function(n) {
            d[n] = cloneUnlessOtherwiseSpecified(e[n], s)
        })), getKeys(n).forEach((function(p) {
            s.isMergeableObject(n[p]) && e[p] ? d[p] = function(e, n) {
                if (!n.customMerge) return deepmerge;
                let s = n.customMerge(e);
                return "function" == typeof s ? s : deepmerge
            }(p, s)(e[p], n[p], s) : d[p] = cloneUnlessOtherwiseSpecified(n[p], s)
        })), d
    }

    function deepmerge(e, n, s) {
        (s = s || {}).arrayMerge = s.arrayMerge || defaultArrayMerge, s.isMergeableObject = s.isMergeableObject || isMergeableObject;
        let d = Array.isArray(n);
        return d === Array.isArray(e) ? d ? s.arrayMerge(e, n, s) : mergeObject(e, n, s) : cloneUnlessOtherwiseSpecified(n, s)
    }

    function _define_property$1R(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$P(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1R(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$w(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function _object_without_properties$3(e, n) {
        if (null == e) return {};
        var s, d, p = function(e, n) {
            if (null == e) return {};
            var s, d, p = {},
                h = Object.keys(e);
            for (d = 0; d < h.length; d++) s = h[d], n.indexOf(s) >= 0 || (p[s] = e[s]);
            return p
        }(e, n);
        if (Object.getOwnPropertySymbols) {
            var h = Object.getOwnPropertySymbols(e);
            for (d = 0; d < h.length; d++) s = h[d], n.indexOf(s) >= 0 || Object.prototype.propertyIsEnumerable.call(e, s) && (p[s] = e[s])
        }
        return p
    }
    var U;
    deepmerge.all = function(e, n) {
            if (!Array.isArray(e)) throw new Error("first argument should be an array");
            return e.reduce((function(e, s) {
                return deepmerge(e, s, n)
            }), {})
        },
        function(e) {
            e.dataRecordDidDelete = "dataRecordDidDelete", e.dataRecordWillDelete = "dataRecordWillDelete", e.dataRecordDidMaterialize = "dataRecordDidMaterialize", e.dataRecordDidPopulate = "dataRecordDidPopulate", e.dataRecordWillPopulate = "dataRecordWillPopulate"
        }(U || (U = {}));
    const isDataRecord = e => !(!e || "function" != typeof e.hasAttributes || "function" != typeof e.hasRelationships || "function" != typeof e.hasViews || "function" != typeof e.serialize);
    class DataRecord {
        hasProperties(e) {
            return !e || (e.attributes || e.relationships || e.views ? !(e.attributes && !this.hasAttributes(e.attributes)) && (!(e.relationships && !this.hasRelationships(e.relationships)) && !(e.views && !this.hasViews(e.views))) : this.hasAttributes() || this.hasRelationships() || this.hasViews())
        }
        hasAttributes(e) {
            return this._hasProperties(this._mjs.attributes, e)
        }
        hasRelationships(e) {
            return this._hasProperties(this._mjs.relationships, e)
        }
        hasViews(e) {
            return this._hasProperties(this._mjs.views, e)
        }
        meta(e) {
            return e ? this._meta[e] : this._meta
        }
        serialize(e = !0, n = {}, s = {}) {
            const d = {
                id: this.id,
                type: this.type
            };
            return n[`${this.type}-${this.id}`] && !s.allowFullDuplicateSerializations ? d : (n[`${this.type}-${this.id}`] = !0, this.hasAttributes() && (d.attributes = this._mjs.attributes.reduce((e, n) => (e[n] = this[n], e), {})), this._mjs.relationships.length > 0 && (d.relationships = this._serializeRelatedData(this._mjs.relationships, n, s)), this._mjs.views.length > 0 && (d.views = this._serializeRelatedData(this._mjs.views, n, s)), e ? {
                data: d
            } : d)
        }
        setProperty(e, n, s = "attributes", d = {}) {
            function isMergeableObject(e) {
                return !(!e || "object" != typeof e || e instanceof DataRecord)
            }
            hasOwn(this, e) || (this._mjs[s] || (this._mjs[s] = []), this._mjs[s].push(e));
            const setDescriptor = e => ({
                value: e,
                writable: !0,
                configurable: !0,
                enumerable: !0
            });
            this[e] && n && "object" == typeof this[e] && "object" == typeof n ? "attributes" === s ? Object.defineProperty(this, e, setDescriptor(deepmerge(this[e], n, {
                arrayMerge: function(e, n, s) {
                    return n
                },
                isMergeableObject: isMergeableObject
            }))) : "relationships" === s && Array.isArray(this[e]) && d.extendRelationships ? Object.defineProperty(this, e, setDescriptor(deepmerge(this[e], n, {
                isMergeableObject: isMergeableObject
            }))) : Object.defineProperty(this, e, setDescriptor(n)) : Object.defineProperty(this, e, setDescriptor(n))
        }
        removeRelative(e, n) {
            this[e] && (Array.isArray(this[e]) ? this[e] = this[e].filter(e => e.id !== n) : delete this[e])
        }
        setParent(e) {
            const n = this._mjs.parents,
                s = n && n.length > 0;
            this._mjs.parents = s ? n.concat(e) : e
        }
        _hasProperties(e, n) {
            return !!e && (n ? ensureArray(n).every(n => e.includes(n)) : e.length > 0)
        }
        _serializeRelatedData(e, n = {}, s = {}) {
            return e.reduce((e, d) => {
                if (s.excludeRelationships && s.excludeRelationships.has(d)) return e;
                if (s.includeRelationships && !s.includeRelationships.has(d)) return e;
                const p = this[d];
                return Array.isArray(p) ? e[d] = {
                    data: p.map(e => "function" == typeof e.serialize ? e.serialize(!1, n, s) : e)
                } : e[d] = p && "function" == typeof p.serialize ? p.serialize(!1, n, s) : p, e
            }, {})
        }
        constructor(e, n, s = {}) {
            _define_property$1R(this, "type", void 0), _define_property$1R(this, "id", void 0), _define_property$1R(this, "_mjs", void 0), _define_property$1R(this, "_meta", void 0), this.type = e, this.id = n, this._mjs = {
                attributes: [],
                relationships: [],
                views: []
            }, this._meta = {}, this._mjs = _object_spread$P({}, this._mjs, s)
        }
    }
    class DataStore extends Notifications {
        get mapping() {
            return this._mapping
        }
        set mapping(e) {
            this._mapping = e
        }
        clear() {
            this._records = {}, this._expiryRecords = new Set
        }
        peek(e, n, s) {
            if (this._checkForExpiredRecords(), !this._records[e]) return n ? null : [];
            if (!n) return Object.values(this._records[e]);
            if (Array.isArray(n)) return n.map(n => {
                const d = this._records[e][n];
                if (d && d.hasProperties(s)) return d
            });
            const d = this._records[e][n];
            return d && d.hasProperties(s) ? d : null
        }
        populateDataRecords(e, n = {}, s = {}) {
            if (!e.data) return [];
            if (!Array.isArray(e.data)) return this.populateDataRecord(e.data, n, s);
            const d = [];
            return e.data.forEach((e, p) => {
                const h = _object_spread_props$w(_object_spread$P({}, s), {
                    parents: s.parents ? [_object_spread_props$w(_object_spread$P({}, s.parents[0]), {
                        position: p
                    })] : []
                });
                s.parents && (s.parents[0].position = p);
                const y = this.populateDataRecord(e, n, h);
                d.push(y)
            }), d
        }
        populateDataRecord(e, n = {}, s) {
            const d = s.filter || this.filter,
                p = s.mapping || this.mapping;
            if (d && !d(e)) return;
            if (p) {
                let n = "function" == typeof p ? p(e) : transform$a(p, e);
                Object.assign(e, n)
            }
            this._shouldDisableRecordReuse && (n = {});
            const h = this._materializeRecord(n, _object_spread$P({
                id: e.id,
                type: e.type
            }, s));
            return e.meta && (h._meta = e.meta), e.attributes && e.attributes.cachingPolicy && e.attributes.cachingPolicy.maxAge && (h._mjs.expiration = Date.now() + 1e3 * e.attributes.cachingPolicy.maxAge, this._removeOnExpiration && this._expiryRecords.add(h)), this._populateDataAttributes(e, h), "object" == typeof e.relationships && Object.keys(e.relationships).forEach(d => {
                let y = e.relationships[d];
                y && "data" in y && (y = this.populateDataRecords(y, n, {
                    mapping: p,
                    parents: [{
                        relationshipName: d,
                        parentType: h.type,
                        parentId: h.id
                    }]
                }), h.setProperty(d, y, "relationships", s))
            }), "object" == typeof e.views && Object.keys(e.views).forEach(s => {
                const d = e.views[s];
                if (d.attributes || d.data) {
                    const e = new DataRecord("view", s);
                    if (this._populateDataAttributes(d, e), d.data) {
                        const s = this.populateDataRecords(d, n, p);
                        e.setProperty("data", s, "relationships")
                    }
                    h.setProperty(s, e, "views")
                }
            }), h
        }
        query(e, n) {
            this._checkForExpiredRecords();
            let includeRecord = e => !1;
            return "string" == typeof e && n ? includeRecord = s => (null == s ? void 0 : s[e]) === n : "function" == typeof e ? includeRecord = n => {
                try {
                    return e(n)
                } catch (Rt) {
                    return !1
                }
            } : "object" == typeof e && (includeRecord = n => {
                const s = Object.keys(e);
                let d = 0;
                return s.forEach(s => {
                    (null == n ? void 0 : n[s]) === e[s] && d++
                }), s.length === d
            }), Object.values(this._records).reduce((e, n) => (Object.values(n).forEach(n => {
                includeRecord(n) && e.push(n)
            }), e), [])
        }
        remove(e, n) {
            setTimeout(this._checkForExpiredRecords.bind(this), 0);
            if (!hasOwn(this._records, e)) return;
            const s = this.peek(e, n);
            s && (this.dispatchEvent("dataRecordWillDelete", [e, n]), s._mjs.parents && s._mjs.parents.length > 0 && s._mjs.parents.forEach(({
                relationshipName: e,
                parentType: n,
                parentId: d
            }) => {
                this.peek(n, d).removeRelative(e, s.id)
            }), delete this._records[e][n], this.dispatchEvent("dataRecordDidDelete", [e, n]))
        }
        save(e, n = {}) {
            return setTimeout(this._checkForExpiredRecords.bind(this), 0), this.populateDataRecords(e, this._records, n)
        }
        _populateDataAttributes(e, n) {
            "object" == typeof e.attributes && (this.dispatchEvent("dataRecordWillPopulate", [n.type, n.id]), Object.keys(e.attributes).forEach(s => {
                n.setProperty(s, e.attributes[s], "attributes")
            }), this.dispatchEvent("dataRecordDidPopulate", [n.type, n.id]))
        }
        _materializeRecord(e, n) {
            const {
                type: s,
                id: d
            } = n, p = _object_without_properties$3(n, ["type", "id"]);
            return e[s] = e[s] || {}, e[s][d] ? e[s][d].setParent(p.parents || []) : e[s][d] = new DataRecord(s, d, p), this.dispatchEvent("dataRecordDidMaterialize", [s, d]), e[s][d]
        }
        _checkForExpiredRecords() {
            const e = [];
            this._expiryRecords.forEach(n => {
                Date.now() > n._mjs.expiration && (e.push([n.type, n.id]), this._expiryRecords.delete(n))
            }), e.forEach(e => {
                this.remove(...e)
            })
        }
        constructor(e = {}) {
            super(["dataRecordDidDelete", "dataRecordWillDelete", "dataRecordDidMaterialize", "dataRecordWillPopulate", "dataRecordDidPopulate"]), _define_property$1R(this, "_records", void 0), _define_property$1R(this, "_expiryRecords", void 0), _define_property$1R(this, "_mapping", void 0), _define_property$1R(this, "_removeOnExpiration", !1), _define_property$1R(this, "_shouldDisableRecordReuse", !0), _define_property$1R(this, "filter", void 0), this._records = {}, this._expiryRecords = new Set, this._removeOnExpiration = !!e.removeOnExpiration, this._mapping = e.mapping, this._shouldDisableRecordReuse = !!e.shouldDisableRecordReuse, this.filter = e.filter
        }
    }

    function _define_property$1Q(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class DeveloperToken {
        get isExpired() {
            return this.expiration < Date.now()
        }
        _decode(e) {
            return JSON.parse(P(e))
        }
        constructor(e) {
            if (_define_property$1Q(this, "token", void 0), _define_property$1Q(this, "expiration", void 0), _define_property$1Q(this, "keyId", void 0), _define_property$1Q(this, "teamId", void 0), this.token = e, !e || !/^[a-z0-9\-\_]{16,}\.[a-z0-9\-\_]{16,}\.[a-z0-9\-\_]{16,}/i.test(e)) throw new Error("Invalid token.");
            const [n, s] = e.split("."), {
                exp: d,
                iss: p
            } = this._decode(s);
            if (this.expiration = 1e3 * d, this.isExpired) throw new Error("Initialized with an expired token.");
            this.teamId = p;
            const {
                kid: h
            } = this._decode(n);
            this.keyId = h
        }
    }

    function flattenAll(e) {
        return function(e, n = 1) {
            if ("function" == typeof Array.prototype.flat) return Array.prototype.flat.call(e, n);
            if (null == e) throw new TypeError("Cannot convert undefined or null to object");
            return Array.isArray(e) || (e = Array.from(e)),
                function flat(e, n) {
                    return n <= 0 ? e.slice() : Array.prototype.reduce.call(e, (function(e, s) {
                        return Array.isArray(s) ? e.concat(flat(s, n - 1)) : [...e, s]
                    }), [])
                }(e, n)
        }(e, 1 / 0)
    }

    function invoke(e) {
        return void 0 === e || (e => "function" != typeof e)(e) ? e : e()
    }

    function isObject(e) {
        return !!e && "object" == typeof e && !Array.isArray(e)
    }

    function isFunction(e) {
        return "function" == typeof e
    }

    function isString(e) {
        return "string" == typeof e
    }

    function isEmptyString(e, n) {
        return isString(e) ? 0 === (!1 !== (null == n ? void 0 : n.trim) ? e.trim() : e).length : !1 === (null == n ? void 0 : n.strict)
    }

    function _define_property$1P(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$O(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1P(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$v(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const F = function(e) {
        return "boolean" == typeof e
    }(B = isEmptyString) ? !B : function(...e) {
        return !B(...e)
    };
    var B;

    function formatPrimitive(e, n) {
        const s = n.path.map((e, s) => 0 === s ? n.encode(e) : `[${n.encode(e)}]`).join("");
        return null === e ? s : `${s}=${n.encode(e)}`
    }
    const G = {
            comma: function(e, n) {
                return formatPrimitive(e.join(","), n)
            },
            repeat: function(e, n) {
                return e.map(e => formatPrimitive(String(e), n)).filter(e => e.length > 0).join("&")
            },
            bracket: function(e, n) {
                return e.map((function(e) {
                    return n.next(e, _object_spread_props$v(_object_spread$O({}, n), {
                        path: [...n.path, ""]
                    }))
                })).filter(F).join("&")
            },
            index: function(e, n) {
                return e.map((function(e, s) {
                    return n.next(e, _object_spread_props$v(_object_spread$O({}, n), {
                        path: [...n.path, String(s)]
                    }))
                })).filter(F).join("&")
            }
        },
        V = {
            bracket: function(e, n) {
                return Object.keys(e).sort(n.sort).map((function(s) {
                    return n.next(e[s], _object_spread_props$v(_object_spread$O({}, n), {
                        path: n.path.concat(s)
                    }))
                })).filter(F).join("&")
            }
        },
        DEFAULT_ENCODER = e => encodeURIComponent(String(e)),
        STRING_ENCODER = e => String(e);

    function encodeQueryParameters(e, n) {
        if (!e) return "";
        let s = "";
        if (!0 === (null == n ? void 0 : n.prefix) ? s = "?" : isString(null == n ? void 0 : n.prefix) && (s = n.prefix), isString(e)) return s + e.replace(/^[?&]+/, "");
        var d;
        const p = isFunction(null == n ? void 0 : n.arrayFormat) ? n.arrayFormat : G[null !== (d = null == n ? void 0 : n.arrayFormat) && void 0 !== d ? d : "comma"];
        var h;
        const y = isFunction(null == n ? void 0 : n.objectFormat) ? n.objectFormat : V[null !== (h = null == n ? void 0 : n.objectFormat) && void 0 !== h ? h : "bracket"];
        var _;
        const m = null !== (_ = null == n ? void 0 : n.sort) && void 0 !== _ ? _ : (...e) => 0;
        let v = DEFAULT_ENCODER;
        isFunction(null == n ? void 0 : n.encode) ? v = n.encode : !1 === (null == n ? void 0 : n.encode) && (v = STRING_ENCODER);
        const g = y(e, {
            path: [],
            next: function(e, s) {
                return function(e, n) {
                    return void 0 === e && !1 !== (null == n ? void 0 : n.skipUndefined) || (null === e && !1 !== (null == n ? void 0 : n.skipNull) || !(!isEmptyString(e) || !1 === (null == n ? void 0 : n.skipEmptyString)))
                }(e, n) ? "" : isObject(e) ? y(e, s) : Array.isArray(e) ? p(e, s) : formatPrimitive(e, s)
            },
            encode: v,
            sort: m
        });
        return "" === g ? "" : s + g
    }

    function _define_property$1O(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const DEFAULT_CACHE_KEY_FUNCTION = (e, n) => `${n}${e}`;
    class NetworkCache {
        getItem(e) {
            const n = this.cacheKeyForPath(e),
                s = this.storage.getItem(n);
            if (null !== s) {
                const {
                    x: e,
                    d: d
                } = JSON.parse(s);
                if (e > Date.now()) return d;
                this.storage.removeItem(n)
            }
        }
        setItem(e, n, s = this.ttl) {
            const d = this.cacheKeyForPath(e);
            this.storage.setItem(d, JSON.stringify({
                x: Date.now() + s,
                d: n
            }))
        }
        removeItem(e) {
            const n = this.cacheKeyForPath(e);
            this.storage.removeItem(n)
        }
        removeItemsMatching(e, n = !0) {
            const s = this.cacheKeyForPath(e);
            this.removeItemsMatchingCacheKey(s, n)
        }
        clear() {
            this.removeItemsMatchingCacheKey(this.prefix, !1)
        }
        removeItemsMatchingCacheKey(e, n) {
            const s = new RegExp(`^${e}${n?"$":""}`);
            (this.storage instanceof GenericStorage ? this.storage.keys : Object.keys(this.storage)).forEach(e => {
                e && s.test(e) && this.storage.removeItem(e)
            })
        }
        cacheKeyForPath(e) {
            return this.cacheKeyFunction(e, this.prefix)
        }
        constructor(e = {}) {
            _define_property$1O(this, "storage", void 0), _define_property$1O(this, "prefix", void 0), _define_property$1O(this, "ttl", void 0), _define_property$1O(this, "cacheKeyFunction", void 0), this.storage = e.storage || new GenericStorage, this.prefix = e.prefix || "", this.ttl = e.ttl || 3e5, this.cacheKeyFunction = e.cacheKeyFunction || DEFAULT_CACHE_KEY_FUNCTION
        }
    }

    function joinURLPath(...e) {
        const n = flattenAll(e).map(e => e instanceof URL ? e.pathname : e).filter(e => "string" == typeof e && 0 !== e.trim().length);
        if (0 === n.length) return "";
        let s = n[0];
        for (let d = 1; d < n.length; d++) s = s.replace(/[/]+$/, "") + "/" + n[d].replace(/^[/]+/, "");
        return /^([a-z][a-z0-9\-_+]+)?:\/\//i.test(s) || (s = "/" + s.replace(/^[/]+/, "")), s
    }

    function splitURLPath(e) {
        e instanceof URL && (e = e.pathname);
        const n = [],
            s = e.lastIndexOf("#"); - 1 !== s && (n.unshift(e.slice(s)), e = e.slice(0, s));
        const d = e.lastIndexOf("?");
        return -1 !== d && (n.unshift(e.slice(d)), e = e.slice(0, d)), [...e.split(RegExp("(?<![/:]+)\\/+")), ...n].filter(e => 0 !== e.trim().length)
    }

    function _define_property$1N(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$N(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1N(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$u(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const H = "undefined" != typeof Headers,
        headersToDict = e => {
            let n = {};
            var s;
            return s = e, H && s instanceof Headers ? e.forEach((e, s) => n[s] = e) : Array.isArray(e) ? e.forEach(([e, s]) => n[e] = s) : n = e, n
        },
        mergeFetchHeaders = (e = {}, n = {}) => _object_spread$N({}, headersToDict(e), headersToDict(n)),
        mergeFetchOptions = (e, n) => {
            if (e || n) return (null == e ? void 0 : e.headers) && (null == n ? void 0 : n.headers) ? _object_spread_props$u(_object_spread$N({}, e, n), {
                headers: mergeFetchHeaders(e.headers, n.headers)
            }) : _object_spread$N({}, e, n)
        };

    function parseQueryParams(e) {
        if (!e || e.startsWith("http") && !e.includes("?")) return {};
        try {
            var n;
            return parseParams(null !== (n = e.split("?")[1]) && void 0 !== n ? n : e, "&", decodeURIComponent)
        } catch (Rt) {
            return {}
        }
    }

    function parseParams(e, n = "&", s = (e => e)) {
        return "string" != typeof e ? {} : e.split(n).map(e => e.trim().split("=", 2)).reduce((e, n) => {
            const [d, p] = n;
            return "" === d && void 0 === p || (e[s(d)] = s(p), void 0 === p && (e[s(d)] = void 0)), e
        }, {})
    }

    function getMaxAgeFromHeaders(e) {
        const n = function(e, n) {
            if (void 0 !== n) return H && n instanceof Headers ? n.get(e) : n[e]
        }("cache-control", e);
        if (n) {
            return (e => {
                const n = Number(e);
                if (Number.isFinite(n)) return n
            })(parseParams(n, ",")["max-age"])
        }
    }

    function buildURL(e, n, s) {
        isObject(n) && (s = n, n = "");
        const d = joinURLPath([e, null != n ? n : ""]);
        let p = "?";
        d.endsWith("&") || d.endsWith("?") ? p = "" : d.includes("?") && (p = "&");
        return d + (void 0 !== s ? encodeQueryParameters(s, {
            prefix: p
        }) : "")
    }

    function asyncGeneratorStep$1e(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$1M(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$M(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1M(e, n, s[n])
            }))
        }
        return e
    }
    var q;
    ! function(e) {
        e.JSON = "application/json", e.FORM = "application/x-www-form-urlencoded"
    }(q || (q = {}));
    const formatByte = e => ("0" + (255 & e).toString(16)).slice(-2),
        toHexString = (e, n = 8) => {
            if (!(e instanceof Uint8Array)) return "";
            const s = Array.prototype.map.call(e, formatByte).join("");
            return 0 === n ? s : s.replace(new RegExp(`(.{1,${n}})`, "g"), "$1 ").trim()
        };

    function compareUint8Array(e, n) {
        if (void 0 === e && void 0 === n) return !0;
        if (typeof e != typeof n) return !1;
        if (n = n, (e = e).byteLength !== n.byteLength) return !1;
        for (let s = 0; s < e.byteLength; s++)
            if (e[s] !== n[s]) return !1;
        return !0
    }

    function parseVersion(e) {
        const n = {
                version: e.toLowerCase()
            },
            s = e.toLowerCase().split(".").filter(e => !!e);
        if (s.length <= 1 && !/^\d+$/.test(s[0])) return n;
        const d = parseInt(s[0], 10),
            p = parseInt(s[1], 10),
            h = parseInt(s[2], 10);
        return Number.isNaN(d) || (n.major = d, Number.isNaN(p) || (n.minor = p), Number.isNaN(h) || (n.patch = h)), n
    }

    function applyRules(e, n, s) {
        const {
            userAgent: d
        } = null != n ? n : {};
        if ("string" != typeof d || "" === d.trim()) return s;
        for (let p of e) {
            const e = p.slice(0, -1),
                h = p[p.length - 1];
            let y = null;
            for (let p of e)
                if (y = d.match(p), null !== y) {
                    Object.assign(s, h(y, n, s));
                    break
                }
            if (null !== y) break
        }
        return s
    }

    function _define_property$1L(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$L(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1L(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$t(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    var W, z;
    const Y = {
        browser: [
            [/^(itunes|music|tv)\/([\w\.]+)\s/i, e => _object_spread_props$t(_object_spread$L({
                name: "webview",
                variant: e[1].trim().toLowerCase().replace(/(music|tv)/i, "$1.app")
            }, parseVersion(e[2])), {
                mobile: !1
            })],
            [/(?:(?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i, e => _object_spread$L({
                name: "webview",
                variant: "facebook",
                mobile: !0
            }, parseVersion(e[1]))],
            [/(instagram|snapchat)[\/ ]([-\w\.]+)/i, e => _object_spread$L({
                name: "webview",
                variant: e[1].trim().toLowerCase(),
                mobile: !0
            }, parseVersion(e[2]))],
            [/musical_ly(?:.+app_?version\/|_)([\w\.]+)/i, e => _object_spread$L({
                name: "webview",
                variant: "tiktok",
                mobile: !0
            }, parseVersion(e[1]))],
            [/twitter/i, () => ({
                name: "webview",
                variant: "twitter",
                mobile: !0
            })],
            [/ wv\).+?(?:version|chrome)\/([\w\.]+)/i, e => _object_spread$L({
                name: "webview",
                mobile: !0
            }, parseVersion(e[1]))],
            [/electron\/([\w\.]+) safari/i, e => _object_spread$L({
                name: "electron",
                mobile: !1
            }, parseVersion(e[1]))],
            [/tesla\/(.*?(20\d\d\.([-\w\.])+))/i, e => _object_spread_props$t(_object_spread$L({
                name: "other",
                variant: "tesla",
                mobile: !1
            }, parseVersion(e[2])), {
                version: e[1]
            })],
            [/(samsung|huawei)browser\/([-\w\.]+)/i, e => _object_spread$L({
                name: "other",
                variant: e[1].trim().toLowerCase().replace(/browser/i, ""),
                mobile: !0
            }, parseVersion(e[2]))],
            [/yabrowser\/([-\w\.]+)/i, e => _object_spread$L({
                name: "other",
                variant: "yandex",
                mobile: !1
            }, parseVersion(e[1]))],
            [/(brave|flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|whale(?!.+naver)|qqbrowserlite|qq|duckduckgo)\/([-\w\.]+)/i, (e, {
                userAgent: n
            }) => _object_spread$L({
                name: "other",
                variant: e[1].trim().toLowerCase(),
                mobile: /mobile/i.test(n)
            }, parseVersion(e[2].replace(/\-/g, ".")))],
            [/edg(e|ios|a)?\/([\w\.]+)/i, e => _object_spread$L({
                name: "edge",
                mobile: /(edgios|edga)/i.test(null !== (W = e[1]) && void 0 !== W ? W : "")
            }, parseVersion(e[2]))],
            [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i, e => _object_spread$L({
                name: "ie",
                mobile: !1
            }, parseVersion(e[1]))],
            [/opr\/([\w\.]+)/i, /opera mini\/([-\w\.]+)/i, /opera [mobiletab]{3,6}\b.+version\/([-\w\.]+)/i, /opera(?:.+version\/|[\/ ]+)([\w\.]+)/i, e => _object_spread$L({
                name: "opera",
                mobile: /mobile/i.test(e[0])
            }, parseVersion(e[1]))],
            [/headlesschrome(?:\/([\w\.]+)| )/i, e => _object_spread$L({
                name: "chrome",
                variant: "headless",
                mobile: !1
            }, parseVersion(e[1]))],
            [/\b(?:crmo|crios)\/([\w\.]+)/i, e => _object_spread$L({
                name: "chrome",
                mobile: !0
            }, parseVersion(e[1]))],
            [/chrome(?: browser)?\/v?([\w\.]+)( mobile)?/i, e => _object_spread$L({
                name: "chrome",
                mobile: /mobile/i.test(null !== (z = e[2]) && void 0 !== z ? z : "")
            }, parseVersion(e[1]))],
            [/\bfocus\/([\w\.]+)/i, e => _object_spread$L({
                name: "firefox",
                variant: "focus",
                mobile: !0
            }, parseVersion(e[1]))],
            [/fxios\/([\w\.-]+)/i, /(?:mobile|tablet);.*(?:firefox)\/([\w\.-]+)/i, e => _object_spread$L({
                name: "firefox",
                mobile: !0
            }, parseVersion(e[1]))],
            [/(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i, e => _object_spread$L({
                name: "firefox",
                variant: e[1].trim().toLowerCase(),
                mobile: !1
            }, parseVersion(e[2]))],
            [/(?:firefox)\/([\w\.]+)/i, /(?:mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i, e => _object_spread$L({
                name: "firefox",
                mobile: !1
            }, parseVersion(e[1]))],
            [/version\/([\w\.\,]+) .*mobile(?:\/\w+ | ?)safari/i, /version\/([\w\.\,]+) .*(safari)/i, /webkit.+?(?:mobile ?safari|safari)(?:\/([\w\.]+))/i, e => _object_spread$L({
                name: "safari",
                mobile: /mobile/i.test(e[0])
            }, parseVersion(e[1]))]
        ],
        engine: [
            [/webkit\/(?:537\.36).+chrome\/(?!27)([\w\.]+)/i, e => _object_spread$L({
                name: "blink"
            }, parseVersion(e[1]))],
            [/windows.+ edge\/([\w\.]+)/i, e => _object_spread$L({
                name: "blink"
            }, parseVersion(e[1]))],
            [/presto\/([\w\.]+)/i, e => _object_spread$L({
                name: "presto"
            }, parseVersion(e[2]))],
            [/trident\/([\w\.]+)/i, e => _object_spread$L({
                name: "trident"
            }, parseVersion(e[1]))],
            [/gecko\/([\w\.]+)/i, e => _object_spread$L({
                name: "gecko"
            }, parseVersion(e[1]))],
            [/(khtml|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i, e => _object_spread$L({
                name: "other"
            }, parseVersion(e[2]))],
            [/webkit\/([\w\.]+)/i, e => _object_spread$L({
                name: "webkit"
            }, parseVersion(e[1]))]
        ],
        os: [
            [/microsoft windows (vista|xp)/i, /windows nt 6\.2; (arm)/i, /windows (?:phone(?: os)?|mobile)[\/ ]?([\d\.\w ]*)/i, /windows[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i, /(?:win(?=3|9|n)|win 9x )([nt\d\.]+)/i, e => _object_spread$L({
                name: "windows"
            }, parseVersion(e[1]))],
            [/ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i, /(?:ios;fbsv\/|iphone.+ios[\/ ])([\d\.]+)/i, e => _object_spread$L({
                name: "ios"
            }, parseVersion(e[1].replace(/_/g, ".")))],
            [/mac(?:intosh;?)? os x ?([\d\._]+)/i, e => _object_spread$L({
                name: "macos"
            }, parseVersion(e[1].replace(/_/g, ".")))],
            [/cros [\w]+(?:\)| ([\w\.]+)\b)/i, e => _object_spread$L({
                name: "chromeos"
            }, parseVersion(e[1]))],
            [/(?:android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i, /droid ([\w\.]+|[\d+])\b.+(android[- ]x86|harmonyos)/i, e => _object_spread$L({
                name: "android"
            }, parseVersion(e[1]))],
            [/linux/i, () => ({
                name: "linux"
            })]
        ]
    };

    function parseUserAgent(e, n) {
        var s, d, p;
        var h;
        return function(e, n) {
            let s = e;
            for (let d of n) s = d(s);
            return s
        }({
            navigator: e,
            ua: null !== (p = null === (s = e) || void 0 === s ? void 0 : s.userAgent) && void 0 !== p ? p : "",
            extensions: [],
            browser: applyRules(Y.browser, e, {
                name: "unknown",
                mobile: !1
            }),
            engine: applyRules(Y.engine, e, {
                name: "unknown"
            }),
            os: applyRules(Y.os, e, {
                name: "unknown"
            })
        }, null !== (h = null === (d = n) || void 0 === d ? void 0 : d.extensions) && void 0 !== h ? h : [])
    }

    function _define_property$1K(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$K(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1K(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$s(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function flagsExtension(e) {
        let n = e.os.name;
        const s = "android" === e.os.name;
        let d = "macos" === e.os.name,
            p = "ios" === e.os.name;
        var h;
        const y = "ipados" === n || p && /ipad/i.test(e.ua) || d && (null !== (h = e.navigator.maxTouchPoints) && void 0 !== h ? h : 0) >= 2;
        y && (n = "ipados", p = !1, d = !1);
        const _ = _object_spread_props$s(_object_spread$K({}, e.browser), {
                isUnknown: "unknown" === e.browser.name,
                isSafari: "safari" === e.browser.name,
                isChrome: "chrome" === e.browser.name,
                isFirefox: "firefox" === e.browser.name,
                isEdge: "edge" === e.browser.name,
                isWebView: "webview" === e.browser.name,
                isOther: "other" === e.browser.name,
                isMobile: e.browser.mobile || p || y || s || !1
            }),
            m = _object_spread_props$s(_object_spread$K({}, e.engine), {
                isUnknown: "unknown" === e.engine.name,
                isWebKit: "webkit" === e.engine.name,
                isBlink: "blink" === e.engine.name,
                isGecko: "gecko" === e.engine.name
            }),
            v = _object_spread_props$s(_object_spread$K({}, e.os), {
                name: n,
                isUnknown: "unknown" === e.os.name,
                isLinux: "linux" === e.os.name,
                isWindows: "windows" === e.os.name,
                isMacOS: d,
                isAndroid: s,
                isIOS: p,
                isIPadOS: y
            });
        return _object_spread_props$s(_object_spread$K({}, e), {
            extensions: [...e.extensions, "flags"],
            browser: _,
            os: v,
            engine: m
        })
    }

    function asyncGeneratorStep$1d(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$1d(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$1d(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$1d(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function isBrowserEnvironment() {
        return _isBrowserEnvironment.apply(this, arguments)
    }

    function _isBrowserEnvironment() {
        return (_isBrowserEnvironment = _async_to_generator$1d((function*() {
            var e;
            return void 0 !== (null === (e = window) || void 0 === e ? void 0 : e.navigator)
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$1c(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$1c(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$1c(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$1c(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function isNodeEnvironment() {
        return _isNodeEnvironment.apply(this, arguments)
    }

    function _isNodeEnvironment() {
        return (_isNodeEnvironment = _async_to_generator$1c((function*() {
            var e;
            return void 0 !== (null === (e = globalThis) || void 0 === e ? void 0 : e.process)
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$1b(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$1b(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$1b(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$1b(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }
    const Q = {
        playready: ["com.microsoft.playready", "com.youtube.playready"],
        widevine: ["com.widevine.alpha"],
        clearkey: ["org.w3.clearkey"],
        fairplay: ["com.apple.fps", "com.apple.fairplay"]
    };

    function detectEMESupport() {
        return _detectEMESupport.apply(this, arguments)
    }

    function _detectEMESupport() {
        return (_detectEMESupport = _async_to_generator$1b((function*() {
            var e, n, s, d;
            return void 0 !== (null === (n = window) || void 0 === n || null === (e = n.navigator) || void 0 === e ? void 0 : e.requestMediaKeySystemAccess) && void 0 !== (null === (s = window) || void 0 === s ? void 0 : s.MediaKeys) && void 0 !== (null === (d = window) || void 0 === d ? void 0 : d.MediaKeySystemAccess)
        }))).apply(this, arguments)
    }

    function detectEMEKeySystems() {
        return _detectEMEKeySystems.apply(this, arguments)
    }

    function _detectEMEKeySystems() {
        return (_detectEMEKeySystems = _async_to_generator$1b((function*() {
            var e, n;
            if (yield isNodeEnvironment()) return [];
            const s = [],
                d = window;
            if ("function" == typeof(null === (e = d.WebKitMediaKeys) || void 0 === e ? void 0 : e.isTypeSupported))
                for (let y of Q.fairplay) {
                    var p, h;
                    if ((null === (p = d.WebKitMediaKeys) || void 0 === p ? void 0 : p.isTypeSupported(y, "video/mp4")) || (null === (h = d.WebKitMediaKeys) || void 0 === h ? void 0 : h.isTypeSupported(y + ".1_0", "video/mp4"))) return s.push("fairplay"), s
                }
            if ("function" == typeof(null === (n = d.MSMediaKeys) || void 0 === n ? void 0 : n.isTypeSupported))
                for (let y of Q.playready) d.MSMediaKeys.isTypeSupported(y, "video/mp4") && s.push("playready");
            if (yield detectEMESupport()) {
                const e = [{
                    initDataTypes: ["keyids", "cenc"],
                    distinctiveIdentifier: "optional",
                    persistentState: "required",
                    videoCapabilities: [{
                        contentType: 'video/mp4;codecs="avc1.42E01E"',
                        robustness: "SW_SECURE_CRYPTO"
                    }],
                    audioCapabilities: [{
                        contentType: 'audio/mp4;codecs="mp4a.40.2"'
                    }]
                }];
                for (let [n, d] of Object.entries(Q))
                    for (let p of d) try {
                        yield navigator.requestMediaKeySystemAccess(p, e), s.push(n);
                        break
                    } catch (Rt) {}
            }
            return s
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$1a(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$1a(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$1a(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$1a(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function detectMMSSupport() {
        return _detectMMSSupport.apply(this, arguments)
    }

    function _detectMMSSupport() {
        return (_detectMMSSupport = _async_to_generator$1a((function*() {
            var e, n, s, d, p, h;
            const y = null === (e = window) || void 0 === e ? void 0 : e.ManagedSourceBuffer,
                _ = "function" == typeof(null === (s = y) || void 0 === s || null === (n = s.prototype) || void 0 === n ? void 0 : n.appendBuffer) && "function" == typeof(null === (p = y) || void 0 === p || null === (d = p.prototype) || void 0 === d ? void 0 : d.remove);
            return void 0 !== (null === (h = window) || void 0 === h ? void 0 : h.ManagedMediaSource) && _
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$19(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$19(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$19(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$19(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function detectMSESupport() {
        return _detectMSESupport.apply(this, arguments)
    }

    function _detectMSESupport() {
        return (_detectMSESupport = _async_to_generator$19((function*() {
            var e, n;
            return void 0 !== (null === (e = window) || void 0 === e ? void 0 : e.MediaSource) && void 0 !== (null === (n = window) || void 0 === n ? void 0 : n.SourceBuffer)
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$18(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$18(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$18(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$18(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function detectPictureInPictureSupport() {
        return _detectPictureInPictureSupport.apply(this, arguments)
    }

    function _detectPictureInPictureSupport() {
        return (_detectPictureInPictureSupport = _async_to_generator$18((function*() {
            var e, n, s;
            if (yield isNodeEnvironment()) return !1;
            const d = document.createElement("video");
            return void 0 !== (null === (e = d) || void 0 === e ? void 0 : e.webkitSupportsPresentationMode) && "function" == typeof(null === (n = d) || void 0 === n ? void 0 : n.webkitSetPresentationMode) || void 0 !== (null === (s = document) || void 0 === s ? void 0 : s.pictureInPictureEnabled)
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$17(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$1J(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class RuntimeEnvironment {
        get isConfigured() {
            return this.configured
        }
        get userAgent() {
            return this.config.userAgent
        }
        get ua() {
            return this.userAgent.ua
        }
        get isNodeEnvironment() {
            return this.config.isNodeEnvironment
        }
        get isBrowserEnvironment() {
            return this.config.isBrowserEnvironment
        }
        get isPictureInPictureSupported() {
            return this.config.isPictureInPictureSupported
        }
        get isMMSSupported() {
            return this.config.isMMSSupported
        }
        get isMSESupported() {
            return this.config.isMSESupported
        }
        get isEMESupported() {
            return this.config.isEMESupported
        }
        get availableKeySystems() {
            return this.config.availableKeySystems
        }
        get browser() {
            return this.userAgent.browser
        }
        get engine() {
            return this.userAgent.engine
        }
        get os() {
            return this.userAgent.os
        }
        get isMobile() {
            return this.browser.isMobile
        }
        static detect() {
            var e, n = this;
            return (e = function*() {
                var e, s;
                const d = null !== (s = null === (e = window) || void 0 === e ? void 0 : e.navigator) && void 0 !== s ? s : {
                    userAgent: "",
                    maxTouchPoints: 0
                };
                return new n({
                    userAgent: yield parseUserAgent(d, {
                        extensions: [flagsExtension]
                    }), isNodeEnvironment: yield isNodeEnvironment(), isBrowserEnvironment: yield isBrowserEnvironment(), isPictureInPictureSupported: yield detectPictureInPictureSupport(), isMMSSupported: yield detectMMSSupport(), isMSESupported: yield detectMSESupport(), isEMESupported: yield detectEMESupport(), availableKeySystems: yield detectEMEKeySystems()
                })
            }, function() {
                var n = this,
                    s = arguments;
                return new Promise((function(d, p) {
                    var h = e.apply(n, s);

                    function _next(e) {
                        asyncGeneratorStep$17(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$17(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        configure(e) {
            for (const [n, s] of Object.entries(e)) this.config[n] = s;
            this.configured = !0
        }
        constructor(e) {
            _define_property$1J(this, "configured", !1), _define_property$1J(this, "config", void 0), this.config = e, this.configured = !0
        }
    }

    function _define_property$1I(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function omit(e, n) {
        const s = function(e) {
            for (var n = 1; n < arguments.length; n++) {
                var s = null != arguments[n] ? arguments[n] : {},
                    d = Object.keys(s);
                "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(s, e).enumerable
                })))), d.forEach((function(n) {
                    _define_property$1I(e, n, s[n])
                }))
            }
            return e
        }({}, e);
        for (const d of Object.keys(e)) n.includes(d) && delete s[d];
        return s
    }
    class PubSub {
        publish(e, n) {
            const s = this.getSubscribersForType(e);
            void 0 !== s && s.forEach(s => {
                s(e, n)
            })
        }
        subscribe(e, n) {
            this.getSubscribersForType(e, !0).push(n)
        }
        subscribeOnce(e, n) {
            const onceCallback = (e, s) => {
                this.unsubscribe(e, onceCallback), n(e, s)
            };
            this.subscribe(e, onceCallback)
        }
        unsubscribe(e, n) {
            const s = this.getSubscribersForType(e);
            if (void 0 !== s)
                for (let d = 0; d < s.length; d++)
                    if (s[d] === n) {
                        s.splice(d, 1);
                        break
                    }
        }
        clear(e) {
            void 0 === e ? this.events = {} : delete this.events[e]
        }
        getSubscribersForType(e, n = !1) {
            return void 0 === this.events[e] && n && (this.events[e] = []), this.events[e]
        }
        constructor() {
            ! function(e, n, s) {
                n in e ? Object.defineProperty(e, n, {
                    value: s,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = s
            }(this, "events", Object.create(null))
        }
    }

    function asyncGeneratorStep$16(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$16(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$16(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$16(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1G(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class RequestManager {
        static create(e) {
            var n = this;
            return _async_to_generator$16((function*() {
                return new n(e)
            }))()
        }
        get fetch() {
            if (void 0 === this.fetchFunction) throw new MKError(MKError.Reason.INTERNAL_ERROR, "Could not find fetch implementation");
            return this.fetchFunction
        }
        get isConfigured() {
            return this.configured
        }
        configure(e) {
            void 0 !== (null == e ? void 0 : e.fetchFunction) && (this.fetchFunction = e.fetchFunction), this.configured = !0
        }
        buildURL(e, n, s) {
            return new URL(buildURL(e, n, s))
        }
        buildHeaders(...e) {
            return flattenAll(e).reduce((function(e, n) {
                let s;
                return s = n instanceof Headers || n instanceof Map ? Array.from(n.entries()) : Object.entries(n), s.map(([n, s]) => {
                    void 0 === s ? e.delete(n) : e.set(n, s)
                }), e
            }), new Headers)
        }
        buildRequest(e, n) {
            return new Request(new URL(e), n)
        }
        fetchText(e) {
            var n = this;
            return _async_to_generator$16((function*() {
                let s;
                try {
                    s = yield n.fetch(e)
                } catch (ce) {
                    const s = e instanceof Request ? e.url : String(e);
                    throw new MKError(MKError.Reason.NETWORK_ERROR, "Unable to complete request for " + s)
                }
                try {
                    return yield s.text()
                } catch (ce) {
                    const s = e instanceof Request ? e.url : String(e);
                    throw new MKError(MKError.Reason.REQUEST_ERROR, "Unable to read body as text for " + s)
                }
            }))()
        }
        fetchJSON(e) {
            var n = this;
            return _async_to_generator$16((function*() {
                let s;
                try {
                    s = yield n.fetch(e)
                } catch (ce) {
                    const s = e instanceof Request ? e.url : String(e);
                    throw new MKError(MKError.Reason.NETWORK_ERROR, "Unable to complete request for " + s)
                }
                try {
                    return yield s.json()
                } catch (ce) {
                    const s = e instanceof Request ? e.url : String(e);
                    throw new MKError(MKError.Reason.REQUEST_ERROR, "Unable to read body as JSON for " + s)
                }
            }))()
        }
        fetchArrayBuffer(e) {
            var n = this;
            return _async_to_generator$16((function*() {
                let s;
                try {
                    s = yield n.fetch(e)
                } catch (ce) {
                    const s = e instanceof Request ? e.url : String(e);
                    throw new MKError(MKError.Reason.NETWORK_ERROR, "Unable to complete request for " + s)
                }
                try {
                    return yield s.arrayBuffer()
                } catch (ce) {
                    const s = e instanceof Request ? e.url : String(e);
                    throw new MKError(MKError.Reason.REQUEST_ERROR, "Unable to read body as ArrayBuffer for " + s)
                }
            }))()
        }
        constructor(e) {
            var n;
            _define_property$1G(this, "configured", !1), _define_property$1G(this, "fetchFunction", void 0 !== (null === (n = globalThis) || void 0 === n ? void 0 : n.fetch) ? fetch.bind(globalThis) : void 0), this.configure(null != e ? e : {})
        }
    }
    const J = new Map;

    function singularizeMediaType(e) {
        if (J.has(e)) return J.get(e);
        let n = dasherize(e);
        return n.endsWith("s") && (n = n.slice(0, -1)), J.set(e, n), n
    }
    const X = new Logger("media-item");

    function mediaItemLogString(e) {
        let n = e.id;
        var s;
        const d = null !== (s = e.attributes) && void 0 !== s ? s : {};
        let p = "";
        const h = d.name || d.title;
        return isEmptyString(h) || (p += h), isEmptyString(d.albumName) || (p += " - " + d.albumName), isEmptyString(d.artistName) || (p += " - " + d.artistName), "" !== p && (n += ` (${p})`), n
    }
    var Z, ee;
    e.PlaybackType = void 0, (Z = e.PlaybackType || (e.PlaybackType = {}))[Z.none = 0] = "none", Z[Z.preview = 1] = "preview", Z[Z.unencryptedFull = 2] = "unencryptedFull", Z[Z.encryptedFull = 3] = "encryptedFull",
        function(e) {
            e[e.none = 0] = "none", e[e.loading = 1] = "loading", e[e.ready = 2] = "ready", e[e.playing = 3] = "playing", e[e.ended = 4] = "ended", e[e.unavailable = 5] = "unavailable", e[e.restricted = 6] = "restricted", e[e.error = 7] = "error", e[e.unsupported = 8] = "unsupported"
        }(ee || (ee = {}));
    const {
        none: te,
        loading: re,
        ready: ie,
        playing: ne,
        ended: oe,
        unavailable: ae,
        restricted: se,
        error: ce,
        unsupported: de
    } = ee, le = {
        [te]: {
            allowed: [re],
            unknown: [oe, ae, se, ce, de]
        },
        [re]: {
            allowed: [ie, se, ce, de],
            unknown: []
        },
        [ie]: {
            allowed: [ne],
            unknown: [ce]
        },
        [ne]: {
            allowed: [oe, ce],
            unknown: [ae, se, de]
        },
        [oe]: {
            allowed: [],
            unknown: []
        },
        [ae]: {
            allowed: [],
            unknown: []
        },
        [se]: {
            allowed: [],
            unknown: []
        },
        [ce]: {
            allowed: [],
            unknown: []
        },
        [de]: {
            allowed: [],
            unknown: []
        }
    }, toName = e => ee[e], createMediaItemStateGuard = (e = te) => {
        const n = {
            current: e,
            set: function(e) {
                const {
                    current: s
                } = n;
                if (!((e, n) => le[e].allowed.includes(n))(s, e)) {
                    const n = ((e, n) => le[e].unknown.includes(n))(s, e);
                    X.debug(`MediaItem.state was changed from ${toName(s)} to ${toName(e)}`, n ? "but it is unknown whether it should be allowed or not." : "and it should not be happening")
                }
                n.current = e
            }
        };
        return n
    };

    function transform$9(e) {
        return transform$a({
            "attributes.albumName": "metadata.playlistName",
            "attributes.artistName": "metadata.artistName",
            "attributes.artwork": function() {
                const n = null == e ? void 0 : e.artworkURL;
                if (n) return function(e) {
                    const n = e.split("/").pop(),
                        [s, d] = !!n && n.match(/\d+/g) || ["100", "100"];
                    return {
                        width: parseInt(s, 10),
                        height: parseInt(d, 10),
                        url: e.replace(`${s}x${d}`, "{w}x{h}")
                    }
                }(n)
            },
            "attributes.composerName": "metadata.composerName",
            "attributes.contentRating": function() {
                var n;
                if (1 === (null == e || null === (n = e.metadata) || void 0 === n ? void 0 : n.explicit)) return "explicit"
            },
            "attributes.discNumber": function() {
                var n;
                return (null == e || null === (n = e.metadata) || void 0 === n ? void 0 : n.discNumber) || 1
            },
            "attributes.durationInMillis": "metadata.duration",
            "attributes.genreNames": function() {
                var n;
                return [null == e || null === (n = e.metadata) || void 0 === n ? void 0 : n.genre]
            },
            "attributes.isrc": function() {
                var n;
                const s = null == e || null === (n = e.metadata) || void 0 === n ? void 0 : n.xid;
                if (s) return s.replace(/^([^:]+):isrc:/, "$1")
            },
            "attributes.name": "metadata.itemName",
            "attributes.playParams.id": "metadata.itemId",
            "attributes.playParams.kind": "metadata.kind",
            "attributes.previews": function() {
                return [{
                    url: null == e ? void 0 : e.previewURL
                }]
            },
            "attributes.releaseDate": "metadata.releaseDate",
            "attributes.trackNumber": "metadata.trackNumber",
            assetURL: "URL",
            cloudId: "metadata.cloud-id",
            id: function() {
                var n;
                return "" + (null == e || null === (n = e.metadata) || void 0 === n ? void 0 : n.itemId)
            },
            flavor: "flavor",
            type: "metadata.kind"
        }, e)
    }

    function _define_property$1F(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const {
        mediaItemStateDidChange: ue,
        mediaItemStateWillChange: pe
    } = E, he = BooleanDevFlag.register("mk-music-movie-playback");
    class MediaItem extends Notifications {
        get ageGatePolicy() {
            var e;
            return null === (e = this.defaultPlayable) || void 0 === e ? void 0 : e.ageGatePolicy
        }
        get albumInfo() {
            const {
                albumName: e,
                artistName: n
            } = this, s = [];
            return n && s.push(n), e && s.push(e), s.join(" - ")
        }
        get albumName() {
            return this.attributes.albumName
        }
        get artistName() {
            return this.attributes.genreNames && this.attributes.genreNames.indexOf("Classical") > -1 && this.attributes.composerName ? this.attributes.composerName : this.attributes.artistName
        }
        get artwork() {
            var e, n;
            return null !== (n = this.attributes.artwork) && void 0 !== n ? n : null === (e = this.attributes.images) || void 0 === e ? void 0 : e.coverArt16X9
        }
        get artworkURL() {
            if (this.artwork && this.artwork.url) return this.artwork.url
        }
        get canPlay() {
            return this.isPlayable && this.isReady
        }
        get container() {
            return this._container
        }
        set container(e) {
            this._container = e
        }
        get contentRating() {
            return this.attributes.contentRating
        }
        get context() {
            return this._context
        }
        set context(e) {
            this._context = e
        }
        get defaultPlayable() {
            var e;
            return null === (e = this.playables) || void 0 === e ? void 0 : e[0]
        }
        get discNumber() {
            return this.attributes.discNumber
        }
        get hasContainerArtwork() {
            return this.container && this.container.attributes && this.container.attributes.artwork && this.container.attributes.artwork.url
        }
        get hasPlaylistContainer() {
            return this.container && "playlists" === this.container.type && this.container.attributes
        }
        get supportsLinearScrubbing() {
            var e, n, s;
            return this.isLinearStream && !0 === (null === (s = this.defaultPlayable) || void 0 === s || null === (n = s.assets) || void 0 === n || null === (e = n.streamCapability) || void 0 === e ? void 0 : e.supportsLinearScrubbing)
        }
        get isAssetScrubbingDisabled() {
            return !!this.isLinearStream && !this.supportsLinearScrubbing
        }
        get isLinearStream() {
            return "LiveService" === (null == (e = this) ? void 0 : e.type) || "Event" === (null == e || null === (n = e.defaultPlayable) || void 0 === n ? void 0 : n.type) || "EbsEvent" === (null == e || null === (s = e.defaultPlayable) || void 0 === s ? void 0 : s.type);
            var e, n, s
        }
        get isAlgoStation() {
            return isAlgoStation(this)
        }
        get isRadioStation() {
            return isRadioStation(this)
        }
        get isRadioEpisode() {
            return isRadioEpisode(this)
        }
        get isLiveRadioStation() {
            return isLiveRadioStation(this)
        }
        get isLiveAudioStation() {
            return isLiveRadioStation(this, "audio")
        }
        get isLiveVideoStation() {
            return isLiveRadioStation(this, "video")
        }
        get isAOD() {
            return isRadioEpisode(e = this, n) || !!(null == e || null === (s = e.attributes) || void 0 === s ? void 0 : s.isAOD);
            var e, n, s
        }
        get isSong() {
            return "song" === this.type
        }
        get info() {
            return `${this.title} - ${this.albumInfo}`
        }
        get isCloudItem() {
            return this.isLibraryItem
        }
        get isLibraryItem() {
            var e, n;
            return !0 === (null === (e = this.playParams) || void 0 === e ? void 0 : e.isLibrary) || isLibraryType(null === (n = this.playParams) || void 0 === n ? void 0 : n.id) || isLibraryType(this.id)
        }
        get isCloudUpload() {
            return "-1" === String(this._songId)
        }
        get isExplicitItem() {
            return "explicit" === this.contentRating
        }
        get isLoading() {
            return this.state === ee.loading
        }
        get isPlayableMediaType() {
            return !("musicMovie" !== this.type || !he.enabled) || (this.isUTS || -1 !== T.indexOf(this.type))
        }
        get isPlayable() {
            var e;
            return !!this.isUTS || !!this.isPlayableMediaType && (!!(this.isLiveRadioStation || this.isRadioEpisode || this.hasOffersHlsUrl) || (this.needsPlayParams ? !!this.playParams : !!this.rawAssetUrl || !!(null === (e = this.attributes.previews) || void 0 === e ? void 0 : e.length)))
        }
        get isPlaying() {
            return this.state === ee.playing
        }
        get isPreparedToPlay() {
            const e = isString(this.assetURL) && !isEmptyString(this.assetURL),
                n = !(!this.keyURLs || isEmptyString(this.keyURLs["hls-key-cert-url"]) || isEmptyString(this.keyURLs["hls-key-server-url"]) || isEmptyString(this.keyURLs["widevine-cert-url"]));
            if ("song" === this.type) {
                var s;
                const e = isString(this.songId) && !isEmptyString(this.songId) && "-1" !== this.songId;
                var d;
                const p = (null !== (d = null === (s = this.assets) || void 0 === s ? void 0 : s.length) && void 0 !== d ? d : 0) > 0;
                return e && p && n
            }
            return this.isUTS ? e && n || this.playRawAssetURL : e || this.playRawAssetURL
        }
        get isrc() {
            return this.attributes.isrc
        }
        get isReady() {
            return this.state === ee.ready
        }
        get isRestricted() {
            return this.state === ee.restricted
        }
        get isUTS() {
            return !!this.defaultPlayable
        }
        get isUnavailable() {
            return this.state === ee.unavailable
        }
        get needsPlayParams() {
            return ["musicMovie", "musicVideo", "song"].includes(this.type)
        }
        get normalizedType() {
            return normalizeMediaType(this.type)
        }
        get offers() {
            return this.attributes.offers
        }
        get offersHlsUrl() {
            const {
                offers: e
            } = this, n = null == e ? void 0 : e.find(e => {
                var n;
                return !!(null === (n = e.hlsUrl) || void 0 === n ? void 0 : n.length)
            });
            return null == n ? void 0 : n.hlsUrl
        }
        get hasOffersHlsUrl() {
            return isString(this.offersHlsUrl) && !isEmptyString(this.offersHlsUrl)
        }
        get rawAssetUrl() {
            return this.attributes.assetUrl
        }
        set playbackData(e) {
            if (void 0 === e) return;
            this.previewURL && (e.previewURL = this.previewURL);
            const n = transform$9(e);
            this.artwork && n.artwork && delete n.artwork, n.id !== this.id && delete n.id, this.playParams && n.attributes.playParams && (n.attributes.playParams = this.playParams), n.attributes = function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$1F(e, n, s[n])
                    }))
                }
                return e
            }({}, this.attributes, n.attributes), Object.assign(this, n), X.debug("media-item: item merged with playbackData", this), this.state = ee.ready
        }
        get playbackDuration() {
            return this.attributes.durationInMillis || this.attributes.durationInMilliseconds
        }
        get playEvent() {
            var e;
            return null === (e = this.defaultPlayable) || void 0 === e ? void 0 : e.playEvent
        }
        get playlistArtworkURL() {
            var e, n, s;
            return this.hasPlaylistContainer && this.hasContainerArtwork ? null === (s = this.container) || void 0 === s || null === (n = s.attributes) || void 0 === n || null === (e = n.artwork) || void 0 === e ? void 0 : e.url : this.artworkURL
        }
        get playlistName() {
            var e, n;
            return this.hasPlaylistContainer ? null === (n = this.container) || void 0 === n || null === (e = n.attributes) || void 0 === e ? void 0 : e.name : this.albumName
        }
        get playParams() {
            return this.attributes.playParams
        }
        get playRawAssetURL() {
            return this.isCloudUpload || !!this.rawAssetUrl
        }
        get previewURL() {
            var e, n, s, d, p, h, y, _, m, v, g, b, S, P, k;
            return (null === (s = this.attributes) || void 0 === s || null === (n = s.previews) || void 0 === n || null === (e = n[0]) || void 0 === e ? void 0 : e.url) || (null === (h = this.attributes) || void 0 === h || null === (p = h.previews) || void 0 === p || null === (d = p[0]) || void 0 === d ? void 0 : d.hlsUrl) || (null === (v = this.attributes) || void 0 === v || null === (m = v.trailers) || void 0 === m || null === (_ = m[0]) || void 0 === _ || null === (y = _.assets) || void 0 === y ? void 0 : y.hlsUrl) || (null === (S = this.attributes) || void 0 === S || null === (b = S.movieClips) || void 0 === b || null === (g = b[0]) || void 0 === g ? void 0 : g.hlsUrl) || (null === (k = this.attributes) || void 0 === k || null === (P = k.video) || void 0 === P ? void 0 : P.hlsUrl)
        }
        get rating() {
            return this.attributes.rating
        }
        get releaseDate() {
            if (this._releaseDate) return this._releaseDate;
            if (this.attributes && (this.attributes.releaseDate || this.attributes.releaseDateTime)) {
                const e = this.attributes.releaseDate || this.attributes.releaseDateTime;
                return this._releaseDate = /^\d{4}-\d{1,2}-\d{1,2}/.test(e) ? new Date(e) : void 0, this._releaseDate
            }
        }
        set releaseDate(e) {
            this._releaseDate = "string" == typeof e ? /^\d{4}-\d{1,2}-\d{1,2}/.test(e) ? new Date(e) : void 0 : "number" == typeof e ? new Date(e) : e
        }
        get songId() {
            return void 0 !== this._songId && "-1" !== String(this._songId) ? this._songId : this.id
        }
        set songId(e) {
            this._songId = void 0 !== e ? String(e) : void 0
        }
        get state() {
            return this._state.current
        }
        set state(e) {
            const n = {
                oldState: this._state.current,
                state: e
            };
            this._stateWillChange && this._stateWillChange(this), this.dispatchEvent(pe, n), this._state.set(e), this._stateDidChange && this._stateDidChange(this), this.dispatchEvent(ue, n)
        }
        get title() {
            return this.attributes.name || this.attributes.title
        }
        get trackNumber() {
            return this.attributes.trackNumber
        }
        beginMonitoringStateDidChange(e) {
            this._stateDidChange = e
        }
        beginMonitoringStateWillChange(e) {
            this._stateWillChange = e
        }
        endMonitoringStateDidChange() {
            this._stateDidChange = void 0
        }
        endMonitoringStateWillChange() {
            this._stateWillChange = void 0
        }
        isEqual(e) {
            return this.id === e.id && this.type === e.type && this.attributes === e.attributes
        }
        resetState() {
            this.endMonitoringStateWillChange(), this.endMonitoringStateDidChange(), this.state = ee.none
        }
        restrict() {
            this.isExplicitItem && (this.state = ee.restricted, this._removePlayableData())
        }
        notSupported() {
            this.state = ee.unsupported, this._removePlayableData()
        }
        updateFromLoadError(e) {
            switch (e.reason) {
                case MKError.Reason.CONTENT_RESTRICTED:
                    this.state = ee.restricted;
                    break;
                case MKError.Reason.CONTENT_UNAVAILABLE:
                    this.state = ee.unavailable;
                    break;
                default:
                    this.state = ee.error
            }
        }
        _removePlayableData() {
            var e, n, s;
            null === (e = this.attributes) || void 0 === e || delete e.playParams, null === (n = this.attributes) || void 0 === n || delete n.previews, null === (s = this.attributes) || void 0 === s || delete s.trailers
        }
        constructor(n = {}) {
            super([ue, pe]), _define_property$1F(this, "id", void 0), _define_property$1F(this, "type", void 0), _define_property$1F(this, "cloudId", void 0), _define_property$1F(this, "playables", void 0), _define_property$1F(this, "channels", void 0), _define_property$1F(this, "assetURL", void 0), _define_property$1F(this, "hlsMetadata", {}), _define_property$1F(this, "flavor", void 0), _define_property$1F(this, "currentKeyPlay", void 0), _define_property$1F(this, "keyPlayShelf", void 0), _define_property$1F(this, "keyServerQueryParameters", void 0), _define_property$1F(this, "podpafMetrics", void 0), _define_property$1F(this, "attributes", {}), _define_property$1F(this, "meta", {}), _define_property$1F(this, "playbackType", e.PlaybackType.none), _define_property$1F(this, "trackInfo", void 0), _define_property$1F(this, "href", void 0), _define_property$1F(this, "relationships", void 0), _define_property$1F(this, "_container", void 0), _define_property$1F(this, "_context", void 0), _define_property$1F(this, "_releaseDate", void 0), _define_property$1F(this, "_state", createMediaItemStateGuard()), _define_property$1F(this, "_stateDidChange", void 0), _define_property$1F(this, "_stateWillChange", void 0), _define_property$1F(this, "_songId", void 0), _define_property$1F(this, "assets", []), _define_property$1F(this, "keyURLs", void 0), X.debug("media-item: creating Media Item with options:", n);
            var s;
            n.id && n.attributes ? (Object.assign(this, n), this.type = (null === (s = this.playParams) || void 0 === s ? void 0 : s.kind) ? this.playParams.kind : this.type || "song") : (this.id = n.id || generateUUID(), this.type = n.type || "song", this.attributes = {
                playParams: {
                    id: this.id,
                    kind: this.type
                }
            });
            this._context = n.context || {}, n.container ? this._container = n.container : n.containerId && n.containerType && (this._container = {
                id: n.containerId,
                type: n.containerType
            })
        }
    }
    const ye = ["contributors", "modalities", "movie", "musicVideo", "musicMovie", "trailer", "tvEpisode", "uploadedVideo", "uploaded-videos", "music-videos", "music-movies", "tv-episodes", "workouts"];
    var _e, fe;

    function asyncGeneratorStep$15(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$15(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$15(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$15(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }
    e.PlaybackStates = void 0, (_e = e.PlaybackStates || (e.PlaybackStates = {}))[_e.none = 0] = "none", _e[_e.loading = 1] = "loading", _e[_e.playing = 2] = "playing", _e[_e.paused = 3] = "paused", _e[_e.stopped = 4] = "stopped", _e[_e.ended = 5] = "ended", _e[_e.seeking = 6] = "seeking", _e[_e.waiting = 8] = "waiting", _e[_e.stalled = 9] = "stalled", _e[_e.completed = 10] = "completed", e.PresentationMode = void 0, (fe = e.PresentationMode || (e.PresentationMode = {}))[fe.pictureinpicture = 0] = "pictureinpicture", fe[fe.inline = 1] = "inline";
    const me = ["apps.apple.com", "books.apple.com", "fitness.apple.com", "music.apple.com", "podcasts.apple.com", "tv.apple.com"];
    const ve = new Set([]),
        ge = /\.apple\.com$/;

    function getCommerceHostname(e, n) {
        !n && "undefined" != typeof location && location.hostname && (n = location);
        let s = e + ".itunes.apple.com";
        if (!n) return s;
        const d = function(e) {
            if (!e || !ge.test(e)) return;
            const n = e.split(".");
            let s = n[n.length - 3];
            const d = s;
            if (s && s.includes("-")) {
                const e = s.split("-");
                s = e[e.length - 1]
            }
            return ve.has(s) ? d : void 0
        }(n.hostname);
        return d && (s = `${e}.${d}.apple.com`), s
    }
    var be, Se, Pe;

    function buildQueryParams(e = {
        app: "music",
        p: "subscribe"
    }) {
        return void 0 === e.app && (e.app = "music"), void 0 === e.p && (e.p = "subscribe"), Object.keys(e).map(n => `${encodeURIComponent(n)}=${encodeURIComponent(e[n])}`).join("&")
    }! function(e) {
        e.APP = "music", e.P = "subscribe"
    }(be || (be = {})),
    function(e) {
        e.DEFAULT_CID = "pldfltcid", e.TV_CID = "pltvcid", e.RESTRICTIONS_ENABLED = "itre", e.STOREFRONT_COUNTRY_CODE = "itua", e.USER_TOKEN = "media-user-token"
    }(Se || (Se = {})), e.SKRealm = void 0, (Pe = e.SKRealm || (e.SKRealm = {}))[Pe.MUSIC = 0] = "MUSIC", Pe[Pe.PODCAST = 1] = "PODCAST", Pe[Pe.TV = 2] = "TV";
    const ke = {
            [e.SKRealm.TV]: "com.apple.onboarding.tvappweb",
            [e.SKRealm.MUSIC]: "com.apple.onboarding.musicappweb",
            [e.SKRealm.PODCAST]: "com.apple.onboarding.podcastsweb"
        },
        Te = {
            [e.SKRealm.TV]: "pltvcid",
            [e.SKRealm.MUSIC]: "pldfltcid",
            [e.SKRealm.PODCAST]: "pldfltcid"
        },
        Ee = new Logger("storekit");

    function asyncGeneratorStep$14(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$1E(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    var we;
    ! function(e) {
        e[e.ParseError = -32700] = "ParseError", e[e.InvalidRequest = -32600] = "InvalidRequest", e[e.MethodNotFound = -32601] = "MethodNotFound", e[e.InvalidParams = -32602] = "InvalidParams", e[e.InternalError = -32603] = "InternalError"
    }(we || (we = {}));
    class Dispatch {
        get source() {
            return this._source
        }
        set source(e) {
            if (!e && this._source) return this._source.removeEventListener("message", this.handle), void(this._source = void 0);
            e.addEventListener("message", this.handle), this._source = e
        }
        apply(e, n) {
            if (!this.destination) throw new Error("No destination");
            const s = this._sequence++,
                d = new Promise((e, n) => {
                    this._registry[s] = {
                        resolve: e,
                        reject: n
                    }
                });
            return this.send(this.destination, {
                jsonrpc: "2.0",
                id: s,
                method: e,
                params: n
            }), d
        }
        call(e, ...n) {
            return this.apply(e, n)
        }
        handleRequest(e) {
            var n, s = this;
            return (n = function*() {
                const n = {
                        jsonrpc: "2.0",
                        id: e.id
                    },
                    d = s.methods[e.method];
                if (!d) return Object.assign(n, {
                    error: {
                        code: -32601,
                        message: "Method not found"
                    }
                });
                try {
                    const s = yield d.apply(void 0, ensureArray(e.params));
                    return Object.assign(n, {
                        result: s
                    })
                } catch (ce) {
                    return Object.assign(n, {
                        error: {
                            code: ce.code || -32603,
                            message: ce.message
                        }
                    })
                }
            }, function() {
                var e = this,
                    s = arguments;
                return new Promise((function(d, p) {
                    var h = n.apply(e, s);

                    function _next(e) {
                        asyncGeneratorStep$14(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$14(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        handleResponse(e) {
            const n = this._registry[e.id];
            delete this._registry[e.id], n && (e.error ? n.reject(Object.assign(Error(), e.error)) : n.resolve(e.result))
        }
        send(e, n) {
            e.postMessage(n, e.window === e ? this.origin : void 0)
        }
        constructor(e = {}) {
            _define_property$1E(this, "destination", void 0), _define_property$1E(this, "origin", void 0), _define_property$1E(this, "methods", void 0), _define_property$1E(this, "_registry", {}), _define_property$1E(this, "_sequence", 0), _define_property$1E(this, "_source", void 0), _define_property$1E(this, "handle", e => {
                e.data && "2.0" === e.data.jsonrpc && ("*" !== this.origin && this.origin !== e.origin || (e.data.method && this.destination ? this.handleRequest(e.data).then(e => {
                    this.send(this.destination, e)
                }) : (hasOwn(e.data, "result") || e.data.error) && this.handleResponse(e.data)))
            }), this.destination = e.destination, this.methods = e.methods || {}, this.origin = e.origin || "*", e.source && (this.source = e.source)
        }
    }

    function asyncGeneratorStep$13(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$13(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$13(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$13(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1D(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$H(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1D(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$r(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    var Ie;

    function validateToken(e) {
        return "string" == typeof e && e.length > 0
    }! function(e) {
        e[e.UNAVAILABLE = -1] = "UNAVAILABLE", e[e.NOT_DETERMINED = 0] = "NOT_DETERMINED", e[e.DENIED = 1] = "DENIED", e[e.RESTRICTED = 2] = "RESTRICTED", e[e.AUTHORIZED = 3] = "AUTHORIZED"
    }(Ie || (Ie = {}));
    const Oe = `https://${getCommerceHostname("buy")}/commerce/account/authenticateMusicKitRequest`,
        Re = "https://authorize.music.apple.com",
        Ae = /^https?:\/\/(.+\.)*(apple\.com|apps\.mzstatic\.com)(\/[\w\d]+)*$/;
    var $e, Me, Ce;
    ! function(e) {
        e[e.AUTHORIZE = 0] = "AUTHORIZE", e[e.SUBSCRIBE = 1] = "SUBSCRIBE"
    }($e || ($e = {}));
    class ServiceSetupView {
        get isServiceView() {
            return /(authorize\.(.+\.)*apple\.com)/i.test(window.location.hostname) || window && window.name === this.target || !1
        }
        focus() {
            this._window && window.focus && this._window.focus()
        }
        load(e = {
            action: 0
        }) {
            var n = this;
            return _async_to_generator$13((function*() {
                return 1 === e.action ? n._subscribeAction(e.parameters) : n._authorizeAction(e.parameters)
            }))()
        }
        present(e = "", n) {
            const {
                height: s,
                left: d,
                top: p,
                width: h
            } = this._calculateClientDimensions(), y = {
                height: 650,
                menubar: "no",
                resizable: "no",
                scrollbars: "no",
                status: "no",
                toolbar: "no",
                width: 650
            }, _ = _object_spread$H(_object_spread_props$r(_object_spread$H({}, y), {
                left: h / 2 - y.width / 2 + d,
                top: s / 2 - y.height / 2 + p
            }), n), m = Object.keys(_).map(e => `${e}=${_[e]}`).join(",");
            return /trident|msie/i.test(navigator.userAgent) ? (this._window = window.open(window.location.href, this.target, m) || void 0, this._window.location.href = e) : this._window = window.open(e, this.target, m) || void 0, /\bedge\b/i.test(navigator.userAgent) && (this._window.opener = self), this.focus(), this._window
        }
        _startPollingForWindowClosed(e) {
            this._window && void 0 === this._windowClosedInterval && (this._windowClosedInterval = setInterval(() => {
                var n;
                (null === (n = this._window) || void 0 === n ? void 0 : n.closed) && (this._stopPollingForWindowClosed(), e())
            }, 500))
        }
        _stopPollingForWindowClosed() {
            void 0 !== this._windowClosedInterval && (clearInterval(this._windowClosedInterval), this._windowClosedInterval = void 0)
        }
        _authorizeAction(e = {}) {
            var n = this;
            return _async_to_generator$13((function*() {
                var s;
                let d, p;
                const h = (null === (s = window.location) || void 0 === s ? void 0 : s.href) || "";
                return "GET" === n.authenticateMethod ? p = `${Re}/woa?${buildQueryParams(_object_spread_props$r(_object_spread$H({},n.deeplinkParameters),{a:btoa(n._thirdPartyInfo()),referrer:h}))}` : (d = n._buildFormElement(Oe), document.body.appendChild(d)), new Promise((s, h) => {
                    const y = n.present(p);
                    n._startPollingForWindowClosed(() => {
                        h(0)
                    }), n.dispatch = new Dispatch({
                        methods: {
                            authorize: function(e, n, d) {
                                if (validateToken(e)) {
                                    s({
                                        restricted: n && "1" === n,
                                        userToken: e,
                                        cid: d
                                    })
                                } else h(0)
                            },
                            close: function() {},
                            decline: function() {
                                h(1)
                            },
                            switchUserId: function() {
                                h(0)
                            },
                            thirdPartyInfo: () => n._thirdPartyInfo(n.developerToken, _object_spread$H({}, n.deeplinkParameters, e)),
                            unavailable: function() {
                                h(-1)
                            }
                        },
                        origin: Re,
                        source: window,
                        destination: y
                    }), d && d.submit()
                })
            }))()
        }
        _buildFormElement(e, n = this.target, s = this.developerToken) {
            const d = document.createElement("form");
            d.setAttribute("method", "post"), d.setAttribute("action", e), d.setAttribute("target", n), d.style.display = "none";
            const p = document.createElement("input");
            p.setAttribute("name", "jwtToken"), p.setAttribute("value", s), d.appendChild(p);
            const h = document.createElement("input");
            h.setAttribute("name", "isWebPlayer"), h.setAttribute("value", "true"), d.appendChild(h);
            const y = document.createElement("input");
            return y.setAttribute("name", "LogoURL"), y.setAttribute("value", ""), d.appendChild(y), d
        }
        _calculateClientDimensions(e = window) {
            return {
                height: e.innerHeight ? e.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height,
                left: e.screenLeft ? e.screenLeft : screen.availLeft || screen.left,
                top: e.screenTop ? e.screenTop : screen.availTop || screen.top,
                width: e.innerWidth ? e.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width
            }
        }
        _subscribeAction(e = {}) {
            var n = this;
            return _async_to_generator$13((function*() {
                return Object.assign(e, n.deeplinkParameters), new Promise((s, d) => {
                    const p = "https://authorize.music.apple.com/upsell?" + buildQueryParams(e);
                    n.present(p), window.addEventListener("message", ({
                        data: e,
                        origin: n,
                        source: p
                    }) => {
                        const {
                            closeWindow: h,
                            launchClient: y
                        } = "string" == typeof e ? JSON.parse(e) : e;
                        n && !Ae.test(n) || (y ? 0 === y.supported ? d("Unable to subscribe on this platform.") : s(y) : d("Subscribe action error."))
                    })
                })
            }))()
        }
        _thirdPartyInfo(e = this.developerToken, n) {
            let s = this.iconURL;
            const d = window.location.host || document.referrer,
                p = [...[].slice.call(document.querySelectorAll('link[rel="apple-music-app-icon"]')), ...[].slice.call(document.querySelectorAll('link[rel="apple-touch-icon-precomposed"]')), ...[].slice.call(document.querySelectorAll('link[rel="apple-touch-icon"]'))];
            if (p && p[0] && p[0].href) {
                const e = p.find(e => !!e.sizes && "120x120" === e.sizes.value);
                var h;
                s = null !== (h = null == e ? void 0 : e.href) && void 0 !== h ? h : p[0].href
            }
            return JSON.stringify({
                thirdPartyIconURL: s,
                thirdPartyName: d,
                thirdPartyParameters: n,
                thirdPartyToken: e
            })
        }
        constructor(e, n = {}) {
            if (_define_property$1D(this, "developerToken", void 0), _define_property$1D(this, "authenticateMethod", void 0), _define_property$1D(this, "deeplinkParameters", void 0), _define_property$1D(this, "iconURL", void 0), _define_property$1D(this, "target", void 0), _define_property$1D(this, "dispatch", void 0), _define_property$1D(this, "_window", void 0), _define_property$1D(this, "_windowClosedInterval", void 0), this.developerToken = e, this.authenticateMethod = "GET", this.target = "apple-music-service-view", this.deeplinkParameters = n && n.deeplinkParameters || {}, this.iconURL = n && n.iconURL, this.authenticateMethod = n && n.authenticateMethod || "GET", this.isServiceView && window.opener !== window) {
                var s;
                const e = null === (s = getSessionStorage()) || void 0 === s ? void 0 : s.getItem("ac"),
                    n = null != e ? new URL(e).origin : void 0;
                var d;
                if (n) this.dispatch = new Dispatch({
                    destination: null !== (d = window.opener) && void 0 !== d ? d : void 0,
                    origin: n,
                    source: window
                })
            }
        }
    }

    function asyncGeneratorStep$12(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$12(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$12(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$12(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1C(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _fetchStorefronts() {
        return (_fetchStorefronts = _async_to_generator$12((function*(e, n = "https://api.music.apple.com/v1") {
            const s = new Headers({
                    Authorization: "Bearer " + e
                }),
                d = yield fetch(n + "/storefronts", {
                    headers: s
                }), p = yield d.json();
            return p.errors ? Promise.reject(p.errors) : p.data
        }))).apply(this, arguments)
    }! function(e) {
        e.ID = "us", e.LANGUAGE_TAG = "en-gb"
    }(Me || (Me = {}));

    function asyncGeneratorStep$11(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$11(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$11(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$11(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1B(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$G(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1B(e, n, s[n])
            }))
        }
        return e
    }

    function _ts_metadata$p(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }! function(e) {
        e.authorizationStatusDidChange = "authorizationStatusDidChange", e.authorizationStatusWillChange = "authorizationStatusWillChange", e.eligibleForSubscribeView = "eligibleForSubscribeView", e.storefrontCountryCodeDidChange = "storefrontCountryCodeDidChange", e.storefrontIdentifierDidChange = "storefrontIdentifierDidChange", e.userTokenDidChange = "userTokenDidChange"
    }(Ce || (Ce = {})), Se.DEFAULT_CID;
    const De = "https://" + getCommerceHostname("buy"),
        Le = `https://${getCommerceHostname("play")}/WebObjects/MZPlay.woa/wa`;
    class StoreKit extends Notifications {
        updateUserTokenFromStorage() {
            const e = this._getStorageItem(Se.USER_TOKEN);
            this.userToken = e || void 0
        }
        get authorizationStatus() {
            return this._authorizationStatus
        }
        set authorizationStatus(e) {
            this._authorizationStatus !== e && (this._getIsActiveSubscription.updateCache(void 0), this.dispatchEvent("authorizationStatusWillChange", {
                authorizationStatus: this._authorizationStatus,
                newAuthorizationStatus: e
            }), this._authorizationStatus = e, this.dispatchEvent("authorizationStatusDidChange", {
                authorizationStatus: e
            }))
        }
        get cid() {
            if (!this._cids[this.cidNamespace]) {
                const e = this._getStorageItem(this.cidNamespace);
                this._cids[this.cidNamespace] = e || void 0
            }
            return this._cids[this.cidNamespace]
        }
        set cid(e) {
            e ? this._setStorageItem(this.cidNamespace, e) : this._removeStorageItem(this.cidNamespace), this._cids[this.cidNamespace] = e
        }
        eligibleForSubscribeView() {
            var e = this;
            return _async_to_generator$11((function*() {
                const n = yield e.hasMusicSubscription();
                return (!e.hasAuthorized || e.hasAuthorized && !n) && !e._dispatchedSubscribeView
            }))()
        }
        get hasAuthorized() {
            return this.authorizationStatus > Ie.DENIED
        }
        get logoutURL() {
            if (!this._disableLogoutURL) return this.playBase + "/webPlayerLogout"
        }
        get _pldfltcid() {
            return this._cids[Se.DEFAULT_CID]
        }
        set _pldfltcid(e) {
            this._cids[Se.DEFAULT_CID] = e
        }
        get restrictedEnabled() {
            if (this.userToken && "boolean" != typeof this._restrictedEnabled) {
                const e = this._getStorageItem(Se.RESTRICTIONS_ENABLED);
                if (e) this._restrictedEnabled = "0" !== e;
                else if (this._storefrontCountryCode) {
                    const e = ["br", "ch", "gt", "hu", "id", "in", "it", "kr", "la", "lt", "my", "ru", "sg", "tr"];
                    this._restrictedEnabled = -1 !== e.indexOf(this._storefrontCountryCode) || void 0
                }
            }
            return this._restrictedEnabled
        }
        set restrictedEnabled(e) {
            this._restrictedEnabledOverridden || (this.userToken && void 0 !== e && this._setStorageItem(Se.RESTRICTIONS_ENABLED, e ? "1" : "0"), this._restrictedEnabled = e, e && (this.authorizationStatus = Ie.RESTRICTED))
        }
        overrideRestrictEnabled(e) {
            this._restrictedEnabledOverridden = !1, this.restrictedEnabled = e, this._restrictedEnabledOverridden = !0
        }
        get storefrontCountryCode() {
            if (!this._storefrontCountryCode) {
                const e = this._getStorageItem(Se.STOREFRONT_COUNTRY_CODE);
                this._storefrontCountryCode = (null == e ? void 0 : e.toLowerCase()) || Me.ID
            }
            return this._storefrontCountryCode
        }
        set storefrontCountryCode(e) {
            e && this.userToken ? this._setStorageItem(Se.STOREFRONT_COUNTRY_CODE, e) : this._removeStorageItem(Se.STOREFRONT_COUNTRY_CODE), e !== this._storefrontCountryCode && (this._storefrontCountryCode = e, this.dispatchEvent("storefrontCountryCodeDidChange", {
                storefrontCountryCode: e
            }))
        }
        get storefrontIdentifier() {
            return this._storefrontIdentifier
        }
        set storefrontIdentifier(e) {
            this._storefrontIdentifier = e, this.dispatchEvent("storefrontIdentifierDidChange", {
                storefrontIdentifier: e
            })
        }
        runTokenValidations(e, n = !0) {
            e && validateToken(e) ? (n && this._setStorageItem(Se.USER_TOKEN, e), this.authorizationStatus = this.restrictedEnabled ? Ie.RESTRICTED : Ie.AUTHORIZED) : (this._removeStorageItem(Se.USER_TOKEN), this.authorizationStatus = Ie.NOT_DETERMINED)
        }
        wrapDynamicUserTokenForChanges(e, n = invoke(e)) {
            if ("function" != typeof e) return e;
            let s = n;
            return () => {
                const n = invoke(e);
                return s !== n && (s = n, this.runTokenValidations(n, !1), this.dispatchEvent("userTokenDidChange", {
                    userToken: n
                })), n || ""
            }
        }
        get dynamicUserToken() {
            return this._dynamicUserToken
        }
        set dynamicUserToken(e) {
            const n = invoke(e);
            this._dynamicUserToken = this.wrapDynamicUserTokenForChanges(e, n), this.runTokenValidations(n, "function" != typeof e), this.dispatchEvent("userTokenDidChange", {
                userToken: n
            })
        }
        get userToken() {
            return invoke(this.dynamicUserToken)
        }
        set userToken(e) {
            this.dynamicUserToken = e
        }
        get userTokenIsValid() {
            return validateToken(this.userToken)
        }
        deeplinkURL(e = {}) {
            return "https://finance-app.itunes.apple.com/deeplink?" + buildQueryParams(e = _object_spread$G({}, this.deeplinkParameters || {}, e))
        }
        itunesDeeplinkURL(e = {
            p: "browse"
        }) {
            return "https://itunes.apple.com/deeplink?" + buildQueryParams(e = _object_spread$G({}, this.deeplinkParameters || {}, e))
        }
        pldfltcid() {
            var e = this;
            return _async_to_generator$11((function*() {
                if (!e._cids[Se.DEFAULT_CID]) try {
                    yield e.infoRefresh()
                } catch (Rt) {
                    return
                }
                return e._cids[Se.DEFAULT_CID]
            }))()
        }
        renewUserToken() {
            var e = this;
            return _async_to_generator$11((function*() {
                if (!e.userToken) return e.requestUserToken();
                const n = new Headers({
                        Authorization: "Bearer " + e.developerToken,
                        Accept: "application/json",
                        "Content-Type": "application/json",
                        "X-Apple-Music-User-Token": "" + e.userToken
                    }),
                    s = yield e.fetch(e.playBase + "/renewMusicToken", {
                        method: "POST",
                        headers: n
                    });
                if (401 === s.status) return yield e.revokeUserToken(), Promise.reject(new Error("Renew token"));
                const d = yield s.json();
                return d["music-token"] && (e.userToken = d["music-token"]), e.userToken
            }))()
        }
        requestStorefrontCountryCode() {
            var e = this;
            return _async_to_generator$11((function*() {
                if (e.authorizationStatus <= Ie.DENIED) return Promise.reject("Not authorized: " + e.authorizationStatus);
                const n = new Headers({
                        Authorization: "Bearer " + e.developerToken,
                        "Music-User-Token": e.userToken || ""
                    }),
                    s = yield e.fetch(e.apiBase + "/me/storefront", {
                        headers: n
                    });
                if (s && !s.ok) return 401 !== s.status && 403 !== s.status || e._reset(), Promise.reject("Storefront Country Code error.");
                const d = yield s.json();
                if (d.errors) return Promise.reject(d.errors);
                const [p] = d.data;
                return p && p.id ? (e.storefrontCountryCode = p.id, e.storefrontCountryCode) : Promise.reject("Storefront Country Code error.")
            }))()
        }
        requestStorefrontIdentifier() {
            var e = this;
            return _async_to_generator$11((function*() {
                if (!e.storefrontIdentifier) {
                    const n = yield class {
                        static inferFromLanguages(e, n = function() {
                            if ("undefined" == typeof navigator) return [];
                            if (navigator.languages) return navigator.languages;
                            const e = navigator.language || navigator.userLanguage;
                            return e ? [e] : []
                        }()) {
                            return _async_to_generator$12((function*() {
                                const s = yield function(e) {
                                    return _fetchStorefronts.apply(this, arguments)
                                }(e), d = s.map(e => e.id), p = n[0] || "en-US", [h, y] = p.toLowerCase().split(/-|_/), _ = d.includes(y) ? y : "us";
                                return s.find(e => e.id === _)
                            }))()
                        }
                        constructor(e, n, s) {
                            _define_property$1C(this, "id", void 0), _define_property$1C(this, "attributes", void 0), _define_property$1C(this, "href", void 0), _define_property$1C(this, "type", void 0), this.id = e, this.attributes = n, this.type = "storefronts", this.href = s || `/v1/${this.type}/${e}`
                        }
                    }.inferFromLanguages(e.developerToken);
                    e.storefrontIdentifier = n.id
                }
                return e.storefrontIdentifier
            }))()
        }
        requestUserToken() {
            var e = this;
            return _async_to_generator$11((function*() {
                if (e._serviceSetupView.isServiceView) return e.userToken || "";
                try {
                    const n = yield e._serviceSetupView.load({
                        action: $e.AUTHORIZE
                    });
                    e.cid = n.cid, e.userToken = n.userToken, e.restrictedEnabled = n.restricted
                } catch (n) {
                    return e._reset(), e.authorizationStatus = n, Promise.reject(n)
                }
                return e.userToken
            }))()
        }
        revokeUserToken() {
            var e = this;
            return _async_to_generator$11((function*() {
                try {
                    yield e._webPlayerLogout()
                } catch (Rt) {}
                e.dispatchEvent("authorizationStatusWillChange", {
                    authorizationStatus: e.authorizationStatus,
                    newAuthorizationStatus: Ie.NOT_DETERMINED
                }), e._reset(), e.dispatchEvent("authorizationStatusDidChange", {
                    authorizationStatus: e.authorizationStatus
                }), e.dispatchEvent("userTokenDidChange", {
                    userToken: e.userToken
                })
            }))()
        }
        setCids(e) {
            this._cids = _object_spread$G({}, this._cids, e), Object.keys(this._cids).forEach(e => {
                this._setStorageItem(e, this._cids[e])
            })
        }
        hasMusicSubscription() {
            var e = this;
            return _async_to_generator$11((function*() {
                return !!e.hasAuthorized && e._getIsActiveSubscription()
            }))()
        }
        _getIsActiveSubscription() {
            var e = this;
            return _async_to_generator$11((function*() {
                var n;
                return !!(null === (n = (yield e.me()).subscription) || void 0 === n ? void 0 : n.active)
            }))()
        }
        resetSubscribeViewEligibility() {
            this._dispatchedSubscribeView = !1
        }
        presentSubscribeViewForEligibleUsers(e = {}, n = !0) {
            var s = this;
            return _async_to_generator$11((function*() {
                const d = yield s.eligibleForSubscribeView();
                if (!s._serviceSetupView.isServiceView && d) {
                    if (!n) return s.dispatchEvent("eligibleForSubscribeView", e), void(s._dispatchedSubscribeView = !0);
                    try {
                        const e = yield s._serviceSetupView.load({
                            action: $e.SUBSCRIBE
                        });
                        return s._dispatchedSubscribeView = !0, e
                    } catch (p) {
                        return s.revokeUserToken()
                    }
                }
            }))()
        }
        infoRefresh() {
            var e = this;
            return _async_to_generator$11((function*() {
                if (e.authorizationStatus <= Ie.DENIED) return Promise.reject("Not authorized: " + e.authorizationStatus);
                const n = new Headers({
                    Authorization: "Bearer " + e.developerToken,
                    "Music-User-Token": e.userToken || ""
                });
                try {
                    const s = yield e.fetch(e.iTunesBuyBase + "/account/web/infoRefresh", {
                        credentials: "include",
                        headers: n
                    }), d = yield s.json();
                    e.setCids(d)
                } catch (Rt) {}
            }))()
        }
        me() {
            if (this.authorizationStatus <= Ie.DENIED) return Promise.reject("Not authorized: " + this.authorizationStatus);
            if (!this._me) {
                var n = this;
                this._me = new Promise((s = _async_to_generator$11((function*(s, d) {
                    const p = new Headers({
                            Authorization: "Bearer " + n.developerToken,
                            "Music-User-Token": n.userToken || ""
                        }),
                        h = buildURL(n.apiBase, "/me/account", _object_spread$G({
                            meta: "subscription"
                        }, n.meParameters));
                    let y;
                    try {
                        y = yield n.fetch(h, {
                            headers: p
                        })
                    } catch (Rt) {
                        return d(new MKError(MKError.Reason.NETWORK_ERROR, "Failed to fetch /me/account"))
                    }
                    if (y && !y.ok) return n.realm === e.SKRealm.TV || 401 !== y.status && 403 !== y.status || n._reset(), d("Account error.");
                    let _ = yield y.json();
                    if (_.errors) return d(_.errors);
                    const {
                        data: m,
                        meta: v
                    } = _;
                    if (!v || !v.subscription) return d("Account error.");
                    n.storefrontCountryCode = v.subscription.storefront;
                    const g = {
                        meta: v,
                        subscription: v.subscription
                    };
                    return m && m.length && (g.attributes = m[0].attributes), s(g)
                })), function(e, n) {
                    return s.apply(this, arguments)
                })).then(e => {
                    var n;
                    return this._getIsActiveSubscription.updateCache((null === (n = e.subscription) || void 0 === n ? void 0 : n.active) || !1), this._me = null, e
                }).catch(e => (this._me = null, Promise.reject(e)))
            }
            var s;
            return this._me
        }
        _getStorageItem(e) {
            var n;
            if (e) return "cookie" === this.persist ? getCookie(e) : "localstorage" === this.persist ? null === (n = this.storage) || void 0 === n ? void 0 : n.getItem(`${this.storagePrefix}.${e}`) : void 0
        }
        _processLocationHash(e) {
            const n = /^\#([a-zA-Z0-9+\/]{200,}={0,2})$/;
            if (n.test(e)) {
                const s = e.replace(n, "$1");
                try {
                    const {
                        itre: e,
                        musicUserToken: n,
                        cid: d
                    } = JSON.parse(atob(s));
                    this.restrictedEnabled = e && "1" === e, this.userToken = n, this.cid = d
                } catch (Rt) {}
                history.replaceState(null, document.title, " ")
            }
        }
        _removeStorageItem(e) {
            if ("cookie" === this.persist) this._removeCookieFromDomains(e);
            else if ("localstorage" === this.persist) {
                var n;
                return null === (n = this.storage) || void 0 === n ? void 0 : n.removeItem(`${this.storagePrefix}.${e}`)
            }
        }
        _removeCookieFromDomains(e, n = window) {
            Ee.debug("Calling removeCookie", e), removeCookie(e);
            const {
                hostname: s
            } = n.location, d = s.split(".");
            if (d.length && (d.shift(), d.length > 2))
                for (let p = d.length; p > 2; p--) {
                    const s = d.join(".");
                    d.shift(), Ee.debug("Calling removeCookie", e, n, s), removeCookie(e, n, s)
                }
        }
        _reset(e = Ie.NOT_DETERMINED) {
            this._authorizationStatus = e, this._cids = {}, this._dispatchedSubscribeView = !1, this._restrictedEnabled = void 0, this._storefrontCountryCode = void 0, this._getIsActiveSubscription.updateCache(void 0), Object.keys(Te).forEach(e => {
                this._removeStorageItem(Te[e])
            }), this._removeStorageItem(Se.RESTRICTIONS_ENABLED), this._removeStorageItem(Se.USER_TOKEN), this._removeStorageItem(Se.STOREFRONT_COUNTRY_CODE), this._dynamicUserToken = void 0, this._me = null
        }
        _setStorageItem(e, n) {
            if ("cookie" === this.persist) {
                var s;
                if (null === (s = this.reflector) || void 0 === s ? void 0 : s.skipJsCookieWrite(e)) return;
                return Ee.debug("Calling setCookie from _setStorageItem", e, n), setCookie(e, n, "/", 180, void 0, function(e) {
                    let n = e;
                    return e && me.some((function(s) {
                        if (e.endsWith("." + s)) return n = s, !0
                    })), n
                }(window.location.hostname))
            }
            var d;
            if ("localstorage" === this.persist) return null === (d = this.storage) || void 0 === d ? void 0 : d.setItem(`${this.storagePrefix}.${e}`, n)
        }
        _webPlayerLogout() {
            var e = this;
            return _async_to_generator$11((function*() {
                const n = e.logoutURL;
                if (!n) return;
                const s = new Headers({
                        Authorization: "Bearer " + e.developerToken,
                        Accept: "application/json",
                        "Content-Type": "application/json",
                        "X-Apple-Music-User-Token": "" + e.userToken
                    }),
                    d = yield e.fetch(n, {
                        method: "POST",
                        headers: s,
                        credentials: "same-origin"
                    });
                return d && !d.ok ? Promise.reject(d.status) : d.json()
            }))()
        }
        constructor(n, s) {
            var d;
            (super(["authorizationStatusDidChange", "authorizationStatusWillChange", "eligibleForSubscribeView", "storefrontCountryCodeDidChange", "userTokenDidChange", "storefrontIdentifierDidChange"]), _define_property$1B(this, "developerToken", void 0), _define_property$1B(this, "apiBase", void 0), _define_property$1B(this, "bundleId", void 0), _define_property$1B(this, "cidNamespace", void 0), _define_property$1B(this, "deeplinkParameters", void 0), _define_property$1B(this, "iconURL", void 0), _define_property$1B(this, "iTunesBuyBase", void 0), _define_property$1B(this, "meParameters", void 0), _define_property$1B(this, "persist", void 0), _define_property$1B(this, "playBase", void 0), _define_property$1B(this, "prefix", void 0), _define_property$1B(this, "realm", void 0), _define_property$1B(this, "storage", void 0), _define_property$1B(this, "storagePrefix", void 0), _define_property$1B(this, "whenAuthCompleted", void 0), _define_property$1B(this, "fetch", void 0), _define_property$1B(this, "_authorizationStatus", void 0), _define_property$1B(this, "_developerToken", void 0), _define_property$1B(this, "_disableLogoutURL", void 0), _define_property$1B(this, "_dispatchedSubscribeView", void 0), _define_property$1B(this, "_me", void 0), _define_property$1B(this, "_cids", void 0), _define_property$1B(this, "_restrictedEnabled", void 0), _define_property$1B(this, "_restrictedEnabledOverridden", void 0), _define_property$1B(this, "_serviceSetupView", void 0), _define_property$1B(this, "reflector", void 0), _define_property$1B(this, "_storefrontCountryCode", void 0), _define_property$1B(this, "_storefrontIdentifier", void 0), _define_property$1B(this, "_dynamicUserToken", void 0), this.developerToken = n, this.apiBase = "https://api.music.apple.com/v1", this.iTunesBuyBase = De, this.meParameters = {}, this.persist = "localstorage", this.playBase = Le, this.prefix = "music", this.realm = e.SKRealm.MUSIC, this.storage = getLocalStorage(), this._authorizationStatus = Ie.NOT_DETERMINED, this._disableLogoutURL = !1, this._dispatchedSubscribeView = !1, this._me = null, this._cids = {}, this._restrictedEnabledOverridden = !1, this._dynamicUserToken = getCookie(Se.USER_TOKEN), Ee.info("StoreKit initialized"), s && (s.apiBase && (this.apiBase = s.apiBase), s.deeplink && (this.deeplinkParameters = s.deeplink), s.meParameters && (this.meParameters = s.meParameters), s.persist && (this.persist = s.persist), s.prefix && (this.prefix = s.prefix), void 0 !== s.realm && (this.realm = s.realm), this.bundleId = ke[this.realm]), this.fetch = void 0 !== s && "function" == typeof s.fetch ? s.fetch : globalThis.fetch.bind(globalThis), this.cidNamespace = Te[this.realm], this._developerToken = new DeveloperToken(n), this._serviceSetupView = new ServiceSetupView(n, {
                authenticateMethod: s && s.authenticateMethod,
                iconURL: s && s.iconURL,
                deeplinkParameters: this.deeplinkParameters
            }), this.storagePrefix = `${this.prefix}.${this._developerToken.teamId}`.toLocaleLowerCase(), this.updateUserTokenFromStorage(), this.developerToken && this.userTokenIsValid && (this._restrictedEnabled = this.restrictedEnabled), this._storefrontCountryCode = this.storefrontCountryCode, this.whenAuthCompleted = Promise.resolve(), isNodeEnvironment$1()) || (this._processLocationHash(window.location.hash), "cookie" === this.persist && (null === (d = this.reflector) || void 0 === d || d.refresh()))
        }
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([((e = 300) => (n, s, d) => {
        if (void 0 === d || "function" != typeof d.value) throw new TypeError(`Only methods can be decorated with @CachedResult, but ${s} is not a method.`);
        return {
            configurable: !0,
            get: function() {
                const n = d.value,
                    p = 1e3 * e;
                let h, y = -1;

                function cachedResultMethod() {
                    return _cachedResultMethod.apply(this, arguments)
                }

                function _cachedResultMethod() {
                    return (_cachedResultMethod = _async_to_generator$15((function*(...e) {
                        const s = Date.now();
                        return (void 0 === h || -1 === y || y > 0 && s > y + p) && (y = s, h = yield n.apply(this, e)), h
                    }))).apply(this, arguments)
                }
                return cachedResultMethod.updateCache = function(e) {
                    y = Date.now(), h = e
                }, cachedResultMethod.getCachedValue = () => h, Object.defineProperty(this, s, {
                    value: cachedResultMethod,
                    configurable: !0,
                    writable: !0
                }), cachedResultMethod
            }
        }
    })(900), _ts_metadata$p("design:type", Function), _ts_metadata$p("design:paramtypes", []), _ts_metadata$p("design:returntype", Promise)], StoreKit.prototype, "_getIsActiveSubscription", null);
    const xe = new Logger("player"),
        je = new Logger("paf"),
        Ne = new Logger("services"),
        Ue = BooleanDevFlag.register("mk-console-logging"),
        Fe = StringDevFlag.register("mk-logging-levels"),
        Be = w.ERROR;
    let Ke = Be;
    const Ge = new Logger("mk", {
        level: Ke,
        handlers: {
            console: new class {
                get hasConsole() {
                    return "undefined" != typeof console
                }
                process(e) {
                    if (!this.enabled || !this.hasConsole) return;
                    let n = "log";
                    if (this.mapLevels) {
                        const d = this.levelMapping.get(e.level);
                        void 0 !== (s = d) && s in console && (n = d)
                    }
                    var s, d;
                    const p = null !== (d = e.args) && void 0 !== d ? d : [],
                        h = this.format(e);
                    console[n](h, ...p)
                }
                constructor(e = {}) {
                    var n, s, d, p;
                    _define_property$1S(this, "enabled", void 0), _define_property$1S(this, "mapLevels", void 0), _define_property$1S(this, "levelMapping", void 0), _define_property$1S(this, "format", void 0), this.enabled = null === (n = e.enabled) || void 0 === n || n, this.mapLevels = null === (s = e.mapLevels) || void 0 === s || s, this.levelMapping = null !== (d = e.levelMapping) && void 0 !== d ? d : $, this.format = null !== (p = e.formatter) && void 0 !== p ? p : M
                }
            }({
                enabled: !1
            }),
            external: new CallbackHandler(() => {})
        }
    });

    function applyLoggingLevels(e) {
        ! function(e, n) {
            walk(e, (function(e) {
                let s;
                const d = e.namespace;
                e.clearLevel(), void 0 === e.parent && void 0 !== n["*"] ? s = getLoggingLevel(n["*"]) : void 0 !== n[d] && (s = getLoggingLevel(n[d])), void 0 !== s && e.setLevel(s)
            }))
        }(Ge, function(e) {
            const n = getLoggingLevel(e.trim(), {
                allowShorthands: !0
            });
            if (void 0 !== n) return {
                "*": n
            };
            const s = {},
                d = e.split(",").filter(e => "" !== e.trim());
            for (const m of d) {
                var p, h;
                const e = m.split("=", 2);
                if (2 !== e.length) continue;
                var y;
                const n = null !== (y = null === (p = e[0]) || void 0 === p ? void 0 : p.trim()) && void 0 !== y ? y : "";
                var _;
                const d = getLoggingLevel(null !== (_ = null === (h = e[1]) || void 0 === h ? void 0 : h.trim()) && void 0 !== _ ? _ : "", {
                    allowShorthands: !0
                });
                "" !== n && void 0 !== d && (s[n] = d)
            }
            return s
        }(e))
    }

    function clearLoggingLevels() {
        Ge.setLevel(Ke),
            function(e, n = {
                includeRoot: !0
            }) {
                walk(e, (function(e) {
                    (void 0 !== e.parent || n.includeRoot) && e.clearLevel()
                }))
            }(Ge, {
                includeRoot: !1
            })
    }

    function setConsoleOutput(e) {
        Ge.handlers.console.enabled = null != e && e
    }

    function setRootLoggingLevel(e) {
        var n;
        Ke = null !== (n = getLoggingLevel(e)) && void 0 !== n ? n : Ke
    }
    const Ve = {
        getLogger: (e = "*") => Ge.getByNamespace(null != e ? e : "*"),
        setConsoleOutput(e) {
            !0 === e ? (Ue.enable(), setConsoleOutput(!0), Ge.info("Console output is enabled with level " + Ge.levelName)) : (Ue.disable(), setConsoleOutput(!1))
        },
        setLoggingLevels(e, n) {
            "" !== e.trim() ? (Fe.set(e), applyLoggingLevels(e), Ve.setConsoleOutput(null == n || n)) : Ve.clearLoggingLevels(null != n && n)
        },
        clearLoggingLevels(e = !1) {
            Ve.setConsoleOutput(e), Fe.clear(), clearLoggingLevels()
        },
        listLoggers: e => function(e) {
            const n = {};
            void 0 !== e && (e = e.startsWith("mk/") ? e : "mk/" + e);
            const s = Ge.children;
            for (; s.length > 0;) {
                const d = s.shift();
                if (void 0 === d) break;
                (void 0 === e || d.namespace.startsWith(e)) && (n[d.namespace] = d.levelName, s.unshift(...d.children))
            }
            return n
        }(e)
    };
    var He;
    Ue.enabled && Ve.setConsoleOutput(Ue.enabled), void 0 !== Fe.value && Ve.setLoggingLevels(Fe.value, Ue.enabled),
        function(e) {
            e.NONE = "none", e.FAIRPLAY = "com.apple.fps", e.PLAYREADY = "com.microsoft.playready", e.WIDEVINE = "com.widevine.alpha"
        }(He || (He = {}));
    const qe = {
            app: {},
            features: {},
            urls: {}
        },
        We = "mk-player-tsid",
        ze = 'audio/mp4;codecs="mp4a.40.2"';
    var Ye, Qe, Je;

    function asyncGeneratorStep$10(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$10(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$10(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$10(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function findMediaKeySystemAccess(e, n) {
        return _findMediaKeySystemAccess.apply(this, arguments)
    }

    function _findMediaKeySystemAccess() {
        return (_findMediaKeySystemAccess = _async_to_generator$10((function*(e, n) {
            for (let s = 0; s < e.length; s++) try {
                const d = e[s];
                return [d, yield navigator.requestMediaKeySystemAccess(d, n)]
            } catch (Rt) {}
            return []
        }))).apply(this, arguments)
    }! function(e) {
        e.playbackLicenseError = "playbackLicenseError", e.playbackSessionError = "playbackSessionError", e.manifestParsed = "manifestParsed", e.audioCodecIdentified = "audioCodecIdentified", e.audioTracksSwitched = "audioTracksSwitched", e.audioTracksUpdated = "audioTracksUpdated", e.textTracksSwitched = "textTracksSwitched", e.textTracksUpdated = "textTracksUpdated", e.inlineStylesParsed = "inlineStylesParsed", e.levelUpdated = "levelUpdated"
    }(Ye || (Ye = {})),
    function(e) {
        e.MP4 = "audio/mp4", e.AVC1 = "video/mp4"
    }(Qe || (Qe = {})),
    function(e) {
        e.WIDEVINE = "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed", e.PLAYREADY = "com.microsoft.playready", e.FAIRPLAY = "com.apple.streamingkeydelivery"
    }(Je || (Je = {}));
    let Xe;
    const {
        NONE: Ze,
        FAIRPLAY: et,
        WIDEVINE: tt,
        PLAYREADY: rt
    } = He;

    function supportsDrm() {
        if (!Xe) throw new Error("findKeySystemPreference has not been invoked");
        return Xe !== Ze
    }

    function potentialKeySystemsForAccess() {
        return function() {
            const e = getSessionStorage();
            return !!e && "true" === e.getItem("mk-playready-cbcs-unsupported")
        }() ? [tt] : qe.features["prefer-playready"] ? [rt, tt] : [tt, rt]
    }

    function findKeySystemPreference(e) {
        return _findKeySystemPreference.apply(this, arguments)
    }

    function _findKeySystemPreference() {
        return (_findKeySystemPreference = _async_to_generator$10((function*(e) {
            var n, s, d;
            if (null === (d = null == e ? void 0 : e.isNodeEnvironment) || void 0 === d || !d) {
                if (null === (n = window.WebKitMediaKeys) || void 0 === n ? void 0 : n.isTypeSupported(et + ".1_0", Qe.AVC1)) Xe = et;
                else if (null === (s = window.MSMediaKeys) || void 0 === s ? void 0 : s.isTypeSupported(rt, Qe.AVC1)) Xe = rt;
                else {
                    const e = document.createElement("video");
                    if (hasMediaKeySupport() && e.canPlayType('video/mp4;codecs="avc1.42E01E"') && e.canPlayType(ze)) {
                        const e = [{
                                initDataTypes: ["keyids", "cenc"],
                                distinctiveIdentifier: "optional",
                                persistentState: "required",
                                videoCapabilities: [{
                                    contentType: 'video/mp4;codecs="avc1.42E01E"',
                                    robustness: "SW_SECURE_CRYPTO"
                                }],
                                audioCapabilities: [{
                                    contentType: ze
                                }]
                            }],
                            n = potentialKeySystemsForAccess(),
                            [s] = yield findMediaKeySystemAccess(n, e);
                        Xe = s
                    }
                }
                return Xe = null != Xe ? Xe : Ze, Xe
            }
            Xe = Ze
        }))).apply(this, arguments)
    }

    function hasMediaKeySupport() {
        return !!(navigator && navigator.requestMediaKeySystemAccess && window.MediaKeys && window.MediaKeySystemAccess)
    }
    const AsyncDebounce = (e = 100, n) => (s, d, p) => {
            const h = p.value,
                y = asyncDebounce(h, e, n);
            p.value = y
        },
        asyncDebounce = (e, n = 250, s = {
            isImmediate: !1
        }) => {
            let d, p;

            function fulfill(e) {
                return null == e ? void 0 : e.resolve(s.cancelledValue)
            }
            const clearLastPromise = () => {
                    d && (d.resolved || (fulfill(d), d.timeoutId && clearTimeout(d.timeoutId)), d = void 0)
                },
                invokeFn = (n, s, p, h) => {
                    e.apply(n, h).then(e => {
                        s(e), d && (d.resolved = !0)
                    }).catch(p)
                };
            return s.isImmediate ? function(...e) {
                const s = Date.now(),
                    h = this;
                return p && s >= p && clearLastPromise(), p = Date.now() + n, d ? fulfill(Promise) : new Promise((n, s) => {
                    d = {
                        resolve: n,
                        reject: s
                    }, invokeFn(h, n, s, e)
                })
            } : function(...e) {
                const s = this;
                return d && clearLastPromise(), new Promise((function(p, h) {
                    const y = setTimeout(invokeFn.bind(void 0, s, p, h, e), n);
                    d = {
                        resolve: p,
                        reject: h,
                        timeoutId: y
                    }
                }))
            }
        };

    function asyncGeneratorStep$$(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$$(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$$(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$$(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }
    const it = {},
        SerialAsync = e => {
            let n = Promise.resolve();
            return (s, d, p) => {
                const h = p.value;
                return p.value = _async_to_generator$$((function*(...s) {
                    return e && (n = (e => {
                        let n = it[e];
                        return n || (n = Promise.resolve(), it[e] = n), n
                    })(e)), n = n.catch(() => {}).then(() => h.apply(this, s)), e && (it[e] = n), n
                })), p
            }
        };
    var nt, ot, at;
    e.PlaybackBitrate = void 0, (nt = e.PlaybackBitrate || (e.PlaybackBitrate = {}))[nt.STANDARD = 64] = "STANDARD", nt[nt.HIGH = 256] = "HIGH",
        function(e) {
            e.apiStorefrontChanged = "apiStorefrontChanged", e.hlsLevelUpdated = "hlsLevelUpdated", e.mediaContentComplete = "mediaContentComplete", e.playbackPause = "playbackPause", e.playbackPlay = "playbackPlay", e.playbackScrub = "playbackScrub", e.playbackSeek = "playbackSeek", e.playbackSkip = "playbackSkip", e.playbackStop = "playbackStop", e.lyricsPlay = "lyricsPlay", e.lyricsStop = "lyricsStop", e.playerActivate = "playerActivate", e.playerExit = "playerExit", e.queueModified = "queueModified", e.userActivityIntent = "userActivityIntent", e.applicationActivityIntent = "applicationActivityIntent", e.timedMetadata = "timedMetadata"
        }(ot || (ot = {})),
        function(e) {
            e[e.ACCURATE = 0] = "ACCURATE", e[e.ROUND = 1] = "ROUND"
        }(at || (at = {}));
    class TimingAccuracy {
        time(e = 0) {
            return 1 === this.mode ? Math.round(e) : e
        }
        constructor(e = !1) {
            ! function(e, n, s) {
                n in e ? Object.defineProperty(e, n, {
                    value: s,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = s
            }(this, "mode", void 0), this.mode = e ? 0 : 1
        }
    }
    const st = {
        audioTrackAdded: "audioTrackAdded",
        audioTrackChanged: "audioTrackChanged",
        audioTrackRemoved: "audioTrackRemoved",
        bufferedProgressDidChange: "bufferedProgressDidChange",
        drmUnsupported: "drmUnsupported",
        forcedTextTrackChanged: "forcedTextTrackChanged",
        mediaCanPlay: "mediaCanPlay",
        mediaElementCreated: "mediaElementCreated",
        mediaPlaybackError: "mediaPlaybackError",
        nowPlayingItemDidChange: "nowPlayingItemDidChange",
        nowPlayingItemWillChange: "nowPlayingItemWillChange",
        metadataDidChange: "metadataDidChange",
        hlsDaterangeUpdated: "player.hls.daterangeUpdated",
        playbackBitrateDidChange: "playbackBitrateDidChange",
        playbackDurationDidChange: "playbackDurationDidChange",
        playbackProgressDidChange: "playbackProgressDidChange",
        playbackRateDidChange: "playbackRateDidChange",
        playbackStateDidChange: "playbackStateDidChange",
        playbackStateWillChange: "playbackStateWillChange",
        playbackTargetAvailableDidChange: "playbackTargetAvailableDidChange",
        playbackTargetIsWirelessDidChange: "playbackTargetIsWirelessDidChange",
        playbackTimeDidChange: "playbackTimeDidChange",
        playbackVolumeDidChange: "playbackVolumeDidChange",
        playerTypeDidChange: "playerTypeDidChange",
        presentationModeDidChange: "presentationModeDidChange",
        primaryPlayerDidChange: "primaryPlayerDidChange",
        textTrackAdded: "textTrackAdded",
        textTrackChanged: "textTrackChanged",
        textTrackRemoved: "textTrackRemoved",
        timedMetadataDidChange: "timedMetadataDidChange"
    };

    function _define_property$1z(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class BitrateCalculator {
        get bitrate() {
            return this._bitrate
        }
        set bitrate(e) {
            this._bitrate !== e && (this._bitrate = e, this._dispatcher.publish(st.playbackBitrateDidChange, {
                bitrate: e
            }))
        }
        _calculateAverageDownlink() {
            return 0 === this._downlinkSamples.length ? 0 : this._downlinkSamples.reduce((e, n) => e + n, 0) / this._downlinkSamples.length || 0
        }
        _recalculateBitrate(n) {
            xe.debug("_recalculateBitrate", n), this._downlinkSamples.push(n);
            this._calculateAverageDownlink() > e.PlaybackBitrate.STANDARD ? (xe.debug("setting bitrate to", e.PlaybackBitrate.HIGH), this.bitrate = e.PlaybackBitrate.HIGH) : (xe.debug("setting bitrate to", e.PlaybackBitrate.STANDARD), this.bitrate = e.PlaybackBitrate.STANDARD)
        }
        constructor(n, s = e.PlaybackBitrate.STANDARD) {
            var d, p, h;
            _define_property$1z(this, "_bitrate", void 0), _define_property$1z(this, "_dispatcher", void 0), _define_property$1z(this, "_downlinkSamples", []), this._bitrate = s, this._dispatcher = n, void 0 !== (null === (h = window) || void 0 === h || null === (p = h.navigator) || void 0 === p || null === (d = p.connection) || void 0 === d ? void 0 : d.downlink) && this._recalculateBitrate(100 * (window.navigator.connection.downlink || 0))
        }
    }
    var ct, dt, lt, ut, pt, ht, yt;
    ! function(e) {
        e.MUSICKIT = "music_kit-integration", e.OTHER = "other", e.MINI = "mini", e.SONG = "song", e.ALBUM = "album", e.ALBUM_CLASSICAL = "album-classical", e.ARTIST = "artist", e.COMPILATION = "compilation", e.COMPILATION_CLASSICAL = "compilation-classical", e.PLAYLIST = "playlist", e.PLAYLIST_CLASSICAL = "playlist-classical", e.RADIO = "radio", e.SEARCH = "search", e.STATION = "station"
    }(ct || (ct = {})),
    function(e) {
        e[e.UNKNOWN = 0] = "UNKNOWN", e[e.RADIO = 1] = "RADIO", e[e.PLAYLIST = 2] = "PLAYLIST", e[e.ALBUM = 3] = "ALBUM", e[e.ARTIST = 4] = "ARTIST"
    }(dt || (dt = {})), e.PlayActivityEndReasonType = void 0, (lt = e.PlayActivityEndReasonType || (e.PlayActivityEndReasonType = {}))[lt.NOT_APPLICABLE = 0] = "NOT_APPLICABLE", lt[lt.OTHER = 1] = "OTHER", lt[lt.TRACK_SKIPPED_FORWARDS = 2] = "TRACK_SKIPPED_FORWARDS", lt[lt.PLAYBACK_MANUALLY_PAUSED = 3] = "PLAYBACK_MANUALLY_PAUSED", lt[lt.PLAYBACK_SUSPENDED = 4] = "PLAYBACK_SUSPENDED", lt[lt.MANUALLY_SELECTED_PLAYBACK_OF_A_DIFF_ITEM = 5] = "MANUALLY_SELECTED_PLAYBACK_OF_A_DIFF_ITEM", lt[lt.PLAYBACK_PAUSED_DUE_TO_INACTIVITY = 6] = "PLAYBACK_PAUSED_DUE_TO_INACTIVITY", lt[lt.NATURAL_END_OF_TRACK = 7] = "NATURAL_END_OF_TRACK", lt[lt.PLAYBACK_STOPPED_DUE_TO_SESSION_TIMEOUT = 8] = "PLAYBACK_STOPPED_DUE_TO_SESSION_TIMEOUT", lt[lt.TRACK_BANNED = 9] = "TRACK_BANNED", lt[lt.FAILED_TO_LOAD = 10] = "FAILED_TO_LOAD", lt[lt.PAUSED_ON_TIMEOUT = 11] = "PAUSED_ON_TIMEOUT", lt[lt.SCRUB_BEGIN = 12] = "SCRUB_BEGIN", lt[lt.SCRUB_END = 13] = "SCRUB_END", lt[lt.TRACK_SKIPPED_BACKWARDS = 14] = "TRACK_SKIPPED_BACKWARDS", lt[lt.NOT_SUPPORTED_BY_CLIENT = 15] = "NOT_SUPPORTED_BY_CLIENT", lt[lt.QUICK_PLAY = 16] = "QUICK_PLAY", lt[lt.EXITED_APPLICATION = 17] = "EXITED_APPLICATION",
        function(e) {
            e[e.Manual = 0] = "Manual", e[e.Interval = 1] = "Interval", e[e.SkipIntro = 2] = "SkipIntro", e[e.Automatic = 3] = "Automatic", e[e.SkipToLiveManual = 4] = "SkipToLiveManual", e[e.SkipToLiveAutomatic = 5] = "SkipToLiveAutomatic"
        }(ut || (ut = {})),
        function(e) {
            e[e.UNKNOWN = 0] = "UNKNOWN", e[e.NO_RIGHTS = 1] = "NO_RIGHTS", e[e.PURCHASED = 2] = "PURCHASED", e[e.UPLOADED = 3] = "UPLOADED", e[e.MATCHED = 4] = "MATCHED", e[e.ADDED = 5] = "ADDED", e[e.SUBSCRIBED = 6] = "SUBSCRIBED", e[e.NOT_SUPPORTED = 7] = "NOT_SUPPORTED"
        }(pt || (pt = {})),
        function(e) {
            e[e.NO_SELECTION_PLAY = 0] = "NO_SELECTION_PLAY", e[e.RESUME_LAST_PLAYED_SONG = 1] = "RESUME_LAST_PLAYED_SONG", e[e.RESUME_CURRENT_DEVICE_POSITION = 2] = "RESUME_CURRENT_DEVICE_POSITION"
        }(ht || (ht = {})),
        function(e) {
            e[e.NOT_APPLICABLE = 0] = "NOT_APPLICABLE", e[e.SIMILARITIES = 1] = "SIMILARITIES", e[e.ESSENTIALS = 2] = "ESSENTIALS", e[e.USER_LIBRARY = 3] = "USER_LIBRARY", e[e.ALGO_HEATSEEKER = 4] = "ALGO_HEATSEEKER", e[e.SEED_TRACK = 5] = "SEED_TRACK", e[e.GN_1M_TEMPORARY = 6] = "GN_1M_TEMPORARY", e[e.VECTOR = 8] = "VECTOR", e[e.ARTIST_SIMILARITIES = 9] = "ARTIST_SIMILARITIES", e[e.STORY_ALBUM_LISTENERS_ALSO_BOUGHT = 10] = "STORY_ALBUM_LISTENERS_ALSO_BOUGHT", e[e.STORY_ALBUM_SALES_LEADER = 11] = "STORY_ALBUM_SALES_LEADER", e[e.STORY_BILLBOARD = 12] = "STORY_BILLBOARD", e[e.STORY_COMPLETE_MY_ALBUM = 13] = "STORY_COMPLETE_MY_ALBUM", e[e.STORY_CRITICAL_PICK = 14] = "STORY_CRITICAL_PICK", e[e.STORY_ITUNES_ESSENTIAL = 15] = "STORY_ITUNES_ESSENTIAL", e[e.STORY_HEATSEEKER = 16] = "STORY_HEATSEEKER", e[e.STORY_IDENTITY = 17] = "STORY_IDENTITY", e[e.STORY_POWER_SONG = 18] = "STORY_POWER_SONG", e[e.STORY_SONG_SALES_LEADER = 20] = "STORY_SONG_SALES_LEADER", e[e.GENRE_SIMILARITIES = 21] = "GENRE_SIMILARITIES", e[e.STORY_IMIX = 22] = "STORY_IMIX", e[e.STORY_OTHER_MIX = 23] = "STORY_OTHER_MIX", e[e.EDITORIAL = 24] = "EDITORIAL", e[e.TOP_SONGS = 25] = "TOP_SONGS", e[e.SUBFORMAT_SONGS = 26] = "SUBFORMAT_SONGS", e[e.CRITICAL_PICKS = 27] = "CRITICAL_PICKS", e[e.US_ARTIST_SIMS = 28] = "US_ARTIST_SIMS", e[e.HEAVY_ROTATION = 29] = "HEAVY_ROTATION", e[e.STORY_FORMAT_STATION_HEAVY_ROTATION = 30] = "STORY_FORMAT_STATION_HEAVY_ROTATION", e[e.ARTIST_BASED_CORE_SIMILAR_ARTISTS = 31] = "ARTIST_BASED_CORE_SIMILAR_ARTISTS", e[e.ARTIST_BASED_FAMILIAR_SIMILAR_ARTISTS = 32] = "ARTIST_BASED_FAMILIAR_SIMILAR_ARTISTS", e[e.ARTIST_BASED_DISCOVERIES = 33] = "ARTIST_BASED_DISCOVERIES", e[e.ARTIST_BASED_HOT_SONGS = 34] = "ARTIST_BASED_HOT_SONGS", e[e.ARTIST_BASED_SEED_ARTIST = 35] = "ARTIST_BASED_SEED_ARTIST", e[e.ARTIST_BASED_COMPOSER = 36] = "ARTIST_BASED_COMPOSER", e[e.EDITORIAL_STATION_INTRO = 37] = "EDITORIAL_STATION_INTRO", e[e.EDITORIAL_RELATIVE_REPEAT = 38] = "EDITORIAL_RELATIVE_REPEAT", e[e.EDITORIAL_ABSOLUTE_REPEAT = 39] = "EDITORIAL_ABSOLUTE_REPEAT", e[e.EDITORIAL_SCHEDULED = 40] = "EDITORIAL_SCHEDULED", e[e.EDITORIAL_SUGGESTED_ARTIST = 41] = "EDITORIAL_SUGGESTED_ARTIST", e[e.FOR_YOU_FAMILIAR = 42] = "FOR_YOU_FAMILIAR", e[e.FOR_YOU_RECOMMENDED = 43] = "FOR_YOU_RECOMMENDED", e[e.FOR_YOU_FAVORITE_ARTIST = 44] = "FOR_YOU_FAVORITE_ARTIST", e[e.FOR_YOU_RECOMMENDED_ARTIST = 45] = "FOR_YOU_RECOMMENDED_ARTIST", e[e.EDITORIAL_POSITIONAL = 46] = "EDITORIAL_POSITIONAL", e[e.SIMILAR_SONGS = 47] = "SIMILAR_SONGS", e[e.SONG_ATTRIBUTE_FAVORITE_ARTIST = 48] = "SONG_ATTRIBUTE_FAVORITE_ARTIST", e[e.SONG_ATTRIBUTE_FAVORITE_ARTIST_DERIVED = 49] = "SONG_ATTRIBUTE_FAVORITE_ARTIST_DERIVED", e[e.SONG_ATTRIBUTE_FAVORITE_ARTIST_EDITORIAL = 50] = "SONG_ATTRIBUTE_FAVORITE_ARTIST_EDITORIAL", e[e.SONG_ATTRIBUTE_RECOMMENDED = 51] = "SONG_ATTRIBUTE_RECOMMENDED", e[e.SONG_ATTRIBUTE_RECOMMENDED_DERIVED = 52] = "SONG_ATTRIBUTE_RECOMMENDED_DERIVED", e[e.SONG_ATTRIBUTE_RECOMMENDED_EDITORIAL = 53] = "SONG_ATTRIBUTE_RECOMMENDED_EDITORIAL", e[e.SONG_ATTRIBUTE_NON_PERSONALIZED = 54] = "SONG_ATTRIBUTE_NON_PERSONALIZED", e[e.SONG_ATTRIBUTE_NON_PERSONALIZED_DERIVED = 55] = "SONG_ATTRIBUTE_NON_PERSONALIZED_DERIVED", e[e.SONG_ATTRIBUTE_NON_PERSONALIZED_EDITORIAL = 56] = "SONG_ATTRIBUTE_NON_PERSONALIZED_EDITORIAL", e[e.PERSONAL_STATION = 57] = "PERSONAL_STATION", e[e.PERSONAL_STATION_FAVORITE_ARTIST = 58] = "PERSONAL_STATION_FAVORITE_ARTIST", e[e.PERSONAL_STATION_RECOMMENDED = 59] = "PERSONAL_STATION_RECOMMENDED", e[e.NEW_MUSIC_STATION = 60] = "NEW_MUSIC_STATION", e[e.NEW_MUSIC_STATION_FAVORITE_ARTIST = 61] = "NEW_MUSIC_STATION_FAVORITE_ARTIST", e[e.NEW_MUSIC_STATION_RECOMMENDED = 62] = "NEW_MUSIC_STATION_RECOMMENDED"
        }(yt || (yt = {}));
    var _t, ft, mt, vt, gt, bt, St, Pt, kt, Tt, Et, wt, It, Ot;
    /*! *****************************************************************************
      Copyright (c) Microsoft Corporation.

      Permission to use, copy, modify, and/or distribute this software for any
      purpose with or without fee is hereby granted.

      THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
      REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
      AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
      INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
      LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
      OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
      PERFORMANCE OF THIS SOFTWARE.
      ***************************************************************************** */
    function t(e, n) {
        var s = "function" == typeof Symbol && e[Symbol.iterator];
        if (!s) return e;
        var d, p, h = s.call(e),
            y = [];
        try {
            for (;
                (void 0 === n || n-- > 0) && !(d = h.next()).done;) y.push(d.value)
        } catch (e) {
            p = {
                error: e
            }
        } finally {
            try {
                d && !d.done && (s = h.return) && s.call(h)
            } finally {
                if (p) throw p.error
            }
        }
        return y
    }! function(e) {
        e[e.UNKNOWN_FORMAT = 0] = "UNKNOWN_FORMAT", e[e.STEREO = 1] = "STEREO", e[e.SPATIAL = 2] = "SPATIAL", e[e.PREFERENCE_FORMAT_UNSUPPORTED = 3] = "PREFERENCE_FORMAT_UNSUPPORTED"
    }(_t || (_t = {})),
    function(e) {
        e[e.UNKNOWN_QUALITY = 0] = "UNKNOWN_QUALITY", e[e.HIGH_EFFICIENCY = 1] = "HIGH_EFFICIENCY", e[e.HIGH_QUALITY = 2] = "HIGH_QUALITY", e[e.LOSSLESS = 3] = "LOSSLESS", e[e.HIGH_RESOLUTION_LOSSLESS = 4] = "HIGH_RESOLUTION_LOSSLESS", e[e.PREFERENCE_QUALITY_UNSUPPORTED = 5] = "PREFERENCE_QUALITY_UNSUPPORTED"
    }(ft || (ft = {})),
    function(e) {
        e[e.UNSPECIFIED = 0] = "UNSPECIFIED", e[e.STATIC = 1] = "STATIC", e[e.LINE_BY_LINE = 2] = "LINE_BY_LINE", e[e.WORD_BY_WORD = 3] = "WORD_BY_WORD"
    }(mt || (mt = {})),
    function(e) {
        e[e.REPEAT_UNKNOWN = 0] = "REPEAT_UNKNOWN", e[e.REPEAT_OFF = 1] = "REPEAT_OFF", e[e.REPEAT_ONE = 2] = "REPEAT_ONE", e[e.REPEAT_ALL = 3] = "REPEAT_ALL"
    }(vt || (vt = {})),
    function(e) {
        e[e.SHUFFLE_UNKNOWN = 0] = "SHUFFLE_UNKNOWN", e[e.SHUFFLE_OFF = 1] = "SHUFFLE_OFF", e[e.SHUFFLE_ON = 2] = "SHUFFLE_ON"
    }(gt || (gt = {})),
    function(e) {
        e[e.AUTO_UNKNOWN = 0] = "AUTO_UNKNOWN", e[e.AUTO_OFF = 1] = "AUTO_OFF", e[e.AUTO_ON = 2] = "AUTO_ON", e[e.AUTO_ON_CONTENT_UNSUPPORTED = 3] = "AUTO_ON_CONTENT_UNSUPPORTED"
    }(bt || (bt = {})),
    function(e) {
        e[e.NOT_SPECIFIED = 0] = "NOT_SPECIFIED", e[e.CONTAINER_CHANGED = 1] = "CONTAINER_CHANGED"
    }(St || (St = {})),
    function(e) {
        e[e.PLAY_END = 0] = "PLAY_END", e[e.PLAY_START = 1] = "PLAY_START", e[e.LYRIC_DISPLAY = 2] = "LYRIC_DISPLAY"
    }(Pt || (Pt = {})),
    function(e) {
        e[e.INVALID = 0] = "INVALID", e[e.ITUNES_STORE_CONTENT = 1] = "ITUNES_STORE_CONTENT", e[e.NON_SONG_CLIP = 2] = "NON_SONG_CLIP", e[e.AD = 3] = "AD", e[e.STREAM = 4] = "STREAM", e[e.AUDIO_AD = 5] = "AUDIO_AD", e[e.VIDEO_AD = 6] = "VIDEO_AD", e[e.TIMED_METADATA_PING = 7] = "TIMED_METADATA_PING", e[e.ARTIST_UPLOADED_CONTENT = 8] = "ARTIST_UPLOADED_CONTENT", e[e.AGGREGATE_NON_CATALOG_PLAY_TIME = 9] = "AGGREGATE_NON_CATALOG_PLAY_TIME", e[e.ORIGINAL_CONTENT_MOVIES = 10] = "ORIGINAL_CONTENT_MOVIES", e[e.ORIGINAL_CONTENT_SHOWS = 11] = "ORIGINAL_CONTENT_SHOWS"
    }(kt || (kt = {})),
    function(e) {
        e[e.AUDIO = 0] = "AUDIO", e[e.VIDEO = 1] = "VIDEO"
    }(Tt || (Tt = {})),
    function(e) {
        e[e.AUTO = 0] = "AUTO", e[e.MANUAL = 1] = "MANUAL"
    }(Et || (Et = {})),
    function(e) {
        e[e.ORIGINATING_DEVICE = 0] = "ORIGINATING_DEVICE", e[e.PAIRED_WATCH = 1] = "PAIRED_WATCH", e[e.SONOS = 2] = "SONOS", e[e.CAR_PLAY = 3] = "CAR_PLAY", e[e.WEB_AUC = 4] = "WEB_AUC", e[e.TWITTER_AUC = 5] = "TWITTER_AUC", e[e.MUSIC_SDK = 6] = "MUSIC_SDK", e[e.ATV_REMOTE = 7] = "ATV_REMOTE", e[e.WEBPLAYER = 8] = "WEBPLAYER", e[e.WHOLE_HOUSE_AUDIO = 9] = "WHOLE_HOUSE_AUDIO", e[e.MUSICKIT = 10] = "MUSICKIT", e[e.VW = 11] = "VW", e[e.UNKNOWN_SOURCE_TYPE = 12] = "UNKNOWN_SOURCE_TYPE", e[e.AMAZON = 13] = "AMAZON", e[e.PORSCHE = 14] = "PORSCHE", e[e.CHROMECAST = 15] = "CHROMECAST", e[e.WEB_APP = 16] = "WEB_APP", e[e.MERCEDES_BENZ = 17] = "MERCEDES_BENZ", e[e.THIRD_PARTY_TV = 18] = "THIRD_PARTY_TV", e[e.SEAT = 19] = "SEAT", e[e.CUPRA = 20] = "CUPRA"
    }(wt || (wt = {})),
    function(e) {
        e[e.EPISODE = 1] = "EPISODE", e[e.SHOUTCAST = 2] = "SHOUTCAST"
    }(It || (It = {})),
    function(e) {
        e[e.NotStarted = 0] = "NotStarted", e[e.Running = 1] = "Running", e[e.Stopped = 2] = "Stopped"
    }(Ot || (Ot = {}));
    var Rt = {
        type: "xstate.init"
    };

    function r(e) {
        return void 0 === e ? [] : [].concat(e)
    }

    function o(e) {
        return {
            type: "xstate.assign",
            assignment: e
        }
    }

    function i(e, n) {
        return "string" == typeof(e = "string" == typeof e && n && n[e] ? n[e] : e) ? {
            type: e
        } : "function" == typeof e ? {
            type: e.name,
            exec: e
        } : e
    }

    function a(e) {
        return function(n) {
            return e === n
        }
    }

    function u(e) {
        return "string" == typeof e ? {
            type: e
        } : e
    }

    function c(e, n) {
        return {
            value: e,
            context: n,
            actions: [],
            changed: !1,
            matches: a(e)
        }
    }

    function f(e, n, s) {
        var d = n,
            p = !1;
        return [e.filter((function(e) {
            if ("xstate.assign" === e.type) {
                p = !0;
                var n = Object.assign({}, d);
                return "function" == typeof e.assignment ? n = e.assignment(d, s) : Object.keys(e.assignment).forEach((function(p) {
                    n[p] = "function" == typeof e.assignment[p] ? e.assignment[p](d, s) : e.assignment[p]
                })), d = n, !1
            }
            return !0
        })), d, p]
    }
    var l = function(e, n) {
        return e.actions.forEach((function(s) {
            var d = s.exec;
            return d && d(e.context, n)
        }))
    };
    const At = /(?:st|ra)\.([0-9]+)/,
        $t = /st\.([0-9]+)/;

    function asyncGeneratorStep$_(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$1y(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$F(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1y(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$q(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function _object_without_properties$2(e, n) {
        if (null == e) return {};
        var s, d, p = function(e, n) {
            if (null == e) return {};
            var s, d, p = {},
                h = Object.keys(e);
            for (d = 0; d < h.length; d++) s = h[d], n.indexOf(s) >= 0 || (p[s] = e[s]);
            return p
        }(e, n);
        if (Object.getOwnPropertySymbols) {
            var h = Object.getOwnPropertySymbols(e);
            for (d = 0; d < h.length; d++) s = h[d], n.indexOf(s) >= 0 || Object.prototype.propertyIsEnumerable.call(e, s) && (p[s] = e[s])
        }
        return p
    }
    const toTimeMeasuredData = e => {
        var {
            timestamp: n
        } = e;
        return _object_spread_props$q(_object_spread$F({}, _object_without_properties$2(e, ["timestamp"])), {
            "milliseconds-since-play": Date.now() - n
        })
    };
    class PlayActivitySender {
        get accessToken() {
            return invoke(this._accessToken)
        }
        get musicUserToken() {
            return invoke(this._musicUserToken)
        }
        get url() {
            return this._isQA ? "https://universal-activity-service.itunes.apple.com/qa/play" : "https://universal-activity-service.itunes.apple.com/play"
        }
        send(e) {
            var n, s = this;
            return (n = function*() {
                const n = {
                    client_id: s._clientId,
                    event_type: s._eventType,
                    data: ensureArray(e).map(toTimeMeasuredData)
                };
                if (0 === n.data.length) throw new Error("send() called without any data");
                const d = s._generateFetchOptions({
                    method: "POST",
                    body: JSON.stringify(n),
                    headers: s.headers()
                });
                return yield s._fetch(s.url, d), s._logInfo && je.info("play activity:", s._sourceType === wt.AMAZON ? JSON.stringify(n) : n), n
            }, function() {
                var e = this,
                    s = arguments;
                return new Promise((function(d, p) {
                    var h = n.apply(e, s);

                    function _next(e) {
                        asyncGeneratorStep$_(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$_(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        baseHeaders() {
            var e, n;
            const s = null !== (n = null === (e = this._fetchOptions) || void 0 === e ? void 0 : e.headers) && void 0 !== n ? n : {};
            return s instanceof this._headersClass ? new this._headersClass(Array.from(s.entries())) : new this._headersClass(s)
        }
        headers() {
            const e = this._preferDSID ? "X-Dsid" : "media-user-token",
                n = this.baseHeaders();
            return n.set("Authorization", "Bearer " + this.accessToken), n.set("Content-Type", "application/json"), n.set(e, "" + this.musicUserToken), this._isQA && void 0 !== this._traceTag && n.set("Data-Trace-Tag", this._traceTag), n
        }
        _generateFetchOptions(e) {
            return _object_spread$F({}, this._fetchOptions, e)
        }
        constructor(e) {
            var n, s, d, p;
            _define_property$1y(this, "mode", Et.AUTO), _define_property$1y(this, "_accessToken", void 0), _define_property$1y(this, "_musicUserToken", void 0), _define_property$1y(this, "_bundleId", void 0), _define_property$1y(this, "_clientId", void 0), _define_property$1y(this, "_eventType", void 0), _define_property$1y(this, "_fetch", void 0), _define_property$1y(this, "_fetchOptions", void 0), _define_property$1y(this, "_headersClass", void 0), _define_property$1y(this, "_isQA", !1), _define_property$1y(this, "_logInfo", !1), _define_property$1y(this, "_preferDSID", !1), _define_property$1y(this, "_sourceType", void 0), _define_property$1y(this, "_traceTag", void 0), this._accessToken = e.accessToken, this._bundleId = e.bundleId, this._clientId = e.clientId, this._eventType = e.eventType, this._fetch = null !== (n = e.fetch) && void 0 !== n ? n : fetch, this._fetchOptions = null !== (s = e.fetchOptions) && void 0 !== s ? s : {}, this._headersClass = null !== (d = e.headersClass) && void 0 !== d ? d : Headers, this._isQA = null !== (p = e.isQA) && void 0 !== p && p, this._logInfo = e.logInfo || this._isQA, this._musicUserToken = e.musicUserToken, this._preferDSID = e.preferDSID, this._sourceType = e.sourceType, this._traceTag = e.traceTag
        }
    }
    const fullAppId = (e, n) => {
            if (void 0 === (null == n ? void 0 : n.name)) return "MusicKitApp/1.0";
            if (void 0 !== e) return e;
            return `${function(e){return e.toLowerCase().replace(/[-_]+/g," ").replace(/[^\w\s]/g,"").replace(/\b./g,e=>e.toUpperCase()).replace(/\s/g,"")}(n.name)}/${(null==n?void 0:n.version)||"1.0"}`
        },
        os = e => {
            var n, s;
            const d = e.toLowerCase();
            let p, h = "Unidentified OS";
            const y = /mobile/.test(d);
            var _;
            y && /android|adr/.test(d) ? (h = "Android", p = d.match(/(?:android|adr)\ ((\d+[._])+\d+)/)) : y && /iphone|ipad|ipod/.test(d) ? (h = "iOS", p = d.match(/os\ ((\d+[._])+\d+)\ like\ mac\ os\ x/)) : /tizen/.test(d) ? (h = "Tizen", p = d.match(/tizen (.*)/)) : /web0s|webos/.test(d) ? (h = "WebOS", p = d.match(/[web0s|webos] (.*)/)) : !y && /cros/.test(d) ? h = "ChromeOS" : !y && /macintosh/.test(d) ? (h = "macOS", p = d.match(/os\ x\ ((\d+[._])+\d+)\b/)) : !y && /linux/.test(d) ? h = "Linux" : !y && /windows/.test(d) && (h = "Windows", p = d.match(/windows ([^\)]*)/));
            return `${h}/${null!==(_=null==p||null===(s=p[1])||void 0===s||null===(n=s.replace)||void 0===n?void 0:n.call(s,/_/g,"."))&&void 0!==_?_:"0.0"}`
        },
        model = e => "model/" + ((null == e ? void 0 : e.platform) || "Unavailable"),
        build = e => {
            const n = null == e ? void 0 : e.build;
            return void 0 === n || "" === n ? "build/0.0.0" : "build/" + n
        };

    function asyncGeneratorStep$Z(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$1x(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$E(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1x(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$p(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const Mt = {
        platform: "",
        userAgent: ""
    };
    const Ct = new Map([
        ["play", Pt.PLAY_START],
        ["playbackstarted", Pt.PLAY_START],
        ["stop", Pt.PLAY_END],
        ["playbackstopped", Pt.PLAY_END]
    ]);

    function mapEventTypeString(e) {
        return "number" == typeof e ? e : null !== (n = Ct.get(e)) && void 0 !== n ? n : Pt.PLAY_END;
        var n
    }
    const Dt = new Map([
        ["exit", e.PlayActivityEndReasonType.EXITED_APPLICATION],
        ["next", e.PlayActivityEndReasonType.TRACK_SKIPPED_FORWARDS],
        ["pause", e.PlayActivityEndReasonType.PLAYBACK_MANUALLY_PAUSED],
        ["playbackfinished", e.PlayActivityEndReasonType.NATURAL_END_OF_TRACK],
        ["playbackstopped", e.PlayActivityEndReasonType.PLAYBACK_MANUALLY_PAUSED],
        ["previous", e.PlayActivityEndReasonType.TRACK_SKIPPED_BACKWARDS],
        ["scrub_begin", e.PlayActivityEndReasonType.SCRUB_BEGIN],
        ["scrub_end", e.PlayActivityEndReasonType.SCRUB_END],
        ["stop", e.PlayActivityEndReasonType.NATURAL_END_OF_TRACK]
    ]);

    function normalizePlayActivityDescriptor(e) {
        const n = deepClone(e),
            s = function(e) {
                var n;
                const s = null !== (n = e.eventType) && void 0 !== n ? n : Pt.PLAY_START;
                if ("number" == typeof s) return {
                    eventType: s
                };
                return {
                    eventTypeString: s,
                    eventType: mapEventTypeString(s)
                }
            }(e);
        return n.eventType = s.eventType, n.eventTypeString = s.eventTypeString, void 0 === n.endReasonType && void 0 !== s.eventTypeString && (n.endReasonType = function(e) {
            if (void 0 !== e) return Dt.get(e)
        }(s.eventTypeString)), !1 !== n.reporting && (n.reporting = !0), n
    }

    function _define_property$1w(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread_props$o(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const createHelper = (e, n) => (s, d, p) => {
        const {
            helpers: h
        } = p.cache;
        return e in h || (h[e] = n(s, d, p)), h[e]
    };
    const returnAsField = (e, n) => (...s) => function(e, n) {
            if (void 0 !== n) return {
                [e]: n
            }
        }(e, n(...s)),
        createFieldFn = (e, n) => {
            const normalizeReturnValue = n => null == n ? void 0 : {
                [e]: n
            };
            return (s, d, p) => {
                const {
                    fields: h
                } = p.cache;
                return e in h || (p.cache.fields = _object_spread_props$o(function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var s = null != arguments[n] ? arguments[n] : {},
                            d = Object.keys(s);
                        "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                            return Object.getOwnPropertyDescriptor(s, e).enumerable
                        })))), d.forEach((function(n) {
                            _define_property$1w(e, n, s[n])
                        }))
                    }
                    return e
                }({}, h), {
                    [e]: normalizeReturnValue(n(s, d, p))
                })), p.cache.fields[e]
            }
        },
        createClientFieldFn = (e, n) => createFieldFn(e, (e, s, {
            client: d
        }) => d[n]),
        Lt = createFieldFn("event-type", (e, n, s) => {
            return void 0 === e.eventType ? Pt.PLAY_START : e.itemType === kt.TIMED_METADATA_PING && void 0 !== e.timedMetadata ? Pt.PLAY_END : null !== (d = e.eventType) && void 0 !== d ? d : Pt.PLAY_START;
            var d
        }),
        xt = createHelper("should-include-audio-quality", (e, n, s) => {
            var d, p;
            const h = e.userPreference;
            return Lt(e, n, s)["event-type"] === Pt.PLAY_END && void 0 !== (null === (d = e.audioQuality) || void 0 === d ? void 0 : d.provided) && void 0 !== (null === (p = e.audioQuality) || void 0 === p ? void 0 : p.targeted) && void 0 !== (null == h ? void 0 : h.audioQuality) && void 0 !== (null == h ? void 0 : h.playbackFormat)
        }),
        jt = createFieldFn("audio-quality-provided", (e, n, s) => {
            if (!xt(e, n, s)) return;
            const d = e.audioQuality;
            if (void 0 === (null == d ? void 0 : d.provided)) return;
            const {
                provided: p
            } = d;
            var h, y, _;
            return {
                "audio-sample-rate-in-hz": null !== (h = p.audioSampleRateHz) && void 0 !== h ? h : 0,
                "audio-bit-depth": null !== (y = p.audioBitDepth) && void 0 !== y ? y : 0,
                "bit-rate-in-bps": null !== (_ = p.bitRateBps) && void 0 !== _ ? _ : 0,
                codec: p.codec,
                "audio-channel-type": p.audioChannelType,
                "playback-format": p.playbackFormat
            }
        }),
        Nt = createFieldFn("audio-quality-targeted", (e, n, s) => {
            if (!xt(e, n, s)) return;
            const d = e.audioQuality;
            if (void 0 === (null == d ? void 0 : d.targeted)) return;
            const {
                targeted: p
            } = d;
            var h, y, _;
            return {
                "audio-sample-rate-in-hz": null !== (h = p.audioSampleRateHz) && void 0 !== h ? h : 0,
                "audio-bit-depth": null !== (y = p.audioBitDepth) && void 0 !== y ? y : 0,
                "bit-rate-in-bps": null !== (_ = p.bitRateBps) && void 0 !== _ ? _ : 0,
                codec: p.codec,
                "audio-channel-type": p.audioChannelType,
                "playback-format": p.playbackFormat
            }
        }),
        Ut = createClientFieldFn("bundle-id", "bundleId"),
        Ft = createClientFieldFn("build-version", "buildVersion"),
        Bt = ["uploadedVideo", "uploadedAudio", "uploaded-videos", "uploaded-audios"],
        Kt = createHelper("is-auc", ({
            kind: e
        }) => void 0 !== e && Bt.includes(e)),
        Gt = createHelper("should-send-timed-metadata", ({
            endReasonType: n,
            eventType: s,
            itemType: d,
            timedMetadata: p
        }) => void 0 !== p && (d === kt.TIMED_METADATA_PING || s === Pt.PLAY_START || n === e.PlayActivityEndReasonType.PLAYBACK_MANUALLY_PAUSED)),
        Vt = createFieldFn("type", (e, n, s) => {
            const {
                id: d,
                reporting: p
            } = e;
            var h;
            if ("-1" === d || !p) switch (null === (h = Lt(e, n, s)) || void 0 === h ? void 0 : h["event-type"]) {
                case Pt.PLAY_END:
                    return kt.AGGREGATE_NON_CATALOG_PLAY_TIME;
                case Pt.PLAY_START:
                    if ("-1" === d) return kt.INVALID
            }
            const {
                format: y,
                kind: _,
                itemType: m
            } = e;
            return "musicMovie" === _ ? kt.ORIGINAL_CONTENT_MOVIES : Gt(e, n, s) ? m === kt.TIMED_METADATA_PING ? m : kt.STREAM : "stream" === y ? kt.STREAM : Kt(e, n, s) ? kt.ARTIST_UPLOADED_CONTENT : null != m ? m : kt.ITUNES_STORE_CONTENT
        }),
        Ht = createFieldFn("container-type", (e, n, s) => {
            var d, p, h, y;
            if ((null === (d = Vt(e, n, s)) || void 0 === d ? void 0 : d.type) === kt.AGGREGATE_NON_CATALOG_PLAY_TIME) return;
            const _ = null !== (y = null === (p = e.container) || void 0 === p ? void 0 : p.type) && void 0 !== y ? y : null === (h = e.container) || void 0 === h ? void 0 : h.kind;
            if ("number" == typeof _) return _;
            switch (_) {
                case "album":
                case "albums":
                case "library-albums":
                    return dt.ALBUM;
                case "artist":
                case "artists":
                case "library-artists":
                    return dt.ARTIST;
                case "playlist":
                case "playlists":
                case "library-playlists":
                    return dt.PLAYLIST;
                case "radio":
                case "radioStation":
                case "station":
                case "stations":
                    return dt.RADIO;
                default:
                    return dt.UNKNOWN
            }
        });

    function _define_property$1v(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const qt = [returnAsField("album-adam-id", (e, n, s) => {
            var d;
            if ((null === (d = Ht(e, n, s)) || void 0 === d ? void 0 : d["container-type"]) !== dt.ALBUM) return;
            const {
                container: p
            } = e, h = null == p ? void 0 : p.id;
            return void 0 === h || isLibraryType(h) ? void 0 : h
        }), returnAsField("cloud-album-id", (e, n, s) => {
            var d;
            if ((null === (d = Ht(e, n, s)) || void 0 === d ? void 0 : d["container-type"]) !== dt.ALBUM) return;
            const {
                container: p
            } = e, h = null == p ? void 0 : p.id;
            return void 0 !== h && isLibraryType(h) ? h : void 0
        }), returnAsField("global-playlist-id", (e, n, s) => {
            var d;
            if ((null === (d = Ht(e, n, s)) || void 0 === d ? void 0 : d["container-type"]) !== dt.PLAYLIST) return;
            const {
                container: p
            } = e;
            var h;
            const y = null !== (h = null == p ? void 0 : p.catalogId) && void 0 !== h ? h : null == p ? void 0 : p.globalId;
            return (null == p ? void 0 : p.isLibrary) && y ? y : isLibraryType(null == p ? void 0 : p.id) || null == p ? void 0 : p.id
        }), returnAsField("playlist-version-hash", (e, n, s) => {
            var d;
            if ((null === (d = Ht(e, n, s)) || void 0 === d ? void 0 : d["container-type"]) !== dt.PLAYLIST) return;
            const {
                container: p
            } = e, h = null == p ? void 0 : p.versionHash;
            return void 0 !== h && "" !== h ? h : void 0
        }), returnAsField("station-hash", (e, n, s) => {
            var d, p;
            if ((null === (d = Ht(e, n, s)) || void 0 === d ? void 0 : d["container-type"]) !== dt.RADIO) return;
            const h = null === (p = e.container) || void 0 === p ? void 0 : p.stationHash;
            return void 0 !== h && "" !== h ? h : void 0
        }), returnAsField("station-id", (e, n, s) => {
            var d, p;
            if ((null === (d = Ht(e, n, s)) || void 0 === d ? void 0 : d["container-type"]) === dt.RADIO) return null === (p = e.container) || void 0 === p ? void 0 : p.id
        }), returnAsField("station-personalized-id", (e, n, s) => {
            var d, p;
            if ((null === (d = Ht(e, n, s)) || void 0 === d ? void 0 : d["container-type"]) !== dt.RADIO) return;
            const h = null === (p = e.container) || void 0 === p ? void 0 : p.id;
            return void 0 !== h && $t.test(h) ? parseInt(h.replace($t, "$1"), 10) : void 0
        }), returnAsField("universal-library-id", (e, n, s) => {
            var d;
            if ((null === (d = Ht(e, n, s)) || void 0 === d ? void 0 : d["container-type"]) !== dt.PLAYLIST) return;
            const {
                container: p
            } = e;
            var h;
            const y = null !== (h = null == p ? void 0 : p.catalogId) && void 0 !== h ? h : null == p ? void 0 : p.globalId,
                _ = null == p ? void 0 : p.id;
            if (void 0 !== _)
                if ((null == p ? void 0 : p.isLibrary) && y) {
                    if ("" !== _) return _
                } else if (isLibraryType(_)) return _
        })],
        Wt = createFieldFn("container-ids", (e, n, s) => {
            var d;
            if ((null === (d = Vt(e, n, s)) || void 0 === d ? void 0 : d.type) === kt.AGGREGATE_NON_CATALOG_PLAY_TIME) return;
            const p = qt.reduce((d, p) => function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$1v(e, n, s[n])
                    }))
                }
                return e
            }({}, d, p(e, n, s)), Object.create(null));
            return isEmpty(p) ? void 0 : p
        }),
        zt = createClientFieldFn("developer-token", "accessToken"),
        Yt = createClientFieldFn("device-name", "deviceName"),
        Qt = createFieldFn("display-type", (e, n, s) => {
            var d, p;
            if ((null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"]) === Pt.LYRIC_DISPLAY) return null === (p = e.lyricDescriptor) || void 0 === p ? void 0 : p.displayType
        }),
        Jt = createHelper("initial-start-position-in-milliseconds", ({
            position: e = 0,
            startPositionInMilliseconds: n
        }) => n || Math.round(1e3 * e)),
        Xt = createFieldFn("end-position-in-milliseconds", (e, n, s) => {
            var d;
            switch (null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"]) {
                case Pt.LYRIC_DISPLAY:
                    var p;
                    if (void 0 === (null === (p = e.lyricDescriptor) || void 0 === p ? void 0 : p.duration)) return;
                    return Math.round(e.lyricDescriptor.duration);
                case Pt.PLAY_START:
                    return;
                default:
                    if (n && void 0 === n.position) return;
                    return e.endPositionInMilliseconds || Jt(e, n, s)
            }
        }),
        Zt = createHelper("is-private", ({
            id: e,
            reporting: n
        }) => "-1" === e || !n),
        er = createFieldFn("end-reason-type", (n, s, d) => {
            var p;
            if (!s || void 0 !== (null == s ? void 0 : s.position)) return (null === (p = Vt(n, s, d)) || void 0 === p ? void 0 : p.type) === kt.TIMED_METADATA_PING && void 0 !== n.timedMetadata || Zt(n, s, d) && n.eventType === Pt.PLAY_END ? e.PlayActivityEndReasonType.NOT_APPLICABLE : n.endReasonType
        }),
        {
            CONTAINER_CHANGED: tr,
            NOT_SPECIFIED: rr
        } = St,
        ir = createFieldFn("event-reason-hint-type", (e, n, s) => {
            var d, p;
            if ((null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"]) !== Pt.PLAY_START) return;
            const h = e.container;
            return void 0 === h ? rr : !1 === n ? s.isAlexa ? rr : tr : (null == n || null === (p = n.container) || void 0 === p ? void 0 : p.id) !== h.id ? tr : rr
        }),
        nr = createFieldFn("feature-name", (e, n, s) => {
            var d, p, h;
            if ((null === (d = Vt(e, n, s)) || void 0 === d ? void 0 : d.type) === kt.AGGREGATE_NON_CATALOG_PLAY_TIME) return;
            return "" + (null !== (h = null === (p = e.container) || void 0 === p ? void 0 : p.name) && void 0 !== h ? h : ct.MUSICKIT)
        }),
        or = createClientFieldFn("guid", "guid"),
        ar = createHelper("should-have-auc-adam-id", Kt),
        sr = createHelper("should-have-radio-adam-id", ({
            id: e,
            container: n
        }) => At.test(e) || "radioStation" === (null == n ? void 0 : n.kind)),
        cr = createHelper("is-library-item-or-library-type", ({
            id: e,
            isLibrary: n
        }, s, d) => n || isLibraryType(e)),
        dr = createHelper("catalog-id", ({
            catalogId: e,
            container: n
        }) => null != e ? e : null == n ? void 0 : n.catalogId),
        lr = createHelper("is-library-item-with-catalog-id", (e, n, s) => e.isLibrary && !!dr(e, n, s));

    function _define_property$1u(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const ur = [returnAsField("auc-adam-id", (e, n, s) => {
            if (!Zt(e, n, s) && !sr(e, n, s)) return ar(e, n, s) ? e.id : void 0
        }), returnAsField("cloud-id", (e, n, s) => {
            var d;
            const {
                id: p
            } = e, h = void 0 !== p && "" !== p;
            return Zt(e, n, s) && (null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"]) === Pt.PLAY_START && h && "-1" !== p ? p : sr(e, n, s) || ar(e, n, s) ? e.cloudId : lr(e, n, s) && h || cr(e, n, s) ? p : e.cloudId
        }), returnAsField("lyric-id", (e, n, s) => {
            var d, p;
            if ((null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"]) === Pt.LYRIC_DISPLAY) return null === (p = e.lyricDescriptor) || void 0 === p ? void 0 : p.id
        }), returnAsField("purchased-adam-id", (e, n, s) => e.purchasedId), returnAsField("reporting-adam-id", (e, n, s) => {
            if (!0 !== s.client.allowReportingId) return;
            var d;
            return (null !== (d = Lt(e, n, s)) && void 0 !== d ? d : {})["event-type"], cr(e, n, s) ? e.reportingId : void 0
        }), returnAsField("radio-adam-id", (e, n, s) => {
            if (Zt(e, n, s)) return;
            const {
                container: d,
                id: p
            } = e;
            return At.test(p) || "radioStation" === (null == d ? void 0 : d.kind) ? parseInt(("" + p).replace(At, "$1"), 10) : void 0
        }), returnAsField("subscription-adam-id", (e, n, s) => {
            if (!(Zt(e, n, s) || sr(e, n, s) || ar(e, n, s))) {
                if (lr(e, n, s)) return dr(e, n, s);
                if (!cr(e, n, s)) return e.id
            }
        })],
        pr = createFieldFn("ids", (e, n, s) => {
            var d;
            if ((null === (d = Vt(e, n, s)) || void 0 === d ? void 0 : d.type) === kt.AGGREGATE_NON_CATALOG_PLAY_TIME) return;
            const p = ur.reduce((d, p) => function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$1u(e, n, s[n])
                    }))
                }
                return e
            }({}, d, p(e, n, s)), Object.create(null));
            return isEmpty(p) ? void 0 : p
        }),
        hr = createClientFieldFn("internal-build", "internalBuild"),
        yr = createFieldFn("is-collaborative", (e, n, s) => {
            var d;
            return !0 === (null === (d = e.container) || void 0 === d ? void 0 : d.isCollaborative) || void 0
        }),
        _r = createFieldFn("lyric-language", (e, n, s) => {
            var d, p;
            if ((null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"]) === Pt.LYRIC_DISPLAY) return null === (p = e.lyricDescriptor) || void 0 === p ? void 0 : p.language
        }),
        fr = createHelper("has-episode-streaming-kind", ({
            streamingKind: e
        }, n, s) => e === It.EPISODE),
        mr = createHelper("is-stream", (e, n, s) => {
            var d;
            return (null === (d = Vt(e, n, s)) || void 0 === d ? void 0 : d.type) === kt.STREAM
        }),
        vr = createHelper("is-live-stream", (e, n, s) => mr(e, n, s) && !fr(e, n, s)),
        gr = createFieldFn("media-duration-in-milliseconds", (e, n, s) => {
            var d;
            const p = null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"];
            if (p === Pt.LYRIC_DISPLAY) return 0;
            if (vr(e, n, s)) return 0;
            const h = Math.round(1e3 * e.duration);
            if (p === Pt.PLAY_START) return h;
            var y, _;
            const m = null !== (_ = e.startPositionInMilliseconds) && void 0 !== _ ? _ : Math.round(1e3 * (null !== (y = e.position) && void 0 !== y ? y : 0));
            return m > 1e3 * e.duration ? m : h
        }),
        {
            AUDIO: br,
            VIDEO: Sr
        } = Tt,
        Pr = createFieldFn("media-type", (e, n, s) => {
            var d;
            if ((null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"]) === Pt.LYRIC_DISPLAY) return br;
            const {
                kind: p,
                mediaType: h
            } = e;
            if ("number" == typeof h) return h;
            const y = "string" == typeof h ? h : p;
            return y && /video|movie/i.test(y) ? Sr : br
        }),
        kr = createClientFieldFn("metrics-client-id", "metricsClientId"),
        Tr = createFieldFn("offline", () => !1),
        Er = createFieldFn("persistent-id", () => generateUUID()),
        wr = createFieldFn("play-mode", (e, n, s) => {
            var d, p, h, y, _;
            if ((null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"]) === Pt.LYRIC_DISPLAY || (null === (p = Vt(e, n, s)) || void 0 === p ? void 0 : p.type) === kt.AGGREGATE_NON_CATALOG_PLAY_TIME) return {
                "auto-play-mode": null !== (h = wr.autoplayMode) && void 0 !== h ? h : 0,
                "repeat-play-mode": null !== (y = wr.repeatPlayMode) && void 0 !== y ? y : 0,
                "shuffle-play-mode": null !== (_ = wr.shufflePlayMode) && void 0 !== _ ? _ : 0
            };
            const m = invoke(e.playMode);
            var v, g, b;
            return void 0 !== m ? {
                "auto-play-mode": null !== (v = m.autoplayMode) && void 0 !== v ? v : 0,
                "repeat-play-mode": null !== (g = m.repeatPlayMode) && void 0 !== g ? g : 0,
                "shuffle-play-mode": null !== (b = m.shufflePlayMode) && void 0 !== b ? b : 0
            } : void 0
        }),
        Ir = createClientFieldFn("private-enabled", "privateEnabled"),
        Or = createFieldFn("reco-data", (e, n, s) => {
            var d, p;
            if ((null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"]) !== Pt.LYRIC_DISPLAY && (null === (p = Vt(e, n, s)) || void 0 === p ? void 0 : p.type) !== kt.AGGREGATE_NON_CATALOG_PLAY_TIME) return e.recoData
        }),
        Rr = createClientFieldFn("sb-enabled", "userIsSubscribed"),
        Ar = createClientFieldFn("siri-initiated", "siriInitiated"),
        $r = createClientFieldFn("source-type", "sourceType"),
        Mr = createFieldFn("start-position-in-milliseconds", (e, n, s) => {
            var d, p;
            const h = null === (d = Lt(e, n, s)) || void 0 === d ? void 0 : d["event-type"];
            return h === Pt.LYRIC_DISPLAY || (null === (p = Vt(e, n, s)) || void 0 === p ? void 0 : p.type) === kt.AGGREGATE_NON_CATALOG_PLAY_TIME || vr(e, n, s) ? 0 : h === Pt.PLAY_START ? Jt(e, n, s) : null !== (_ = null !== (y = e.startPositionInMilliseconds) && void 0 !== y ? y : previousPosition(n)) && void 0 !== _ ? _ : 0;
            var y, _
        }),
        previousPosition = e => e && void 0 !== e.position ? Math.round(1e3 * e.position) : 0,
        Cr = createClientFieldFn("store-front", "storefrontId"),
        Dr = createFieldFn("timed-metadata", (n, s, d) => {
            var p, h;
            const y = n.timedMetadata;
            if (void 0 === y) return;
            const _ = null === (p = Lt(n, s, d)) || void 0 === p ? void 0 : p["event-type"];
            return (null === (h = er(n, s, d)) || void 0 === h ? void 0 : h["end-reason-type"]) !== e.PlayActivityEndReasonType.SCRUB_END && _ === Pt.PLAY_END ? toHexString(y, 0) : void 0
        }),
        Lr = createFieldFn("timestamp", ({
            timestamp: e
        }, n, s) => null != e ? e : Date.now()),
        xr = createClientFieldFn("user-agent", "userAgent"),
        jr = createFieldFn("user-preference-audio-quality", (e, n, s) => {
            var d;
            if (xt(e, n, s)) return null === (d = e.userPreference) || void 0 === d ? void 0 : d.audioQuality
        }),
        Nr = createFieldFn("user-preference-playback-format", (e, n, s) => {
            var d;
            if (xt(e, n, s)) return null === (d = e.userPreference) || void 0 === d ? void 0 : d.playbackFormat
        }),
        Ur = createFieldFn("user-token", (e, n, {
            client: s
        }) => {
            if (!s.preferDSID) return s.musicUserToken
        }),
        Fr = createFieldFn("utc-offset-in-seconds", (e, n, s) => {
            var d;
            return (null === (d = Vt(e, n, s)) || void 0 === d ? void 0 : d.type) === kt.AGGREGATE_NON_CATALOG_PLAY_TIME ? 0 : s.client.utcOffsetInSeconds
        }),
        Br = {
            "audio-quality-provided": jt,
            "audio-quality-targeted": Nt,
            "bundle-id": Ut,
            "build-version": Ft,
            "container-ids": Wt,
            "container-type": Ht,
            "developer-token": zt,
            "device-name": Yt,
            "display-type": Qt,
            "end-position-in-milliseconds": Xt,
            "end-reason-type": er,
            "event-reason-hint-type": ir,
            "event-type": Lt,
            "feature-name": nr,
            guid: or,
            ids: pr,
            "internal-build": hr,
            "is-collaborative": yr,
            "lyric-language": _r,
            "media-duration-in-milliseconds": gr,
            "media-type": Pr,
            "metrics-client-id": kr,
            offline: Tr,
            "persistent-id": Er,
            "play-mode": wr,
            "private-enabled": Ir,
            "reco-data": Or,
            "sb-enabled": Rr,
            "siri-initiated": Ar,
            "source-type": $r,
            "start-position-in-milliseconds": Mr,
            "store-front": Cr,
            "timed-metadata": Dr,
            timestamp: Lr,
            type: Vt,
            "user-agent": xr,
            "user-preference-audio-quality": jr,
            "user-preference-playback-format": Nr,
            "user-token": Ur,
            "utc-offset-in-seconds": Fr
        };

    function _define_property$1t(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$A(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1t(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$n(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    let Kr = 0;

    function _define_property$1s(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread_props$m(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const buildPlayActivityData = (e, n, s, d = !1) => {
        const p = ((e, ...n) => _object_spread_props$n(_object_spread$A({}, e, Object.assign({}, ...n)), {
            cache: {
                fields: Object.assign({}, ...n.map(e => {
                    var n;
                    return null == e || null === (n = e.cache) || void 0 === n ? void 0 : n.fields
                })),
                helpers: Object.assign({}, ...n.map(e => {
                    var n;
                    return null == e || null === (n = e.cache) || void 0 === n ? void 0 : n.helpers
                }))
            }
        }))("boolean" == typeof d ? ((e = {}, n) => _object_spread$A({
            id: (Kr++).toFixed(0),
            client: n,
            isAlexa: !1
        }, e))({
            isAlexa: d
        }, e) : _object_spread_props$m(function(e) {
            for (var n = 1; n < arguments.length; n++) {
                var s = null != arguments[n] ? arguments[n] : {},
                    d = Object.keys(s);
                "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(s, e).enumerable
                })))), d.forEach((function(n) {
                    _define_property$1s(e, n, s[n])
                }))
            }
            return e
        }({}, d), {
            client: e
        }));
        return n = normalizePlayActivityDescriptor(n), s && (s = normalizePlayActivityDescriptor(s)), Object.assign(Object.create(null), ...Object.values(Br).map(e => null == e ? void 0 : e(n, s, p)))
    };
    var Gr;
    ! function(e) {
        e[e.ALEXA = 13] = "ALEXA"
    }(Gr || (Gr = {}));
    const createCookieJar = e => {
            switch (void 0 === e && (e = "browser"), e) {
                case "browser":
                    return {
                        get: getCookie,
                        set: setCookie
                    };
                case "memory":
                    return ((e = {}) => ({
                        get(n) {
                            if (void 0 !== n) return e[n]
                        },
                        set(n, s) {
                            e[n] = s
                        }
                    }))();
                default:
                    return e
            }
        },
        empty = (e, n) => write(e, n, [], "/", 0),
        read = (e, n) => {
            const s = e.get(n);
            if (void 0 === s || "" === s) return [];
            return ensureArray(JSON.parse(atob(s)))
        },
        write = (e, n, s, d, p, h) => e.set(n, btoa(JSON.stringify(s)), d, p, h);

    function asyncGeneratorStep$Y(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$Y(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$Y(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$Y(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1r(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const {
        AUTO: Vr
    } = Et;
    class PlayActivityBatchableSender {
        flush() {
            var e = this;
            return _async_to_generator$Y((function*() {
                const n = read(e.jar, "amupaee");
                if (void 0 !== n && 0 !== n.length) try {
                    yield e.sender.send(n), empty(e.jar, "amupaee")
                } catch (ce) {
                    throw new Error("flush: " + ce.message)
                }
            }))()
        }
        send(n) {
            var s = this;
            return _async_to_generator$Y((function*() {
                if (s.mode === Vr && (Array.isArray(n) || n["end-reason-type"] !== e.PlayActivityEndReasonType.EXITED_APPLICATION)) return s.sender.send(n);
                ((e, n, s, d, p, h) => {
                    write(e, n, [...read(e, n), s], d, p, h)
                })(s.jar, "amupaee", n, "/")
            }))()
        }
        constructor(e, n) {
            _define_property$1r(this, "sender", void 0), _define_property$1r(this, "jar", void 0), _define_property$1r(this, "mode", void 0), this.sender = e, this.jar = n, this.mode = Vr
        }
    }

    function asyncGeneratorStep$X(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$X(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$X(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$X(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1q(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class Timeline {
        get events() {
            return this._events
        }
        get first() {
            return this.at(0)
        }
        get keys() {
            return this._keys
        }
        get last() {
            return this.at(this.length - 1)
        }
        get length() {
            return this._keys.length
        }
        get second() {
            return this.at(1)
        }
        at(e) {
            if (e > this.length - 1) throw new Error("Invalid timeline index");
            const n = this._keys[e];
            return this._events[n]
        }
        before(e) {
            if ("number" != typeof e) {
                const n = [];
                for (const e in this._events) hasOwn(this._events, e) && n.push(this._events[e]);
                e = this._keys[n.indexOf(e)]
            }
            const n = this._keys.indexOf(e);
            if (-1 === n) throw new Error("Key not found");
            if (n > 0) return this._events[this._keys[n - 1]]
        }
        drain() {
            const e = this._keys.map(e => this._events[e]);
            return this.reset(), e
        }
        reset() {
            this._events = {}, this._keys = []
        }
        pop() {
            var e = this;
            return _async_to_generator$X((function*() {
                const n = e._keys.pop();
                if (void 0 === n) return Promise.reject("TIMELINE IS EMPTY");
                const s = e._events[n];
                return delete e._events[n], Promise.resolve(s)
            }))()
        }
        add(e, n) {
            var s = this;
            return _async_to_generator$X((function*() {
                return s.push(e, n)
            }))()
        }
        push(e, n = Date.now()) {
            var s = this;
            return _async_to_generator$X((function*() {
                for (; - 1 !== s._keys.indexOf(n);) n++;
                return s._events[n] = e, s._keys.push(n), Promise.resolve(n)
            }))()
        }
        shift() {
            var e = this;
            return _async_to_generator$X((function*() {
                const n = e._keys.shift();
                if (void 0 === n) return Promise.reject("TIMELINE IS EMPTY");
                const s = e._events[n];
                return delete e._events[n], Promise.resolve(s)
            }))()
        }
        unshift(e, n = Date.now()) {
            var s = this;
            return _async_to_generator$X((function*() {
                for (; - 1 !== s._keys.indexOf(n);) n++;
                return s._events[n] = e, s._keys.unshift(n), Promise.resolve(n)
            }))()
        }
        constructor() {
            _define_property$1q(this, "_events", {}), _define_property$1q(this, "_keys", [])
        }
    }
    const transitionEvent = e => ({
        type: e
    });

    function deriveTransitionEvent(n) {
        if (n.itemType === kt.TIMED_METADATA_PING) return !1;
        if (function(e) {
                return e.eventType === Pt.PLAY_START
            }(n)) return transitionEvent("play");
        if (function(e) {
                if (e.eventType !== Pt.PLAY_END) return !1;
                if (void 0 === e.endReasonType) throw new Error("PLAY_END activity descriptor requires an endReasonType value");
                return !0
            }(n)) {
            const s = n.endReasonType;
            if (s === e.PlayActivityEndReasonType.SCRUB_BEGIN) return transitionEvent("scrubBegin");
            if (s === e.PlayActivityEndReasonType.SCRUB_END) return transitionEvent("scrubEnd");
            if (s === e.PlayActivityEndReasonType.EXITED_APPLICATION) return !1
        }
        return transitionEvent("stop")
    }

    function _define_property$1p(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$y(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1p(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$l(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function _object_without_properties$1(e, n) {
        if (null == e) return {};
        var s, d, p = function(e, n) {
            if (null == e) return {};
            var s, d, p = {},
                h = Object.keys(e);
            for (d = 0; d < h.length; d++) s = h[d], n.indexOf(s) >= 0 || (p[s] = e[s]);
            return p
        }(e, n);
        if (Object.getOwnPropertySymbols) {
            var h = Object.getOwnPropertySymbols(e);
            for (d = 0; d < h.length; d++) s = h[d], n.indexOf(s) >= 0 || Object.prototype.propertyIsEnumerable.call(e, s) && (p[s] = e[s])
        }
        return p
    }
    const createMPAFMachine = () => function(e, n) {
        void 0 === n && (n = {});
        var s = t(f(r(e.states[e.initial].entry).map((function(e) {
                return i(e, n.actions)
            })), e.context, Rt), 2),
            d = s[0],
            p = s[1],
            h = {
                config: e,
                _options: n,
                initialState: {
                    value: e.initial,
                    actions: d,
                    context: p,
                    matches: a(e.initial)
                },
                transition: function(n, s) {
                    var d, p, y = "string" == typeof n ? {
                            value: n,
                            context: e.context
                        } : n,
                        _ = y.value,
                        m = y.context,
                        v = u(s),
                        g = e.states[_];
                    if (g.on) {
                        var b = r(g.on[v.type]);
                        try {
                            for (var S = function(e) {
                                    var n = "function" == typeof Symbol && Symbol.iterator,
                                        s = n && e[n],
                                        d = 0;
                                    if (s) return s.call(e);
                                    if (e && "number" == typeof e.length) return {
                                        next: function() {
                                            return e && d >= e.length && (e = void 0), {
                                                value: e && e[d++],
                                                done: !e
                                            }
                                        }
                                    };
                                    throw new TypeError(n ? "Object is not iterable." : "Symbol.iterator is not defined.")
                                }(b), P = S.next(); !P.done; P = S.next()) {
                                var k = P.value;
                                if (void 0 === k) return c(_, m);
                                var T = "string" == typeof k ? {
                                        target: k
                                    } : k,
                                    E = T.target,
                                    w = T.actions,
                                    I = void 0 === w ? [] : w,
                                    O = T.cond,
                                    R = void 0 === O ? function() {
                                        return !0
                                    } : O,
                                    A = void 0 === E,
                                    $ = null != E ? E : _,
                                    M = e.states[$];
                                if (R(m, v)) {
                                    var C = t(f((A ? r(I) : [].concat(g.exit, I, M.entry).filter((function(e) {
                                            return e
                                        }))).map((function(e) {
                                            return i(e, h._options.actions)
                                        })), m, v), 3),
                                        D = C[0],
                                        L = C[1],
                                        x = C[2],
                                        j = null != E ? E : _;
                                    return {
                                        value: j,
                                        context: L,
                                        actions: D,
                                        changed: E !== _ || D.length > 0 || x,
                                        matches: a(j)
                                    }
                                }
                            }
                        } catch (t) {
                            d = {
                                error: t
                            }
                        } finally {
                            try {
                                P && !P.done && (p = S.return) && p.call(S)
                            } finally {
                                if (d) throw d.error
                            }
                        }
                    }
                    return c(_, m)
                }
            };
        return h
    }({
        id: "mpaf",
        initial: "idle",
        context: {},
        states: {
            error: {},
            idle: {
                on: {
                    play: "playing",
                    stop: "idle",
                    scrubBegin: {
                        target: "scrubbing",
                        actions: o(e => _object_spread_props$l(_object_spread$y({}, e), {
                            stateBeforeScrub: "idle"
                        }))
                    },
                    scrubEnd: {
                        target: "error",
                        actions: ["clearStateBeforeScrub", "setScrubEndError"]
                    }
                }
            },
            playing: {
                on: {
                    scrubBegin: {
                        target: "scrubbing",
                        actions: o(e => _object_spread_props$l(_object_spread$y({}, e), {
                            stateBeforeScrub: "playing"
                        }))
                    },
                    stop: "idle",
                    scrubEnd: {
                        target: "error",
                        actions: ["clearStateBeforeScrub", "setScrubEndError"]
                    }
                }
            },
            scrubbing: {
                on: {
                    scrubEnd: [{
                        target: "idle",
                        cond: ({
                            stateBeforeScrub: e
                        }) => "idle" === e,
                        actions: ["clearStateBeforeScrub"]
                    }, {
                        target: "playing",
                        actions: ["clearStateBeforeScrub"]
                    }]
                }
            }
        }
    }, {
        actions: {
            clearStateBeforeScrub: o(e => _object_without_properties$1(e, ["stateBeforeScrub"])),
            setScrubEndError: o(e => _object_spread_props$l(_object_spread$y({}, e), {
                errorMessage: "The scrub() method was called with the SCRUB_END action without a previous SCRUB_START descriptor"
            }))
        }
    });
    class MPAFStateMachine {
        get currentState() {
            return this.machineService.state
        }
        get currentStateName() {
            return this.currentState.value
        }
        matches(e) {
            return this.machineService.state.matches(e)
        }
        transition(e, n) {
            const s = deriveTransitionEvent(e);
            if (!1 === s) return this.currentStateName;
            if (this.machineService.send(s), this.matches("error")) throw new Error(this.machineService.state.context.errorMessage);
            return this.currentStateName
        }
        constructor() {
            _define_property$1p(this, "machine", void 0), _define_property$1p(this, "machineService", void 0), this.machine = createMPAFMachine(), this.machineService = function(e) {
                var n = e.initialState,
                    s = Ot.NotStarted,
                    d = new Set,
                    p = {
                        _machine: e,
                        send: function(p) {
                            s === Ot.Running && (n = e.transition(n, p), l(n, u(p)), d.forEach((function(e) {
                                return e(n)
                            })))
                        },
                        subscribe: function(e) {
                            return d.add(e), e(n), {
                                unsubscribe: function() {
                                    return d.delete(e)
                                }
                            }
                        },
                        start: function(d) {
                            if (d) {
                                var h = "object" == typeof d ? d : {
                                    context: e.config.context,
                                    value: d
                                };
                                n = {
                                    value: h.value,
                                    actions: [],
                                    context: h.context,
                                    matches: a(h.value)
                                }
                            }
                            return s = Ot.Running, l(n, Rt), p
                        },
                        stop: function() {
                            return s = Ot.Stopped, d.clear(), p
                        },
                        get state() {
                            return n
                        },
                        get status() {
                            return s
                        }
                    };
                return p
            }(this.machine).start()
        }
    }

    function asyncGeneratorStep$W(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$W(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$W(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$W(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1o(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$x(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1o(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$k(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    class StatelessPlayActivity extends class {
        get accessToken() {
            return invoke(this._accessToken)
        }
        get appID() {
            return void 0 === this._appId && (this._appId = fullAppId(this._appId, this._appInfo)), this._appId
        }
        get deviceName() {
            return this._deviceName
        }
        get musicUserToken() {
            return invoke(this._musicUserToken)
        }
        get navigator() {
            var e;
            return null !== (e = this._navigator) && void 0 !== e ? e : "undefined" == typeof navigator ? Mt : navigator
        }
        get storefrontId() {
            return invoke(this._storefrontId)
        }
        get userAgent() {
            var e;
            return null !== (e = this._userAgent) && void 0 !== e ? e : this.navigator.userAgent
        }
        get userIsSubscribed() {
            return invoke(this._userIsSubscribed)
        }
        get allowReportingId() {
            return invoke(this._allowReportingId)
        }
        get utcOffsetInSeconds() {
            if (void 0 === this._utcOffsetInSeconds && void 0 !== this._utcOffset && !isNaN(this._utcOffset)) {
                const e = 60 * this._utcOffset;
                this._utcOffsetInSeconds = e <= 0 ? Math.abs(e) : -e
            }
            return void 0 === this._utcOffsetInSeconds || isNaN(this._utcOffsetInSeconds) ? -1 : this._utcOffsetInSeconds
        }
        send(e) {
            var n, s = this;
            return (n = function*() {
                return s.sender.send(e)
            }, function() {
                var e = this,
                    s = arguments;
                return new Promise((function(d, p) {
                    var h = n.apply(e, s);

                    function _next(e) {
                        asyncGeneratorStep$Z(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$Z(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        buildDescriptorForPlayParams(e, n, s, d, p) {
            const h = "stream" === e.format ? kt.STREAM : kt.ITUNES_STORE_CONTENT;
            return _object_spread$E(_object_spread_props$p(_object_spread$E({}, e), {
                container: s,
                duration: null != d ? d : 0,
                eventType: n,
                itemType: h
            }), p)
        }
        buildForPlayParams(e, n, s, d = 0, p = {}, h = !1) {
            return this.build(this.buildDescriptorForPlayParams(e, n, s, d, p), h)
        }
        constructor(e, n, s, d) {
            var p, h, y, _, m, v;
            (_define_property$1x(this, "_accessToken", void 0), _define_property$1x(this, "_musicUserToken", void 0), _define_property$1x(this, "_storefrontId", void 0), _define_property$1x(this, "privateEnabled", void 0), _define_property$1x(this, "siriInitiated", void 0), _define_property$1x(this, "bundleId", void 0), _define_property$1x(this, "buildVersion", void 0), _define_property$1x(this, "clientId", void 0), _define_property$1x(this, "eventType", void 0), _define_property$1x(this, "guid", void 0), _define_property$1x(this, "internalBuild", void 0), _define_property$1x(this, "metricsClientId", void 0), _define_property$1x(this, "preferDSID", void 0), _define_property$1x(this, "sender", void 0), _define_property$1x(this, "sourceType", void 0), _define_property$1x(this, "_appId", void 0), _define_property$1x(this, "_appInfo", void 0), _define_property$1x(this, "_deviceName", void 0), _define_property$1x(this, "_navigator", void 0), _define_property$1x(this, "_utcOffset", void 0), _define_property$1x(this, "_utcOffsetInSeconds", void 0), _define_property$1x(this, "_userAgent", void 0), _define_property$1x(this, "_userIsSubscribed", void 0), _define_property$1x(this, "_allowReportingId", void 0), this._accessToken = e, this._musicUserToken = n, this._storefrontId = s, this.privateEnabled = !1, this.siriInitiated = !1, this.clientId = "JSCLIENT", this.eventType = "JSPLAY", this.internalBuild = !1, this.preferDSID = !1, this.sourceType = wt.MUSICKIT, this._utcOffset = (new Date).getTimezoneOffset(), this._userIsSubscribed = !0, this._allowReportingId = !1, d) && (this._appInfo = d.app, this._navigator = d.navigator, this._userAgent = d.userAgent, hasOwn(d, "utcOffset") && isNaN(d.utcOffset) ? this._utcOffsetInSeconds = -1 : hasOwn(d, "utcOffset") && (this._utcOffset = d.utcOffset), this.clientId = d.clientId || "JSCLIENT", this._deviceName = d.deviceName, this.guid = d.guid, this.metricsClientId = d.metricsClientId, this.preferDSID = null !== (y = d.preferDSID) && void 0 !== y && y, this.sourceType = void 0 !== d.sourceType && "number" == typeof d.sourceType ? d.sourceType : wt.MUSICKIT, this._userIsSubscribed = null === (_ = d.userIsSubscribed) || void 0 === _ || _, this._allowReportingId = null !== (m = d.allowReportingId) && void 0 !== m && m, (null === (h = d.app) || void 0 === h ? void 0 : h.bundleId) && (this.bundleId = null === (v = d.app) || void 0 === v ? void 0 : v.bundleId));
            this.buildVersion = ((e, n, s, d) => [fullAppId(e, n), os(d), model(s), build(n)].join(" "))(this._appId, this._appInfo, this.navigator, this.userAgent), this.sender = new PlayActivitySender({
                bundleId: this.bundleId,
                accessToken: this._accessToken,
                clientId: this.clientId,
                eventType: this.eventType,
                fetch: null == d ? void 0 : d.fetch,
                fetchOptions: null == d ? void 0 : d.fetchOptions,
                headersClass: null == d || null === (p = d.fetch) || void 0 === p ? void 0 : p.Headers,
                isQA: null == d ? void 0 : d.isQA,
                logInfo: null == d ? void 0 : d.logInfo,
                musicUserToken: this._musicUserToken,
                preferDSID: this.preferDSID,
                sourceType: this.sourceType,
                traceTag: null == d ? void 0 : d.traceTag
            })
        }
    } {
        build(e, n) {
            return buildPlayActivityData(this, e, n, "JSCLIENT" !== this.clientId)
        }
        constructor(e, n, s, d) {
            super(e, n, s, d)
        }
    }
    class PlayActivity {
        get mode() {
            return this.sender.mode
        }
        set mode(e) {
            this.sender.mode = e
        }
        get privateEnabled() {
            return this._paf.privateEnabled
        }
        set privateEnabled(e) {
            this._paf.privateEnabled = e
        }
        clearTimedMetadata() {
            this.timedMetadata = void 0
        }
        setTimedMetadata(e) {
            this.timedMetadata = e
        }
        activate(n = !1) {
            var s = this;
            return _async_to_generator$W((function*() {
                if (n) try {
                    yield s.flush()
                } catch (p) {
                    if (!(e => (e => {
                            switch (typeof e) {
                                case "string":
                                    return e;
                                case "object":
                                    return e.message ? "string" != typeof e.message ? "" : e.message : "";
                                default:
                                    return ""
                            }
                        })(e).includes("send() called without any data"))(p)) throw p
                }
                const d = s.timeline.last;
                if (d && d.endReasonType === e.PlayActivityEndReasonType.EXITED_APPLICATION) return s.timeline.pop();
                s.clearTimedMetadata()
            }))()
        }
        exit(n = 0) {
            var s = this;
            return _async_to_generator$W((function*() {
                yield s.stop(n, e.PlayActivityEndReasonType.EXITED_APPLICATION)
            }))()
        }
        pause(n = 0) {
            var s = this;
            return _async_to_generator$W((function*() {
                yield s.stop(n, e.PlayActivityEndReasonType.PLAYBACK_MANUALLY_PAUSED)
            }))()
        }
        pingTimedMetadata(e, n, s = this.previousDescriptor) {
            var d = this;
            return _async_to_generator$W((function*() {
                yield d._addToTimeline(_object_spread_props$k(_object_spread$x({}, s), {
                    position: e,
                    itemType: kt.TIMED_METADATA_PING,
                    timedMetadata: n
                }))
            }))()
        }
        play(e, n = 0) {
            var s = this;
            return _async_to_generator$W((function*() {
                const d = s.timeline.length > 0;
                if (void 0 === e) {
                    if (!d) return;
                    const e = s.previousDescriptor;
                    return e.eventType === Pt.PLAY_END && delete e.endReasonType, void(yield s._addToTimeline(_object_spread_props$k(_object_spread$x({}, s.sanitizePreviousDescriptor(e)), {
                        eventType: Pt.PLAY_START
                    })))
                }
                if (d) {
                    const e = s.previousDescriptor;
                    if (s._machine.matches("playing") && !(({
                            id: e,
                            reporting: n = !0,
                            eventType: s
                        }) => ("-1" === e || !n) && s === Pt.PLAY_END)(e)) return Promise.reject(new Error("The play() method was called without a previous stop() or pause() call."))
                }
                yield s._addToTimeline(_object_spread_props$k(_object_spread$x({}, e), {
                    eventType: Pt.PLAY_START,
                    position: n
                }))
            }))()
        }
        scrub(n = 0, s = e.PlayActivityEndReasonType.SCRUB_BEGIN) {
            var d = this;
            return _async_to_generator$W((function*() {
                yield d._addToTimeline(_object_spread_props$k(_object_spread$x({}, d.sanitizePreviousDescriptor(d.previousDescriptor)), {
                    eventType: Pt.PLAY_END,
                    endReasonType: s,
                    position: n
                }))
            }))()
        }
        skip(n, s = e.PlayActivityEndReasonType.TRACK_SKIPPED_FORWARDS, d = 0) {
            var p = this;
            return _async_to_generator$W((function*() {
                yield p.stop(d, s), yield p.play(n)
            }))()
        }
        stop(n = 0, s = e.PlayActivityEndReasonType.NATURAL_END_OF_TRACK) {
            var d = this;
            return _async_to_generator$W((function*() {
                let p = d.previousDescriptor;
                if (p.endReasonType === e.PlayActivityEndReasonType.EXITED_APPLICATION && (yield d.timeline.pop(), empty(d._cookieJar, "amupaee"), p = d.previousDescriptor), d._machine.matches("playing")) {
                    const e = _object_spread_props$k(_object_spread$x({}, d.sanitizePreviousDescriptor(p)), {
                        eventType: Pt.PLAY_END,
                        endReasonType: s,
                        position: n,
                        timedMetadata: d.timedMetadata
                    });
                    yield d._addToTimeline(e)
                }
            }))()
        }
        build(e, n) {
            if (void 0 === e && void 0 === n && je.warn("You are calling build() from a stateful PAF client. Please, use a stateless client or exit(), pause(), play(), scrub(), skip() or stop() instead."), void 0 === e) {
                if (0 === this.timeline.length) throw new Error("build() called without a play activity descriptor");
                e = this.timeline.last
            }
            if (void 0 === n) {
                if (void 0 === (n = this.timeline.before(e)) && e.eventType === Pt.PLAY_END) throw new Error("Cannot build() for PLAY_END descriptors without previous descriptors");
                n = null != n && n
            }
            return this._paf.build(_object_spread$x({
                timedMetadata: this.timedMetadata
            }, e), n)
        }
        addForPlayParams(e, n, s, d = 0, p = {}) {
            var h = this;
            return _async_to_generator$W((function*() {
                yield h._addToTimeline(h.buildDescriptorForPlayParams(e, n, s, d, p))
            }))()
        }
        buildDescriptorForPlayParams(e, n, s, d = 0, p = {}) {
            const h = "stream" === e.format ? kt.STREAM : kt.ITUNES_STORE_CONTENT;
            return normalizePlayActivityDescriptor(_object_spread$x(_object_spread_props$k(_object_spread$x({}, e), {
                container: s,
                duration: d,
                eventType: n,
                itemType: h
            }), p))
        }
        flush() {
            return this.sender.flush()
        }
        _addToTimeline(e) {
            var n = this;
            return _async_to_generator$W((function*() {
                e = _object_spread_props$k(_object_spread$x({}, e), {
                    timestamp: Date.now()
                });
                const s = n.timeline.length > 0 && n.timeline.last;
                yield n.timeline.add(e);
                const d = n.build(e, s);
                yield n.send(d, e)
            }))()
        }
        get previousDescriptor() {
            const e = this.timeline.last;
            if (void 0 === e) throw new Error("A method was called without a previous descriptor");
            return omit(e, ["timestamp"])
        }
        buildForPlayParams(e, n, s, d = 0, p = {}, h = !1) {
            return je.warn("You are using buildsForPlayParams from a stateful PlayActivity. Please, use StatelessPlayActivity instead"), this._paf.buildForPlayParams(e, n, s, d, p, h)
        }
        send(e, n) {
            e = ensureArray(e);
            const s = normalizePlayActivityDescriptor(n);
            return e.forEach(e => this._machine.transition(s, e)), this.sender.send(e)
        }
        sanitizePreviousDescriptor(e) {
            let n = deepClone(e);
            return n.itemType === kt.TIMED_METADATA_PING && (n = omit(n, ["itemType"])), n
        }
        constructor(e, n, s, d) {
            _define_property$1o(this, "sender", void 0), _define_property$1o(this, "timeline", new Timeline), _define_property$1o(this, "_cookieJar", void 0), _define_property$1o(this, "_paf", void 0), _define_property$1o(this, "_machine", void 0), _define_property$1o(this, "timedMetadata", void 0), this._paf = new StatelessPlayActivity(e, n, s, d), this._cookieJar = createCookieJar(null == d ? void 0 : d.cookieJar), this.sender = new PlayActivityBatchableSender(this._paf.sender, this._cookieJar), this._machine = new MPAFStateMachine
        }
    }
    const Bind = () => (e, n, s) => {
            if (void 0 === s || "function" != typeof s.value) throw new TypeError(`Only methods can be decorated with @Bind, but ${n} is not a method.`);
            return {
                configurable: !0,
                get: function() {
                    const e = s.value.bind(this);
                    return Object.defineProperty(this, n, {
                        value: e,
                        configurable: !0,
                        writable: !0
                    }), e
                }
            }
        },
        Hr = ["exitFullscreen", "webkitExitFullscreen", "mozCancelFullScreen", "msExitFullscreen"],
        qr = ["fullscreenElement", "webkitFullscreenElement", "mozFullScreenElement", "msFullscreenElement"],
        Wr = ["requestFullscreen", "webkitRequestFullscreen", "mozRequestFullScreen", "msRequestFullscreen"],
        noop = () => Promise.resolve(),
        zr = (e => {
            if (void 0 === e) return noop;
            const n = Hr.find(n => "function" == typeof e.prototype[n]);
            return "string" != typeof n ? noop : (e = self.document) => {
                var s;
                return null == e || null === (s = e[n]) || void 0 === s ? void 0 : s.call(e)
            }
        })(Document),
        Yr = (e => {
            if (void 0 === e) return () => !1;
            const n = qr.find(n => n in e.prototype);
            return "string" != typeof n ? () => !1 : (e = self.document) => !!e[n]
        })(Document),
        Qr = (e => {
            if (void 0 === e) return noop;
            const n = Wr.find(n => "function" == typeof e.prototype[n]);
            return "string" != typeof n ? noop : e => null == e ? void 0 : e[n]()
        })(HTMLElement);

    function asyncGeneratorStep$V(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$V(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$V(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$V(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }
    class Fullscreen {
        exit() {
            var e = this;
            return _async_to_generator$V((function*() {
                if (e.isInFullscreen()) return e.stopDispatchingEvents(() => e.exitFullscreen())
            }))()
        }
        request(e) {
            var n = this;
            return _async_to_generator$V((function*() {
                if (void 0 !== e) return n.stopDispatchingEvents(() => n.requestFullscreenForElement(e))
            }))()
        }
        stopDispatchingEvents(e) {
            var n = this;
            return _async_to_generator$V((function*() {
                return n.player.windowHandlers.stopListeningToVisibilityChanges(e)
            }))()
        }
        exitFullscreen() {
            return zr()
        }
        isInFullscreen() {
            return Yr()
        }
        requestFullscreenForElement(e) {
            return Qr(e)
        }
        constructor(e) {
            ! function(e, n, s) {
                n in e ? Object.defineProperty(e, n, {
                    value: s,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = s
            }(this, "player", void 0), this.player = e
        }
    }

    function asyncGeneratorStep$U(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$1m(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class UnsupportedSeeker {
        start() {
            xe.warn("seeker.start is not supported in this playback method")
        }
        end() {
            xe.warn("seeker.end is not supported in this playback method")
        }
        seekToTime(e) {
            return xe.warn("seekToTime is not supported in this playback method"), Promise.resolve()
        }
        constructor() {
            _define_property$1m(this, "ended", !1)
        }
    }
    class PlayerSeeker {
        get ended() {
            return this._ended
        }
        get isEngagedInPlayback() {
            return this._player.isEngagedInPlayback
        }
        get stillPlayingSameItem() {
            return this._currentItem === this._player.nowPlayingItem
        }
        end() {
            xe.debug("seeker: end"), -1 !== this._startTime ? this._ended ? xe.warn("seeker: Cannot end the same seeker twice.") : (this.dispatchStartEvent(), this.dispatchEndEvent()) : xe.warn("seeker: Cannot end a seeker before starting it.")
        }
        seekToTime(e) {
            var n, s = this;
            return (n = function*() {
                if (xe.debug("seeker: seekToTime", e), !s.ended) return s.stillPlayingSameItem || (s._currentItem = s._player.nowPlayingItem, s._startTime = 0), s._lastSeekedTime = e, s._player.seekToTime(e);
                xe.warn("seeker: Cannot seek once the seeker has ended")
            }, function() {
                var e = this,
                    s = arguments;
                return new Promise((function(d, p) {
                    var h = n.apply(e, s);

                    function _next(e) {
                        asyncGeneratorStep$U(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$U(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        start() {
            xe.debug("seeker: start"), -1 === this._startTime ? (this._currentItem = this._player.nowPlayingItem, this._startTime = this._player.currentPlaybackTime, this._lastSeekedTime = this._startTime) : xe.warn("seeker: Cannot start same seeker twice")
        }
        dispatch(e, n) {
            this.isEngagedInPlayback ? (xe.debug("seeker: dispatch", e), this._player.dispatch(e, n)) : xe.debug("seeker: do not dispatch because isEngagedInPlayback", this.isEngagedInPlayback)
        }
        dispatchStartEvent() {
            this.stillPlayingSameItem || (this._startTime = 0, this._lastSeekedTime = 0), this.dispatch(ot.playbackScrub, {
                item: this._currentItem,
                position: this._startTime
            })
        }
        dispatchEndEvent() {
            this._ended = !0, this.dispatch(ot.playbackScrub, {
                item: this._currentItem,
                position: this._lastSeekedTime,
                endReasonType: e.PlayActivityEndReasonType.SCRUB_END
            })
        }
        constructor(e) {
            _define_property$1m(this, "_ended", !1), _define_property$1m(this, "_lastSeekedTime", -1), _define_property$1m(this, "_player", void 0), _define_property$1m(this, "_startTime", -1), _define_property$1m(this, "_currentItem", void 0), xe.debug("seeker: new"), this._player = e
        }
    }

    function asyncGeneratorStep$T(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$1l(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$o(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$o(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    const {
        visibilityChangeEvent: Jr,
        visibilityState: Xr,
        unloadEventName: Zr
    } = (() => {
        let e = "visibilitychange",
            n = "visibilityState";
        void 0 !== document.mozHidden ? (e = "mozvisibilitychange", n = "mozVisibilityState") : void 0 !== document.msHidden ? (e = "msvisibilitychange", n = "msVisibilityState") : document.webkitHidden && (e = "webkitvisibilitychange", n = "webkitVisibilityState");
        return {
            visibilityChangeEvent: e,
            visibilityState: n,
            unloadEventName: "onpagehide" in window ? "pagehide" : "unload"
        }
    })();
    class WindowHandlers {
        activate(e = self, n = self.document) {
            n.addEventListener(Jr, this.visibilityChanged), e.addEventListener("storage", this.storage, !1), e.addEventListener(Zr, this.windowUnloaded)
        }
        deactivate() {
            document.removeEventListener(Jr, this.visibilityChanged), window.removeEventListener("storage", this.storage), window.addEventListener(Zr, this.windowUnloaded)
        }
        stopListeningToVisibilityChanges(e) {
            var n, s = this;
            return (n = function*() {
                s.dispatchVisibilityChanges = !1;
                const n = yield e();
                return s.dispatchVisibilityChanges = !0, n
            }, function() {
                var e = this,
                    s = arguments;
                return new Promise((function(d, p) {
                    var h = n.apply(e, s);

                    function _next(e) {
                        asyncGeneratorStep$T(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$T(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        dispatch(e, n = {}) {
            this.player.dispatch(e, n)
        }
        storage({
            key: e,
            newValue: n
        }) {
            e === We && this.player.tsidChanged(n)
        }
        visibilityChanged(e) {
            const n = e.target[Xr];
            xe.info("dc visibilityState", n, e, Yr()), this.runtimeEnvironment.os.isIOS && this.dispatchVisibilityChanges && ("hidden" === n ? this.dispatch(ot.playerExit, {
                item: this.player.nowPlayingItem,
                position: this.player.currentPlaybackTime
            }) : "visible" === n && this.dispatch(ot.playerActivate))
        }
        windowUnloaded() {
            this.player.isPlaying && this.dispatch(ot.playerExit, {
                item: this.player.nowPlayingItem,
                position: this.player.currentPlaybackTime
            })
        }
        constructor(e, n) {
            _define_property$1l(this, "player", void 0), _define_property$1l(this, "runtimeEnvironment", void 0), _define_property$1l(this, "dispatchVisibilityChanges", !0), this.player = e, this.runtimeEnvironment = n
        }
    }

    function asyncGeneratorStep$S(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$S(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$S(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$S(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1k(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$w(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1k(e, n, s[n])
            }))
        }
        return e
    }

    function _ts_metadata$n(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    _ts_decorate$o([Bind(), _ts_metadata$o("design:type", Function), _ts_metadata$o("design:paramtypes", [void 0]), _ts_metadata$o("design:returntype", void 0)], WindowHandlers.prototype, "storage", null), _ts_decorate$o([Bind(), _ts_metadata$o("design:type", Function), _ts_metadata$o("design:paramtypes", ["undefined" == typeof Event ? Object : Event]), _ts_metadata$o("design:returntype", void 0)], WindowHandlers.prototype, "visibilityChanged", null), _ts_decorate$o([Bind(), _ts_metadata$o("design:type", Function), _ts_metadata$o("design:paramtypes", []), _ts_metadata$o("design:returntype", void 0)], WindowHandlers.prototype, "windowUnloaded", null);
    const ei = ["canplay", "durationchange", "ended", "error", "loadedmetadata", "loadstart", "pause", "play", "playing", "progress", "ratechange", "seeked", "seeking", "timeupdate", "volumechange", "waiting"],
        ti = ["NotAllowedError", "NotSupportedError"];
    class BasePlayer {
        get bitrate() {
            return this._bitrateCalculator.bitrate
        }
        get currentBufferedProgress() {
            return this._currentBufferedProgress
        }
        get _currentDuration() {
            return this._targetElement.duration
        }
        get _currentTime() {
            const e = this._targetElement.currentTime,
                n = this._buffer;
            var s;
            return e - (null !== (s = null == n ? void 0 : n.currentTimestampOffset) && void 0 !== s ? s : 0)
        }
        get currentPlaybackDuration() {
            const n = this.nowPlayingItem;
            if (!n) return 0;
            const s = "podcast-episodes" === n.type,
                d = n.playbackType === e.PlaybackType.encryptedFull || n.playbackType === e.PlaybackType.unencryptedFull,
                p = n.playbackDuration;
            return d && p && !s ? this.calculateTime(p / 1e3) : this.calculateTime(this._currentDuration)
        }
        get currentPlaybackTime() {
            return this.calculateTime(this._currentTime)
        }
        calculateTime(e) {
            return this._timing.time(e)
        }
        get currentPlaybackTimeRemaining() {
            return this.currentPlaybackDuration - this.currentPlaybackTime
        }
        get currentPlaybackProgress() {
            return this._currentPlaybackProgress || 0
        }
        get hasMediaElement() {
            return this._targetElement instanceof HTMLElement && null !== this._targetElement.parentNode
        }
        get isEngagedInPlayback() {
            return !this._stopped && !this.isPaused()
        }
        get isPlaying() {
            return this.playbackState === e.PlaybackStates.playing
        }
        get isPrimaryPlayer() {
            return this._isPrimaryPlayer
        }
        set isPrimaryPlayer(e) {
            var n;
            e !== this._isPrimaryPlayer && (this._isPrimaryPlayer = e, this._isPrimaryPlayer ? null === (n = getLocalStorage()) || void 0 === n || n.setItem(We, this._serial) : (this._dispatcher.publish(st.primaryPlayerDidChange, {
                target: this
            }), this.pause({
                userInitiated: !1
            })))
        }
        get isReady() {
            return 0 !== this._targetElement.readyState
        }
        get nowPlayingItem() {
            return this._nowPlayingItem
        }
        set nowPlayingItem(e) {
            const n = this._dispatcher;
            if (void 0 === e) return n.publish(st.nowPlayingItemWillChange, {
                item: e
            }), this._nowPlayingItem = e, void n.publish(st.nowPlayingItemDidChange, {
                item: e
            });
            const s = this._nowPlayingItem,
                d = this._buffer;
            (null == s ? void 0 : s.isEqual(e)) || (n.publish(st.nowPlayingItemWillChange, {
                item: e
            }), this.isPlaying && (null == d ? void 0 : d.currentItem) !== e && this._pauseMedia(), s && (xe.debug("setting state to ended on ", s.title), s.state = ee.ended, s.endMonitoringStateDidChange(), s.endMonitoringStateWillChange()), this._nowPlayingItem = e, xe.debug("setting state to playing on ", e.title), e.state = ee.playing, e && e.info && this._setTargetElementTitle(e.info), n.publish(st.nowPlayingItemDidChange, {
                item: e
            }), n.publish(st.playbackDurationDidChange, {
                currentTarget: this._targetElement,
                duration: this.currentPlaybackDuration,
                target: this._targetElement,
                type: "durationchange"
            }))
        }
        get playbackRate() {
            return this._targetElement.playbackRate
        }
        set playbackRate(e) {
            this._targetElement.playbackRate = e
        }
        get defaultPlaybackRate() {
            return this._targetElement.defaultPlaybackRate
        }
        set defaultPlaybackRate(e) {
            this._targetElement.defaultPlaybackRate = e
        }
        get playbackState() {
            return this._playbackState
        }
        setPlaybackState(e, n) {
            const s = this._playbackState;
            if (e === s) return;
            const d = {
                oldState: s,
                state: e,
                nowPlayingItem: n
            };
            xe.debug("BasePlayer.playbackState is changing", d), this._dispatcher.publish(st.playbackStateWillChange, d), this._playbackState = e, this._dispatcher.publish(st.playbackStateDidChange, d)
        }
        get playbackTargetAvailable() {
            return void 0 !== window.WebKitPlaybackTargetAvailabilityEvent && this._playbackTargetAvailable
        }
        set playbackTargetAvailable(e) {
            e !== this._playbackTargetAvailable && (this._playbackTargetAvailable = e, this._dispatcher.publish(st.playbackTargetAvailableDidChange, {
                available: e
            }))
        }
        get playbackTargetIsWireless() {
            return void 0 !== window.WebKitPlaybackTargetAvailabilityEvent && this._playbackTargetIsWireless
        }
        set playbackTargetIsWireless(e) {
            e !== this._playbackTargetIsWireless && (this._playbackTargetIsWireless = e, this._dispatcher.publish(st.playbackTargetIsWirelessDidChange, {
                playing: e
            }))
        }
        get volume() {
            return this._targetElement.volume
        }
        set volume(e) {
            this._targetElement.volume = e
        }
        get isDestroyed() {
            return this._isDestroyed
        }
        get isInitialized() {
            return this._isInitialized
        }
        clearNextManifest() {
            var e;
            null === (e = this._buffer) || void 0 === e || e.clearNextManifest()
        }
        initialize() {
            var e = this;
            return _async_to_generator$S((function*() {
                xe.trace("BasePlayer.initialize"), e._isInitialized ? xe.warn("Player is already initialized") : (yield e.initializeMediaElement(), yield e.initializeExtension(), e.initializeEventHandlers(), e._dispatcher.publish(st.mediaElementCreated, e._targetElement), e._isInitialized = !0)
            }))()
        }
        initializeEventHandlers() {
            if (this.windowHandlers.activate(), !this.hasMediaElement) return;
            const e = this._targetElement;
            window.WebKitPlaybackTargetAvailabilityEvent && (e.addEventListener("webkitplaybacktargetavailabilitychanged", e => {
                this.playbackTargetAvailable = "available" === e.availability
            }), e.addEventListener("webkitcurrentplaybacktargetiswirelesschanged", e => {
                this.playbackTargetIsWireless = e.target === this._targetElement && !this.playbackTargetIsWireless
            })), xe.debug(`Adding event handlers to <HTMLMediaElement id=${this._targetElement.id} />`, this._targetElement), ei.forEach(n => e.addEventListener(n, this)), this._dispatcher.publish(ot.playerActivate)
        }
        removeEventHandlers() {
            xe.trace("BasePlayer.removeEventHandlers()"), setTimeout(() => {
                xe.debug(`Removing event handlers from <HTMLMediaElement id=${this._targetElement.id} />`, this._targetElement), ei.forEach(e => this._targetElement.removeEventListener(e, this)), this.windowHandlers.deactivate()
            }, 0)
        }
        isPaused() {
            return this._paused
        }
        exitFullscreen() {
            return this.fullscreen.exit()
        }
        requestFullscreen(e) {
            return this.fullscreen.request(e)
        }
        newSeeker() {
            var e;
            return null === (e = this._seeker) || void 0 === e || e.end(), this._seeker = new PlayerSeeker(this), this._seeker
        }
        stop(e) {
            var n = this;
            return _async_to_generator$S((function*() {
                xe.debug("BasePlayer.stop", e), yield n._waitForPendingPlay(), n.isPlaying && (xe.debug("BasePlayer.play dispatching playbackStop"), n.dispatch(ot.playbackStop, _object_spread$w({
                    item: n.nowPlayingItem,
                    position: n.currentPlaybackTime,
                    startPosition: n.initialPlaybackTime,
                    playingDate: n.currentPlayingDate,
                    startPlayingDate: n.initialPlayingDate
                }, e))), yield n.stopMediaAndCleanup()
            }))()
        }
        stopMediaAndCleanup(n = e.PlaybackStates.stopped) {
            var s = this;
            return _async_to_generator$S((function*() {
                xe.debug("BasePlayer.stopMediaAndCleanup", n), yield s.stopMediaElement(), s._stopped = !0, s._paused = !1;
                const e = s.nowPlayingItem;
                s.nowPlayingItem = void 0, s.initialPlayingDate = void 0, s.initialPlaybackTime = void 0, s.setPlaybackState(n, e)
            }))()
        }
        onPlaybackError(n, s) {
            this.resetDeferredPlay(), this.stop({
                endReasonType: e.PlayActivityEndReasonType.FAILED_TO_LOAD,
                userInitiated: !1
            })
        }
        calculatePlaybackProgress() {
            const e = Math.round(100 * (this.currentPlaybackTime / this.currentPlaybackDuration || 0)) / 100;
            this._currentPlaybackProgress !== e && (this._currentPlaybackProgress = e, this._dispatcher.publish(st.playbackProgressDidChange, {
                progress: this._currentPlaybackProgress
            }))
        }
        calculateBufferedProgress(e) {
            const n = Math.round(e / this.currentPlaybackDuration * 100);
            this._currentBufferedProgress !== n && (this._currentBufferedProgress = n, this._dispatcher.publish(st.bufferedProgressDidChange, {
                progress: n
            }))
        }
        destroy() {
            var e, n;
            if (xe.debug("BasePlayer.destroy()"), this._isDestroyed = !0, this._dispatcher.unsubscribe(st.mediaPlaybackError, this.onPlaybackError), !this.hasMediaElement) return;
            const s = this._targetElement;
            null === (e = this.extension) || void 0 === e || e.destroy(s), this.resetMediaElement(), this.removeEventHandlers(), null === (n = s.parentNode) || void 0 === n || n.removeChild(s)
        }
        handleEvent(n) {
            var s = this;
            return _async_to_generator$S((function*() {
                "timeupdate" !== n.type && xe.debug("BasePlayer.handleEvent: ", n.type, n);
                const {
                    nowPlayingItem: d
                } = s;
                switch (n.timestamp = Date.now(), n.type) {
                    case "canplay":
                        s._dispatcher.publish(st.mediaCanPlay, n), s._playbackState !== e.PlaybackStates.waiting || s._targetElement.paused || s.setPlaybackState(e.PlaybackStates.playing, d);
                        break;
                    case "durationchange":
                        s._targetElement.duration !== 1 / 0 && (n.duration = s.currentPlaybackDuration, s._dispatcher.publish(st.playbackDurationDidChange, n), s.calculatePlaybackProgress());
                        break;
                    case "ended":
                        {
                            var p;
                            if (xe.debug('media element "ended" event'), null === (p = s.nowPlayingItem) || void 0 === p ? void 0 : p.isLinearStream) return void xe.warn("ignoring ended event for linear stream", n);
                            if (s.isElementCleaned()) {
                                xe.debug('media element already cleaned, ignoring "ended" event');
                                break
                            }
                            const d = s.nowPlayingItem,
                                h = (null == d ? void 0 : d.playbackDuration) ? d.playbackDuration / 1e3 : s.currentPlaybackTime,
                                y = s.currentPlayingDate;yield s.stopMediaAndCleanup(e.PlaybackStates.ended),
                            s.dispatch(ot.playbackStop, {
                                item: d,
                                position: h,
                                playingDate: y,
                                endReasonType: e.PlayActivityEndReasonType.NATURAL_END_OF_TRACK
                            });
                            break
                        }
                    case "error":
                        xe.error("Playback Error", n, s._targetElement.error), s._dispatcher.publish(st.mediaPlaybackError, new MKError(MKError.Reason.MEDIA_PLAYBACK, "Playback Error"));
                        break;
                    case "loadedmetadata":
                        s._dispatcher.publish(st.metadataDidChange, n);
                        break;
                    case "loadstart":
                        s.setPlaybackState(e.PlaybackStates.loading, d);
                        break;
                    case "pause":
                        s.setPlaybackState(s._stopped ? e.PlaybackStates.stopped : e.PlaybackStates.paused, d);
                        break;
                    case "play":
                    case "playing":
                        s._paused = !1, s._stopped = !1, s.isPrimaryPlayer = !0, s.setPlaybackState(e.PlaybackStates.playing, d);
                        break;
                    case "progress":
                        {
                            const e = s._targetElement.buffered;s.handleBufferStart(),
                            1 === e.length && 0 === e.start(0) && s.calculateBufferedProgress(e.end(0));
                            break
                        }
                    case "ratechange":
                        s._dispatcher.publish(st.playbackRateDidChange, n);
                        break;
                    case "seeked":
                        s._stopped ? s.setPlaybackState(e.PlaybackStates.stopped, d) : s._paused ? s.setPlaybackState(e.PlaybackStates.paused, d) : s.playbackState !== e.PlaybackStates.ended && s.setPlaybackState(e.PlaybackStates.playing, d);
                        break;
                    case "seeking":
                        s.playbackState === e.PlaybackStates.paused ? s._paused = !0 : s.playbackState === e.PlaybackStates.stopped && (s._stopped = !0), s.playbackState !== e.PlaybackStates.ended && s.setPlaybackState(e.PlaybackStates.seeking, d);
                        break;
                    case "timeupdate":
                        {
                            s._dispatcher.publish(st.playbackTimeDidChange, {
                                currentPlaybackDuration: s.currentPlaybackDuration,
                                currentPlaybackTime: s.currentPlaybackTime,
                                currentPlaybackTimeRemaining: s.currentPlaybackTimeRemaining
                            }),
                            s.calculatePlaybackProgress();
                            const e = s._buffer;e && (e.currentTime = s.currentPlaybackTime);
                            break
                        }
                    case "volumechange":
                        s._dispatcher.publish(st.playbackVolumeDidChange, n);
                        break;
                    case "waiting":
                        s.setPlaybackState(e.PlaybackStates.waiting, d)
                }
            }))()
        }
        handleBufferStart() {
            const {
                _targetElement: e
            } = this;
            void 0 !== this.initialPlaybackTime || e.paused || 0 === e.buffered.length || (this.initialPlaybackTime = this.currentPlaybackTime, this.initialPlayingDate = this.currentPlayingDate, xe.debug("BasePlayer.handleBufferStart: setting initialPlaybackTime", this.initialPlaybackTime))
        }
        pause(e = {}) {
            var n = this;
            return _async_to_generator$S((function*() {
                yield n._waitForPendingPlay(), n.isPlaying && (yield n._pauseMedia(), n._paused = !0, n.dispatch(ot.playbackPause, _object_spread$w({
                    item: n.nowPlayingItem,
                    position: n.currentPlaybackTime,
                    playingDate: n.currentPlayingDate
                }, e)))
            }))()
        }
        play(e = !0) {
            var n = this;
            return _async_to_generator$S((function*() {
                if (xe.debug("BasePlayer.play()"), n.nowPlayingItem) try {
                    yield n._playMedia(), xe.debug("BasePlayer.play dispatching playbackPlay"), n.dispatch(ot.playbackPlay, {
                        userInitiated: e,
                        item: n.nowPlayingItem,
                        position: n.currentPlaybackTime,
                        playingDate: n.currentPlayingDate
                    })
                } catch (Rt) {
                    if (Rt && ti.includes(Rt.name) && xe.error("BasePlayer.play() rejected due to", Rt), "NotAllowedError" === (null == Rt ? void 0 : Rt.name)) throw new MKError(MKError.Reason.USER_INTERACTION_REQUIRED, "Playback of media content requires user interaction first and cannot be automatically started on page load.")
                }
            }))()
        }
        preload() {
            return this._loadMedia()
        }
        showPlaybackTargetPicker() {
            this.playbackTargetAvailable && this._targetElement.webkitShowPlaybackTargetPicker()
        }
        dispatch(e, n) {
            void 0 === n.item && (n.item = this.nowPlayingItem), hasOwn(n, "isPlaying") || (n.isPlaying = this.isPlaying), this._dispatcher.publish(e, n)
        }
        tsidChanged(e) {
            void 0 !== e && "" !== e && (this.isPrimaryPlayer = e === this._serial)
        }
        _waitForPendingPlay() {
            var e = this;
            return _async_to_generator$S((function*() {
                e._deferredPlay && (yield e._deferredPlay.promise, e._deferredPlay = void 0)
            }))()
        }
        _loadMedia() {
            var e = this;
            return _async_to_generator$S((function*() {
                xe.debug("BasePlayer._loadMedia", e._targetElement), e._targetElement.load()
            }))()
        }
        _pauseMedia() {
            var e = this;
            return _async_to_generator$S((function*() {
                e._targetElement.pause()
            }))()
        }
        _playAssetURL(e, n) {
            var s = this;
            return _async_to_generator$S((function*() {
                xe.debug("BasePlayer._playAssetURL", e), s._targetElement.src = e;
                const d = s._loadMedia();
                if (n) return xe.debug("BasePlayer.loadOnly"), void(yield d);
                yield s._playMedia()
            }))()
        }
        playItemFromUnencryptedSource(e, n, s) {
            var d = this;
            return _async_to_generator$S((function*() {
                return (null == s ? void 0 : s.startTime) && (e += "#t=" + s.startTime), n || d.startPlaybackSequence(), yield d._playAssetURL(e, n), d.finishPlaybackSequence()
            }))()
        }
        _playMedia() {
            var e = this;
            return _async_to_generator$S((function*() {
                xe.debug("BasePlayer._playMedia", e._targetElement, e.extension);
                try {
                    yield e._targetElement.play(), e._playbackDidStart = !0
                } catch (ce) {
                    throw xe.error("BasePlayer._playMedia: targetElement.play() rejected", ce), ce
                }
            }))()
        }
        _setTargetElementTitle(e) {
            this.hasMediaElement && (this._targetElement.title = e)
        }
        resetDeferredPlay() {
            this._deferredPlay = void 0
        }
        stopMediaElement() {
            var e = this;
            return _async_to_generator$S((function*() {
                xe.trace("BasePlayer.stopMediaElement()"), e.hasMediaElement && (xe.debug("Stopping HTMLMediaElement id=" + e._targetElement.id, e._targetElement), e._targetElement.pause(), e.resetMediaElement())
            }))()
        }
        resetMediaElement() {
            xe.trace("BasePlayer.cleanupElement()");
            const e = this._targetElement;
            e && !this.isElementCleaned() ? (xe.debug("Resetting HTMLMediaElement", e), e.currentTime = 0, e.removeAttribute("src"), e.removeAttribute("title")) : xe.debug("No HTMLMediaElement to reset")
        }
        isElementCleaned() {
            const e = this._targetElement;
            return !e || 0 === e.currentTime && "" === e.src && "" === e.title
        }
        finishPlaybackSequence() {
            var e;
            xe.debug("BasePlayer.finishPlaybackSequence", this._deferredPlay);
            const n = null === (e = this._deferredPlay) || void 0 === e ? void 0 : e.resolve(void 0);
            return this._deferredPlay = void 0, n
        }
        startPlaybackSequence() {
            return xe.debug("BasePlayer.startPlaybackSequence", this._deferredPlay), this._deferredPlay && (xe.warn("Previous playback sequence not cleared"), this.finishPlaybackSequence()), this._deferredPlay = function() {
                let e, n;
                return {
                    promise: new Promise((function(s, d) {
                        e = s, n = d
                    })),
                    resolve: function(n) {
                        null == e || e(n)
                    },
                    reject: function(e) {
                        null == n || n(e)
                    }
                }
            }(), this._deferredPlay.promise
        }
        constructor(n) {
            var s;
            _define_property$1k(this, "privateEnabled", !1), _define_property$1k(this, "siriInitiated", !1), _define_property$1k(this, "windowHandlers", void 0), _define_property$1k(this, "_dispatcher", void 0), _define_property$1k(this, "_buffer", void 0), _define_property$1k(this, "services", void 0), _define_property$1k(this, "_context", void 0), _define_property$1k(this, "_currentBufferedProgress", 0), _define_property$1k(this, "initialPlayingDate", void 0), _define_property$1k(this, "initialPlaybackTime", void 0), _define_property$1k(this, "_nowPlayingItem", void 0), _define_property$1k(this, "_paused", !1), _define_property$1k(this, "_playbackDidStart", !1), _define_property$1k(this, "_playbackState", e.PlaybackStates.none), _define_property$1k(this, "_stopped", !1), _define_property$1k(this, "_timing", void 0), _define_property$1k(this, "_bitrateCalculator", void 0), _define_property$1k(this, "_currentPlaybackProgress", 0), _define_property$1k(this, "_isPrimaryPlayer", !0), _define_property$1k(this, "_playbackTargetAvailable", !1), _define_property$1k(this, "_playbackTargetIsWireless", !1), _define_property$1k(this, "_seeker", void 0), _define_property$1k(this, "_serial", Date.now().toString()), _define_property$1k(this, "fullscreen", void 0), _define_property$1k(this, "_isDestroyed", !1), _define_property$1k(this, "_isInitialized", !1), _define_property$1k(this, "_deferredPlay", void 0), this.services = n.services, this._dispatcher = n.services.dispatcher, this._timing = n.services.timing, this._context = n.context || {}, this.privateEnabled = n.privateEnabled || !1, this.siriInitiated = n.siriInitiated || !1, this._bitrateCalculator = n.services.bitrateCalculator, this.windowHandlers = new WindowHandlers(this, n.services.runtime), this.fullscreen = new Fullscreen(this), null === (s = getLocalStorage()) || void 0 === s || s.setItem(We, this._serial), this._dispatcher.subscribe(st.mediaPlaybackError, this.onPlaybackError)
        }
    }

    function generateAssetUrl(e, n) {
        if ("Preview" === e.type && !isEmptyString(e.previewURL, {
                trim: !0
            })) return e.previewURL;
        if (!e.assetURL) throw new Error("Cannot generate asset URL");
        const s = {};
        return (null == n ? void 0 : n.startOver) && (s.startOver = !0), (null == n ? void 0 : n.bingeWatching) && (s.bingeWatching = !0), e.supportsLinearScrubbing && (s.linearScrubbingSupported = !0), e.assetURL.match(/xapsub=accepts-css/) || (s.xapsub = "accepts-css"), buildURL(e.assetURL, s)
    }
    var ri;

    function toPersistedTrack(e) {
        return {
            label: e.label,
            kind: e.kind,
            language: e.language
        }
    }

    function saveTrack(e, n) {
        var s, d;
        s = e, d = toPersistedTrack(n), hasLocalStorage() && (d ? getLocalStorage().setItem(s, JSON.stringify(d)) : getLocalStorage().setItem(s, ""))
    }

    function loadTrack(e) {
        return getJsonFromLocalStorage(e)
    }

    function trackEquals(e, n) {
        const s = toPersistedTrack(e),
            d = toPersistedTrack(n);
        for (const p of Object.keys(s))
            if (s[p] !== d[p]) return !1;
        return !0
    }

    function _define_property$1j(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$n("design:type", Function), _ts_metadata$n("design:paramtypes", [String, void 0 === MKError ? Object : MKError]), _ts_metadata$n("design:returntype", void 0)], BasePlayer.prototype, "onPlaybackError", null),
    function(e) {
        e.Home = "com.apple.amp.appletv.home-team-radio", e.Away = "com.apple.amp.appletv.away-team-radio"
    }(ri || (ri = {}));
    class AudioTrackManager {
        get isDestroyed() {
            return this._isDestroyed
        }
        get currentTrack() {
            return this.tracks.find(e => e.enabled)
        }
        set currentTrack(e) {
            e && (xe.debug("MEDIA_TRACK Setting audio track " + e.label), this.extensionTracks ? (xe.debug(`MEDIA_TRACK Setting track on extension ${e.id}-${e.label}`), this.extensionTracks.audioTrack = e) : (xe.debug("MEDIA_TRACK disabling all audio tracks"), Array.from(this.mediaElement.audioTracks).forEach(n => {
                n !== e && (n.enabled = !1)
            }), xe.debug("MEDIA_TRACK enabling", e), e.enabled = !0), function(e) {
                return void 0 !== e.characteristics && e.characteristics.includes("com.apple.amp.appletv.home-team-radio")
            }(e) || function(e) {
                return void 0 !== e.characteristics && e.characteristics.includes("com.apple.amp.appletv.away-team-radio")
            }(e) || (saveTrack("mk-audio-track", e), xe.debug(`MEDIA_TRACK save track selection ${e.language},${e.label},${e.kind}`)))
        }
        get tracks() {
            return this.extensionTracks ? this._extensionTracks || this.extensionTracks.audioTracks || [] : Array.from(this.mediaElement.audioTracks)
        }
        destroy() {
            if (this._isDestroyed = !0, this.extensionTracks) {
                const e = this.extensionTracks;
                e.removeEventListener(Ye.audioTracksUpdated, this.onExtensionAudioTracksUpdated), e.removeEventListener(Ye.audioTracksSwitched, this.onExtensionAudioTrackSwitched)
            } else {
                if (!this.mediaElement.audioTracks) return;
                this.mediaElement.audioTracks.removeEventListener("addtrack", this.onAudioTrackAdded), this.mediaElement.audioTracks.removeEventListener("change", this.onAudioTrackChanged), this.mediaElement.audioTracks.removeEventListener("removetrack", this.onAudioTrackRemoved)
            }
        }
        onExtensionAudioTracksUpdated(e) {
            var n;
            xe.debug("MEDIA_TRACK Extension audio tracks updated " + JSON.stringify(e)), this._extensionTracks = e;
            const s = loadTrack("mk-audio-track");
            if ((null === (n = this.tracks) || void 0 === n ? void 0 : n.length) >= 0 && void 0 !== s && (void 0 === this.currentTrack || !trackEquals(this.currentTrack, s)))
                for (const d of this.tracks)
                    if (trackEquals(d, s)) {
                        xe.debug("Found track matching persisted track: " + d.label), this.currentTrack = d;
                        break
                    }
            this.dispatcher.publish(st.audioTrackAdded, e)
        }
        onExtensionAudioTrackSwitched(e) {
            if (xe.debug("MEDIA_TRACK Extension audio track switched " + JSON.stringify(e)), this._extensionTracks) {
                const preserveSelectedTrack = n => {
                    n.enabled = e.selectedId === n.id
                };
                this._extensionTracks.forEach(preserveSelectedTrack)
            }
            this.dispatcher.publish(st.audioTrackChanged, e)
        }
        onAudioTrackAdded(e) {
            const n = loadTrack("mk-audio-track");
            void 0 !== n && trackEquals(e.track, n) && (xe.debug("Found new track matching persisted track: " + e.track.label), this.currentTrack = e.track), this.dispatcher.publish(st.audioTrackAdded, e)
        }
        onAudioTrackChanged(e) {
            this.dispatcher.publish(st.audioTrackChanged, e)
        }
        onAudioTrackRemoved(e) {
            this.dispatcher.publish(st.audioTrackRemoved, e)
        }
        constructor(e, n, s) {
            if (_define_property$1j(this, "mediaElement", void 0), _define_property$1j(this, "dispatcher", void 0), _define_property$1j(this, "extensionTracks", void 0), _define_property$1j(this, "_extensionTracks", void 0), _define_property$1j(this, "_isDestroyed", void 0), this.mediaElement = e, this.dispatcher = n, this.extensionTracks = s, this._extensionTracks = [], this._isDestroyed = !1, this.extensionTracks) {
                xe.debug("MEDIA_TRACK Initializing audio track manager for hls track events"), this.onExtensionAudioTracksUpdated = this.onExtensionAudioTracksUpdated.bind(this), this.onExtensionAudioTrackSwitched = this.onExtensionAudioTrackSwitched.bind(this);
                const e = this.extensionTracks;
                e.addEventListener(Ye.audioTracksUpdated, this.onExtensionAudioTracksUpdated), e.addEventListener(Ye.audioTracksSwitched, this.onExtensionAudioTrackSwitched)
            } else {
                if (!e.audioTracks) return;
                xe.debug("MEDIA_TRACK Initializing audio track manager for native track events"), this.onAudioTrackAdded = this.onAudioTrackAdded.bind(this), this.onAudioTrackChanged = this.onAudioTrackChanged.bind(this), this.onAudioTrackRemoved = this.onAudioTrackRemoved.bind(this), e.audioTracks.addEventListener("addtrack", this.onAudioTrackAdded), e.audioTracks.addEventListener("change", this.onAudioTrackChanged), e.audioTracks.addEventListener("removetrack", this.onAudioTrackRemoved)
            }
        }
    }
    const ii = [],
        ni = [];

    function nextAvailableAudioElement() {
        let e = ni.pop();
        return e ? xe.debug(`dom-helpers: retrieving audio tag, ${ni.length} remain`) : (xe.debug("dom-helpers: no available audio tags, creating one"), e = document.createElement("audio")), e
    }

    function deferPlayback() {
        fillAvailableElements("audio", ni), fillAvailableElements("video", ii), xe.debug(`dom-helpers: defer playback called.  There are ${ii.length} available video elements and ${ni.length} available audio elements.`)
    }

    function fillAvailableElements(e, n) {
        let s = 100 - n.length;
        for (; s > 0;) {
            const d = document.createElement(e);
            d.load(), n.push(d), s--
        }
    }
    const oi = BooleanDevFlag.register("mk-load-manifest-once"),
        shouldLoadManifestOnce = () => !oi.configured || oi.enabled;

    function isValidPercentValue(e) {
        return "number" == typeof e && e >= 0 && e <= 100
    }

    function isValidLineAndPositionSetting(e) {
        return "number" == typeof e || "auto" === e
    }
    const ai = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&lrm;": "‎",
            "&rlm;": "‏",
            "&nbsp;": " "
        },
        si = {
            c: "span",
            i: "i",
            b: "b",
            u: "u",
            ruby: "ruby",
            rt: "rt",
            v: "span",
            lang: "span"
        },
        ci = {
            v: "title",
            lang: "lang"
        },
        di = {
            rt: "ruby"
        },
        li = {
            "text-combine-upright": "-webkit-text-combine:horizontal; text-orientation: mixed;"
        };
    class ParserUtility {
        static parseTimeStamp(e) {
            function computeSeconds(e) {
                const [n, s, d, p] = e.map(e => e ? parseInt("" + e) : 0);
                return 3600 * n + 60 * s + d + p / 1e3
            }
            const n = /^(\d+):(\d{2})(:\d{2})?\.(\d{3})/.exec(e);
            return n ? n[3] ? computeSeconds([n[1], n[2], n[3].substring(1), n[4]]) : parseInt(n[1]) > 59 ? computeSeconds([n[1], n[2], null, n[4]]) : computeSeconds([null, n[1], n[2], n[4]]) : null
        }
        static parseContent(e, n, s) {
            let d = n.text;

            function nextToken() {
                if (!d) return null;
                const e = /^([^<]*)(<[^>]+>?)?/.exec(d);
                return n = e[1] ? e[1] : e[2], d = d.substr(n.length), n;
                var n
            }

            function unescape1(e) {
                return ai[e]
            }

            function unescape(e) {
                return e.replace(/&(amp|lt|gt|lrm|rlm|nbsp);/g, unescape1)
            }

            function shouldAdd(e, n) {
                return !di[n.dataset.localName] || di[n.dataset.localName] === e.dataset.localName
            }

            function createElement(n, d, p) {
                const h = si[n];
                if (!h) return null;
                const y = e.document.createElement(h);
                y.dataset.localName = h;
                const _ = ci[n];
                if (_ && p && (y[_] = p.trim()), d)
                    if (s[d]) {
                        const e = function(e) {
                            let n = "";
                            for (const s in e) n += li[s] ? li[s] : s + ":" + e[s] + ";";
                            return n
                        }(s[d]);
                        y.setAttribute("style", e)
                    } else console.info(`WebVTT: parseContent: Style referenced, but no style defined for '${d}'!`);
                return y
            }
            const p = e.document.createElement("div"),
                h = [];
            let y, _, m = p;
            for (; null !== (y = nextToken());)
                if ("<" !== y[0]) m.appendChild(e.document.createTextNode(unescape(y)));
                else {
                    if ("/" === y[1]) {
                        h.length && h[h.length - 1] === y.substr(2).replace(">", "") && (h.pop(), m = m.parentNode);
                        continue
                    }
                    const n = ParserUtility.parseTimeStamp(y.substr(1, y.length - 2));
                    let s;
                    if (n) {
                        s = e.document.createProcessingInstruction("timestamp", n.toString()), m.appendChild(s);
                        continue
                    }
                    if (_ = /^<([^.\s/0-9>]+)(\.[^\s\\>]+)?([^>\\]+)?(\\?)>?$/.exec(y), !_) continue;
                    if (s = createElement(_[1], _[2], _[3]), !s) continue;
                    if (!shouldAdd(m, s)) continue;
                    _[2], h.push(_[1]), m.appendChild(s), m = s
                }
            return p
        }
    }

    function _define_property$1i(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class VTTCue {
        get id() {
            return this._id
        }
        set id(e) {
            this._id = "" + e
        }
        get pauseOnExit() {
            return this._pauseOnExit
        }
        set pauseOnExit(e) {
            this._pauseOnExit = !!e
        }
        get startTime() {
            return this._startTime
        }
        set startTime(e) {
            if ("number" != typeof e) throw new TypeError("Start time must be set to a number: " + e);
            this._startTime = e, this.hasBeenReset = !0
        }
        get endTime() {
            return this._endTime
        }
        set endTime(e) {
            if ("number" != typeof e) throw new TypeError("End time must be set to a number: " + e);
            this._endTime = e, this.hasBeenReset = !0
        }
        get text() {
            return this._text
        }
        set text(e) {
            this._text = "" + e, this.hasBeenReset = !0
        }
        get region() {
            return this._region
        }
        set region(e) {
            this._region = e, this.hasBeenReset = !0
        }
        get vertical() {
            return this._vertical
        }
        set vertical(e) {
            if (! function(e) {
                    return "string" == typeof e && ["", "rl", "lr"].includes(e)
                }(e)) throw new SyntaxError("An invalid or illegal string was specified for vertical: " + e);
            this._vertical = e, this.hasBeenReset = !0
        }
        get snapToLines() {
            return this._snapToLines
        }
        set snapToLines(e) {
            this._snapToLines = !!e, this.hasBeenReset = !0
        }
        get line() {
            return this._line
        }
        set line(e) {
            if (!isValidLineAndPositionSetting(e)) throw new SyntaxError("An invalid number or illegal string was specified for line: " + e);
            this._line = e, this.hasBeenReset = !0
        }
        get lineAlign() {
            return this._lineAlign
        }
        set lineAlign(e) {
            if (! function(e) {
                    return "string" == typeof e && ["start", "center", "end"].includes(e)
                }(e)) throw new SyntaxError("An invalid or illegal string was specified for lineAlign: " + e);
            this._lineAlign = e, this.hasBeenReset = !0
        }
        get position() {
            return this._position
        }
        set position(e) {
            if (!isValidLineAndPositionSetting(e)) throw new Error("Position must be between 0 and 100 or auto: " + e);
            this._position = e, this.hasBeenReset = !0
        }
        get positionAlign() {
            return this._positionAlign
        }
        set positionAlign(e) {
            if (! function(e) {
                    return "string" == typeof e && ["line-left", "center", "line-right", "auto", "left", "start", "middle", "end", "right"].includes(e)
                }(e)) throw new SyntaxError("An invalid or illegal string was specified for positionAlign: " + e);
            this._positionAlign = e, this.hasBeenReset = !0
        }
        get size() {
            return this._size
        }
        set size(e) {
            if (e < 0 || e > 100) throw new Error("Size must be between 0 and 100: " + e);
            this._size = e, this.hasBeenReset = !0
        }
        get align() {
            return this._align
        }
        set align(e) {
            if (! function(e) {
                    return "string" == typeof e && ["start", "center", "end", "left", "right", "middle"].includes(e)
                }(e)) throw new SyntaxError("An invalid or illegal string was specified for align: " + e);
            this._align = e, this.hasBeenReset = !0
        }
        getCueAsHTML() {
            return ParserUtility.parseContent(window, this, {})
        }
        static create(e) {
            if (!e.hasOwnProperty("startTime") || !e.hasOwnProperty("endTime") || !e.hasOwnProperty("text")) throw new Error("You must at least have start time, end time, and text.");
            const n = new this(e.startTime, e.endTime, e.text);
            return Object.keys(e).forEach(s => {
                n.hasOwnProperty(s) && (n[s] = e[s])
            }), n
        }
        static fromJSON(e) {
            return this.create(JSON.parse(e))
        }
        toJSON() {
            const e = {};
            return Object.keys(this).forEach(n => {
                this.hasOwnProperty(n) && "getCueAsHTML" !== n && "hasBeenReset" !== n && "displayState" !== n && (e[n] = this[n])
            }), e
        }
        constructor(e, n, s) {
            _define_property$1i(this, "_id", ""), _define_property$1i(this, "_startTime", void 0), _define_property$1i(this, "_endTime", void 0), _define_property$1i(this, "_pauseOnExit", !1), _define_property$1i(this, "_region", null), _define_property$1i(this, "_vertical", ""), _define_property$1i(this, "_snapToLines", !0), _define_property$1i(this, "_line", "auto"), _define_property$1i(this, "_lineAlign", "start"), _define_property$1i(this, "_position", "auto"), _define_property$1i(this, "_positionAlign", "auto"), _define_property$1i(this, "_size", 100), _define_property$1i(this, "_align", "center"), _define_property$1i(this, "_text", void 0), _define_property$1i(this, "hasBeenReset", !1), _define_property$1i(this, "displayState", void 0), _define_property$1i(this, "track", void 0), _define_property$1i(this, "axis", void 0), _define_property$1i(this, "onenter", void 0), _define_property$1i(this, "onexit", void 0), _define_property$1i(this, "dispatchEvent", void 0), _define_property$1i(this, "addEventListener", void 0), _define_property$1i(this, "removeEventListener", void 0), this._startTime = e, this._endTime = n, this._text = s
        }
    }

    function _define_property$1h(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    "undefined" != typeof window && null != window.VTTCue && (window.VTTCue.create = VTTCue.create, window.VTTCue.fromJSON = VTTCue.fromJSON, window.VTTCue.prototype.toJSON = VTTCue.prototype.toJSON);
    class VTTRegion {
        get id() {
            return this._id
        }
        set id(e) {
            if ("string" != typeof e) throw new Error("ID must be a string.");
            this._id = e
        }
        get lines() {
            return this._lines
        }
        set lines(e) {
            if ("number" != typeof e) throw new TypeError("Lines must be set to a number.");
            this._lines = e
        }
        get regionAnchorX() {
            return this._regionAnchorX
        }
        set regionAnchorX(e) {
            if (!isValidPercentValue(e)) throw new TypeError("RegionAnchorX must be between 0 and 100.");
            this._regionAnchorX = e
        }
        get regionAnchorY() {
            return this._regionAnchorY
        }
        set regionAnchorY(e) {
            if (!isValidPercentValue(e)) throw new TypeError("RegionAnchorY must be between 0 and 100.");
            this._regionAnchorY = e
        }
        get scroll() {
            return this._scroll
        }
        set scroll(e) {
            if ("string" == typeof e) {
                const n = e.toLowerCase();
                if (function(e) {
                        return ["", "up"].includes(e)
                    }(n)) return void(this._scroll = n)
            }
            throw new SyntaxError("An invalid or illegal string was specified.")
        }
        get viewportAnchorX() {
            return this._viewportAnchorX
        }
        set viewportAnchorX(e) {
            if (!isValidPercentValue(e)) throw new TypeError("ViewportAnchorX must be between 0 and 100.");
            this._viewportAnchorX = e
        }
        get viewportAnchorY() {
            return this._viewportAnchorY
        }
        set viewportAnchorY(e) {
            if (!isValidPercentValue(e)) throw new TypeError("ViewportAnchorY must be between 0 and 100.");
            this._viewportAnchorY = e
        }
        get width() {
            return this._width
        }
        set width(e) {
            if (!isValidPercentValue(e)) throw new TypeError("Width must be between 0 and 100.");
            this._lines = e
        }
        toJSON() {
            const e = {};
            return Object.keys(this).forEach(n => {
                this.hasOwnProperty(n) && (e[n] = this[n])
            }), e
        }
        static create(e) {
            const n = new this;
            return Object.keys(e).forEach(s => {
                n.hasOwnProperty(s) && (n[s] = e[s])
            }), n
        }
        static fromJSON(e) {
            return this.create(JSON.parse(e))
        }
        constructor() {
            _define_property$1h(this, "_id", ""), _define_property$1h(this, "_lines", 3), _define_property$1h(this, "_regionAnchorX", 0), _define_property$1h(this, "_regionAnchorY", 100), _define_property$1h(this, "_scroll", ""), _define_property$1h(this, "_viewportAnchorX", 0), _define_property$1h(this, "_viewportAnchorY", 100), _define_property$1h(this, "_width", 100)
        }
    }

    function _define_property$1g(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    "undefined" != typeof window && null != window.VTTRegion && (window.VTTRegion.create = VTTRegion.create, window.VTTRegion.fromJSON = VTTRegion.fromJSON, window.VTTRegion.prototype.toJSON = VTTRegion.prototype.toJSON);
    class ParsingError extends Error {
        constructor(e, n) {
            super(), _define_property$1g(this, "code", void 0), this.name = "ParsingError", this.code = "number" == typeof e ? e : e.code, n ? this.message = n : e instanceof ParsingError && (this.message = e.message)
        }
    }

    function _define_property$1f(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    _define_property$1g(ParsingError, "Errors", {
        BadSignature: new ParsingError(0, "Malformed WebVTT signature."),
        BadTimeStamp: new ParsingError(1, "Malformed time stamp.")
    });
    const ui = [/^(::cue\()(\..*)(\))/, /^(::cue\()(#.*)(\))/, /^(::cue\()(c|i|b|u|ruby|rt|v|lang)(\))/],
        pi = [
            [1470, 1470],
            [1472, 1472],
            [1475, 1475],
            [1478, 1478],
            [1488, 1514],
            [1520, 1524],
            [1544, 1544],
            [1547, 1547],
            [1549, 1549],
            [1563, 1563],
            [1566, 1610],
            [1645, 1647],
            [1649, 1749],
            [1765, 1766],
            [1774, 1775],
            [1786, 1805],
            [1807, 1808],
            [1810, 1839],
            [1869, 1957],
            [1969, 1969],
            [1984, 2026],
            [2036, 2037],
            [2042, 2042],
            [2048, 2069],
            [2074, 2074],
            [2084, 2084],
            [2088, 2088],
            [2096, 2110],
            [2112, 2136],
            [2142, 2142],
            [2208, 2208],
            [2210, 2220],
            [8207, 8207],
            [64285, 64285],
            [64287, 64296],
            [64298, 64310],
            [64312, 64316],
            [64318, 64318],
            [64320, 64321],
            [64323, 64324],
            [64326, 64449],
            [64467, 64829],
            [64848, 64911],
            [64914, 64967],
            [65008, 65020],
            [65136, 65140],
            [65142, 65276],
            [67584, 67589],
            [67592, 67592],
            [67594, 67637],
            [67639, 67640],
            [67644, 67644],
            [67647, 67669],
            [67671, 67679],
            [67840, 67867],
            [67872, 67897],
            [67903, 67903],
            [67968, 68023],
            [68030, 68031],
            [68096, 68096],
            [68112, 68115],
            [68117, 68119],
            [68121, 68147],
            [68160, 68167],
            [68176, 68184],
            [68192, 68223],
            [68352, 68405],
            [68416, 68437],
            [68440, 68466],
            [68472, 68479],
            [68608, 68680],
            [126464, 126467],
            [126469, 126495],
            [126497, 126498],
            [126500, 126500],
            [126503, 126503],
            [126505, 126514],
            [126516, 126519],
            [126521, 126521],
            [126523, 126523],
            [126530, 126530],
            [126535, 126535],
            [126537, 126537],
            [126539, 126539],
            [126541, 126543],
            [126545, 126546],
            [126548, 126548],
            [126551, 126551],
            [126553, 126553],
            [126555, 126555],
            [126557, 126557],
            [126559, 126559],
            [126561, 126562],
            [126564, 126564],
            [126567, 126570],
            [126572, 126578],
            [126580, 126583],
            [126585, 126588],
            [126590, 126590],
            [126592, 126601],
            [126603, 126619],
            [126625, 126627],
            [126629, 126633],
            [126635, 126651],
            [1114109, 1114109]
        ];
    class StyleBox {
        applyStyles(e, n) {
            n = n || this.div;
            for (const s in e) e.hasOwnProperty(s) && (n.style[s] = e[s])
        }
        formatStyle(e, n) {
            return 0 === e ? "0" : e + n
        }
        constructor() {
            _define_property$1f(this, "div", void 0)
        }
    }
    class CueStyleBox extends StyleBox {
        determineBidi(e) {
            let n, s = [],
                d = "";
            if (!e || !e.childNodes) return "ltr";

            function pushNodes(e, n) {
                for (let s = n.childNodes.length - 1; s >= 0; s--) e.push(n.childNodes[s])
            }

            function nextTextNode(e) {
                if (!e || !e.length) return null;
                let n = e.pop(),
                    s = n.textContent || n.innerText;
                if (s) {
                    const n = /^.*(\n|\r)/.exec(s);
                    return n ? (e.length = 0, n[0]) : s
                }
                return "ruby" === n.tagName ? nextTextNode(e) : n.childNodes ? (pushNodes(e, n), nextTextNode(e)) : void 0
            }

            function isContainedInCharacterList(e, n) {
                for (const s of n)
                    if (e >= s[0] && e <= s[1]) return !0;
                return !1
            }
            for (pushNodes(s, e); d = nextTextNode(s);)
                for (let e = 0; e < d.length; e++)
                    if (n = d.charCodeAt(e), isContainedInCharacterList(n, pi)) return "rtl";
            return "ltr"
        }
        parseOpacity(e) {
            if (!e || "string" != typeof e) return null;
            const n = (e = e.replace(/ /g, "").replace("rgba(", "").replace(")", "")).split(",");
            return n && n.length >= 4 ? n[3] : null
        }
        directionSettingToWritingMode(e) {
            return "" === e ? "horizontal-tb" : "lr" === e ? "vertical-lr" : "vertical-rl"
        }
        move(e) {
            this.applyStyles({
                top: this.formatStyle(e.top, "px"),
                bottom: this.formatStyle(e.bottom, "px"),
                left: this.formatStyle(e.left, "px"),
                right: this.formatStyle(e.right, "px"),
                height: this.formatStyle(e.height, "px"),
                width: this.formatStyle(e.width, "px")
            })
        }
        constructor(e, n, s, d, p) {
            super(), _define_property$1f(this, "cue", void 0), _define_property$1f(this, "backgroundDiv", void 0), _define_property$1f(this, "cueDiv", void 0), this.cue = n;
            let h = {
                textAlign: {
                    start: "left",
                    "line-left": "left",
                    left: "left",
                    center: "center",
                    middle: "center",
                    "line-right": "right",
                    right: "right",
                    end: "right"
                }[n.positionAlign] || n.align,
                whiteSpace: "pre-line",
                position: "absolute"
            };
            h.direction = this.determineBidi(this.cueDiv), h.writingMode = this.directionSettingToWritingMode(n.vertical), h.unicodeBidi = "plaintext", this.div = e.document.createElement("div"), this.applyStyles(h), h = {
                backgroundColor: d.backgroundColor,
                display: "inline-block"
            }, this.parseOpacity(h.backgroundColor) && (h.padding = "5px", h.borderRadius = "5px"), this.backgroundDiv = e.document.createElement("div"), this.applyStyles(h, this.backgroundDiv), h = {
                color: s.color,
                backgroundColor: s.backgroundColor,
                textShadow: s.textShadow,
                fontSize: s.fontSize,
                fontFamily: s.fontFamily,
                position: "relative",
                left: "0",
                right: "0",
                top: "0",
                bottom: "0",
                display: "inline-block",
                textOrientation: "upright"
            }, h.writingMode = this.directionSettingToWritingMode(n.vertical), h.unicodeBidi = "plaintext", this.cueDiv = ParserUtility.parseContent(e, n, p), this.applyStyles(h, this.cueDiv), this.backgroundDiv.appendChild(this.cueDiv), this.div.appendChild(this.backgroundDiv);
            let y = 0;
            if ("number" == typeof n.position) {
                let e = n.positionAlign || n.align;
                if (e) switch (e) {
                    case "start":
                    case "left":
                        y = n.position;
                        break;
                    case "center":
                    case "middle":
                        y = n.position - n.size / 2;
                        break;
                    case "end":
                    case "right":
                        y = n.position - n.size
                }
            }
            "" === n.vertical ? this.applyStyles({
                left: this.formatStyle(y, "%"),
                width: this.formatStyle(n.size, "%")
            }) : this.applyStyles({
                top: this.formatStyle(y, "%"),
                height: this.formatStyle(n.size, "%")
            })
        }
    }
    class BoxPosition {
        calculateNewLines(e) {
            let n = 1;
            for (let s = 0; s < e.length; s++) "\n" === e[s] && n++;
            return n
        }
        move(e, n) {
            switch (n = void 0 !== n ? n : this.singleLineHeight, e) {
                case "+x":
                    this.left += n, this.right += n;
                    break;
                case "-x":
                    this.left -= n, this.right -= n;
                    break;
                case "+y":
                    this.top += n, this.bottom += n;
                    break;
                case "-y":
                    this.top -= n, this.bottom -= n
            }
        }
        overlaps(e) {
            return this.left < e.right && this.right > e.left && this.top < e.bottom && this.bottom > e.top
        }
        overlapsAny(e) {
            for (const n of e)
                if (this.overlaps(n)) return !0;
            return !1
        }
        within(e) {
            return this.top >= e.top && this.bottom <= e.bottom && this.left >= e.left && this.right <= e.right
        }
        moveIfOutOfBounds(e, n) {
            switch (n) {
                case "+x":
                    this.left < e.left && (this.left = e.left, this.right = this.left + this.width);
                    break;
                case "-x":
                    this.right > e.right && (this.right = e.right, this.left = this.right - this.width);
                    break;
                case "+y":
                    this.top < e.top && (this.top = e.top, this.bottom = this.top + this.height);
                    break;
                case "-y":
                    this.bottom > e.bottom && (this.bottom = e.bottom, this.top = this.bottom - this.height)
            }
        }
        toCSSCompatValues(e) {
            return {
                top: this.top - e.top,
                bottom: e.bottom - this.bottom,
                left: this.left - e.left,
                right: e.right - this.right,
                height: this.height,
                width: this.width
            }
        }
        static getSimpleBoxPosition(e) {
            let n = null;
            e instanceof StyleBox && e.div ? n = e.div : e instanceof HTMLElement && (n = e);
            let s = n.offsetHeight || 0,
                d = n.offsetWidth || 0,
                p = n.offsetTop || 0,
                h = p + s,
                y = n.getBoundingClientRect();
            const {
                left: _,
                right: m
            } = y;
            return y.top && (p = y.top), y.height && (s = y.height), y.width && (d = y.width), y.bottom && (h = y.bottom), {
                left: _,
                right: m,
                top: p,
                height: s,
                bottom: h,
                width: d
            }
        }
        static getBoxPosition(e, n) {
            if (e && e.length > 0) {
                let s = 0,
                    d = e[0][n];
                for (let p = 0; p < e.length; p++) n in ["top", "right"] ? e[p][n] > d && (s = p, d = e[p][n]) : n in ["bottom", "left"] && e[p][n] < d && (s = p, d = e[p][n]);
                return e[s]
            }
            return null
        }
        static moveToMinimumDistancePlacement(e, n, s) {
            "height" === e.property ? "+y" === n ? (e.top = s.topMostBoxPosition.bottom + 0, e.bottom = e.top + e.height) : "-y" === n && (e.bottom = s.bottomMostBoxPosition.top - 0, e.top = e.bottom - e.height) : "width" === e.property && ("+x" === n ? (e.left = s.rightMostBoxPosition.right + 0, e.right = e.left + e.width) : "-x" === n && (e.right = s.leftMostBoxPosition.left - 0, e.left = e.right - e.width))
        }
        static moveBoxToLinePosition(e, n, s) {
            const d = e.cue;
            let p, h = new BoxPosition(e),
                y = function(e) {
                    if ("number" == typeof e.line && (e.snapToLines || e.line >= 0 && e.line <= 100)) return e.line;
                    if (!e.track || !e.track.textTrackList || !e.track.textTrackList.mediaElement) return -1;
                    let n = 0;
                    const s = e.track,
                        d = s.textTrackList;
                    for (let p = 0; p < d.length && d[p] !== s; p++) "showing" === d[p].mode && n++;
                    return -1 * ++n
                }(d),
                _ = [];
            if (d.snapToLines) {
                let e = 0;
                switch (d.vertical) {
                    case "":
                        _ = ["+y", "-y"], p = "height";
                        break;
                    case "rl":
                        _ = ["+x", "-x"], p = "width";
                        break;
                    case "lr":
                        _ = ["-x", "+x"], p = "width"
                }
                const s = h.lineHeight,
                    m = n[p] + s,
                    v = _[0];
                if (y < 0) {
                    let p = 0;
                    switch (d.vertical) {
                        case "":
                            p = n.height - s - .05 * n.height;
                            break;
                        case "rl":
                        case "lr":
                            p = -n.width + s + .05 * n.width
                    }
                    e = p, _ = _.reverse()
                } else {
                    switch (d.vertical) {
                        case "":
                            e = s * Math.round(y);
                            break;
                        case "rl":
                            e = n.width - s * Math.round(y);
                            break;
                        case "lr":
                            e = s * Math.round(y)
                    }
                    Math.abs(e) > m && (e = e < 0 ? -1 : 1, e *= Math.ceil(m / s) * s)
                }
                h.move(v, e)
            } else {
                const s = "" === d.vertical ? n.height : n.width,
                    p = h.lineHeight / s * 100;
                switch (d.lineAlign) {
                    case "center":
                        y -= p / 2;
                        break;
                    case "end":
                        y -= p
                }
                switch (d.vertical) {
                    case "":
                        e.applyStyles({
                            top: e.formatStyle(y, "%")
                        });
                        break;
                    case "rl":
                        e.applyStyles({
                            right: e.formatStyle(y, "%")
                        });
                        break;
                    case "lr":
                        e.applyStyles({
                            left: e.formatStyle(y, "%")
                        })
                }
                _ = ["+y", "-y", "+x", "-x"], "+y" === d.axis ? _ = ["+y", "-y", "+x", "-x"] : "-y" === d.axis && (_ = ["-y", "+y", "+x", "-x"]), h = new BoxPosition(e)
            }
            const m = function(e, d) {
                let p;
                for (let h = 0; h < d.length; h++) {
                    e.moveIfOutOfBounds(n, d[h]);
                    let y = 0,
                        _ = !1;
                    for (; e.overlapsAny(s) && !(y > 9);) _ ? e.move(d[h]) : (s && s.length > 0 && (p || (p = {
                        topMostBoxPosition: BoxPosition.getBoxPosition(s, "top"),
                        bottomMostBoxPosition: BoxPosition.getBoxPosition(s, "bottom"),
                        leftMostBoxPosition: BoxPosition.getBoxPosition(s, "left"),
                        rightMostBoxPosition: BoxPosition.getBoxPosition(s, "right")
                    }), BoxPosition.moveToMinimumDistancePlacement(e, d[h], p)), _ = !0), y++
                }
                return e
            }(h, _);
            e.move(m.toCSSCompatValues(n))
        }
        constructor(e) {
            var n;
            let s, d, p, h, y, _;
            if (_define_property$1f(this, "left", void 0), _define_property$1f(this, "right", void 0), _define_property$1f(this, "top", void 0), _define_property$1f(this, "height", void 0), _define_property$1f(this, "bottom", void 0), _define_property$1f(this, "width", void 0), _define_property$1f(this, "lineHeight", void 0), _define_property$1f(this, "singleLineHeight", void 0), _define_property$1f(this, "property", void 0), e instanceof CueStyleBox && e.cue ? (n = e.cue) && "" !== n.vertical ? this.property = "width" : this.property = "height" : e instanceof BoxPosition && (this.property = e.property || "height"), e instanceof CueStyleBox && e.div) {
                p = e.div.offsetHeight, h = e.div.offsetWidth, y = e.div.offsetTop;
                const n = e.div.firstChild;
                if (_ = n ? n.getBoundingClientRect() : e.div.getBoundingClientRect(), s = _ && _[this.property] || null, n && n.firstChild) {
                    const e = n.firstChild;
                    if (e && "string" == typeof e.textContent) {
                        d = s / this.calculateNewLines(e.textContent)
                    }
                }
            } else e instanceof BoxPosition && (_ = e);
            this.left = _.left, this.right = _.right, this.top = _.top || y, this.height = _.height || p, this.bottom = _.bottom || y + (_.height || p), this.width = _.width || h, this.lineHeight = null !== s ? s : _.lineHeight, this.singleLineHeight = null !== d ? d : _.singleLineHeight, this.singleLineHeight || (this.singleLineHeight = 41)
        }
    }
    class WebVTTRenderer {
        initSubtitleCSS() {
            const e = [new VTTCue(0, 0, "String to init CSS - Won't be visible to user")];
            this.paddedOverlay.style.opacity = "0", this.processCues(e), this.processCues([]), this.paddedOverlay.style.opacity = "1"
        }
        convertCueToDOMTree(e) {
            return e ? ParserUtility.parseContent(this.window, e, this.globalStyleCollection) : null
        }
        setStyles(e) {
            function applyStyles(e, n, s) {
                for (const d in n) n.hasOwnProperty(d) && (!0 === s && void 0 !== e[d] || !1 === s) && (e[d] = n[d])
            }
            for (const n in e) {
                let s = !1,
                    d = null;
                "::cue" === n ? (d = this.foregroundStyleOptions, s = !0) : "::-webkit-media-text-track-display" === n && (d = this.backgroundStyleOptions, s = !0);
                const p = e[n];
                if (!0 === s) applyStyles(d, p, s);
                else
                    for (let e = 0; e < ui.length; e++) {
                        const d = ui[e].exec(n);
                        if (d && 4 === d.length) {
                            const e = d[2],
                                n = {};
                            applyStyles(n, p, s), this.globalStyleCollection[e] = n
                        }
                    }
            }
            this.initSubtitleCSS(), this.loggingEnabled && (console.log("WebVTTRenderer setStyles foregroundStyleOptions: " + JSON.stringify(this.foregroundStyleOptions)), console.log("WebVTTRenderer setStyles backgroundStyleOptions: " + JSON.stringify(this.backgroundStyleOptions)), console.log("WebVTTRenderer setStyles globalStyleCollection: " + JSON.stringify(this.globalStyleCollection)))
        }
        processCues(e) {
            if (!e) return;
            for (; this.paddedOverlay.firstChild;) this.paddedOverlay.removeChild(this.paddedOverlay.firstChild);
            if (! function(e) {
                    for (let n = 0; n < e.length; n++)
                        if (e[n].hasBeenReset || !e[n].displayState) return !0;
                    return !1
                }(e)) {
                for (let n = 0; n < e.length; n++) this.paddedOverlay.appendChild(e[n].displayState);
                return
            }
            const n = [],
                s = BoxPosition.getSimpleBoxPosition(this.paddedOverlay);
            e.length > 1 && (e = function(e) {
                const n = [];
                let s = 0;
                for (let d = 0; d < e.length; d++) {
                    let p = e[d];
                    if ("number" != typeof p.line) return e;
                    s += p.line, n.push(p)
                }
                return s /= e.length, s > 50 ? (n.forEach((function(e) {
                    e.axis = "-y"
                })), n.sort((e, n) => n.line - e.line)) : (n.forEach((function(e) {
                    e.axis = "+y"
                })), n.sort((e, n) => e.line - n.line)), n
            }(e));
            for (let d = 0; d < e.length; d++) {
                let p = e[d],
                    h = new CueStyleBox(this.window, p, this.foregroundStyleOptions, this.backgroundStyleOptions, this.globalStyleCollection);
                this.paddedOverlay.appendChild(h.div), BoxPosition.moveBoxToLinePosition(h, s, n), p.displayState = h.div, n.push(BoxPosition.getSimpleBoxPosition(h))
            }
        }
        setSize(e, n) {
            e && (this.overlay.style.width = e + "px"), n && (this.overlay.style.height = n + "px")
        }
        getOverlay() {
            return this.overlay
        }
        constructor(e, n, s = !0) {
            if (_define_property$1f(this, "window", void 0), _define_property$1f(this, "overlay", void 0), _define_property$1f(this, "loggingEnabled", void 0), _define_property$1f(this, "foregroundStyleOptions", void 0), _define_property$1f(this, "backgroundStyleOptions", void 0), _define_property$1f(this, "globalStyleCollection", void 0), _define_property$1f(this, "paddedOverlay", void 0), !e) return null;
            this.window = e, this.overlay = n, this.loggingEnabled = s, this.foregroundStyleOptions = {
                fontFamily: "Helvetica",
                fontSize: "36px",
                color: "rgba(255, 255, 255, 1)",
                textShadow: "",
                backgroundColor: "rgba(0, 0, 0, 0)"
            }, this.backgroundStyleOptions = {
                backgroundColor: "rgba(0, 0, 0, 0.5)"
            }, this.globalStyleCollection = {};
            const d = e.document.createElement("div");
            d.style.position = "absolute", d.style.left = "0", d.style.right = "0", d.style.top = "0", d.style.bottom = "0", d.style.margin = "1.5%", this.paddedOverlay = d, n.appendChild(this.paddedOverlay), this.initSubtitleCSS()
        }
    }

    function isTextTrackID3FrameCue(e) {
        return null != e && "string" == typeof e.id && void 0 !== e.value && "string" == typeof e.value.key
    }

    function _define_property$1e(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    _define_property$1f(WebVTTRenderer, "__brand__", "@amp/vtt.js");
    const {
        textTracksSwitched: hi,
        textTracksUpdated: yi,
        inlineStylesParsed: _i
    } = Ye;
    class TextTrackManager {
        get isDestroyed() {
            return this._isDestroyed
        }
        get currentTrack() {
            return this.tracks.find(e => "showing" === e.mode)
        }
        set currentTrack(e) {
            if (!e) return;
            let n;
            saveTrack("mk-text-track", e), xe.debug(`MEDIA_TRACK save track selection ${e.language},${e.label},${e.kind}`), this.extensionTracks ? (xe.debug("MEDIA_TRACK Setting track on extension " + e.label), "Off" === e.label ? (this.clearCurrentlyPlayingTrack(), n = this.extensionTracks.selectForcedTrack(), void 0 === n && this.onExtensionTextTrackSwitched({
                track: e
            })) : this.extensionTracks.textTrack = e) : (xe.debug("MEDIA_TRACK Setting track on element " + e.label), this._tracks.forEach(n => {
                n !== e && "showing" === n.mode && (n.mode = "disabled")
            }), e && (xe.debug("MEDIA_TRACK setting track mode to showing for " + e.label), this.isTrackOff(e) ? (this._tracks[0].mode = "showing", n = this.selectNativeForcedTrack(this.mediaElement.audioTracks)) : e.mode = "showing")), this.dispatcher.publish(st.forcedTextTrackChanged, n)
        }
        get tracks() {
            return this._tracks
        }
        destroy() {
            if (this._isDestroyed = !0, this.clearCurrentlyPlayingTrack(), this.extensionTracks) {
                const e = this.extensionTracks;
                e.removeEventListener(yi, this.onExtensionTextTracksAdded), e.removeEventListener(hi, this.onExtensionTextTrackSwitched), e.removeEventListener(_i, this.onExtensionInlineStylesParsed)
            } else this.mediaElement.textTracks.removeEventListener("addtrack", this.onTextTrackAdded), this.mediaElement.textTracks.removeEventListener("change", this.onTextTrackChanged), this.mediaElement.textTracks.removeEventListener("removetrack", this.onTextTrackRemoved), this.mediaElement.removeEventListener("playing", this.onPlayStart);
            this.dispatcher.unsubscribe(st.audioTrackChanged, this.onAudioTrackAddedOrChanged), this.dispatcher.unsubscribe(st.audioTrackAdded, this.onAudioTrackAddedOrChanged)
        }
        restoreSelectedTrack() {
            var e;
            const n = loadTrack("mk-text-track");
            if ((null === (e = this.tracks) || void 0 === e ? void 0 : e.length) >= 0 && void 0 !== n && (void 0 === this.currentTrack || !trackEquals(this.currentTrack, n)))
                for (const s of this.tracks)
                    if (trackEquals(s, n)) {
                        xe.debug("Found track matching persisted track: " + s.label), this.currentTrack = s;
                        break
                    }
        }
        getSavedTrack() {
            return loadTrack("mk-text-track")
        }
        onExtensionInlineStylesParsed(e) {
            xe.debug("MEDIA_TRACK Extension inline styles parsed", e), this.renderer.setStyles(e.styles)
        }
        onExtensionTextTracksAdded(e) {
            xe.debug("MEDIA_TRACK Extension text tracks updated " + JSON.stringify(e)), this._tracks.push(...e), this.restoreSelectedTrack(), this.dispatcher.publish(st.textTrackAdded, e)
        }
        onExtensionTextTrackSwitched(e) {
            xe.debug("MEDIA_TRACKS Extension text track switched " + e), this.handleVTT(e);
            const n = e.track;
            if (this._tracks) {
                const preserveSelectedTrack = s => {
                    e.track ? n.forced && "Off" === s.label || "Off" === n.label && "Off" === s.label ? s.mode = "showing" : s.mode = e.track.persistentID === s.id ? "showing" : "disabled" : s.mode = "Off" === s.label ? "showing" : "disabled"
                };
                this._tracks.forEach(preserveSelectedTrack)
            }
            this.dispatcher.publish(st.textTrackChanged, e)
        }
        handleVTT(e) {
            const n = e && e.track && e.track.id;
            if (void 0 !== n && n >= 0) {
                const e = this.filterSelectableTextTracks(this.mediaElement.textTracks)[n];
                this.onNativeTrackChange(e)
            } else this.clearCurrentlyPlayingTrack()
        }
        onAudioTrackAddedOrChanged(e, n) {
            if (xe.debug("MEDIA_TRACKS text track manager detects audio track change"), this.shouldForceSubtitle())
                if (this.extensionTracks) {
                    xe.debug("MEDIA_TRACKS selecting forced text track via extension");
                    const e = this.extensionTracks.selectForcedTrack();
                    e ? this.dispatcher.publish(st.forcedTextTrackChanged, e) : this.clearCurrentlyPlayingTrack()
                } else xe.debug("MEDIA_TRACKS selecting forced text track natively"), this.currentTrack = this._tracks[0]
        }
        onTextTrackAdded(e) {
            this._tracks.push(e.track), this.dispatcher.publish(st.textTrackAdded, e)
        }
        onPlayStart() {
            this.restoreSelectedTrack()
        }
        onTextTrackRemoved(e) {
            this.dispatcher.publish(st.textTrackRemoved, e)
        }
        onTextTrackChanged(e) {
            const n = this.findNativeSelectedTextTrack();
            let s = this.getSavedTrack();
            if (s || (s = this._tracks[0]), n && !trackEquals(n, s))
                if (this.isTrackOff(s) && "forced" !== n.kind) {
                    const e = this.tracks.find(e => trackEquals(e, s));
                    this.currentTrack = e
                } else {
                    const e = this.findNativeTrack(s);
                    e && (this.currentTrack = e)
                }
            else this.dispatcher.publish(st.textTrackChanged, e)
        }
        findNativeSelectedTextTrack() {
            for (let e = 0; e < this.mediaElement.textTracks.length; e++) {
                const n = this.mediaElement.textTracks[e];
                if ("showing" === n.mode) return n
            }
        }
        findNativeTrack(e) {
            for (let n = 0; n < this.mediaElement.textTracks.length; n++) {
                const s = this.mediaElement.textTracks[n];
                if (trackEquals(s, e)) return s
            }
        }
        selectNativeForcedTrack(e) {
            for (let n = 0; n < e.length; n++) {
                const s = e[n];
                if (s.enabled) {
                    const e = this.findNativeForcedTrack(s);
                    return e && "showing" !== e.mode && (e.mode = "showing"), e
                }
            }
        }
        findNativeForcedTrack(e) {
            const n = this.mediaElement.textTracks;
            for (let s = 0; s < n.length; s++) {
                const d = n[s];
                if ("forced" === d.kind && d.language === e.language) return d
            }
        }
        onNativeTrackChange(e) {
            this.clearCurrentlyPlayingTrack(), this._currentlyPlayingTrack = e, e.addEventListener("cuechange", this.onCueChange)
        }
        clearCurrentlyPlayingTrack() {
            void 0 !== this._currentlyPlayingTrack && function(e) {
                return null != e && "string" == typeof e.id && "removeEventListener" in e
            }(this._currentlyPlayingTrack) && (this._currentlyPlayingTrack.removeEventListener("cuechange", this.onCueChange), this.renderer.processCues({}), delete this._currentlyPlayingTrack)
        }
        onCueChange(e) {
            const n = e && e.target && e.target.activeCues;
            n && this.renderer.processCues(n)
        }
        filterSelectableTextTracks(e) {
            const n = [];
            for (let s = 0; s < e.length; s++) {
                const d = e[s];
                ("captions" === d.kind || "subtitles" === d.kind || "metadata" === d.kind && d.customTextTrackCueRenderer) && n.push(d)
            }
            return n
        }
        shouldForceSubtitle() {
            xe.debug("MEDIA_TRACKS Determining whether to select forced text track");
            const e = this.getSavedTrack();
            return !e || this.isTrackOff(e)
        }
        isTrackOff(e) {
            return "Off" === e.label || "Auto" === e.label
        }
        constructor(e, n, s) {
            _define_property$1e(this, "mediaElement", void 0), _define_property$1e(this, "dispatcher", void 0), _define_property$1e(this, "extensionTracks", void 0), _define_property$1e(this, "_tracks", void 0), _define_property$1e(this, "renderer", void 0), _define_property$1e(this, "_currentlyPlayingTrack", void 0), _define_property$1e(this, "_isDestroyed", void 0), this.mediaElement = e, this.dispatcher = n, this.extensionTracks = s, this._tracks = [], this._isDestroyed = !1;
            const d = this.getSavedTrack();
            if (this._tracks.push({
                    id: -2,
                    label: "Off",
                    language: "",
                    kind: "subtitles",
                    mode: !d || this.isTrackOff(d) ? "showing" : "disabled"
                }), this.extensionTracks) {
                xe.debug("MEDIA_TRACK Initializing text track manager for HLS.js track events");
                const n = e.parentElement;
                this.renderer = new WebVTTRenderer(window, n, !1), this.renderer.setStyles({
                    "::cue": {
                        fontSize: "calc(1vw + 1em)"
                    }
                }), this.onExtensionTextTracksAdded = this.onExtensionTextTracksAdded.bind(this), this.onExtensionTextTrackSwitched = this.onExtensionTextTrackSwitched.bind(this), this.onExtensionInlineStylesParsed = this.onExtensionInlineStylesParsed.bind(this), this.onCueChange = this.onCueChange.bind(this);
                const s = this.extensionTracks;
                s.addEventListener(yi, this.onExtensionTextTracksAdded), s.addEventListener(hi, this.onExtensionTextTrackSwitched), s.addEventListener(_i, this.onExtensionInlineStylesParsed)
            } else xe.debug("MEDIA_TRACK Initializing text track manager for native track events"), this.onTextTrackAdded = this.onTextTrackAdded.bind(this), this.onTextTrackChanged = this.onTextTrackChanged.bind(this), this.onTextTrackRemoved = this.onTextTrackRemoved.bind(this), this.onPlayStart = this.onPlayStart.bind(this), e.textTracks.addEventListener("addtrack", this.onTextTrackAdded), e.textTracks.addEventListener("change", this.onTextTrackChanged), e.textTracks.addEventListener("removetrack", this.onTextTrackRemoved), e.addEventListener("playing", this.onPlayStart);
            this.onAudioTrackAddedOrChanged = debounce(this.onAudioTrackAddedOrChanged.bind(this)), n.subscribe(st.audioTrackChanged, this.onAudioTrackAddedOrChanged), n.subscribe(st.audioTrackAdded, this.onAudioTrackAddedOrChanged)
        }
    }

    function asyncGeneratorStep$R(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$R(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$R(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$R(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1d(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_metadata$m(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    const fi = {
            "picture-in-picture": e.PresentationMode.pictureinpicture,
            inline: e.PresentationMode.inline
        },
        mi = {};
    mi[e.PresentationMode.pictureinpicture] = "picture-in-picture", mi[e.PresentationMode.inline] = "inline";
    const {
        presentationModeDidChange: vi
    } = st, {
        playbackLicenseError: gi
    } = Ye, {
        stopped: bi
    } = e.PlaybackStates;
    class VideoPlayer extends BasePlayer {
        get audioTracks() {
            var e, n;
            return null !== (n = null === (e = this.audioTrackManager) || void 0 === e ? void 0 : e.tracks) && void 0 !== n ? n : []
        }
        get containerElement() {
            return this._context.videoContainerElement ? this._context.videoContainerElement : document.getElementById("apple-music-video-container")
        }
        get currentAudioTrack() {
            var e;
            return null === (e = this.audioTrackManager) || void 0 === e ? void 0 : e.currentTrack
        }
        set currentAudioTrack(e) {
            void 0 !== this.audioTrackManager && (this.audioTrackManager.currentTrack = e)
        }
        get currentTextTrack() {
            var e;
            return null === (e = this.textTrackManager) || void 0 === e ? void 0 : e.currentTrack
        }
        set currentTextTrack(e) {
            void 0 !== this.textTrackManager && (this.textTrackManager.currentTrack = e)
        }
        get _targetElement() {
            return this.video || function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$1d(e, n, s[n])
                    }))
                }
                return e
            }({}, document.createElement("video"))
        }
        get textTracks() {
            var e, n;
            return null !== (n = null === (e = this.textTrackManager) || void 0 === e ? void 0 : e.tracks) && void 0 !== n ? n : []
        }
        initializeExtension() {
            var e = this;
            return _async_to_generator$R((function*() {
                const {
                    os: n
                } = e.services.runtime;
                e.restrictPlatforms && n.isAndroid ? xe.warn("videoPlayer.initializeExtension Not supported on the current platform") : e.video || xe.warn("videoPlayer.initializeExtension No video element, not initializing extension")
            }))()
        }
        onPlaybackLicenseError(e) {
            this.resetDeferredPlay(), this._dispatcher.publish(gi, e)
        }
        setupTrackManagers(e) {
            var n, s, d, p;
            null === (s = this.textTrackManager) || void 0 === s || null === (n = s.destroy) || void 0 === n || n.call(s), this.textTrackManager = new TextTrackManager(this._targetElement, this._dispatcher, e), null === (p = this.audioTrackManager) || void 0 === p || null === (d = p.destroy) || void 0 === d || d.call(p), this.audioTrackManager = new AudioTrackManager(this._targetElement, this._dispatcher, e)
        }
        destroy() {
            var e, n;
            this.finishPlaybackSequence(), null === (e = this.textTrackManager) || void 0 === e || e.destroy(), null === (n = this.audioTrackManager) || void 0 === n || n.destroy(), super.destroy()
        }
        initializeEventHandlers() {
            var e = this,
                _superprop_get_initializeEventHandlers = () => super.initializeEventHandlers;
            return _async_to_generator$R((function*() {
                _superprop_get_initializeEventHandlers().call(e), e.hasMediaElement && (e._targetElement.addEventListener("webkitpresentationmodechanged", e.pipEventHandler), e._targetElement.addEventListener("enterpictureinpicture", e.pipEventHandler), e._targetElement.addEventListener("leavepictureinpicture", e.pipEventHandler))
            }))()
        }
        removeEventHandlers() {
            if (super.removeEventHandlers(), !this.hasMediaElement) return;
            const {
                _targetElement: e
            } = this;
            e.removeEventListener("webkitpresentationmodechanged", this.pipEventHandler), e.removeEventListener("enterpictureinpicture", this.pipEventHandler), e.removeEventListener("leavepictureinpicture", this.pipEventHandler)
        }
        initializeMediaElement() {
            var e = this;
            return _async_to_generator$R((function*() {
                xe.debug("videoPlayer.initializeMediaElement Initializing media element");
                const n = e.containerElement;
                n ? (e.video = function() {
                    let e = ii.pop();
                    return e ? xe.debug(`dom-helpers: retrieving video tag, ${ii.length} remain`) : (xe.debug("dom-helpers: no available video tags, creating one"), e = document.createElement("video")), e
                }(), e.video.autoplay = !1, e.video.controls = !1, e.video.playsInline = !0, e.video.id = "apple-music-video-player", n.appendChild(e.video)) : xe.warn("videoPlayer.initializeMediaElement No video element; no container defined")
            }))()
        }
        stopMediaElement() {
            var e = this,
                _superprop_get_stopMediaElement = () => super.stopMediaElement;
            return _async_to_generator$R((function*() {
                yield _superprop_get_stopMediaElement().call(e), e.destroy()
            }))()
        }
        pipEventHandler(n) {
            switch (n.type) {
                case "enterpictureinpicture":
                    this._dispatcher.publish(vi, {
                        mode: e.PresentationMode.pictureinpicture
                    });
                    break;
                case "leavepictureinpicture":
                    this._dispatcher.publish(vi, {
                        mode: e.PresentationMode.inline
                    });
                    break;
                case "webkitpresentationmodechanged":
                    {
                        const e = this._targetElement;this._dispatcher.publish(vi, {
                            mode: this._translateStringToPresentationMode(e.webkitPresentationMode)
                        });
                        break
                    }
            }
        }
        playItemFromEncryptedSource(n, s = !1, d = {}) {
            var p = this;
            return _async_to_generator$R((function*() {
                if (xe.debug("videoPlayer.playItemFromEncryptedSource", n, s), p.playbackState === bi) return void xe.debug("video-player.playItemFromEncryptedSource aborting playback because player is stopped");
                n.playbackType = e.PlaybackType.encryptedFull, p.nowPlayingItem = n, n.state = ee.loading, p.userInitiated = s;
                const h = generateAssetUrl(n, d);
                yield p.playHlsStream(h, n, d)
            }))()
        }
        playItemFromUnencryptedSource(e, n, s) {
            var d = this;
            return _async_to_generator$R((function*() {
                if (xe.debug("videoPlayer.playItemFromUnencryptedSource", e, n), d.playbackState === bi) return void xe.debug("videoPlayer.playItemFromUnencryptedSource aborting playback because player is stopped");
                const [s] = e.split("?");
                s.endsWith("m3u") || s.endsWith("m3u8") ? yield d.playHlsStream(e): yield d._playAssetURL(e, n)
            }))()
        }
        setPresentationMode(n) {
            var s = this;
            return _async_to_generator$R((function*() {
                const d = s._targetElement;
                if (d.webkitSupportsPresentationMode && "function" == typeof d.webkitSetPresentationMode) return d.webkitSetPresentationMode(s._translatePresentationModeToString(n));
                if (d.requestPictureInPicture && document.exitPictureInPicture) {
                    if (n === e.PresentationMode.pictureinpicture) return d.requestPictureInPicture();
                    if (n === e.PresentationMode.inline) return document.exitPictureInPicture()
                }
            }))()
        }
        _translateStringToPresentationMode(n) {
            let s = fi[n];
            return void 0 === s && (xe.warn(`videoPlayer._translateStringToPresentationMode ${n} is not a valid presentation mode, setting to inline`), s = e.PresentationMode.inline), s
        }
        _translatePresentationModeToString(e) {
            let n = mi[e];
            return void 0 === n && (xe.warn(`videoPlayer._translatePresentationModeToString ${e} is not a valid presentation mode, setting to inline`), n = "inline"), n
        }
        preloadItem(e, n) {
            return _async_to_generator$R((function*() {}))()
        }
        constructor(e) {
            super(e), _define_property$1d(this, "extension", void 0), _define_property$1d(this, "video", void 0), _define_property$1d(this, "mediaPlayerType", "video"), _define_property$1d(this, "restrictPlatforms", void 0), _define_property$1d(this, "textTrackManager", void 0), _define_property$1d(this, "audioTrackManager", void 0), _define_property$1d(this, "_shouldLoadManifestsOnce", !1), _define_property$1d(this, "userInitiated", !1), this.restrictPlatforms = !("restrict-platforms" in qe.features) || qe.features["restrict-platforms"], this.pipEventHandler = this.pipEventHandler.bind(this), this._shouldLoadManifestsOnce = shouldLoadManifestOnce()
        }
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$m("design:type", Function), _ts_metadata$m("design:paramtypes", [void 0]), _ts_metadata$m("design:returntype", void 0)], VideoPlayer.prototype, "onPlaybackLicenseError", null);
    const decayingOperation = (e, n, s, d = 0) => e().catch(p => {
        const h = d + 1;

        function possiblyRetry(d) {
            if (d && h < 3) {
                const d = 1e3 * h;
                return new Promise((p, y) => {
                    setTimeout(() => {
                        decayingOperation(e, n, s, h).then(p, y)
                    }, d)
                })
            }
            throw p
        }
        const y = n(p);
        return "boolean" == typeof y ? possiblyRetry(y) : y.then(possiblyRetry)
    });
    let Si = {
        developerToken: "developerTokenNotSet",
        musicUserToken: "musicUserTokenNotSet",
        cid: "cidNotSet"
    };

    function asyncGeneratorStep$Q(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$Q(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$Q(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$Q(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1c(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$u(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1c(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$j(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function createHlsOffersLicenseChallengeBody(e) {
        return {
            "adam-id": e.id,
            id: 1
        }
    }

    function createStreamingKeysLicenseChallengeBody(e, n, s = 0) {
        var d;
        return _object_spread$u({
            id: s,
            "lease-action": n
        }, null !== (d = e.keyServerQueryParameters) && void 0 !== d ? d : {})
    }

    function createLicenseChallengeBody(e, n, s) {
        let d, p = {
            challenge: s.challenge || j(s.licenseChallenge),
            uri: s.keyuri,
            "key-system": s.keySystem,
            stkn: s.slotToken
        };
        return s.extendedLease && (p["extended-lease"] = s.extendedLease), p = function(e, n) {
            const s = {};
            for (const d of n) d in e && void 0 !== e[d] && (s[d] = e[d]);
            return s
        }(p, Object.keys(p)), d = n.isUTS ? {
            "streaming-request": {
                version: 1,
                "streaming-keys": [_object_spread$u({}, p, createStreamingKeysLicenseChallengeBody(n, e))]
            }
        } : n.isLiveRadioStation ? _object_spread$u({}, p, function(e) {
            return {
                event: e.isLiveAudioStation ? "beats1" : "amtv"
            }
        }(n)) : n.hasOffersHlsUrl ? {
            "license-requests": [_object_spread$u({}, p, createHlsOffersLicenseChallengeBody(n))]
        } : _object_spread$u({}, p, function(e, n = !1) {
            return {
                adamId: e.songId,
                isLibrary: e.isCloudItem,
                "user-initiated": n
            }
        }(n, s.userInitiated)), d
    }
    class License {
        fetch(e) {
            const n = {
                Authorization: "Bearer " + Si.developerToken,
                Accept: "application/json",
                "Content-Type": "application/json",
                "X-Apple-Music-User-Token": "" + Si.musicUserToken
            };
            this.keySystem === He.WIDEVINE && (n["X-Apple-Renewal"] = !0);
            return decayingOperation(() => (xe.debug("Fetching License challenge from " + this.licenseUrl, {
                headers: n,
                body: e
            }), fetch(this.licenseUrl, {
                method: "POST",
                body: JSON.stringify(e),
                headers: new Headers(n)
            })), e => e instanceof TypeError, "license fetch")
        }
        reset() {
            xe.debug("Resetting License instance"), this.licenseUrl = void 0, this.playableItem = void 0, this.licenseData = void 0, this.initiated = void 0, this.keySystem = void 0, this.slotToken = void 0, this.startResponse = void 0
        }
        start(e, n, s, d, p = !1, h = !1) {
            var y = this;
            return _async_to_generator$Q((function*() {
                y.licenseUrl = e, y.playableItem = n, y.licenseData = s, y.keySystem = d, y.initiated = p, xe.debug(`Starting License request to ${y.licenseUrl} with URI ${y.licenseData.keyuri} for ${mediaItemLogString(y.playableItem)}`);
                const _ = s.isRenewalRequest ? "renew" : "start";
                xe.debug(`Treating License request as a ${"renew"===_?"renewal":"new"} request`);
                const m = createLicenseChallengeBody(_, n, _object_spread_props$j(_object_spread$u({}, s), {
                    keySystem: d,
                    extendedLease: h,
                    userInitiated: p
                }));
                n.hasOffersHlsUrl && !y.licenseUrl.includes("start") && (y.licenseUrl += "/" + _), y.startResponse = y.fetch(m);
                try {
                    var v, g, b;
                    const e = yield y.startResponse;
                    if (!e.ok) {
                        let n;
                        try {
                            n = yield e.json()
                        } catch (Rt) {}
                        y.processJsonError(n)
                    }
                    xe.debug("Processing License Challenge reponse as JSON");
                    const n = yield e.json();
                    let s = n;
                    return (null == n || null === (g = n["streaming-response"]) || void 0 === g || null === (v = g["streaming-keys"]) || void 0 === v ? void 0 : v.length) ? s = n["streaming-response"]["streaming-keys"][0] : (null == n || null === (b = n["license-responses"]) || void 0 === b ? void 0 : b.length) && (s = n["license-responses"][0]), 0 !== s.status && y.processJsonError(s), y.slotToken = s.stkn, s
                } catch (ce) {
                    throw xe.error(`License Challenge Request failed to ${y.licenseUrl} with URI ${y.licenseData.keyuri} for ${mediaItemLogString(y.playableItem)}`), y.startResponse = void 0, ce
                }
            }))()
        }
        processJsonError(e) {
            let n = new MKError(MKError.Reason.MEDIA_LICENSE, "Error acquiring license");
            if ((null == e ? void 0 : e.errorCode) && (e.status = e.errorCode), -1021 === (null == e ? void 0 : e.status) && (e.status = 190121), e && 0 !== e.status) {
                if (!e.message) switch (e.status) {
                    case -1004:
                        e.message = MKError.Reason.DEVICE_LIMIT;
                        break;
                    case -1017:
                        e.message = MKError.Reason.GEO_BLOCK;
                        break;
                    default:
                        e.message = MKError.Reason.MEDIA_LICENSE
                }
                n = MKError.serverError(e), n.data = e, n.reason === MKError.Reason.PLAYREADY_CBC_ENCRYPTION_ERROR && function() {
                    const e = getSessionStorage();
                    e && e.setItem("mk-playready-cbcs-unsupported", "true")
                }()
            }
            throw n
        }
        stop() {
            var e = this;
            return _async_to_generator$Q((function*() {
                if (e.startResponse) try {
                    yield e.startResponse
                } catch (ce) {}
                if (!e.playableItem || !e.licenseData || !e.licenseUrl) return;
                if (!e.playableItem.isUTS) return;
                const n = createLicenseChallengeBody("stop", e.playableItem, _object_spread_props$j(_object_spread$u({}, e.licenseData), {
                        keySystem: e.keySystem,
                        slotToken: e.slotToken,
                        userInitiated: e.initiated
                    })),
                    s = e.fetch(n);
                e.reset();
                try {
                    yield s
                } catch (ce) {
                    xe.warn("license.stop request error", ce)
                }
            }))()
        }
        constructor() {
            _define_property$1c(this, "licenseUrl", void 0), _define_property$1c(this, "playableItem", void 0), _define_property$1c(this, "licenseData", void 0), _define_property$1c(this, "initiated", void 0), _define_property$1c(this, "keySystem", void 0), _define_property$1c(this, "slotToken", void 0), _define_property$1c(this, "startResponse", void 0)
        }
    }

    function asyncGeneratorStep$P(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$P(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$P(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$P(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1b(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_metadata$l(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    class KeySession extends Notifications {
        get extID() {
            if (this.extURI) return this.extURI.replace("data:;base64,", "")
        }
        get isFairplay() {
            return this.keySystem === He.FAIRPLAY
        }
        get isPlayReady() {
            return this.keySystem === He.PLAYREADY
        }
        get isWidevine() {
            return this.keySystem === He.WIDEVINE
        }
        acquirePlaybackLicense(e, n, s, d) {
            var p = this;
            return _async_to_generator$P((function*() {
                if (!p.keyServerURL || !p.developerToken || !p.userToken) return;
                const {
                    keyServerURL: s,
                    keySystem: h
                } = p, y = d.item;
                try {
                    return yield p.license.start(s, y, {
                        challenge: n,
                        keyuri: e
                    }, h, p.initiated, p.isLegacyEme && y.isUTS)
                } catch (Rt) {
                    p.dispatchEvent(Ye.playbackLicenseError, Rt)
                }
            }))()
        }
        startLicenseSession(e) {
            var n = this;
            return _async_to_generator$P((function*() {
                let s;
                xe.debug("Starting License Session", e);
                const {
                    message: d,
                    target: p,
                    messageType: h
                } = e;
                if (n.keySystem !== He.FAIRPLAY && "license-request" !== h) return void xe.debug("not making license request for", h);
                if (n.isPlayReady) {
                    const e = String.fromCharCode.apply(null, new Uint16Array(d.buffer || d));
                    s = (new DOMParser).parseFromString(e, "application/xml").getElementsByTagName("Challenge")[0].childNodes[0].nodeValue
                } else s = j(new Uint8Array(d));
                const y = p.extURI || n.extURI,
                    _ = n.mediaKeySessions[y];
                if (!_) return void xe.debug("no key session info, aborting license request");
                const m = n.acquirePlaybackLicense(y, s, n.initiated, _);
                if (_.delayCdmUpdate) _["license-json"] = m;
                else {
                    const e = yield m;
                    yield n.handleLicenseJson(e, p, y)
                }
            }))()
        }
        setKeyURLs(e) {
            this.keyCertURL = e[this.isFairplay ? "hls-key-cert-url" : "widevine-cert-url"], this.keyServerURL = e["hls-key-server-url"]
        }
        dispatchKeyError(e) {
            var n, s;
            this.isFairplay && 4294955417 === (null == e || null === (s = e.target) || void 0 === s || null === (n = s.error) || void 0 === n ? void 0 : n.systemCode) ? xe.error("Ignoring error", e) : (console.error(MKError.Reason.MEDIA_KEY + " error in dispatchKeyError:", e), this.dispatchEvent(Ye.playbackSessionError, new MKError(MKError.Reason.MEDIA_KEY, e)))
        }
        dispatchSessionError(e) {
            this.dispatchEvent(Ye.playbackSessionError, new MKError(MKError.Reason.MEDIA_SESSION, e))
        }
        loadCertificateBuffer() {
            var e = this;
            return _async_to_generator$P((function*() {
                if (!e.keyCertURL) return Promise.reject(new MKError(MKError.Reason.MEDIA_SESSION, "No certificate URL"));
                let n;
                try {
                    n = yield fetch(`${e.keyCertURL}?t=${Date.now()}`)
                } catch (ce) {
                    throw e.dispatchKeyError(ce), ce
                }
                const s = yield n.arrayBuffer(), d = String.fromCharCode.apply(String, new Uint8Array(s));
                return /^\<\?xml/.test(d) ? Promise.reject(new MKError(MKError.Reason.MEDIA_CERTIFICATE, "Invalid certificate.")) : s
            }))()
        }
        handleSessionCreation(e) {
            var n = this;
            return _async_to_generator$P((function*() {
                return n.createSession(e).catch(e => {
                    n.dispatchSessionError(e)
                })
            }))()
        }
        handleLicenseJson(e, n, s) {
            var d = this;
            return _async_to_generator$P((function*() {
                if (xe.debug(`updating session ${s} with license response`, e), null == e ? void 0 : e.license) {
                    const s = D(e.license);
                    try {
                        yield n.update(s)
                    } catch (Rt) {
                        xe.error("Failed to updated media keys", Rt), d.dispatchKeyError(Rt)
                    }
                }
            }))()
        }
        addMediaKeySessionInfo(e, n, s, d = !1) {
            const p = this.mediaKeySessions[e];
            p ? (xe.debug(`keySession info exists for ${s.title}, making existing session ${p.session.sessionId} the old session`), p.oldSession = p.session, p.session = n) : (xe.debug("creating key session info for " + s.title), this.mediaKeySessions[e] = {
                session: n,
                item: s,
                delayCdmUpdate: d
            })
        }
        stopLicenseSession() {
            xe.info("key session sending license stop"), this.license.stop()
        }
        constructor() {
            super([Ye.playbackLicenseError, Ye.playbackSessionError]), _define_property$1b(this, "developerToken", void 0), _define_property$1b(this, "adamId", void 0), _define_property$1b(this, "userToken", void 0), _define_property$1b(this, "extURI", void 0), _define_property$1b(this, "item", void 0), _define_property$1b(this, "initiated", !0), _define_property$1b(this, "isLibrary", !1), _define_property$1b(this, "keyCertURL", void 0), _define_property$1b(this, "keyServerURL", void 0), _define_property$1b(this, "keySystem", He.FAIRPLAY), _define_property$1b(this, "isLegacyEme", !1), _define_property$1b(this, "boundDispatchKeyError", void 0), _define_property$1b(this, "boundDispatchSessionError", void 0), _define_property$1b(this, "boundHandleSessionCreation", void 0), _define_property$1b(this, "boundStartLicenseSession", void 0), _define_property$1b(this, "mediaKeySessions", {}), _define_property$1b(this, "_pendingRenewal", void 0), _define_property$1b(this, "license", void 0), this.boundDispatchKeyError = this.dispatchKeyError.bind(this), this.boundDispatchSessionError = this.dispatchSessionError.bind(this), this.boundHandleSessionCreation = this.handleSessionCreation.bind(this), this.boundStartLicenseSession = this.startLicenseSession.bind(this), this.license = new License
        }
    }

    function asyncGeneratorStep$O(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$O(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$O(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$O(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1a(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_metadata$k(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$l("design:type", Function), _ts_metadata$l("design:paramtypes", [void 0]), _ts_metadata$l("design:returntype", Promise)], KeySession.prototype, "startLicenseSession", null);
    class FairplayEncryptedSession extends KeySession {
        attachMedia(e, n) {
            var s = this;
            return _async_to_generator$O((function*() {
                s.keySystem = n.keySystem, s._keySystemAccess = n, e.addEventListener("encrypted", s.boundHandleSessionCreation, !1)
            }))()
        }
        detachMedia(e) {
            e.removeEventListener("encrypted", this.boundHandleSessionCreation);
            const n = this._mediaKeySessions,
                s = this._mediaKeySessionRenewals;
            Object.values(n).forEach(e => {
                e.removeEventListener("message", this.boundStartLicenseSession), asAsync(e.close())
            }), this._mediaKeySessions = {}, Object.values(s).forEach(e => clearTimeout(e)), this._mediaKeySessionRenewals = {}
        }
        createSession(e) {
            var n = this;
            return _async_to_generator$O((function*() {
                xe.debug("fairplay eme:  createSession", e);
                const s = n._keySystemAccess;
                if (!s) return;
                const {
                    initData: d,
                    target: p,
                    initDataType: h
                } = e;
                var y;
                n._mediaKeysPromise || (n._mediaKeysPromise = new Promise((y = _async_to_generator$O((function*(e, d) {
                    const h = yield s.createMediaKeys();
                    try {
                        yield p.setMediaKeys(h), n._mediaKeys = h;
                        const e = yield n.loadCertificateBuffer();
                        yield h.setServerCertificate(e)
                    } catch (ce) {
                        n.dispatchKeyError(ce), d(ce)
                    }
                    e(h)
                })), function(e, n) {
                    return y.apply(this, arguments)
                })));
                const _ = yield n._mediaKeysPromise, m = new Uint8Array(d), v = String.fromCharCode.apply(void 0, Array.from(m));
                if (n.mediaKeySessions[v]) return void xe.error("fairplay eme: not creating new session for extURI", v);
                const g = _.createSession();
                xe.debug("fairplay eme: creating new key session for", v), n.addMediaKeySessionInfo(v, g, n.item), g.addEventListener("message", n.startFairplayLicenseSession), g.extURI = v, yield g.generateRequest(h, d), n._mediaKeySessions[g.sessionId] = g, xe.debug("fairplay eme: created session", g)
            }))()
        }
        startFairplayLicenseSession(e) {
            const {
                message: n,
                target: s
            } = e, d = j(new Uint8Array(n)), p = s.extURI || this.extURI, h = this.mediaKeySessions[p];
            if (h) return this.acquirePlaybackLicense(p, d, this.initiated, h).then(e => this.handleLicenseJson(e, s, p));
            xe.debug("fairplay eme: no key session info, aborting license request", p)
        }
        handleLicenseJson(e, n, s) {
            var d = this,
                _superprop_get_handleLicenseJson = () => super.handleLicenseJson;
            return _async_to_generator$O((function*() {
                if (!e) return;
                const p = d.mediaKeySessions[s];
                if (!p) return void xe.debug("fairplay eme: media key session does not exist, not updating");
                const h = e["renew-after"];
                if (e.license && h) {
                    xe.debug("fairplay eme: got renew after value", h, s);
                    const e = d._mediaKeySessionRenewals,
                        y = e[n.sessionId];
                    y && clearTimeout(y), e[n.sessionId] = setTimeout(() => d._renewMediaKeySession(p, s), 1e3 * h)
                }
                yield _superprop_get_handleLicenseJson().call(d, e, n, s)
            }))()
        }
        _renewMediaKeySession(e, n) {
            delete this._mediaKeySessionRenewals[e.session.sessionId], xe.debug("fairplay eme: renewing session", e), e.session.update(L("renew"))
        }
        applyDelayedCdmUpdates() {}
        loadKeys(e) {
            return _async_to_generator$O((function*() {}))()
        }
        clearSessions() {
            return _async_to_generator$O((function*() {}))()
        }
        constructor(...e) {
            super(...e), _define_property$1a(this, "_keySystemAccess", void 0), _define_property$1a(this, "_mediaKeysPromise", void 0), _define_property$1a(this, "_mediaKeySessions", {}), _define_property$1a(this, "_mediaKeySessionRenewals", {}), _define_property$1a(this, "_mediaKeys", void 0)
        }
    }

    function asyncGeneratorStep$N(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$N(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$N(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$N(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$19(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$k("design:type", Function), _ts_metadata$k("design:paramtypes", [void 0]), _ts_metadata$k("design:returntype", void 0)], FairplayEncryptedSession.prototype, "startFairplayLicenseSession", null);
    const Pi = /^(?:.*)(skd:\/\/.+)$/i;
    class WebKitSession extends KeySession {
        get isDestroyed() {
            return this._isDestroyed
        }
        attachMedia(e, n) {
            return this.target = e, e.addEventListener("webkitneedkey", this.boundHandleSessionCreation, !1), e.addEventListener("webkitkeyerror", this.boundDispatchKeyError), e
        }
        detachMedia(e) {
            e && (e.removeEventListener("webkitneedkey", this.boundHandleSessionCreation, !1), e.removeEventListener("webkitkeyerror", this.boundDispatchKeyError))
        }
        destroy() {
            xe.debug("FPS destroy"), this._isDestroyed = !0, this.detachMedia(this.target), this.session && (this.session.removeEventListener("webkitkeyerror", this.boundDispatchKeyError), this.session.removeEventListener("webkitkeymessage", this.boundStartLicenseSession))
        }
        createSession(e) {
            xe.debug("FPS createSession", e);
            const {
                initData: n,
                target: s
            } = e, {
                item: d
            } = this;
            if (!d) return xe.error("Cannot createSession without item"), Promise.resolve();
            const p = this._extractAssetId(n);
            if (xe.debug("extURI", p), !s.webkitKeys && window.WebKitMediaKeys) {
                const e = new window.WebKitMediaKeys(this.keySystem);
                s.webkitSetMediaKeys(e)
            }
            return this.loadCertificateBuffer().then(e => {
                const h = this._concatInitDataIdAndCertificate(n, p, e),
                    y = "VIDEO" === s.tagName ? Qe.AVC1 : Qe.MP4,
                    _ = s.webkitKeys.createSession(y, h);
                this.addMediaKeySessionInfo(p, _, d), this.session = _, _.extURI = p, _.addEventListener("webkitkeyerror", this.boundDispatchKeyError), _.addEventListener("webkitkeymessage", this.boundStartLicenseSession)
            })
        }
        _extractAssetId(e) {
            let n = String.fromCharCode.apply(null, new Uint16Array(e.buffer || e));
            const s = n.match(Pi);
            return s && s.length >= 2 && (n = s[1]), xe.debug("Extracted assetId from EXT-X-KEY URI", n), n
        }
        _concatInitDataIdAndCertificate(e, n, s) {
            "string" == typeof n && (n = x(n)), s = new Uint8Array(s);
            let d = 0;
            const p = new ArrayBuffer(e.byteLength + 4 + n.byteLength + 4 + s.byteLength),
                h = new DataView(p);
            new Uint8Array(p, d, e.byteLength).set(e), d += e.byteLength, h.setUint32(d, n.byteLength, !0), d += 4;
            const y = new Uint8Array(p, d, n.byteLength);
            y.set(n), d += y.byteLength, h.setUint32(d, s.byteLength, !0), d += 4;
            return new Uint8Array(p, d, s.byteLength).set(s), new Uint8Array(p, 0, p.byteLength)
        }
        applyDelayedCdmUpdates() {}
        loadKeys(e) {
            return _async_to_generator$N((function*() {}))()
        }
        clearSessions() {
            return _async_to_generator$N((function*() {}))()
        }
        constructor(...e) {
            super(...e), _define_property$19(this, "target", void 0), _define_property$19(this, "session", void 0), _define_property$19(this, "_isDestroyed", !1), _define_property$19(this, "isLegacyEme", !0)
        }
    }

    function asyncGeneratorStep$M(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$M(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$M(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$M(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }
    class MSSession extends KeySession {
        attachMedia(e, n) {
            return this.keySystem = n.keySystem, e.addEventListener("msneedkey", this.boundHandleSessionCreation, !1), e.addEventListener("mskeyerror", this.boundDispatchKeyError), e
        }
        detachMedia(e) {
            e.removeEventListener("msneedkey", this.boundHandleSessionCreation, !1), e.removeEventListener("mskeyerror", this.boundDispatchKeyError)
        }
        createSession(e) {
            const {
                initData: n,
                target: s
            } = e;
            if (!s.msKeys) {
                const e = new MSMediaKeys(this.keySystem);
                s.msSetMediaKeys(e)
            }
            const d = s.msKeys.createSession(Qe.MP4, n);
            return d.addEventListener("mskeyerror", this.dispatchKeyError), d.addEventListener("mskeymessage", this.startLicenseSession.bind(this)), d
        }
        applyDelayedCdmUpdates() {}
        loadKeys(e) {
            return _async_to_generator$M((function*() {}))()
        }
        clearSessions() {
            return _async_to_generator$M((function*() {}))()
        }
    }
    const ki = {
            [He.WIDEVINE]: Je.WIDEVINE,
            [He.FAIRPLAY]: Je.FAIRPLAY,
            [He.PLAYREADY]: Je.PLAYREADY
        },
        Ti = [0, 0, 1, 222, 112, 115, 115, 104, 0, 0, 0, 0, 154, 4, 240, 121, 152, 64, 66, 134, 171, 146, 230, 91, 224, 136, 95, 149, 0, 0, 1, 190],
        Ei = [190, 1, 0, 0, 1, 0, 1, 0, 180, 1];

    function concatenate(e, ...n) {
        let s = 0;
        for (const h of n) s += h.length;
        const d = new e(s);
        let p = 0;
        for (const h of n) d.set(h, p), p += h.length;
        return d
    }
    const {
        WIDEVINE: wi,
        PLAYREADY: Ii
    } = He, Oi = {};
    Oi[wi] = e => {
        xe.debug("generating Widevine pssh for keyId");
        const n = new Uint8Array([0, 0, 0, 52, 112, 115, 115, 104, 0, 0, 0, 0, 237, 239, 139, 169, 121, 214, 74, 206, 163, 200, 39, 220, 213, 29, 33, 237, 0, 0, 0, 20, 8, 1, 18, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);
        for (let s = 0; s < e.length; s++) n[n.length - 16 + s] = e[s];
        return xe.debug("generatePSSH", n), n
    }, Oi[Ii] = e => {
        xe.debug("generating Playready pssh for keyId"), (e => {
            const swap = (e, n, s) => {
                const d = e[n];
                e[n] = e[s], e[s] = d
            };
            swap(e, 0, 3), swap(e, 1, 2), swap(e, 4, 5), swap(e, 6, 7)
        })(e);
        const n = j(e),
            s = '<WRMHEADER xmlns="http://schemas.microsoft.com/DRM/2007/03/PlayReadyHeader" version="4.3.0.0"><DATA><PROTECTINFO><KIDS><KID ALGID="AESCTR" VALUE="[KEYID]"></KID></KIDS></PROTECTINFO></DATA></WRMHEADER>'.replace("[KEYID]", n),
            d = x(s),
            p = new Uint8Array(d.buffer, d.byteOffset, d.byteLength);
        return concatenate(Uint8Array, Ti, Ei, p)
    };

    function asyncGeneratorStep$L(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$L(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$L(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$L(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$18(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class PreloadingEncryptedSession extends KeySession {
        attachMedia(e, n) {
            this.keySystem = n.keySystem, this._keySystemAccess = n, this._target = e
        }
        detachMedia() {
            asAsync(this.clearSessions())
        }
        createSession(e) {
            return _async_to_generator$L((function*() {}))()
        }
        _mediaKeysSetup() {
            var e = this;
            return _async_to_generator$L((function*() {
                const n = e._keySystemAccess;
                var s;
                n && (e._mediaKeysPromise || (e._mediaKeysPromise = new Promise((s = _async_to_generator$L((function*(s, d) {
                    const p = yield n.createMediaKeys();
                    try {
                        var h;
                        yield null === (h = e._target) || void 0 === h ? void 0 : h.setMediaKeys(p), e._mediaKeys = p
                    } catch (ce) {
                        e.dispatchKeyError(ce), d(ce)
                    }
                    if (e.isWidevine) {
                        const n = yield e.loadCertificateBuffer();
                        yield p.setServerCertificate(n)
                    }
                    s(p)
                })), function(e, n) {
                    return s.apply(this, arguments)
                }))), yield e._mediaKeysPromise)
            }))()
        }
        createSessionAndGenerateRequest(e, n, s) {
            var d = this;
            return _async_to_generator$L((function*() {
                var p;
                const h = !!(null == s ? void 0 : s.isRenewal),
                    y = !!(null == s ? void 0 : s.delayCdmUpdate);
                if (!h && d.mediaKeySessions[e]) return;
                xe.debug(`createSessionAndGenerateRequest for item ${n.title}, isRenewal ${h}`);
                const _ = null === (p = d._mediaKeys) || void 0 === p ? void 0 : p.createSession(),
                    {
                        keySystem: m
                    } = d;
                if (!_) return;
                d.addMediaKeySessionInfo(e, _, n, y);
                const v = (e => {
                        if (e.includes("data")) {
                            const [n, s] = e.split(",");
                            return s
                        }
                        return e
                    })(e),
                    g = D(v),
                    b = d.isWidevine && n.isSong || 16 === g.length;
                let S;
                var P;
                return xe.debug("extracted uri", e), d.isPlayReady && !b ? (xe.debug("handling Playready object"), _.extURI = e, P = g, S = concatenate(Uint8Array, new Uint8Array(Ti), P)) : b ? (xe.debug("handling keyId only initData"), _.extURI = "data:;base64," + j(g), S = ((e, n) => {
                    const s = Oi[n];
                    if (!s) return xe.warn("No pssh generator for ", n), e;
                    return s(Uint8Array.from(e))
                })(g, m)) : (xe.debug("handling pssh initData"), _.extURI = e, S = g), _.addEventListener("message", d.startLicenseSession), _.generateRequest("cenc", S).catch(e => {
                    if (e.message.match(/generateRequest.*\(75\)/)) return _.generateRequest("cenc", S);
                    throw e
                })
            }))()
        }
        handleLicenseJson(e, n, s) {
            var d = this,
                _superprop_get_handleLicenseJson = () => super.handleLicenseJson;
            return _async_to_generator$L((function*() {
                var p;
                if (!e) return;
                const h = d.mediaKeySessions[s];
                if (!h) return void xe.debug("media key session does not exist, not updating");
                const y = e["renew-after"];
                if (e.license && y) {
                    xe.debug("Got renew after value", y, s);
                    const e = d._mediaKeySessionRenewals,
                        p = e[n.sessionId];
                    p && clearTimeout(p), e[n.sessionId] = setTimeout(() => d._renewMediaKeySession(h, s), 1e3 * y)
                }
                yield _superprop_get_handleLicenseJson().call(d, e, n, s);
                const _ = null === (p = d.mediaKeySessions[s]) || void 0 === p ? void 0 : p.oldSession;
                _ && (xe.debug("removing old key session after updating", s), yield d._removeAndCloseSession(_), delete d.mediaKeySessions[s].oldSession, delete d._mediaKeySessionRenewals[_.sessionId])
            }))()
        }
        _renewMediaKeySession(e, n) {
            delete this._mediaKeySessionRenewals[e.session.sessionId], asAsync(this.createSessionAndGenerateRequest(n, e.item, {
                isRenewal: !0
            }))
        }
        applyDelayedCdmUpdates() {
            var e = this;
            return _async_to_generator$L((function*() {
                xe.debug("applying delayed CDM updates");
                const n = Object.entries(e.mediaKeySessions);
                for (const s of n) {
                    const [n, d] = s;
                    if (d.delayCdmUpdate) {
                        const s = yield d["license-json"];
                        xe.debug("delayed update of license", s), d.delayCdmUpdate = !1, yield e.handleLicenseJson(s, d.session, n)
                    }
                }
            }))()
        }
        loadKeys(e, n, s) {
            var d = this;
            return _async_to_generator$L((function*() {
                yield d._mediaKeysSetup();
                const p = d.filterKeyValues(e);
                for (const e of p) {
                    const {
                        dataUri: p
                    } = e;
                    yield d.createSessionAndGenerateRequest(p, n, s)
                }
                if (null == n ? void 0 : n.isLiveAudioStation) {
                    const e = Object.keys(d.mediaKeySessions),
                        n = p.reduce((e, n) => (e[n.dataUri] = !0, e), {});
                    for (const s of e) n[s] || (yield d._scheduleRemoveSession(s))
                }
            }))()
        }
        filterKeyValues(e) {
            let n;
            if (1 === e.length) n = e;
            else {
                const s = ki[this.keySystem];
                n = e.filter(e => e.keyFormat === s)
            }
            return n
        }
        clearSessions(e) {
            var n = this;
            return _async_to_generator$L((function*() {
                const s = n.mediaKeySessions;
                if (null == e ? void 0 : e.length) {
                    const s = n.filterKeyValues(e);
                    for (const e of s) {
                        const s = e.dataUri;
                        clearTimeout(n._sessionRemovalTimeouts[s]), yield n._removeSessionImmediately(s)
                    }
                } else {
                    Object.values(n._sessionRemovalTimeouts).forEach(e => clearTimeout(e)), xe.debug("clearing key sessions", s);
                    for (const e of Object.keys(s)) yield n._removeSessionImmediately(e)
                }
            }))()
        }
        _scheduleRemoveSession(e) {
            var n = this;
            return _async_to_generator$L((function*() {
                if (!n.mediaKeySessions[e]) return void xe.warn("no session for dataUri, not scheduling remove", e);
                if (n._sessionRemovalTimeouts[e]) return;
                const s = setTimeout(() => {
                    asAsync(n._removeSessionImmediately(e))
                }, 6e4);
                xe.debug("deferring removal of keysession for dataUri", e), n._sessionRemovalTimeouts[e] = s
            }))()
        }
        _removeSessionImmediately(e) {
            var n = this;
            return _async_to_generator$L((function*() {
                const s = n.mediaKeySessions[e];
                if (!s) return void xe.warn("no session for dataUri, not removing", e);
                xe.debug("removing keysession for", e);
                const {
                    session: d,
                    oldSession: p
                } = s;
                n._clearSessionRenewal(d), delete n.mediaKeySessions[e], yield n._removeAndCloseSession(d), p && (yield n._removeAndCloseSession(p))
            }))()
        }
        _removeAndCloseSession(e) {
            var n = this;
            return _async_to_generator$L((function*() {
                e.removeEventListener("message", n.startLicenseSession), xe.debug("tearing down session", e.sessionId);
                try {
                    yield e.remove()
                } catch (Rt) {
                    xe.warn("Error invoking session.remove()", Rt)
                } finally {
                    try {
                        yield e.close()
                    } catch (Rt) {
                        xe.warn("Error invoking session.close()", Rt)
                    }
                }
            }))()
        }
        _clearSessionRenewal(e) {
            const n = this._mediaKeySessionRenewals[e.sessionId];
            n && (xe.debug("clearing scheduled license renewal for session", e.sessionId), clearTimeout(n), delete this._mediaKeySessionRenewals[e.sessionId])
        }
        constructor(...e) {
            super(...e), _define_property$18(this, "_keySystemAccess", void 0), _define_property$18(this, "_mediaKeysPromise", void 0), _define_property$18(this, "_mediaKeys", void 0), _define_property$18(this, "_target", void 0), _define_property$18(this, "_sessionRemovalTimeouts", {}), _define_property$18(this, "_mediaKeySessionRenewals", {})
        }
    }

    function asyncGeneratorStep$K(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$K(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$K(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$K(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$17(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const Ri = BooleanDevFlag.register("mk-safari-modern-eme");
    class MediaExtension extends Notifications {
        get hasMediaKeySupport() {
            return hasMediaKeySupport()
        }
        get hasMediaSession() {
            return void 0 !== this._session
        }
        get isFairplay() {
            return this._session.isFairplay
        }
        set extURI(e) {
            this._session.extURI = e
        }
        set initiated(e) {
            this._session.initiated = e
        }
        get session() {
            return this._session
        }
        clearSessions(e) {
            var n = this;
            return _async_to_generator$K((function*() {
                var s;
                return null === (s = n.session) || void 0 === s ? void 0 : s.clearSessions(e)
            }))()
        }
        initializeKeySystem() {
            var e = this;
            return _async_to_generator$K((function*() {
                yield e._attachSession();
                const {
                    _session: n
                } = e;
                n && [Ye.playbackLicenseError, Ye.playbackSessionError].forEach(s => {
                    n.addEventListener(s, n => {
                        e.dispatchEvent(s, n)
                    })
                })
            }))()
        }
        _requestModernFairplayAccess() {
            var e = this;
            return _async_to_generator$K((function*() {
                const {
                    contentType: n
                } = e, s = [{
                    initDataTypes: ["skd"],
                    audioCapabilities: [{
                        contentType: n,
                        robustness: ""
                    }],
                    videoCapabilities: [{
                        contentType: n,
                        robustness: ""
                    }],
                    distinctiveIdentifier: "not-allowed",
                    persistentState: "not-allowed",
                    sessionTypes: ["temporary"]
                }], [, d] = yield findMediaKeySystemAccess([He.FAIRPLAY], s);
                return d
            }))()
        }
        _attachSession() {
            var e = this;
            return _async_to_generator$K((function*() {
                var n, s;
                const {
                    mediaElement: d,
                    contentType: p
                } = e;
                if (null === (n = window.WebKitMediaKeys) || void 0 === n ? void 0 : n.isTypeSupported(He.FAIRPLAY + ".1_0", Qe.MP4)) {
                    let n;
                    Ri.enabled && e.hasMediaKeySupport && (n = yield e._requestModernFairplayAccess()), n ? (xe.warn("media-extension: Using Fairplay modern EME"), e._session = new FairplayEncryptedSession, e._session.attachMedia(d, n)) : (xe.warn("media-extension: Using Fairplay legacy EME"), e._session = new WebKitSession, e._session.attachMedia(d, {
                        keySystem: He.FAIRPLAY
                    }))
                } else if (null === (s = window.MSMediaKeys) || void 0 === s ? void 0 : s.isTypeSupported(He.PLAYREADY, Qe.MP4)) e._session = new MSSession, e._session.attachMedia(d, {
                    keySystem: He.PLAYREADY
                });
                else if (e.hasMediaKeySupport && d.canPlayType(p)) {
                    e._session = new PreloadingEncryptedSession;
                    const n = [{
                            initDataTypes: ["cenc", "keyids"],
                            audioCapabilities: [{
                                contentType: p
                            }],
                            distinctiveIdentifier: "optional",
                            persistentState: "required"
                        }],
                        s = potentialKeySystemsForAccess(),
                        [, y] = yield findMediaKeySystemAccess(s, n);
                    var h;
                    if (y) null === (h = e._session) || void 0 === h || h.attachMedia(d, y);
                    else xe.warn("media-extension: No keysystem detected!")
                }
            }))()
        }
        setMediaItem(e) {
            ! function(e, n) {
                n.keyURLs && (e.developerToken = Si.developerToken, e.userToken = Si.musicUserToken, e.item = n, e.adamId = n.songId, e.isLibrary = n.isCloudItem, e.setKeyURLs(n.keyURLs))
            }(this._session, e)
        }
        destroy(e) {
            var n;
            null === (n = this._session) || void 0 === n || n.detachMedia(e)
        }
        constructor(e, n) {
            super([Ye.playbackLicenseError, Ye.playbackSessionError]), _define_property$17(this, "_session", void 0), _define_property$17(this, "mediaElement", void 0), _define_property$17(this, "contentType", void 0), this.mediaElement = e, this.contentType = n
        }
    }
    const Ai = BooleanDevFlag.register("mk-force-audio-mse"),
        shouldForceAudioMse = () => Ai.enabled;

    function asyncGeneratorStep$J(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$16(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class ByteRangeSegment {
        load() {
            var e, n = this;
            return (e = function*() {
                const {
                    url: e,
                    range: s
                } = n;
                if (!e) return new Uint8Array;
                const d = new Headers;
                d.append("Range", s);
                const p = yield fetch(e, {
                    headers: d
                }), h = yield p.arrayBuffer();
                return new Uint8Array(h)
            }, function() {
                var n = this,
                    s = arguments;
                return new Promise((function(d, p) {
                    var h = e.apply(n, s);

                    function _next(e) {
                        asyncGeneratorStep$J(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$J(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        constructor({
            url: e,
            startByte: n,
            length: s,
            isInitSegment: d = !1
        }) {
            _define_property$16(this, "url", void 0), _define_property$16(this, "range", void 0), _define_property$16(this, "startByte", void 0), _define_property$16(this, "endByte", void 0), _define_property$16(this, "length", void 0), _define_property$16(this, "startTime", void 0), _define_property$16(this, "endTime", void 0), _define_property$16(this, "isInitSegment", void 0), this.url = e, this.isInitSegment = d, this.startByte = parseInt(n, 10), this.length = parseInt(s, 10), this.endByte = this.startByte + this.length - 1, this.range = `bytes=${this.startByte}-${this.endByte}`
        }
    }

    function asyncGeneratorStep$I(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$15(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class ContinuousSegment {
        load() {
            var e, n = this;
            return (e = function*() {
                const {
                    url: e
                } = n;
                if (!e) return new Uint8Array;
                const s = yield fetch(e), d = yield s.arrayBuffer();
                return new Uint8Array(d)
            }, function() {
                var n = this,
                    s = arguments;
                return new Promise((function(d, p) {
                    var h = e.apply(n, s);

                    function _next(e) {
                        asyncGeneratorStep$I(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$I(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        constructor(e, n = !1) {
            _define_property$15(this, "url", void 0), _define_property$15(this, "isInitSegment", void 0), this.url = e, this.isInitSegment = n
        }
    }

    function _define_property$14(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const $i = /^#EXT-X-BYTERANGE:([^\n]+)\n/gim,
        Mi = /^#EXT-X-MAP:([^\n]+)\n/im,
        Ci = /#EXTINF:\d*\.\d*\,[\n](.+)|^#EXT-X-MAP:URI="([^"]*)"/gim,
        Di = /#EXTINF:\d*\.\d*,\s*#EXT-X-BITRATE:\d{1,3}[\n](.+)|^#EXT-X-MAP:URI="([^"]*)"/gim;
    class SegmentList {
        get segments() {
            return this._segments
        }
        addSegment(e, n) {
            this._addedSegments[n] || (xe.debug("Adding segment", n), this._segments.push(e), this._addedSegments[n] = !0)
        }
        extractLiveRadioSegments(e, n) {
            this._extractContinuousSegments(Ci, e, n)
        }
        extractHlsOffersSegments(e, n) {
            this._extractContinuousSegments(Di, e, n)
        }
        _extractContinuousSegments(e, n, s) {
            if (!n || !e.test(n)) return;
            let d;
            for (e.lastIndex = 0; d = e.exec(n);) {
                const e = d[0].startsWith("#EXT-X-MAP") ? d[2] : d[1];
                let n = e;
                /^http(s)?:\/\//.test(n) || (n = joinURLPath([...splitURLPath(s).slice(0, -1), e]));
                const p = d[0].startsWith("#EXT-X-MAP");
                this.addSegment(new ContinuousSegment(n, p), e)
            }
        }
        extractByteRangeSegments(e, n) {
            if (!e || !$i.test(e)) return;
            const s = function(e) {
                if (!e || !Mi.test(e)) return;
                const [, n] = e.match(Mi);
                return n.split(",").reduce((e, n) => {
                    const [s, d] = n.split("=");
                    return e[s.toLowerCase()] = d.replace(/\"/gi, ""), e
                }, {})
            }(e);
            var d;
            const p = null !== (d = n.split("/").pop()) && void 0 !== d ? d : "",
                h = n.replace(p, s.uri),
                [y, _] = s.byterange.split("@"),
                m = new ByteRangeSegment({
                    url: h,
                    startByte: _,
                    length: y
                });
            var v;
            this.addSegment(m, m.range), (null !== (v = e.match($i)) && void 0 !== v ? v : []).forEach(e => {
                const [, n, s] = e.match(/^#EXT-X-BYTERANGE:(\d+)@(\d+)\n/), d = new ByteRangeSegment({
                    url: h,
                    startByte: s,
                    length: n
                });
                this.addSegment(d, d.range)
            })
        }
        constructor() {
            _define_property$14(this, "_segments", []), _define_property$14(this, "_addedSegments", {})
        }
    }
    var Li;

    function asyncGeneratorStep$H(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$H(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$H(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$H(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$13(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_metadata$j(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }! function(e) {
        e.keysParsed = "keysParsed"
    }(Li || (Li = {}));
    const xi = /^#EXT-X-TARGETDURATION:(\d+)/im,
        ji = /^#EXT-X-KEY:[^\n]+URI="([^"]+)"/im,
        Ni = /^#EXT-X-KEY:.*(.*$)/gim;

    function loadManifestData(e) {
        return _loadManifestData.apply(this, arguments)
    }

    function _loadManifestData() {
        return (_loadManifestData = _async_to_generator$H((function*(e) {
            return (yield fetch(e)).text()
        }))).apply(this, arguments)
    }
    class Manifest extends Notifications {
        parse() {
            const e = this._item,
                n = this._data;
            if (Xe !== He.FAIRPLAY || shouldForceAudioMse())
                if (this._detectKeyTags(), e.hasOffersHlsUrl) this._segmentList.extractHlsOffersSegments(n, e.assetURL);
                else if (e.isLiveRadioStation) {
                this._segmentList.extractLiveRadioSegments(n, e.assetURL);
                const [, s] = this._data.match(xi);
                xe.debug(`manifest: setting up manifest refresh interval at ${s} seconds`);
                const d = 1e3 * parseInt(s, 10);
                this._manifestRefreshInterval = setInterval(this.liveRadioRefresh, d)
            } else this._segmentList.extractByteRangeSegments(n, e.assetURL)
        }
        static load(e, n = !0) {
            var s = this;
            return _async_to_generator$H((function*() {
                xe.debug("loading manifest for item", e.title);
                const d = e.assetURL;
                let p;
                const h = getSessionStorage(),
                    y = !!h && n;
                if (y && (p = null == h ? void 0 : h.getItem(d), p)) return new s(p, e);
                const _ = (new Date).getTime();
                p = yield loadManifestData(d);
                const m = new s(p, e);
                return m.downlink = function(e, n) {
                    return 8 * n.length / (((new Date).getTime() - e) / 1e3) / 1024
                }(_, p), y && (null == h || h.setItem(d, p)), Promise.resolve(m)
            }))()
        }
        get downlink() {
            return this._downlink
        }
        set downlink(e) {
            this._downlink = e
        }
        get mediaItem() {
            return this._item
        }
        liveRadioRefresh() {
            var e = this;
            return _async_to_generator$H((function*() {
                const n = yield loadManifestData(e._url);
                e._data = n, e._detectKeyTags(), e._segmentList.extractLiveRadioSegments(n, e._url), e.dispatchEvent(Ye.manifestParsed)
            }))()
        }
        segmentsForTimeRange(e) {
            const n = Math.floor(e.start / 10) + 1,
                s = Math.floor(e.end / 10) + 1,
                {
                    segments: d
                } = this;
            return [d[0], ...d.slice(n, s + 1)]
        }
        get segments() {
            return this._segmentList.segments
        }
        get extURI() {
            if (!this._extURI) {
                const e = this._data.match(ji);
                xe.debug("manifest: EXT_X_KEY_URI matches", e), this._extURI = e && e[1] || void 0
            }
            return this._extURI
        }
        get keyValues() {
            let e = this._modernKeys;
            return e.length || (e = this._legacyKeys), e
        }
        _detectKeyTags() {
            const e = this.keyValues;
            e.length && this.dispatchEvent(Li.keysParsed, {
                item: this.mediaItem,
                keys: e
            })
        }
        get _legacyKeys() {
            const e = this._data.match(ji);
            xe.debug("manifest: EXT_X_KEY_URI matches", e);
            const n = e && e[1] || void 0;
            this._extURI = n;
            const s = [];
            return n && s.push({
                keyFormat: Je.WIDEVINE,
                dataUri: n
            }), s
        }
        get _modernKeys() {
            let e;
            const n = [];
            for (; e = Ni.exec(this._data);) {
                var s, d;
                const y = e[0];
                var p;
                const _ = null !== (p = null === (s = /KEYFORMAT="(.*?)"/.exec(y)) || void 0 === s ? void 0 : s[1]) && void 0 !== p ? p : "";
                var h;
                const m = null !== (h = null === (d = /URI="(.*?)"/.exec(y)) || void 0 === d ? void 0 : d[1]) && void 0 !== h ? h : "";
                _ && m && n.push({
                    keyFormat: _,
                    dataUri: m
                })
            }
            return n
        }
        stop() {
            this._manifestRefreshInterval && clearInterval(this._manifestRefreshInterval)
        }
        constructor(e, n) {
            super([Ye.manifestParsed, Li.keysParsed]), _define_property$13(this, "_data", void 0), _define_property$13(this, "_downlink", 0), _define_property$13(this, "_extURI", void 0), _define_property$13(this, "_url", void 0), _define_property$13(this, "_item", void 0), _define_property$13(this, "_segmentList", new SegmentList), _define_property$13(this, "_manifestRefreshInterval", void 0), this._data = e, this._item = n, this._url = n.assetURL
        }
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$j("design:type", Function), _ts_metadata$j("design:paramtypes", []), _ts_metadata$j("design:returntype", Promise)], Manifest.prototype, "liveRadioRefresh", null);
    const Ui = "seamlessAudioTransition",
        Fi = "bufferTimedMetadataDidChange",
        Bi = "loadSegmentError";

    function encodedArrayToString(e, n = "utf-8") {
        return "iso-8859-1" === n ? String.fromCharCode(...e) : new TextDecoder(n).decode(e)
    }

    function readNullTerminatedString(e, n = 0, s) {
        const d = [];
        s = null != s ? s : e.length;
        for (let p = n; p < s; p++) {
            const n = e[p];
            if ("\0" === String.fromCharCode(n)) break;
            d.push(String.fromCharCode(n))
        }
        return [d.join(""), d.length]
    }

    function _define_property$12(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class BaseMp4Box {
        get size() {
            return this.end - this.start
        }
        get rawBytes() {
            return this.data.slice(this.start, this.end)
        }
        constructor(e, n, s, d) {
            _define_property$12(this, "id", void 0), _define_property$12(this, "data", void 0), _define_property$12(this, "start", void 0), _define_property$12(this, "end", void 0), this.id = e, this.data = n, this.start = s, this.end = d
        }
    }
    const Ki = [237, 239, 139, 169, 121, 214, 74, 206, 163, 200, 39, 220, 213, 29, 33, 237];
    class PsshBox extends BaseMp4Box {
        get systemId() {
            const {
                data: e,
                start: n
            } = this, s = n + 12;
            return e.slice(s, s + 16)
        }
        get dataSize() {
            return this.view.getUint32(28)
        }
        get psshData() {
            const {
                data: e,
                start: n,
                dataSize: s
            } = this, d = n + 32;
            return e.slice(d, d + s)
        }
        get keyBytes() {
            const {
                psshData: e
            } = this;
            return e.slice(2, 18)
        }
        get isWidevine() {
            return arrayEquals(this.systemId, Ki)
        }
        constructor(e, n, s) {
            super("pssh", e, n, s),
                function(e, n, s) {
                    n in e ? Object.defineProperty(e, n, {
                        value: s,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[n] = s
                }(this, "view", void 0), this.view = new DataView(e.buffer, n)
        }
    }

    function _define_property$10(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class TencBox extends BaseMp4Box {
        get isProtected() {
            const {
                data: e,
                start: n
            } = this;
            return e[n + 14]
        }
        get defaultKeyId() {
            const {
                data: e,
                start: n
            } = this;
            return e.slice(n + 16, n + 32)
        }
        set defaultKeyId(e) {
            const {
                data: n,
                start: s
            } = this;
            for (let d = 0; d < e.length; d++) n[d + s + 16] = e[d]
        }
        constructor(e, n, s) {
            super("tenc", e, n, s), _define_property$10(this, "data", void 0), _define_property$10(this, "start", void 0), _define_property$10(this, "end", void 0), this.data = e, this.start = n, this.end = s
        }
    }

    function findBox(e, n, s = []) {
        for (let d = n; d < e.length;) {
            if (0 === s.length) return;
            const n = new DataView(e.buffer, d).getUint32(0),
                p = encodedArrayToString(e.subarray(d + 4, d + 8)),
                h = d + n;
            if (1 === s.length && p === s[0]) return new BaseMp4Box(p, e, d, h);
            if (p === s[0]) return findBox(e, d + 8, s.slice(1));
            d += n
        }
    }
    const rewriteDefaultKid = e => {
        const [n] = function(e) {
            const n = findBox(e, 0, ["moov", "trak", "mdia", "minf", "stbl", "stsd"]),
                s = [];
            if (!n) return s;
            for (let d = n.start + 16; d < n.end;) {
                let p = findBox(e, d, ["enca"]),
                    h = 36;
                if (p || (p = findBox(e, d, ["encv"]), h = 86), !p) return s;
                const y = findBox(e, p.start + h, ["sinf", "schi", "tenc"]);
                y ? (s.push(new TencBox(y.data, y.start, y.end)), d = y.end) : d = n.end
            }
            return s
        }(e);
        if (!n) return;
        const s = function(e) {
            const n = findBox(e, 0, ["moov"]),
                s = [];
            if (!n) return s;
            const d = new DataView(e.buffer, 0);
            for (let p = n.start + 8; p < n.size;) {
                const n = d.getUint32(p);
                "pssh" === encodedArrayToString(e.subarray(p + 4, p + 8)) && s.push(new PsshBox(e, p, p + n)), p += n
            }
            return s
        }(e).find(e => e.isWidevine);
        s && (n.defaultKeyId = s.keyBytes)
    };

    function _define_property$$(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class ID3Tag {
        get major() {
            return this.version[0]
        }
        get minor() {
            return this.version[1]
        }
        get revision() {
            var e;
            return null !== (e = this.version[2]) && void 0 !== e ? e : 0
        }
        static parse(e) {
            return function(e) {
                if (0 === e.length || "ID3" !== function(e, n = 0) {
                        return decodeString(e.subarray(n, 3))
                    }(e)) return;
                const n = {};
                let s = 3;
                n.version = [3, e[s++], e[s++]], n.flags = function(e, n = 5) {
                    const s = e[n];
                    return {
                        unsynchronized: decodeBitFlag(s, 7),
                        extendedHeader: decodeBitFlag(s, 6),
                        experimental: decodeBitFlag(s, 5),
                        footer: decodeBitFlag(s, 4)
                    }
                }(e), s += 1;
                const d = s + 4 + decodeSynchSafeUint32(e.subarray(s, s + 4));
                s += 4, n.flags.extendedHeader && (s += decodeSynchSafeUint32(e.subarray(s, s + 4)));
                n.version[1] > 2 && (n.frames = decodeID3Frames(e, n.version, [s, d]));
                return new ID3Tag(n)
            }(e)
        }
        constructor(e) {
            var n;
            _define_property$$(this, "version", [3, 2, 0]), _define_property$$(this, "frames", []), _define_property$$(this, "flags", {
                unsynchronized: !1,
                extendedHeader: !1,
                footer: !1,
                experimental: !1
            }), this.version = e.version, this.flags = function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$$(e, n, s[n])
                    }))
                }
                return e
            }({
                unsynchronized: !1,
                extendedHeader: !1,
                footer: !1,
                experimental: !1
            }, e.flags), this.frames = null !== (n = e.frames) && void 0 !== n ? n : []
        }
    }
    const Gi = {
        WXXX: function(e, n, s) {
            const d = decodeCharset(n[0]),
                [p, h] = decodeNullTerminatedString(n.subarray(1), d),
                y = h > 0 ? h + 2 : 0;
            return {
                key: "WXXX",
                data: decodeString(n.subarray(y), d),
                description: p
            }
        },
        TXXX: function(e, n, s) {
            const d = decodeCharset(n[0]),
                [p, h] = decodeNullTerminatedString(n.subarray(1), d),
                y = h > 0 ? h + 2 : 0;
            return {
                key: "TXXX",
                data: decodeString(n.subarray(y), d),
                description: p
            }
        },
        TPE1: function(e, n, s) {
            return {
                key: "TPE1",
                data: trimNull(decodeString(n.subarray(1), decodeCharset(n[0])))
            }
        },
        TIT2: function(e, n, s) {
            return {
                key: "TIT2",
                data: trimNull(decodeString(n.subarray(1), decodeCharset(n[0])))
            }
        },
        TALB: function(e, n, s) {
            return {
                key: "TALB",
                data: trimNull(decodeString(n.subarray(1), decodeCharset(n[0])))
            }
        },
        TEXT: function(e, n, s) {
            return {
                key: "TEXT",
                data: trimNull(decodeString(n.subarray(1), decodeCharset(n[0])))
            }
        },
        PRIV: function(e, n, s) {
            const [d, p] = decodeNullTerminatedString(n);
            if (0 === p) return;
            return {
                key: "PRIV",
                owner: d,
                data: n.slice(p + 1)
            }
        },
        CHAP: function(e, n, s) {
            const d = new DataView(n.buffer),
                p = {
                    key: "CHAP",
                    elementId: "",
                    startTime: 0,
                    endTime: 0,
                    frames: []
                },
                [h, y] = decodeNullTerminatedString(n);
            p.elementId = h;
            let _ = y + 1;
            return p.startTime = d.getUint32(_), _ += 4, p.endTime = d.getUint32(_), _ += 4, p.startOffset = d.getUint32(_), _ += 4, p.endOffset = d.getUint32(_), _ += 4, p.frames = decodeID3Frames(n, s, [_, n.length]), p
        }
    };

    function decodeID3Frames(e, n, s) {
        var d;
        const p = null !== (d = (s = null != s ? s : [0, e.byteLength])[1]) && void 0 !== d ? d : e.byteLength;
        var h;
        let y = null !== (h = s[0]) && void 0 !== h ? h : 0;
        const _ = new DataView(e.buffer, 0, p),
            m = [];
        for (; y + 8 <= p;) {
            var v;
            const s = decodeString(e.subarray(y, y + 4));
            y += 4;
            const d = 4 === n[1] ? decodeSynchSafeUint32(e.subarray(y, y + 4)) : _.getUint32(y);
            if (y += 4, e[y++], e[y++], y + d > p) break;
            const h = e.slice(y, y + d),
                g = null === (v = Gi[s]) || void 0 === v ? void 0 : v.call(Gi, s, h, n);
            g && m.push(g), y += d
        }
        return m
    }

    function decodeString(e, n = "utf-8") {
        return new TextDecoder(n).decode(e)
    }

    function decodeBitFlag(e, n) {
        return 0 != (e & 1 << n)
    }
    const Vi = {
        0: "iso-8859-1",
        1: "utf-16",
        2: "utf-16be",
        3: "utf-8"
    };

    function decodeCharset(e) {
        var n;
        return null !== (n = Vi[e]) && void 0 !== n ? n : "iso-8859-1"
    }

    function trimNull(e) {
        return e.replace(/^\0*|\0*/g, "")
    }

    function decodeNullTerminatedString(e, n = "utf-8", s = 0) {
        const d = [];
        for (let p = s; p < e.byteLength; p++) {
            const n = e[p];
            if (0 === n) break;
            d.push(n)
        }
        return [decodeString(new Uint8Array(d), n), d.length]
    }

    function decodeSynchSafeUint32(e) {
        return 2097152 * (127 & e[0]) + 16384 * (127 & e[1]) + 128 * (127 & e[2]) + (127 & e[3])
    }

    function checkBoxName(e, n, s) {
        return !(n + 4 > e.length) && (e[n] === s[0] && e[n + 1] === s[1] && e[n + 2] === s[2] && e[n + 3] === s[3])
    }

    function findEmsgs(e) {
        const n = e.length,
            s = [];
        if (function(e) {
                return (null == e ? void 0 : e.length) >= 8 && checkBoxName(e, 4, [102, 116, 121, 112])
            }(e)) return s;
        for (let d = 0; d < n; d++) {
            if (checkBoxName(e, d, [109, 111, 111, 102])) return s;
            if (checkBoxName(e, d, [101, 109, 115, 103])) {
                const n = d - 4,
                    p = new DataView(e.buffer, n).getUint32(0),
                    h = e.subarray(n, n + p);
                d = d + p - 1, s.push(h)
            }
        }
        return s
    }

    function _define_property$_(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class TimedMetadata {
        storefrontAdamId(e) {
            var n;
            return null === (n = this.storefrontAdamIds) || void 0 === n ? void 0 : n[e]
        }
        equals(e) {
            return function(e, n) {
                var s, d, p, h;
                if (void 0 === e && void 0 === n) return !0;
                if (typeof e != typeof n) return !1;
                if (n = n, (e = e).album !== n.album || e.title !== n.title || e.performer !== n.performer) return !1;
                if ((null === (s = e.links) || void 0 === s ? void 0 : s.length) !== (null === (d = n.links) || void 0 === d ? void 0 : d.length)) return !1;
                for (let m = 0; m < (null !== (h = null === (p = e.links) || void 0 === p ? void 0 : p.length) && void 0 !== h ? h : 0); m++) {
                    var y, _;
                    if (!objectKeyValueEquals(null === (y = e.links) || void 0 === y ? void 0 : y[m], null === (_ = n.links) || void 0 === _ ? void 0 : _[m])) return !1
                }
                if (!objectKeyValueEquals(e.storefrontAdamIds, n.storefrontAdamIds)) return !1;
                if (!compareUint8Array(e.blob, n.blob)) return !1;
                return !0
            }(this, e)
        }
        constructor(e) {
            var n;
            _define_property$_(this, "performer", void 0), _define_property$_(this, "title", void 0), _define_property$_(this, "album", void 0), _define_property$_(this, "links", void 0), _define_property$_(this, "storefrontAdamIds", void 0), _define_property$_(this, "blob", void 0), this.performer = null == e ? void 0 : e.performer, this.title = null == e ? void 0 : e.title, this.album = null == e ? void 0 : e.album, this.links = null == e ? void 0 : e.links, this.storefrontAdamIds = null !== (n = null == e ? void 0 : e.storefrontAdamIds) && void 0 !== n ? n : {}, this.blob = null == e ? void 0 : e.blob
        }
    }

    function objectKeyValueEquals(e, n) {
        if (void 0 === e && void 0 === n) return !0;
        if (typeof e != typeof n) return !1;
        e = e, n = n;
        const s = Object.keys(e),
            d = Object.keys(n);
        if (s.length !== d.length) return !1;
        for (const p of s)
            if (e[p] !== n[p]) return !1;
        return !0
    }

    function parseStorefrontAdamIds(e) {
        let n;
        n = "Uint8Array" === e.constructor.name ? new TextDecoder("utf-8").decode(e) : e;
        const s = n.trim().split(",");
        if (0 === s.length) return;
        const isEmptyString = e => void 0 === e || "" === e,
            d = {};
        for (const p of s) {
            const [e, n] = p.split(":", 2).map(e => e.trim());
            isEmptyString(e) || isEmptyString(n) || "0" === n || void 0 !== d[e] || (d[e] = n)
        }
        return d
    }

    function parsePingBlob(e) {
        return "string" == typeof e ? Uint8Array.from(atob(e), e => e.charCodeAt(0)) : e
    }

    function _define_property$Z(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class Emsg {
        get length() {
            return this.data.length
        }
        get elementPresentationTime() {
            const {
                presentationTime: e,
                timeScale: n
            } = this;
            return e && n ? Math.round(e / n) : NaN
        }
        get timedMetadata() {
            var e;
            if (this._timedMetadata) return this._timedMetadata;
            const n = null === (e = this.id3) || void 0 === e ? void 0 : e.frames;
            return n ? (this._timedMetadata = function(e) {
                const n = {};
                for (const d of e)
                    if (void 0 !== d.key) switch (d.key) {
                        case "TALB":
                            n.album = d.data;
                            break;
                        case "TIT2":
                            n.title = d.data;
                            break;
                        case "TPE1":
                            n.performer = d.data;
                            break;
                        case "WXXX":
                            var s;
                            if (void 0 !== d.description)
                                if (void 0 === n.links && (n.links = []), !n.links.some(e => e.url === d.data)) n.links.push({
                                    description: null !== (s = d.description) && void 0 !== s ? s : "",
                                    url: d.data
                                });
                            break;
                        case "PRIV":
                            "com.apple.radio.adamid" === d.owner && (n.storefrontAdamIds = parseStorefrontAdamIds(d.data)), "com.apple.radio.ping.jingle" === d.owner && (n.blob = parsePingBlob(d.data))
                    }
                return new TimedMetadata(n)
            }(n), this._timedMetadata) : void 0
        }
        constructor(e) {
            _define_property$Z(this, "data", void 0), _define_property$Z(this, "schemeIdUri", void 0), _define_property$Z(this, "eventDuration", void 0), _define_property$Z(this, "presentationTime", void 0), _define_property$Z(this, "payload", void 0), _define_property$Z(this, "timeScale", void 0), _define_property$Z(this, "id3", void 0), _define_property$Z(this, "id", void 0), _define_property$Z(this, "_timedMetadata", void 0), this.data = e;
            const n = new DataView(e.buffer);
            let s = 8;
            if (1 !== e[s]) return;
            s += 4, this.timeScale = n.getUint32(s), s += 4;
            const d = n.getUint32(s);
            s += 4;
            const p = n.getUint32(s);
            if (s += 4, this.presentationTime = Math.pow(2, 32) * d + p, !Number.isSafeInteger(this.presentationTime)) throw this.presentationTime = Number.MAX_SAFE_INTEGER, new Error("Failed to create 64 bit integer");
            this.eventDuration = n.getUint32(s), s += 4, this.id = n.getUint32(s), s += 4;
            const [h, y] = readNullTerminatedString(e, s);
            s += y + 1, this.schemeIdUri = h;
            const [_, m] = readNullTerminatedString(e, s);
            s += m + 1, this.payload = e.subarray(s, e.byteLength), this.id3 = ID3Tag.parse(this.payload)
        }
    }

    function _define_property$Y(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class TimedMetadataManager {
        processEmsgs(e) {
            const n = findEmsgs(e);
            n.length && (this._currentEmsgInterval || (this._currentEmsgInterval = setInterval(this._getCurrentEmsg, 1e3)), n.forEach(e => {
                const n = new Emsg(e);
                this._emsgLookup[n.elementPresentationTime] = n
            }))
        }
        stop() {
            const {
                _currentEmsgInterval: e
            } = this;
            e && clearInterval(e)
        }
        _getCurrentEmsg() {
            const {
                _currentTime: e,
                _emsgLookup: n
            } = this, s = Math.round(e()), d = [], p = Object.keys(n);
            for (let y = 0; y < p.length; y++) {
                const e = parseInt(p[y], 10);
                if (!(e < s)) break;
                d.push(e)
            }
            const h = d.pop();
            if (h) {
                const e = n[h];
                if (!e) return;
                const {
                    _currentEmsg: s,
                    _onDidChange: d
                } = this, p = null == s ? void 0 : s.payload, y = e.payload;
                p && arrayEquals(p, y) || (this._currentEmsg = e, d(e)), this._cleanupEmsgs(h)
            }
        }
        _cleanupEmsgs(e) {
            const {
                _emsgLookup: n
            } = this;
            Object.keys(n).forEach(s => {
                parseInt(s, 10) < e && delete n[s]
            })
        }
        constructor(e, n) {
            _define_property$Y(this, "_currentTime", void 0), _define_property$Y(this, "_onDidChange", void 0), _define_property$Y(this, "_currentEmsgInterval", void 0), _define_property$Y(this, "_emsgLookup", void 0), _define_property$Y(this, "_currentEmsg", void 0), this._currentTime = e, this._onDidChange = n, this._emsgLookup = {}, this._getCurrentEmsg = this._getCurrentEmsg.bind(this)
        }
    }

    function _define_property$X(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class SegmentProcessor {
        process(e, n) {
            const {
                _item: s
            } = this;
            try {
                s.isLiveRadioStation ? this._processLiveRadioSegment(e, n) : s.hasOffersHlsUrl && this._processHlsOffersSegment(e, n)
            } catch (Rt) {
                xe.error("Error processing segment", Rt)
            }
        }
        stop() {
            this._timedMetadataManager.stop()
        }
        _processHlsOffersSegment(e, n) {
            e.isInitSegment && rewriteDefaultKid(n)
        }
        _processLiveRadioSegment(e, n) {
            e.isInitSegment && rewriteDefaultKid(n), this._timedMetadataManager.processEmsgs(n)
        }
        constructor(e, n, s) {
            _define_property$X(this, "_item", void 0), _define_property$X(this, "_timedMetadataManager", void 0), this._item = e, this._timedMetadataManager = new TimedMetadataManager(() => n.currentTime, e => {
                s.publish(Fi, {
                    item: this._item,
                    metadata: e.timedMetadata,
                    position: n.currentTime,
                    playingDate: void 0
                })
            })
        }
    }

    function asyncGeneratorStep$G(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$G(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$G(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$G(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$W(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$i(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$i(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    const Hi = xe.createChild("mse"),
        qi = BooleanDevFlag.get("mk-mse-buffer"),
        {
            manifestParsed: Wi
        } = Ye;
    class MseBuffer {
        onSourceOpen() {
            Hi.debug("mediaSource open handler");
            const {
                mediaSource: e
            } = this;
            if (e.activeSourceBuffers.length > 0) return void Hi.debug("not adding new source buffer");
            Hi.debug("adding new source buffer");
            const n = e.addSourceBuffer(ze);
            this.sourceBuffer = n, n.addEventListener("updateend", this.updateEndHandler);
            const {
                clip: s,
                hasAppendWindowSupport: d
            } = this;
            s && (d ? (Hi.debug("appendWindowStart/End", s.start, s.end), n.appendWindowStart = s.start, n.appendWindowEnd = s.end) : (Hi.debug("seeking for clip", s.start), asAsync(this.seek(s.start)))), this.updateSegmentToFetch(0, !0)
        }
        setNextManifest(e) {
            Hi.debug("setting next manifest for ", e.mediaItem.title), this.nextSeamlessTransition ? (Hi.debug("abandoning transition scheduled for " + this.nextSeamlessTransition), this.revertSeamlessTransition(!0), this.playbackTimeline.next = {
                manifest: e
            }) : (this.playbackTimeline.next = {
                manifest: e
            }, this.isFullyBuffered && (Hi.debug("current song is fully buffered, beginning transition to next"), this.transitionToNextManifest()))
        }
        isItemPlaying(e) {
            var n, s;
            const {
                playbackTimeline: d
            } = this, p = this.nextSeamlessTransition ? null === (n = d.previous) || void 0 === n ? void 0 : n.manifest.mediaItem : null === (s = d.current) || void 0 === s ? void 0 : s.manifest.mediaItem;
            return !!p && (Hi.debug(`isItemPlaying ${e.title}, ${p.title}, ${e.id===p.id}`), e.id === p.id)
        }
        get currentItem() {
            return this.manifest.mediaItem
        }
        get playableUrl() {
            let e = this._playableUrl;
            return e || (e = window.URL.createObjectURL(this.mediaSource), Hi.debug("created url", e), this._playableUrl = e, e)
        }
        get segments() {
            const {
                manifest: e,
                clip: n
            } = this;
            return n ? e.segmentsForTimeRange(n) : e.segments || []
        }
        get currentTime() {
            return this._currentTime
        }
        set currentTime(e) {
            if (e += this.currentTimestampOffset, this._currentTime === e) return;
            const {
                nextSeamlessTransition: n
            } = this;
            if (n && e >= n) {
                var s, d;
                Hi.debug("setting offset to", n), this.currentTimestampOffset = n || 0, this.nextSeamlessTransition = void 0, this.duration = this.manifest.mediaItem.playbackDuration / 1e3, Hi.debug("buffer setting duration to", this.duration);
                const e = {
                    previous: null === (d = this.playbackTimeline.previous) || void 0 === d || null === (s = d.manifest) || void 0 === s ? void 0 : s.mediaItem,
                    current: this.manifest.mediaItem
                };
                Hi.debug("dispatching seamless audio transition", e), this.dispatcher.publish(Ui, e)
            }
            this._currentTime = e;
            const {
                isOverBufferLimit: p,
                timeToTrim: h
            } = this, y = e > this.timeToTrim;
            p && y && (Hi.debug("buffer over limit, trimming to ", h), this.removeToTime(h), this.timeToTrim += 10)
        }
        get hasAppendWindowSupport() {
            var e;
            return void 0 !== (null === (e = this.sourceBuffer) || void 0 === e ? void 0 : e.appendWindowStart)
        }
        seek(e) {
            var n = this;
            return _async_to_generator$G((function*() {
                const {
                    duration: s,
                    seekWhenUpdated: d,
                    sourceBuffer: p
                } = n;
                if (n.resolveSeekPromise(!1), Hi.debug("seek to ", e), (e = +e) > s && (Hi.debug("rounding seek time to duration", e, s), e = s), !p) return !1;
                if (n.revertSeamlessTransition(), p.updating) return Hi.debug("sourcebuffer updating, deferring seek"), new Promise(s => {
                    d && d.resolve(!1), n.seekWhenUpdated = {
                        seek: n.seek.bind(n, e),
                        resolve: s
                    }
                });
                n.currentlyLoadingSegmentIndex = void 0, n.updateSegmentToFetch(0, !0), n.removeToTime(e), n.timeToTrim = 10 * Math.floor(e / 10);
                const h = n.getSegmentForTime(e);
                0 !== h && (yield n.firstSegmentLoadPromise), Hi.debug("seeking to", e, "segment", h), n.updateSegmentToFetch(h, !0);
                const y = new Promise(s => {
                    n.seekResolver = {
                        time: e,
                        resolve: s
                    }
                });
                return n.checkSeekBuffered(), y
            }))()
        }
        clearNextManifest() {
            this.revertSeamlessTransition(!0), this.playbackTimeline.next = void 0
        }
        revertSeamlessTransition(e = !1) {
            const {
                playbackTimeline: n,
                nextSeamlessTransition: s
            } = this;
            if (!s || !n.previous) return void Hi.debug("no need to revert, no transition");
            this.isAtEndOfStream = e, Hi.debug("reverting seamless transition with discardNextManifest", e), e ? this.clearBufferToEnd(s) : this.clearBuffer(), Hi.debug("abandoning transition to " + this.manifest.mediaItem.title), n.next = e ? void 0 : n.current, n.current = n.previous, n.previous = void 0;
            const d = this.manifest.mediaItem;
            Hi.debug("current item reverted to " + d.title), this.nextSeamlessTransition = void 0, this.duration = d.playbackDuration / 1e3, Hi.debug("reverted duration to " + this.duration), e || (this.currentTimestampOffset = 0, this.timestampOffsetAdjustment = 0, Hi.debug("reverted currentTimestampOffset and timestampOffsetAdjustment to 0")), this.printInfo(), this.segmentIndexToFetch = -1
        }
        get streamHasEnding() {
            return !this.manifest.mediaItem.isLiveRadioStation
        }
        stop() {
            this.segmentProcessor.stop(), this.setEndOfStream(), this.remove()
        }
        remove() {
            var e;
            Hi.debug("removing sourceBuffer and mediaSource");
            const {
                sourceBuffer: n,
                mediaSource: s
            } = this;
            null === (e = this.seekResolver) || void 0 === e || e.resolve(!1), this.manifest.removeEventListener(Wi, this.onManifestParsed);
            const d = this._playableUrl;
            d && (Hi.debug("revoking url", d), window.URL.revokeObjectURL(d)), s.removeEventListener("sourceopen", this.onSourceOpen), n && (n.removeEventListener("updateend", this.updateEndHandler), this.sourceBuffer = void 0)
        }
        onManifestParsed() {
            const e = this.segmentIndexToFetch + 1;
            Hi.debug("manifestParsed, loading segment", e), this.updateSegmentToFetch(e, !0)
        }
        updateEndHandler() {
            if (this.kickstartBuffer(), this.clearDeferredRemove()) return;
            if (Hi.debug("update end", this.seekWhenUpdated), this.seekWhenUpdated) {
                Hi.debug("updateEndHandler resolving seekWhenUpdated");
                const {
                    seekWhenUpdated: e
                } = this;
                return asAsync(e.seek().then(e.resolve)), void(this.seekWhenUpdated = void 0)
            }
            this.checkSeekBuffered();
            const {
                clip: e,
                sourceBuffer: n,
                hasAppendWindowSupport: s
            } = this;
            if (e && n && !s) {
                const {
                    buffered: s
                } = n;
                if (this.isTimeBuffered(e.end + 1)) {
                    const d = s.end(s.length - 1);
                    return Hi.debug("clipping sourcebuffer to", e.end, d), void n.remove(e.end, d)
                }
            }
            if (this.isAtEndOfStream) return Hi.debug("buffer is at end of stream"), this.streamHasEnding && (Hi.debug("isAtEndOfStream, not fetching any more segments"), this.playbackTimeline.next || this.setEndOfStream(), this.transitionToNextManifest()), void(this.isAtEndOfStream = !1);
            Hi.debug("updateEndHandler invoking loadSegment"), asAsync(this.loadSegment())
        }
        clearDeferredRemove() {
            if (0 === this.deferredRemoves.length) return !1;
            const e = this.deferredRemoves.shift();
            var n;
            (Hi.trace("clearDeferredRemove", e), e.end > e.start) ? null === (n = this.sourceBuffer) || void 0 === n || n.remove(e.start, e.end): e.end <= e.start && Hi.warn(`Trying to remove an invalid time range from SourceBuffer: |${e.start} <=> ${e.end}| (${e.end-e.start})`);
            return !0
        }
        transitionToNextManifest() {
            var e;
            Hi.debug("beginning transition to next manifest");
            const {
                playbackTimeline: n,
                sourceBuffer: s
            } = this;
            if (!n.next || !s) return void Hi.debug("no next manifest");
            const d = this.endOfBufferTime || this.currentTimestampOffset;
            Hi.debug("setting seamless transition at", d), this.nextSeamlessTransition = d, this.timestampOffsetAdjustment = d, this.playbackTimeline.current.endTime = d, n.previous = n.current, Hi.debug("previous manifest set to", null === (e = n.previous) || void 0 === e ? void 0 : e.manifest.mediaItem.title), n.current = n.next, Hi.debug("current manifest set to", n.current.manifest.mediaItem.title), n.next = void 0, this.updateSegmentToFetch(0, !0), this.printInfo()
        }
        updateSegmentToFetch(e, n = !1) {
            this.segments.length && e < this.segments.length && e !== this.segmentIndexToFetch && (this.segmentIndexToFetch = e, n && (Hi.debug("updateSegmentToFetch invoking loadSegment"), asAsync(this.loadSegment())))
        }
        loadSegment() {
            var e = this;
            return _async_to_generator$G((function*() {
                const n = e.segmentIndexToFetch,
                    s = e.segments[n];
                if (n !== e.currentlyLoadingSegmentIndex) {
                    if (s) try {
                        Hi.debug("begin loadSegment " + n), e.currentlyLoadingSegmentIndex = n;
                        const p = s.load();
                        0 === n && (e.firstSegmentLoadPromise = p);
                        const h = yield p;
                        if (0 !== n && n !== e.segmentIndexToFetch) return void Hi.debug("load segment index to fetch changed, not processing bytes for segment", n);
                        e.segmentProcessor.process(s, h), Hi.debug("loadSegment processed: " + n);
                        const {
                            sourceBuffer: y,
                            timestampOffsetAdjustment: _
                        } = e;
                        if (!y) return;
                        try {
                            "number" == typeof _ && (Hi.debug("adjusting timestampOffset of sourcebuffer to", _), y.timestampOffset = _, e.timestampOffsetAdjustment = void 0), y.appendBuffer(h), e.isFullyBuffered = !1, e.isOverBufferLimit = !1, Hi.debug("appended to buffer", h.length), e.printBufferTimes(), n === e.segments.length - 1 ? e.isAtEndOfStream = !0 : n === e.segmentIndexToFetch && (Hi.debug("loadSegment bumping segment index to fetch to ", n + 1), e.updateSegmentToFetch(n + 1))
                        } catch (d) {
                            "QuotaExceededError" === d.name ? (e.isOverBufferLimit = !0, Hi.debug("reached buffer limit")) : Hi.warn("Error appending to source buffer", d)
                        }
                    } catch (Rt) {
                        Hi.error("Error loading segment", Rt), e.dispatcher.publish(Bi, Rt)
                    } finally {
                        e.currentlyLoadingSegmentIndex = void 0
                    }
                } else Hi.debug(`segment ${n} is currently loading, not loading it again`)
            }))()
        }
        setEndOfStream() {
            const {
                sourceBuffer: e,
                mediaSource: n
            } = this;
            e && "ended" !== n.readyState && (e.updating || "open" !== n.readyState ? Hi.error("Could not end of stream (updating, readyState)", e.updating, n.readyState) : (Hi.debug("mediaSource.endOfStream"), n.endOfStream(), this.isFullyBuffered = !0))
        }
        removeToTime(e) {
            Hi.debug("removing to time", e), e > 0 && (this.isTimeBuffered(e) || this.isOverBufferLimit) && this.safeSourceBufferRemove(0, e)
        }
        safeSourceBufferRemove(e, n) {
            Hi.trace("safeSourceBufferRemove", e, n);
            const {
                sourceBuffer: s
            } = this;
            s && (s.updating ? this.deferredRemoves.push({
                start: e,
                end: n
            }) : n <= e ? Hi.warn(`Trying to remove an invalid time range from SourceBuffer: |${e} <=> ${n}| (${n-e})`) : s.remove(e, n))
        }
        get previousOffset() {
            var e, n;
            return (null === (n = this.playbackTimeline) || void 0 === n || null === (e = n.previous) || void 0 === e ? void 0 : e.endTime) || 0
        }
        get manifest() {
            var e;
            return null === (e = this.playbackTimeline.current) || void 0 === e ? void 0 : e.manifest
        }
        checkSeekBuffered() {
            const {
                seekResolver: e,
                currentTimestampOffset: n
            } = this;
            if (!e) return;
            const {
                time: s
            } = e, d = s + n, p = this.isTimeBuffered(d);
            Hi.debug("resolving seek for time, adjustedTime, isBuffered", s, d, p), this.printBufferTimes(), p && (Hi.debug("resolving seek to true for time:", d), this.element.currentTime = d, this.resolveSeekPromise(!0))
        }
        resolveSeekPromise(e) {
            this.seekResolver && (this.seekResolver.resolve(e), this.seekResolver = void 0)
        }
        get endOfBufferTime() {
            var e;
            const n = null === (e = this.sourceBuffer) || void 0 === e ? void 0 : e.buffered;
            return !(!n || !n.length) && n.end(n.length - 1)
        }
        isTimeBuffered(e) {
            var n;
            const s = null === (n = this.sourceBuffer) || void 0 === n ? void 0 : n.buffered;
            if (!s) return !1;
            for (let d = 0; d < s.length; d++)
                if (Hi.debug("isTimeBuffered", s.start(d), e, s.end(d)), e >= s.start(d) && e <= s.end(d)) return !0;
            return !1
        }
        clearBufferToEnd(e) {
            const {
                sourceBuffer: n
            } = this;
            if (!n || !n.buffered) return;
            const s = n.buffered.end(n.buffered.length - 1);
            this.safeSourceBufferRemove(e, s)
        }
        clearBuffer() {
            const {
                sourceBuffer: e
            } = this;
            if (!e || !e.buffered) return;
            const n = e.buffered;
            for (let s = 0; s < n.length; s++) this.safeSourceBufferRemove(n.start(s), n.end(s))
        }
        get bufferTimesString() {
            var e;
            const n = null === (e = this.sourceBuffer) || void 0 === e ? void 0 : e.buffered;
            if (!n) return "";
            const s = [];
            for (let d = 0; d < n.length; d++) s.push(`start ${n.start(d)} end: ${n.end(d)}`);
            return s.join(",")
        }
        printBufferTimes() {
            qi && Hi.debug("buffer times", this.bufferTimesString)
        }
        getSegmentForTime(e) {
            return Math.floor(e / 10) + 1
        }
        kickstartBuffer() {
            const {
                hasKickstarted: e,
                element: n,
                clip: s
            } = this, {
                buffered: d
            } = n;
            e || (this.manifest.mediaItem.isSong ? s && this.isTimeBuffered(s.start) && (n.currentTime = s.start, this.hasKickstarted = !0) : d.length && (n.currentTime = d.start(0), this.hasKickstarted = !0))
        }
        printInfo() {
            var e, n;
            const {
                playbackTimeline: s
            } = this;
            Hi.info("---- Buffer Info ----"), Hi.info("currently buffering item", s.current.manifest.mediaItem.title), Hi.info("next item to buffer", null === (e = s.next) || void 0 === e ? void 0 : e.manifest.mediaItem.title), Hi.info("previously buffered item", null === (n = s.previous) || void 0 === n ? void 0 : n.manifest.mediaItem.title), Hi.info("currentTimestampOffset", this.currentTimestampOffset), Hi.info("currentTime", this.currentTime), Hi.info("duration", this.duration), Hi.info("nextSeamlessTransition", this.nextSeamlessTransition), Hi.info("timestampOffsetAdjustment", this.timestampOffsetAdjustment), Hi.info("buffered times", this.bufferTimesString), Hi.info("isAtEndOfStream", this.isAtEndOfStream), Hi.info("isFullyBuffered", this.isFullyBuffered), Hi.info("segmentIndexToFetch", this.segmentIndexToFetch), Hi.info("segments.length", this.segments.length), Hi.info("---- End Buffer Info ----")
        }
        constructor({
            dispatcher: e,
            element: n,
            manifest: s,
            currentTime: d,
            duration: p,
            clip: h
        }) {
            _define_property$W(this, "dispatcher", void 0), _define_property$W(this, "mediaSource", void 0), _define_property$W(this, "sourceBuffer", void 0), _define_property$W(this, "element", void 0), _define_property$W(this, "_currentTime", void 0), _define_property$W(this, "currentlyLoadingSegmentIndex", void 0), _define_property$W(this, "duration", void 0), _define_property$W(this, "firstSegmentLoadPromise", Promise.resolve()), _define_property$W(this, "hasKickstarted", !1), _define_property$W(this, "isOverBufferLimit", void 0), _define_property$W(this, "seekResolver", void 0), _define_property$W(this, "seekWhenUpdated", void 0), _define_property$W(this, "segmentIndexToFetch", -1), _define_property$W(this, "segmentProcessor", void 0), _define_property$W(this, "timeToTrim", 10), _define_property$W(this, "isAtEndOfStream", !1), _define_property$W(this, "isFullyBuffered", !1), _define_property$W(this, "_playableUrl", void 0), _define_property$W(this, "clip", void 0), _define_property$W(this, "deferredRemoves", []), _define_property$W(this, "timestampOffsetAdjustment", void 0), _define_property$W(this, "playbackTimeline", void 0), _define_property$W(this, "currentTimestampOffset", 0), _define_property$W(this, "nextSeamlessTransition", void 0), this.dispatcher = e, this.clip = h, this.element = n, this.mediaSource = new MediaSource, this.mediaSource.addEventListener("sourceopen", this.onSourceOpen), this.segmentProcessor = new SegmentProcessor(s.mediaItem, n, e), this.playbackTimeline = {
                current: {
                    manifest: s
                }
            }, s.addEventListener(Wi, this.onManifestParsed), this._currentTime = d || 0, this.duration = p, window.mseBuffer = this
        }
    }

    function asyncGeneratorStep$F(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$F(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$F(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$F(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$V(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$h(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$h(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    _ts_decorate$i([Bind(), _ts_metadata$i("design:type", Function), _ts_metadata$i("design:paramtypes", []), _ts_metadata$i("design:returntype", void 0)], MseBuffer.prototype, "onSourceOpen", null), _ts_decorate$i([Bind(), _ts_metadata$i("design:type", Function), _ts_metadata$i("design:paramtypes", []), _ts_metadata$i("design:returntype", void 0)], MseBuffer.prototype, "onManifestParsed", null), _ts_decorate$i([Bind(), _ts_metadata$i("design:type", Function), _ts_metadata$i("design:paramtypes", []), _ts_metadata$i("design:returntype", void 0)], MseBuffer.prototype, "updateEndHandler", null);
    const {
        mediaPlaybackError: zi
    } = st;
    class AudioPlayer extends BasePlayer {
        destroy() {
            var e = this,
                _superprop_get_destroy = () => super.destroy;
            return _async_to_generator$F((function*() {
                _superprop_get_destroy().call(e), e._dispatcher.unsubscribe(Bi, e.onLoadSegmentError)
            }))()
        }
        onLoadSegmentError(e) {
            this._dispatcher.publish(zi, new MKError(MKError.Reason.MEDIA_SESSION, e)), this.destroy()
        }
        get currentPlayingDate() {}
        get isPlayingAtLiveEdge() {
            return !1
        }
        get seekableTimeRanges() {
            return this.currentPlaybackDuration ? [{
                start: 0,
                end: this.currentPlaybackDuration
            }] : void 0
        }
        get supportsPreviewImages() {
            return !1
        }
        get _targetElement() {
            return this.audio
        }
        initializeExtension() {
            var e = this;
            return _async_to_generator$F((function*() {
                e.extension = new MediaExtension(e.audio, ze), yield e.extension.initializeKeySystem(), e.extension.addEventListener(Ye.playbackLicenseError, n => {
                    e.resetDeferredPlay(), e._dispatcher.publish(zi, n)
                }), e.extension.addEventListener(Ye.playbackSessionError, n => {
                    e._dispatcher.publish(zi, new MKError(MKError.Reason.MEDIA_SESSION, n)), e.destroy()
                })
            }))()
        }
        initializeMediaElement() {
            var e = this;
            return _async_to_generator$F((function*() {
                const n = nextAvailableAudioElement();
                n.autoplay = !1, n.id = "apple-music-player", n.controls = !1, n.muted = !1, n.playbackRate = 1, n.preload = "metadata", n.volume = 1, e.audio = n, document.body.appendChild(n), xe.debug("initializedMediaElement", n)
            }))()
        }
        removeEventHandlers() {
            this._targetElement.removeEventListener("timeupdate", this.onTimeUpdate), this._targetElement.removeEventListener("timeupdate", this.delayedCdmUpdateCheck), super.removeEventHandlers()
        }
        stopMediaElement() {
            var e = this,
                _superprop_get_stopMediaElement = () => super.stopMediaElement;
            return _async_to_generator$F((function*() {
                var n;
                yield _superprop_get_stopMediaElement().call(e), yield e.tearDownManifests(), null === (n = e._buffer) || void 0 === n || n.stop(), e._buffer = void 0
            }))()
        }
        preloadItem(e) {
            var n = this;
            return _async_to_generator$F((function*() {
                const {
                    extension: s,
                    nextManifest: d
                } = n, p = n._buffer;
                if ("song" !== e.type || !p || !s || !n.isSeamlessAudioTransitionsEnabled) return;
                if ((null == d ? void 0 : d.mediaItem.id) === e.id) return void xe.debug("already have next manifest for ", e.title);
                n._targetElement.removeEventListener("timeupdate", n.onTimeUpdate), n._targetElement.addEventListener("timeupdate", n.onTimeUpdate), xe.debug("player preparing next manifest for", e.title);
                const h = yield n.loadAndParseManifest(e, !1);
                p.setNextManifest(h), s.setMediaItem(e), s.extURI = h.extURI, n.nextManifest = h
            }))()
        }
        playItemFromEncryptedSource(n, s = !1, d) {
            var p = this;
            return _async_to_generator$F((function*() {
                const h = p._paused && !s;
                xe.debug("playItemFromEncryptedSource", n.title);
                const y = h ? void 0 : p.startPlaybackSequence();
                if (n.playRawAssetURL) return n.playbackType = e.PlaybackType.unencryptedFull, p.nowPlayingItem = n, yield p._playAssetURL(n.assetURL, h), p.finishPlaybackSequence();
                const {
                    extension: _
                } = p;
                var m, v;
                p.delaySeamlessCdmUpdates && (null === (v = p.extension) || void 0 === v || null === (m = v.session) || void 0 === m || m.applyDelayedCdmUpdates());
                if (!_) return y;
                _.initiated = s, _.setMediaItem(n), n.playbackType = e.PlaybackType.encryptedFull, p.nowPlayingItem = n, n.state = ee.loading;
                const g = yield p.getManifestForItem(n);
                p.manifest = g;
                const b = shouldForceAudioMse();
                if ((n.isSong || _.isFairplay && b) && (_.extURI = g.extURI), n.state = ee.ready, _.isFairplay && !b) {
                    let e = n.assetURL;
                    (null == d ? void 0 : d.startTime) && (e += "#t=" + d.startTime), yield p._playAssetURL(e, h)
                } else {
                    const e = p._buffer;
                    e && p.isSeamlessAudioTransitionsEnabled && e.isItemPlaying(g.mediaItem) ? xe.debug("already have buffer, continuing playback") : yield p.beginNewBufferForItem(h, g, d)
                }
                return p.finishPlaybackSequence()
            }))()
        }
        getManifestForItem(e) {
            var n = this;
            return _async_to_generator$F((function*() {
                var s, d;
                xe.debug("reconciling item to play against playing item");
                const {
                    nextManifest: p,
                    manifest: h,
                    isSeamlessAudioTransitionsEnabled: y
                } = n, _ = n._buffer;
                if (!_ || !h) return xe.debug("no buffer or manifest, creating manifest [title, buffer, manifest]", e.title, !!_, !!h), n.loadAndParseManifest(e);
                if (!y) return xe.debug("seamless transitions disabled, stopping and creating manifest for", e.title), yield n.tearDownManifests(), n.loadAndParseManifest(e);
                const m = !_.isItemPlaying(e);
                let v;
                return xe.debug("itemMismatch", m), p && !m ? (xe.debug(`replacing manifest for ${h.mediaItem.title} with next manifest ${p.mediaItem.title}`), v = p, n.nextManifest = void 0, xe.debug("cease listening for keys on manifest for", h.mediaItem.title), yield n.tearDownManifest(h)) : m ? (null == p ? void 0 : p.mediaItem.id) !== e.id ? (xe.debug(`item to play ${e.title} does not match playing or next items, tearing down all manifests`), yield n.tearDownManifests(), v = yield n.loadAndParseManifest(e)) : (xe.debug(`item to play ${e.title} matches next item, tearing down current manifest`), yield n.tearDownManifest(h), v = p) : (xe.debug("item is already playing, returning existing manifest"), v = h), xe.debug("getManifestForItem loading keys for", h.mediaItem.title), null === (d = n.extension) || void 0 === d || null === (s = d.session) || void 0 === s || s.loadKeys(v.keyValues, v.mediaItem), v
            }))()
        }
        seekToTime(e) {
            var n = this;
            return _async_to_generator$F((function*() {
                const s = n._buffer;
                if (s) {
                    xe.debug("audio-player: buffer seek to", e);
                    if (!(yield s.seek(e))) return;
                    n.isSeamlessAudioTransitionsEnabled && n.onTimeUpdate()
                } else xe.debug("audio-player: media element seek to", e), n._targetElement.currentTime = e
            }))()
        }
        tearDownManifests() {
            var e = this;
            return _async_to_generator$F((function*() {
                e.manifest = yield e.tearDownManifest(e.manifest), e.nextManifest = yield e.tearDownManifest(e.nextManifest)
            }))()
        }
        tearDownManifest(e) {
            var n = this;
            return _async_to_generator$F((function*() {
                const {
                    extension: s
                } = n;
                e && (xe.debug("tearing down manifest for", e.mediaItem.title), e.stop(), s && (yield s.clearSessions(e.keyValues)), e.removeEventListener(Li.keysParsed, n.loadKeysHandler))
            }))()
        }
        loadAndParseManifest(e, n = !0) {
            var s = this;
            return _async_to_generator$F((function*() {
                let d;
                xe.debug(`will load and parse manifest for ${e.title}, loadKeys ${n}`);
                try {
                    return d = yield Manifest.load(e, !1), n && d.addEventListener(Li.keysParsed, s.loadKeysHandler), d.parse(), d
                } catch (ce) {
                    s.resetDeferredPlay();
                    const n = new MKError(MKError.Reason.NETWORK_ERROR, "Could not fetch manifest");
                    throw n.data = ce, s._dispatcher.publish(zi, n), n
                }
            }))()
        }
        onTimeUpdate() {
            if (!this._buffer) return;
            const {
                currentPlaybackTimeRemaining: e,
                nextManifest: n,
                delaySeamlessCdmUpdates: s
            } = this;
            if (n && e < 15) {
                var d, p, h, y;
                if (xe.debug("player loading keys for", n.mediaItem.title, s), s) null === (p = this.extension) || void 0 === p || null === (d = p.session) || void 0 === d || d.loadKeys(n.keyValues, n.mediaItem, {
                    delayCdmUpdate: !0
                }), this._targetElement.addEventListener("timeupdate", this.delayedCdmUpdateCheck);
                else null === (y = this.extension) || void 0 === y || null === (h = y.session) || void 0 === h || h.loadKeys(n.keyValues, n.mediaItem);
                this._targetElement.removeEventListener("timeupdate", this.onTimeUpdate)
            }
        }
        delayedCdmUpdateCheck() {
            var e;
            const n = null === (e = this.nowPlayingItem) || void 0 === e ? void 0 : e.playbackDuration,
                s = n ? n / 1e3 : this.currentPlaybackDuration,
                d = this._currentTime,
                p = Number((s - d).toFixed(3));
            if (p < 1) {
                const e = 1e3 * p;
                xe.debug("delayed CDM update in ", e), setTimeout(() => {
                    var e, n;
                    xe.debug("applying delayed CDM update"), null === (n = this.extension) || void 0 === n || null === (e = n.session) || void 0 === e || e.applyDelayedCdmUpdates()
                }, e), this._targetElement.removeEventListener("timeupdate", this.delayedCdmUpdateCheck)
            }
        }
        loadKeysHandler(e) {
            var n, s;
            null === (s = this.extension) || void 0 === s || null === (n = s.session) || void 0 === n || n.loadKeys(e.keys, e.item)
        }
        beginNewBufferForItem(e, n, s) {
            var d = this;
            return _async_to_generator$F((function*() {
                if (xe.debug("creating new MseBuffer for item", n.mediaItem.title, e), d._buffer && (xe.debug("stopping old buffer"), d._buffer.stop()), d._buffer = new MseBuffer({
                        dispatcher: d._dispatcher,
                        element: d._targetElement,
                        duration: n.mediaItem.playbackDuration / 1e3,
                        manifest: n
                    }), yield d._playAssetURL(d._buffer.playableUrl, !0), !e) {
                    let e = Promise.resolve();
                    return (null == s ? void 0 : s.startTime) && (e = d.seekToTime(s.startTime)), e.then(() => d._playMedia())
                }
            }))()
        }
        setPresentationMode(e) {
            return _async_to_generator$F((function*() {
                return Promise.resolve()
            }))()
        }
        loadPreviewImage(e) {
            return _async_to_generator$F((function*() {}))()
        }
        constructor(e) {
            var n, s;
            super(e), _define_property$V(this, "currentAudioTrack", void 0), _define_property$V(this, "currentTextTrack", void 0), _define_property$V(this, "textTracks", []), _define_property$V(this, "audioTracks", []), _define_property$V(this, "audio", void 0), _define_property$V(this, "isSeamlessAudioTransitionsEnabled", !1), _define_property$V(this, "delaySeamlessCdmUpdates", !1), _define_property$V(this, "extension", void 0), _define_property$V(this, "mediaPlayerType", "audio"), _define_property$V(this, "manifest", void 0), _define_property$V(this, "nextManifest", void 0);
            const d = null !== (s = null === (n = e.bag) || void 0 === n ? void 0 : n.features) && void 0 !== s ? s : {};
            this.isSeamlessAudioTransitionsEnabled = !!d["seamless-audio-transitions"], this.delaySeamlessCdmUpdates = !!d["delay-seamless-cdm-updates"], window.audioPlayer = this, this._dispatcher.subscribe(Bi, this.onLoadSegmentError)
        }
    }

    function asyncGeneratorStep$E(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$E(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$E(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$E(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$U(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    _ts_decorate$h([Bind(), _ts_metadata$h("design:type", Function), _ts_metadata$h("design:paramtypes", [void 0]), _ts_metadata$h("design:returntype", void 0)], AudioPlayer.prototype, "onLoadSegmentError", null), _ts_decorate$h([AsyncDebounce(250), _ts_metadata$h("design:type", Function), _ts_metadata$h("design:paramtypes", [Number]), _ts_metadata$h("design:returntype", Promise)], AudioPlayer.prototype, "seekToTime", null), _ts_decorate$h([Bind(), _ts_metadata$h("design:type", Function), _ts_metadata$h("design:paramtypes", []), _ts_metadata$h("design:returntype", void 0)], AudioPlayer.prototype, "onTimeUpdate", null), _ts_decorate$h([Bind(), _ts_metadata$h("design:type", Function), _ts_metadata$h("design:paramtypes", []), _ts_metadata$h("design:returntype", void 0)], AudioPlayer.prototype, "delayedCdmUpdateCheck", null), _ts_decorate$h([Bind(), _ts_metadata$h("design:type", Function), _ts_metadata$h("design:paramtypes", [void 0]), _ts_metadata$h("design:returntype", void 0)], AudioPlayer.prototype, "loadKeysHandler", null);
    class EncryptedSession extends KeySession {
        attachMedia(e, n) {
            var s = this;
            return _async_to_generator$E((function*() {
                s.keySystem = n.keySystem, s._keySystemAccess = n, e.addEventListener("encrypted", s.boundHandleSessionCreation, !1)
            }))()
        }
        detachMedia(e) {
            e.removeEventListener("encrypted", this.boundHandleSessionCreation)
        }
        createSession(e) {
            var n = this;
            return _async_to_generator$E((function*() {
                xe.debug("Encrypted createSession", e);
                const s = n._keySystemAccess;
                if (!s) return;
                const {
                    initData: d,
                    initDataType: p,
                    target: h
                } = e;
                var y;
                return n._mediaKeysPromise || (n._mediaKeysPromise = new Promise((y = _async_to_generator$E((function*(e, d) {
                    const p = yield s.createMediaKeys();
                    try {
                        yield h.setMediaKeys(p)
                    } catch (ce) {
                        n.dispatchKeyError(ce), d(ce)
                    }
                    const y = yield n.loadCertificateBuffer();
                    yield p.setServerCertificate(y), n._mediaKeysServerCertificate = y, e(p)
                })), function(e, n) {
                    return y.apply(this, arguments)
                }))), yield n._mediaKeysPromise, n._mediaKeysServerCertificate ? n._createSession(h, d, p) : void 0
            }))()
        }
        generatePSSH(e) {
            const n = new Uint8Array([0, 0, 0, 52, 112, 115, 115, 104, 0, 0, 0, 0, 237, 239, 139, 169, 121, 214, 74, 206, 163, 200, 39, 220, 213, 29, 33, 237, 0, 0, 0, 20, 8, 1, 18, 16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
                s = D(e);
            for (let d = 0; d < s.length; d++) n[n.length - 16 + d] = s[d];
            return xe.debug("generatePSSH", n), n
        }
        _createSession(e, n, s) {
            const d = e.mediaKeys.createSession(),
                {
                    item: p
                } = this;
            if (!p) return;
            this._teardownCurrentSession(), xe.debug("creating media key session", d);
            let h;
            if (this.isWidevine && p.isSong) h = this.generatePSSH(this.extID);
            else {
                const e = function(e) {
                        const n = [],
                            s = new DataView(e.buffer);
                        for (let d = 0; d < e.length;) {
                            const p = s.getUint32(d);
                            n.push(new PsshBox(e, d, d + p)), d += p
                        }
                        return n
                    }(new Uint8Array(n)).find(e => e.isWidevine),
                    s = null == e ? void 0 : e.rawBytes,
                    p = j(s);
                xe.debug("extracted uri", p), d.extURI = p, h = n
            }
            return d.addEventListener("message", this.startLicenseSession), this._currentSession = d, d.generateRequest(s, h).catch(e => {
                if (e.message.match(/generateRequest.*\(75\)/)) return d.generateRequest(s, h);
                throw e
            })
        }
        _teardownCurrentSession() {
            this._currentSession && (xe.debug("tearing down media key session", this._currentSession), this._currentSession.removeEventListener("message", this.startLicenseSession), this._currentSession = void 0)
        }
        applyDelayedCdmUpdates() {}
        loadKeys(e, n, s) {
            return _async_to_generator$E((function*() {}))()
        }
        clearSessions() {
            return _async_to_generator$E((function*() {}))()
        }
        constructor(...e) {
            super(...e), _define_property$U(this, "_currentSession", void 0), _define_property$U(this, "_keySystemAccess", void 0), _define_property$U(this, "_mediaKeysPromise", void 0), _define_property$U(this, "_mediaKeysServerCertificate", void 0)
        }
    }

    function asyncGeneratorStep$D(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$D(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$D(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$D(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$T(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class MediaExtensionStub extends Notifications {
        destroy(e) {}
        setMediaItem(e) {}
        initializeKeySystem() {
            var e = this;
            return _async_to_generator$D((function*() {
                e.session = new EncryptedSession
            }))()
        }
        clearSessions() {
            return _async_to_generator$D((function*() {}))()
        }
        constructor(e) {
            super(e), _define_property$T(this, "audioTracks", []), _define_property$T(this, "textTracks", []), _define_property$T(this, "session", void 0), _define_property$T(this, "extURI", void 0), _define_property$T(this, "hasMediaKeySupport", void 0), _define_property$T(this, "hasMediaSession", void 0), _define_property$T(this, "initiated", void 0), _define_property$T(this, "isFairplay", void 0), this.extURI = "", this.hasMediaKeySupport = !0, this.initiated = !0, this.isFairplay = !0, this.hasMediaKeySupport = !0, this.hasMediaSession = !0
        }
    }

    function asyncGeneratorStep$C(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$C(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$C(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$C(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$S(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    class PlayerStub {
        get hasMediaElement() {
            return !0
        }
        get isEngagedInPlayback() {
            return !this.paused
        }
        get playbackRate() {
            return this._playbackRate
        }
        set playbackRate(e) {
            this._playbackRate = e, this._dispatcher.publish(st.playbackRateDidChange, new Event("ratechange"))
        }
        get defaultPlaybackRate() {
            return this._defaultPlaybackRate
        }
        set defaultPlaybackRate(e) {
            this._defaultPlaybackRate = e, this._dispatcher.publish(st.playbackRateDidChange, new Event("ratechange"))
        }
        get volume() {
            return this._volume
        }
        set volume(e) {
            this._volume = e, this._dispatcher.publish(st.playbackVolumeDidChange, new Event("volumeChange"))
        }
        destroy() {}
        dispatch() {}
        exitFullscreen() {
            return _async_to_generator$C((function*() {}))()
        }
        loadPreviewImage(e) {
            return _async_to_generator$C((function*() {}))()
        }
        initialize() {
            return _async_to_generator$C((function*() {}))()
        }
        isPaused() {
            return this.paused
        }
        calculateTime(e) {
            return e
        }
        clearNextManifest() {}
        mute() {}
        newSeeker() {
            return new PlayerSeeker(this)
        }
        pause(e) {
            return _async_to_generator$C((function*() {}))()
        }
        play() {
            return _async_to_generator$C((function*() {}))()
        }
        playItemFromEncryptedSource(e, n, s) {
            return _async_to_generator$C((function*() {}))()
        }
        playItemFromUnencryptedSource(e, n, s) {
            return _async_to_generator$C((function*() {}))()
        }
        preload() {
            return _async_to_generator$C((function*() {}))()
        }
        seekToTime(e) {
            return _async_to_generator$C((function*() {}))()
        }
        requestFullscreen() {
            return _async_to_generator$C((function*() {}))()
        }
        setPlaybackState(e, n) {}
        setPresentationMode(e) {
            return _async_to_generator$C((function*() {}))()
        }
        showPlaybackTargetPicker() {}
        stop(e) {
            return _async_to_generator$C((function*() {}))()
        }
        stopMediaAndCleanup() {
            return _async_to_generator$C((function*() {}))()
        }
        supportsPictureInPicture() {
            return !1
        }
        tsidChanged() {}
        preloadItem(e, n) {
            return _async_to_generator$C((function*() {}))()
        }
        constructor(n) {
            _define_property$S(this, "bitrate", e.PlaybackBitrate.STANDARD), _define_property$S(this, "audioTracks", []), _define_property$S(this, "currentBufferedProgress", 0), _define_property$S(this, "currentPlaybackDuration", 0), _define_property$S(this, "currentPlaybackProgress", 0), _define_property$S(this, "currentPlaybackTime", 0), _define_property$S(this, "currentPlaybackTimeRemaining", 0), _define_property$S(this, "currentPlayingDate", void 0), _define_property$S(this, "isPlayingAtLiveEdge", !1), _define_property$S(this, "isPlaying", !1), _define_property$S(this, "isPrimaryPlayer", !0), _define_property$S(this, "isReady", !1), _define_property$S(this, "nowPlayingItem", void 0), _define_property$S(this, "paused", !1), _define_property$S(this, "playbackState", e.PlaybackStates.none), _define_property$S(this, "playbackTargetAvailable", !1), _define_property$S(this, "playbackTargetIsWireless", !1), _define_property$S(this, "previewOnly", !1), _define_property$S(this, "supportsPreviewImages", !1), _define_property$S(this, "textTracks", []), _define_property$S(this, "extension", new MediaExtensionStub([])), _define_property$S(this, "hasAuthorization", !0), _define_property$S(this, "windowHandlers", void 0), _define_property$S(this, "isDestroyed", !1), _define_property$S(this, "services", void 0), _define_property$S(this, "_dispatcher", void 0), _define_property$S(this, "_volume", 1), _define_property$S(this, "_playbackRate", 1), _define_property$S(this, "_defaultPlaybackRate", 1), _define_property$S(this, "currentAudioTrack", void 0), _define_property$S(this, "currentTextTrack", void 0), _define_property$S(this, "seekableTimeRanges", void 0), this.services = n.services, this._dispatcher = n.services.dispatcher, this.windowHandlers = new WindowHandlers(this, n.services.runtime)
        }
    }
    class VideoMediaExtension extends MediaExtension {
        destroy(e) {
            var n;
            null === (n = this._session) || void 0 === n || n.stopLicenseSession(), super.destroy(e)
        }
    }
    const Yi = BooleanDevFlag.register("mk-send-manifest-headers");

    function asyncGeneratorStep$B(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$B(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$B(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$B(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$R(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const Qi = ["https://play.itunes.apple.com/", "https://linear.tv.apple.com/", "https://play-edge.itunes.apple.com"];
    const Ji = new class {
        fetchManifest(e) {
            var n = this;
            return _async_to_generator$B((function*() {
                return xe.info("fetching manifest at", e), shouldLoadManifestOnce() ? n.fetchForCache(e) : n.fetchOnly(e)
            }))()
        }
        getManifest(e) {
            return this.cache.get(e)
        }
        clear(e) {
            e ? this.cache.delete(e) : this.cache.clear()
        }
        fetchForCache(e) {
            var n = this;
            return _async_to_generator$B((function*() {
                const s = function(e) {
                        const n = {};
                        Qi.some(n => e.startsWith(n)) && Si.musicUserToken && (!Yi.configured || Yi.enabled) && (n["media-user-token"] = Si.musicUserToken, n.Authorization = "Bearer " + Si.developerToken);
                        return n
                    }(e),
                    d = yield n.fetch(e, {
                        headers: new Headers(s)
                    });
                let p = yield d.text();
                var h;
                p = ((e, n) => {
                    xe.info("converting manifest URIs to absolute paths");
                    const s = new URL(e);
                    let d = n.replace(/URI="([^"]*)"/g, (function(e, n) {
                        return `URI="${new URL(n,s).href}"`
                    }));
                    return d = d.replace(/^(#EXT-X-STREAM-INF:[^\n]*\n)(.*$)/gim, (function(e, n, d) {
                        return `${n}${new URL(d,s).href}`
                    })), d
                })(e, p);
                const y = null !== (h = d.headers.get("content-type")) && void 0 !== h ? h : void 0,
                    _ = {
                        url: e,
                        content: p,
                        contentType: y
                    };
                return n.cache.set(e, _), _
            }))()
        }
        fetchOnly(e) {
            var n = this;
            return _async_to_generator$B((function*() {
                const s = yield n.fetch(e), d = yield s.text();
                var p;
                const h = null !== (p = s.headers.get("content-type")) && void 0 !== p ? p : void 0;
                return {
                    url: e,
                    content: d,
                    contentType: h
                }
            }))()
        }
        constructor(e = {}) {
            var n, s;
            _define_property$R(this, "cache", void 0), _define_property$R(this, "fetch", void 0), this.fetch = null !== (n = e.fetch) && void 0 !== n ? n : fetch.bind(globalThis), this.cache = null !== (s = e.cache) && void 0 !== s ? s : new Map
        }
    };

    function asyncGeneratorStep$A(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$A(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$A(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$A(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _ts_decorate$g(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$g(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    const {
        mediaPlaybackError: Xi
    } = st, {
        playbackLicenseError: Zi,
        playbackSessionError: en
    } = Ye;
    class NativeSafariVideoPlayer extends VideoPlayer {
        get currentPlayingDate() {}
        get isPlayingAtLiveEdge() {
            return !1
        }
        get seekableTimeRanges() {
            return this.currentPlaybackDuration ? [{
                start: 0,
                end: this.currentPlaybackDuration
            }] : void 0
        }
        get supportsPreviewImages() {
            return !1
        }
        initializeExtension() {
            var e = this;
            return _async_to_generator$A((function*() {
                if (!e.video) return void xe.warn("NativeSafariVideoPlayer.initializeExtension No video element, not initializing extension");
                const n = new VideoMediaExtension(e.video, 'video/mp4;codecs="avc1.42E01E"');
                e.extension = n, yield n.initializeKeySystem(), n.addEventListener(Zi, e.onPlaybackLicenseError), n.addEventListener(en, e.onPlaybackSessionError)
            }))()
        }
        destroy() {
            xe.debug("native-safari-video-player.destroy");
            const {
                extension: e,
                video: n
            } = this;
            this._blobUrl && (URL.revokeObjectURL(this._blobUrl), this._blobUrl = void 0), e && n && (e.removeEventListener(Zi, this.onPlaybackLicenseError), e.removeEventListener(en, this.onPlaybackSessionError), n.removeEventListener("loadedmetadata", this.onMetadataLoaded), super.destroy())
        }
        loadPreviewImage(e) {
            return _async_to_generator$A((function*() {}))()
        }
        preloadItem(e, n) {
            return _async_to_generator$A((function*() {}))()
        }
        playHlsStream(e, n, s = {}) {
            var d = this;
            return _async_to_generator$A((function*() {
                xe.debug("native-safari-video-player.playHlsStream", e);
                const {
                    video: p
                } = d;
                if (!p) {
                    const e = "NativeSafariVideoPlayer.playHlsStream(): No video element";
                    throw xe.error(e), new Error(e)
                }
                d.setupTrackManagers();
                const h = d.startPlaybackSequence(),
                    y = (d._shouldLoadManifestsOnce ? d.playByBlob(e, p, s) : d.playBySource(e, p, s)).then(() => h);
                var _;
                n && (null === (_ = d.extension) || void 0 === _ || _.setMediaItem(n));
                return p.addEventListener("loadedmetadata", d.onMetadataLoaded), y
            }))()
        }
        onPlaybackSessionError(e) {
            this._dispatcher.publish(Xi, new MKError(MKError.Reason.MEDIA_SESSION, e))
        }
        onMetadataLoaded() {
            var e = this;
            return _async_to_generator$A((function*() {
                xe.debug("native-safari-video-player.onMetadataLoaded");
                const {
                    nowPlayingItem: n
                } = e;
                n && (n.state = ee.ready), yield e._playMedia(), e.finishPlaybackSequence()
            }))()
        }
        seekToTime(e) {
            var n = this;
            return _async_to_generator$A((function*() {
                xe.debug("native-safari-video-player: media element seek to", e), n._targetElement.currentTime = e
            }))()
        }
        playByBlob(e, n, s = {}) {
            var d = this;
            return _async_to_generator$A((function*() {
                xe.debug("native-safari-video-player: playing video by blob");
                let p = Ji.getManifest(e);
                if (!p && (xe.debug("native-safari-video-player: fetching manifest"), p = yield Ji.fetchManifest(e), !p)) throw xe.error("No manifest for " + e), new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "Failed to load manifest");
                xe.debug("native-safari-video-player: loaded manifest", !!p), Ji.clear(e);
                const h = p.contentType,
                    y = p.content.replace(/^#EXT-X-SESSION-DATA-ITUNES:.*$/gm, ""),
                    _ = new Blob([y], {
                        type: h
                    });
                e = URL.createObjectURL(_), d._blobUrl = e;
                const m = document.createElement("source");
                m.setAttribute("src", e), h && m.setAttribute("type", h), xe.debug("native-safari-video-player: blob url", e), void 0 !== s.startTime && (n.currentTime = s.startTime), n.appendChild(m)
            }))()
        }
        playBySource(e, n, s = {}) {
            return _async_to_generator$A((function*() {
                xe.debug("native-safari-video-player: playing video by source"), void 0 !== s.startTime && (e += "#t=" + s.startTime), n.src = e
            }))()
        }
        constructor(...e) {
            super(...e),
                function(e, n, s) {
                    n in e ? Object.defineProperty(e, n, {
                        value: s,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[n] = s
                }(this, "_blobUrl", void 0)
        }
    }
    _ts_decorate$g([Bind(), _ts_metadata$g("design:type", Function), _ts_metadata$g("design:paramtypes", [void 0]), _ts_metadata$g("design:returntype", void 0)], NativeSafariVideoPlayer.prototype, "onPlaybackSessionError", null), _ts_decorate$g([Bind(), _ts_metadata$g("design:type", Function), _ts_metadata$g("design:paramtypes", []), _ts_metadata$g("design:returntype", Promise)], NativeSafariVideoPlayer.prototype, "onMetadataLoaded", null), _ts_decorate$g([AsyncDebounce(250), _ts_metadata$g("design:type", Function), _ts_metadata$g("design:paramtypes", [Number]), _ts_metadata$g("design:returntype", Promise)], NativeSafariVideoPlayer.prototype, "seekToTime", null);
    const tn = new RegExp("^https://([a-z0-9]+-)?" + ("js-cdn.music.apple.com" + "/musickit/v3/".replace(/v3/, "(v2|v3)")).replace(/[\.\/]/g, "\\$&"), "i"),
        rn = /^https:\/\/(.*\/includes\/js-cdn)\//i,
        nn = /^([a-z]+:)?\/\//;

    function findScript(e) {
        return isNodeEnvironment$1() || !e ? null : document.querySelector(`script[src*="${e}"]`)
    }

    function getScriptSrcElements() {
        if ("undefined" == typeof document || !document.querySelectorAll) return [];
        return Array.from(document.querySelectorAll("script[src]"))
    }

    function determineCdnBaseHost() {
        if (isNodeEnvironment$1()) return "";
        return `//${function(){for(const e of getScriptSrcElements()){const n=tn.exec(e.src);if(n)return n[1]||""}return""}()}js-cdn.music.apple.com`
    }

    function determineCdnPathHost() {
        const e = function() {
            for (const e of getScriptSrcElements()) {
                const n = rn.exec(e.src);
                if (n) return n[1] || ""
            }
            return ""
        }();
        return e ? "//" + e : e
    }
    const on = StringDevFlag.register("mk-hlsjs-log-level"),
        an = StringDevFlag.register("mk-hlsjs-version");

    function getHlsJsCdnConfig() {
        const e = {
            hls: "",
            rtc: ""
        };
        if (isNodeEnvironment$1()) return e;
        const n = determineCdnPathHost() || determineCdnBaseHost(),
            s = an.get() || "2.910.1",
            d = function() {
                const e = on.value;
                switch (e) {
                    case "info":
                    case "error":
                    case "warn":
                        return "hls.production.verbose.min.js";
                    case "trace":
                    case "debug":
                        return console.warn(`HLS log level ${e} is not supported, loading production build.`), "hls.js";
                    default:
                        return "hls.js"
                }
            }();
        return e.hls = `https:${n}/hls.js/${s}/hls.js/${d}`, e.rtc = `https:${n}/hls.js/${s}/rtc.js/rtc.min.js`, e
    }

    function cdnBaseURL(e, n = window) {
        var s;
        if (isNodeEnvironment$1()) return "";
        const d = null === (s = getLocalStorage()) || void 0 === s ? void 0 : s.getItem("mkCDNBaseURLOverride");
        if (d) return d;
        const p = findScript(e);
        return p ? p.getAttribute("src").replace(new RegExp(e + "$"), "") : (determineCdnPathHost() || determineCdnBaseHost()) + "/musickit/v3/"
    }
    const sn = new Map;

    function loadScript(e, n) {
        const s = sn.get(e);
        if (s) return s;
        const d = new Promise((s, d) => {
            isNodeEnvironment$1() && d("Dynamic script loading is unsupported in Node environments.");
            if (findScript(e)) return s();
            const p = document.createElement("script");
            let h;
            if (n && Object.keys(n).forEach(e => {
                    p.setAttribute(e, n[e])
                }), p.onload = () => {
                    s()
                }, p.onerror = e => {
                    d(e)
                }, nn.test(e)) h = e;
            else {
                h = `${cdnBaseURL(e)}${e}`
            }
            p.src = h, document.head.appendChild(p)
        });
        return sn.set(e, d), d
    }
    const cn = xe.createChild("tracks");

    function _define_property$P(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$s(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$P(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$i(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function _ts_decorate$f(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$f(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    const {
        audioTracksSwitched: dn,
        audioTracksUpdated: ln,
        inlineStylesParsed: un,
        textTracksSwitched: pn,
        textTracksUpdated: hn
    } = Ye;
    class HlsJsTracks extends Notifications {
        get isDestroyed() {
            return this._isDestroyed
        }
        get audioTracks() {
            return this._audioTracks
        }
        get textTracks() {
            return this._textTracks
        }
        set audioTrack(e) {
            this.session && e && void 0 !== e.id && (this.session.audioSelectedPersistentID = e.id)
        }
        set textTrack(e) {
            var n;
            this.session.subtitleSelectedPersistentID = null !== (n = null == e ? void 0 : e.id) && void 0 !== n ? n : -1
        }
        selectForcedTrack() {
            const {
                session: e
            } = this;
            if (!(null == e ? void 0 : e.audioTracks)) return;
            const n = e.audioTracks.filter(n => n.persistentID === e.audioSelectedPersistentID),
                s = n && n.length && n[0];
            if (!s) return;
            const d = e.subtitleMediaOptions.filter(e => 0 === e.MediaSelectionOptionsDisplaysNonForcedSubtitles && e.MediaSelectionOptionsExtendedLanguageTag === s.lang),
                p = null == d ? void 0 : d[0];
            let h;
            return p ? (cn.debug("hlsjsTracks: found forced track for " + p.MediaSelectionOptionsExtendedLanguageTag), e.subtitleSelectedPersistentID = p.MediaSelectionOptionsPersistentID, h = this.normalizeTextTrack(p)) : e.subtitleSelectedPersistentID = -1, h
        }
        audioTracksUpdated(e, n) {
            const s = (n && n.audioMediaSelectionGroup && n.audioMediaSelectionGroup.MediaSelectionGroupOptions || []).map(this.normalizeAudioTrack, this);
            this._audioTracks = s, this.dispatchEvent(ln, s)
        }
        handleAudioTrackSwitched() {
            this.dispatchEvent(dn, {
                selectedId: this.session.audioSelectedPersistentID
            })
        }
        handleInlineStylesParsed(e, n) {
            this.dispatchEvent(un, n)
        }
        handleManifestLoaded(e, n) {
            this.audioTracksUpdated(e, n), this.subtitleTracksUpdated(e, n)
        }
        handleSessionDataComplete(e, n) {
            var s;
            null == n || null === (s = n.itemList) || void 0 === s || s.forEach(e => {
                if ("_hls.localized-rendition-names" === e["DATA-ID"] && e.VALUE) try {
                    this._localizedRenditionNames = JSON.parse(e.VALUE), this._audioTracks.forEach(e => {
                        var n;
                        const s = null === (n = this._localizedRenditionNames) || void 0 === n ? void 0 : n[e.label];
                        s && (e.localizedRenditionNames = s)
                    }), this.dispatchEvent(ln, this._audioTracks)
                } catch (Rt) {
                    return void cn.error("Failed to parse _hls.localized-rendition-names", Rt)
                }
            })
        }
        handleSubtitleTrackSwitch(e, n) {
            this.dispatchEvent(pn, n)
        }
        subtitleTracksUpdated(e, n) {
            const s = n && n.subtitleMediaSelectionGroup && n.subtitleMediaSelectionGroup.MediaSelectionGroupOptions || [],
                d = [];
            s.forEach(e => {
                0 !== e.MediaSelectionOptionsDisplaysNonForcedSubtitles && d.push(this.normalizeTextTrack(e))
            }), this._textTracks = d, this.dispatchEvent(hn, d)
        }
        normalizeAudioTrack(e) {
            const n = e.MediaSelectionOptionsTaggedMediaCharacteristics,
                s = (null != n ? n : []).includes("public.accessibility.describes-video") ? "description" : "main";
            return _object_spread_props$i(_object_spread$s({}, this.normalizeSelectionOption(e)), {
                enabled: !1,
                kind: s,
                characteristics: n
            })
        }
        normalizeTextTrack(e) {
            var n;
            let s;
            return s = (null === (n = e.MediaSelectionOptionsTaggedMediaCharacteristics) || void 0 === n ? void 0 : n.includes("public.accessibility.describes-music-and-sound")) || "clcp" === e.MediaSelectionOptionsMediaType ? "captions" : "subtitles", _object_spread_props$i(_object_spread$s({}, this.normalizeSelectionOption(e)), {
                mode: "disabled",
                kind: s
            })
        }
        normalizeSelectionOption(e) {
            return {
                id: e.MediaSelectionOptionsPersistentID,
                label: e.MediaSelectionOptionsName,
                language: e.MediaSelectionOptionsExtendedLanguageTag
            }
        }
        destroy() {
            this._isDestroyed = !0;
            const {
                MANIFEST_LOADED: e,
                AUDIO_TRACK_SWITCHED: n,
                SUBTITLE_TRACK_SWITCH: s,
                INLINE_STYLES_PARSED: d,
                SESSION_DATA_COMPLETE: p
            } = window.Hls.Events;
            this.session.off(e, this.handleManifestLoaded), this.session.off(n, this.handleAudioTrackSwitched), this.session.off(s, this.handleSubtitleTrackSwitch), this.session.off(d, this.handleInlineStylesParsed), this.session.off(p, this.handleSessionDataComplete)
        }
        constructor(e) {
            super([dn, ln, un, pn, hn]), _define_property$P(this, "session", void 0), _define_property$P(this, "_audioTracks", void 0), _define_property$P(this, "_textTracks", void 0), _define_property$P(this, "_localizedRenditionNames", void 0), _define_property$P(this, "_isDestroyed", void 0), this.session = e, this._audioTracks = [], this._textTracks = [], this._isDestroyed = !1;
            const {
                MANIFEST_LOADED: n,
                AUDIO_TRACK_SWITCHED: s,
                SUBTITLE_TRACK_SWITCH: d,
                INLINE_STYLES_PARSED: p,
                SESSION_DATA_COMPLETE: h
            } = window.Hls.Events;
            this.session.on(n, this.handleManifestLoaded), this.session.on(s, this.handleAudioTrackSwitched), this.session.on(d, this.handleSubtitleTrackSwitch), this.session.on(p, this.handleInlineStylesParsed), this.session.on(h, this.handleSessionDataComplete)
        }
    }

    function _define_property$O(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    _ts_decorate$f([Bind(), _ts_metadata$f("design:type", Function), _ts_metadata$f("design:paramtypes", []), _ts_metadata$f("design:returntype", void 0)], HlsJsTracks.prototype, "handleAudioTrackSwitched", null), _ts_decorate$f([Bind(), _ts_metadata$f("design:type", Function), _ts_metadata$f("design:paramtypes", [void 0, void 0]), _ts_metadata$f("design:returntype", void 0)], HlsJsTracks.prototype, "handleInlineStylesParsed", null), _ts_decorate$f([Bind(), _ts_metadata$f("design:type", Function), _ts_metadata$f("design:paramtypes", [void 0, void 0]), _ts_metadata$f("design:returntype", void 0)], HlsJsTracks.prototype, "handleManifestLoaded", null), _ts_decorate$f([Bind(), _ts_metadata$f("design:type", Function), _ts_metadata$f("design:paramtypes", [void 0, void 0]), _ts_metadata$f("design:returntype", void 0)], HlsJsTracks.prototype, "handleSessionDataComplete", null), _ts_decorate$f([Bind(), _ts_metadata$f("design:type", Function), _ts_metadata$f("design:paramtypes", [void 0, void 0]), _ts_metadata$f("design:returntype", void 0)], HlsJsTracks.prototype, "handleSubtitleTrackSwitch", null);
    class HlsJsPreviewImageLoader {
        loadPreviewImage(e) {
            return this.lastPosition === e || (this.lastPosition = e, this.lastPromise = new Promise((n, s) => {
                this.hls.loadImageIframeData$(e).subscribe(e => {
                    const {
                        data: s
                    } = e, d = new Blob([s], {
                        type: "image/jpeg"
                    });
                    n(d)
                })
            })), this.lastPromise
        }
        constructor(e) {
            _define_property$O(this, "hls", void 0), _define_property$O(this, "lastPosition", void 0), _define_property$O(this, "lastPromise", void 0), this.hls = e
        }
    }

    function asyncGeneratorStep$z(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$z(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$z(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$z(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$N(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$e(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$e(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    const yn = {
        bufferStalledError: "bufferStalledError",
        keySystemGenericError: "keySystemGenericError"
    };
    var _n;
    ! function(e) {
        e.Seek = "Seek", e.HighBuffer = "HighBuffer", e.LowBuffer = "LowBuffer"
    }(_n || (_n = {}));
    const fn = new Set([MKError.Reason.DEVICE_LIMIT, MKError.Reason.GEO_BLOCK, MKError.Reason.WIDEVINE_CDM_EXPIRED]),
        mn = {};
    mn[He.FAIRPLAY] = "fairplaystreaming", mn[He.PLAYREADY] = "playready", mn[He.WIDEVINE] = "widevine";
    const vn = BooleanDevFlag.register("mk-hlsjs-interstitial-playback"),
        gn = BooleanDevFlag.get("mk-hlsjs-item-preloading"),
        bn = JsonDevFlag.register("mk-hlsjs-config-overrides"),
        Sn = BooleanDevFlag.get("mk-block-report-cdn-server");
    class HlsJsVideoPlayer extends VideoPlayer {
        get shouldDispatchErrors() {
            return !this.userInitiated || this._playbackDidStart
        }
        get supportsPreviewImages() {
            var e, n;
            return !this.services.runtime.isMobile && (null === (n = this._hls) || void 0 === n || null === (e = n.iframeVariants) || void 0 === e ? void 0 : e.some(e => "mjpg" === e.imageCodec))
        }
        get currentPlayingDate() {
            var e;
            return null === (e = this._hls) || void 0 === e ? void 0 : e.playingDate
        }
        get isPlayingAtLiveEdge() {
            var e;
            const n = this._hls;
            return !(!n || !(null === (e = this.nowPlayingItem) || void 0 === e ? void 0 : e.isLinearStream)) && !!n.isPlayingAtLive
        }
        get seekableTimeRanges() {
            const e = this._hls;
            return e ? e.seekableTimeRanges : this.currentPlaybackDuration ? [{
                start: 0,
                end: this.currentPlaybackDuration
            }] : void 0
        }
        get currentPlaybackDuration() {
            return this._integratedTimelineDuration ? this._timing.time(this._integratedTimelineDuration) : super.currentPlaybackDuration
        }
        get currentPlaybackTime() {
            let e = {};
            var n, s;
            vn.enabled && (e = null === (n = this._hls) || void 0 === n ? void 0 : n.getCurrentIntegratedTimelineSegmentAndCurrentTime());
            return null !== (s = null == e ? void 0 : e.targetTime) && void 0 !== s ? s : super.currentPlaybackTime
        }
        initializeExtension() {
            var e = this;
            return _async_to_generator$z((function*() {
                e._keySystem = yield findKeySystemPreference(e.services.runtime);
                try {
                    var n;
                    if (!qe.urls.hls) throw new Error("bag.urls.hls is not configured");
                    yield Promise.all([loadScript(qe.urls.hls), null === (n = e._rtcTracker) || void 0 === n ? void 0 : n.loadScript()])
                } catch (Rt) {
                    throw xe.error("hlsjs-video-player failed to load script " + qe.urls.hls, Rt), Rt
                }
            }))()
        }
        destroy() {
            var e;
            if (xe.debug("hlsjs-video-player.destroy"), null === (e = this._hlsJsTracks) || void 0 === e || e.destroy(), this._hls) {
                const {
                    DATERANGE_UPDATED: e,
                    ERROR: n,
                    INTERNAL_ERROR: s,
                    MANIFEST_PARSED: d,
                    KEY_REQUEST_STARTED: p,
                    LICENSE_CHALLENGE_CREATED: h,
                    LEVEL_SWITCHED: y,
                    UNRESOLVED_URI_LOADING: _
                } = window.Hls.Events, m = this._hls;
                m.stopLoad(), m.detachMedia(), m.off(n, this.handleHlsError), m.off(s, this.handleHlsError), m.off(d, this.handleManifestParsed), m.off(p, this.handleKeyRequestStarted), m.off(h, this.handleLicenseChallengeCreated), m.off(y, this.handleLevelSwitched), m.off(e, this.handleDaterangeUpdated), this._shouldLoadManifestsOnce && m.off(_, this.handleUnresolvedUriLoading), m.destroy(), window.hlsSession = void 0
            }
            super.destroy(), asAsync(this._license.stop())
        }
        playHlsStream(e, n, s = {}) {
            var d = this;
            return _async_to_generator$z((function*() {
                xe.debug("hlsjs-video-player.playHlsStream", e, n);
                const {
                    _keySystem: p
                } = d;
                if (!p) return;
                let h, y;
                d._unrecoverableError = void 0, d.createHlsPlayer();
                const hasKey = (e, n) => {
                    var s;
                    return void 0 !== (null == n || null === (s = n.keyURLs) || void 0 === s ? void 0 : s[e])
                };
                p === He.WIDEVINE && hasKey("widevine-cert-url", n) && (h = "WIDEVINE_SOFTWARE", y = {
                    initDataTypes: ["cenc", "keyids"],
                    distinctiveIdentifier: "optional",
                    persistentState: "required"
                });
                const _ = {
                        itemId: null == n ? void 0 : n.id,
                        subs: "accepts-css",
                        platformInfo: {
                            requiresCDMAttachOnStart: p !== He.NONE,
                            maxSecurityLevel: h,
                            keySystemConfig: y
                        },
                        appData: {
                            serviceName: qe.app.name
                        }
                    },
                    {
                        _rtcTracker: m,
                        _hls: v
                    } = d;
                if (m) {
                    const e = m.prepareReportingAgent(n);
                    void 0 !== e && (_.appData.reportingAgent = e)
                }
                xe.debug("RTC: loadSource with load options", _);
                const g = d.startPlaybackSequence();
                return d._shouldLoadManifestsOnce && (e = e.replace("https://", "manifest://"), xe.info("Manifest already loaded, passing url to HLSJS", e)), v.loadSource(e, _, s.startTime), v.attachMedia(d.video), n && (d._licenseServerUrl = n.keyURLs["hls-key-server-url"], p === He.FAIRPLAY && hasKey("hls-key-cert-url", n) ? v.setProtectionData({
                    fairplaystreaming: {
                        serverCertUrl: n.keyURLs["hls-key-cert-url"]
                    }
                }) : hasKey("widevine-cert-url", n) && v.setProtectionData({
                    widevine: {
                        serverCertUrl: n.keyURLs["widevine-cert-url"]
                    }
                })), g
            }))()
        }
        preloadItem(e, n) {
            var s = this;
            return _async_to_generator$z((function*() {
                if (xe.trace("preloadItem", e, n), !0 === gn) {
                    const d = generateAssetUrl(e, n);
                    xe.debug(`Prefetching HLS source for item "${e.id}" with license URL "${d}"`), s._hls.prefetchSource(d, {
                        itemId: e.id
                    })
                }
            }))()
        }
        createHlsPlayer() {
            const {
                _keySystem: e
            } = this, {
                Hls: n
            } = window, s = on.get(), {
                os: d
            } = this.services.runtime, p = {
                clearMediaKeysOnPromise: !1,
                customTextTrackCueRenderer: !0,
                debug: !!s,
                debugLevel: s,
                enableItemPreloading: !0 === gn,
                enableIFramePreloading: !1,
                enablePerformanceLogging: !!s,
                enablePlayReadyKeySystem: !0,
                enableQueryParamsForITunes: !this._shouldLoadManifestsOnce,
                enableRtcReporting: void 0 !== this._rtcTracker,
                keySystemPreference: mn[e],
                useMediaKeySystemAccessFilter: !0,
                maintainMediaKeysBetweenSessions: !1,
                nativeControlsEnabled: d.isAndroid,
                enableContentSteering: !0,
                allowFastSwitchUp: !0,
                liveAllowLowLatencyPlayback: !0
            };
            vn.enabled && Object.assign(p, {
                gapless: !0,
                enableInterstitialPlayback: !0
            }), (e => {
                const {
                    Hls: n
                } = window;
                if (n && Sn) {
                    const s = deepClone(n.DefaultConfig.fragLoadPolicy);
                    s.default.reportCDNServer = !1, s.customURL.reportCDNServer = !1, e.fragLoadPolicy = s
                }
            })(p), (e => {
                const n = bn.value;
                n && "object" == typeof n && Object.assign(e, n)
            })(p);
            const h = new n(p),
                {
                    DATERANGE_UPDATED: y,
                    ERROR: _,
                    INTERNAL_ERROR: m,
                    INTERSTITIALS_ENDED: v,
                    INTERSTITIALS_STARTED: g,
                    INTERSTITIALS_UPDATED: b,
                    KEY_REQUEST_STARTED: S,
                    LEVEL_SWITCHED: P,
                    LICENSE_CHALLENGE_CREATED: k,
                    MANIFEST_PARSED: T,
                    UNRESOLVED_URI_LOADING: E
                } = n.Events;
            h.on(_, this.handleHlsError), h.on(m, this.handleHlsError), h.on(T, this.handleManifestParsed), h.on(S, this.handleKeyRequestStarted), h.on(k, this.handleLicenseChallengeCreated), h.on(P, this.handleLevelSwitched), h.on(y, this.handleDaterangeUpdated), vn.enabled && (h.on(b, this.handleInterstitialUpdated), h.on(g, this.handleInterstitialStarted), h.on(v, this.handleInterstitialEnded)), this._shouldLoadManifestsOnce && h.on(E, this.handleUnresolvedUriLoading), this._hls = h, window.hlsSession = h, this._hlsJsTracks = new HlsJsTracks(this._hls), this.setupTrackManagers(this._hlsJsTracks), this._hlsPreviewImageLoader = new HlsJsPreviewImageLoader(this._hls)
        }
        handleUnresolvedUriLoading(e, n) {
            var s = this;
            return _async_to_generator$z((function*() {
                const e = s._hls,
                    d = n.uri,
                    p = d.replace("manifest://", "https://");
                var h;
                xe.debug("handleUnresolvedUriLoading for uri ", d);
                const y = null !== (h = Ji.getManifest(p)) && void 0 !== h ? h : yield Ji.fetchManifest(p);
                y ? (Ji.clear(p), e.off(window.Hls.Events.UNRESOLVED_URI_LOADING, s.handleUnresolvedUriLoading), e.handleResolvedUri(d, {
                    url: p,
                    status: 200,
                    data: y.content
                })) : xe.error("No cached manifest for " + p)
            }))()
        }
        handleInterstitialUpdated(e, n) {
            xe.debug("handleInterstitialUpdated - ", e, n), n.integratedTimeline.duration && (this._integratedTimelineDuration = n.integratedTimeline.duration)
        }
        handleInterstitialStarted(e, n) {
            xe.debug("handleInterstitialStarted - ", e, n)
        }
        handleInterstitialEnded(e, n) {
            xe.debug("handleInterstitialEnded - ", e, n)
        }
        handleLevelSwitched(e, n) {
            var s, d;
            const {
                level: p
            } = n;
            if (!p) return;
            const h = null === (s = this._levels) || void 0 === s ? void 0 : s.find(e => e.persistentId === p);
            if (!h || (null === (d = this._currentLevel) || void 0 === d ? void 0 : d.persistentId) === (null == h ? void 0 : h.persistentId)) return;
            this._currentLevel = h;
            const y = void 0 !== h.audioGroupId ? this._channelsByGroup[h.audioGroupId] : void 0;
            this._dispatcher.publish(ot.hlsLevelUpdated, {
                level: h,
                channels: y
            })
        }
        handleDaterangeUpdated(e, n) {
            xe.info("handleDaterangeUpdated", JSON.stringify(n)), this._dispatcher.publish(st.hlsDaterangeUpdated, n)
        }
        handleHlsError(e, n) {
            var s;
            if (xe.warn("HLS.js error", JSON.stringify(n)), this._unrecoverableError) return;
            let d = new MKError(MKError.Reason.UNSUPPORTED_ERROR, n.reason);
            d.data = n;
            const {
                bufferStalledError: p,
                keySystemGenericError: h
            } = yn;
            if (n.details === h) return void this._dispatcher.publish(h, d);
            let y = !1;
            var _;
            n.details === p && "Seek" === n.stallType && -12909 === (null === (s = n.response) || void 0 === s ? void 0 : s.code) && (d = new MKError(MKError.Reason.BUFFER_STALLED_ERROR, n.stallType), d.data = {
                stallType: n.stallType,
                code: null === (_ = n.response) || void 0 === _ ? void 0 : _.code
            }, y = !0);
            if ("output-restricted" === n.reason && (d = new MKError(MKError.Reason.OUTPUT_RESTRICTED, n.reason)), n.fatal) {
                if (this._hls.destroy(), !this.shouldDispatchErrors && !y) throw d;
                this._dispatcher.publish(st.mediaPlaybackError, d)
            }
        }
        handleManifestParsed(e, n) {
            var s = this;
            return _async_to_generator$z((function*() {
                var e, d;
                let p;
                xe.debug("handleManifestParsed", n), s._levels = null !== (e = n.levels) && void 0 !== e ? e : [], s.nowPlayingItem.state = ee.ready, s._channelsByGroup = (null !== (d = n.audioTracks) && void 0 !== d ? d : []).reduce((e, n) => (e[n.groupId] = n.channels, e), {});
                try {
                    yield s._playMedia()
                } catch (Rt) {
                    throw xe.warn("error from media element, possibly non-fatal", Rt), Rt
                } finally {
                    p = yield s.finishPlaybackSequence()
                }
                return p
            }))()
        }
        handleKeyRequestStarted(e, n) {
            xe.debug("hlsjs-video.handleKeyRequestStarted"), this._hls.generateKeyRequest(n.keyuri, {})
        }
        handleLicenseChallengeCreated(n, s) {
            var d = this;
            return _async_to_generator$z((function*() {
                xe.trace("handleLicenseChallengeCreated", s);
                const {
                    _licenseServerUrl: n,
                    nowPlayingItem: p,
                    _keySystem: h,
                    userInitiated: y
                } = d;
                try {
                    var _;
                    const e = yield null === (_ = d._license) || void 0 === _ ? void 0 : _.start(n, p, s, h, y), m = {
                        statusCode: e.status
                    };
                    (null == e ? void 0 : e.license) && (h === He.FAIRPLAY ? m.ckc = D(e.license) : m.license = D(e.license));
                    const v = e["renew-after"];
                    v && (m.renewalDate = new Date(Date.now() + 1e3 * v)), d._hls.setLicenseResponse(s.keyuri, m)
                } catch (ce) {
                    if (d._unrecoverableError) return;
                    const p = ce.data,
                        h = {};
                    void 0 !== (null == p ? void 0 : p.status) && (h.statusCode = +p.status), xe.warn("Passing license response error to Hls.js", h), d._hls.setLicenseResponse(s.keyuri, h), MKError.isMKError(ce) && fn.has(ce.reason) && (d._unrecoverableError = ce, d.resetDeferredPlay(), yield d.stop({
                        endReasonType: e.PlayActivityEndReasonType.FAILED_TO_LOAD,
                        userInitiated: y
                    })), d.onPlaybackLicenseError(ce)
                }
            }))()
        }
        seekToTime(e) {
            var n = this;
            return _async_to_generator$z((function*() {
                n._hls ? (xe.debug("hlsjs-video: hls seekTo", e), n._hls.seekTo = e) : (xe.debug("hlsjs-video: media element seek to", e), n._targetElement.currentTime = e)
            }))()
        }
        loadPreviewImage(e) {
            var n = this;
            return _async_to_generator$z((function*() {
                var s;
                return null === (s = n._hlsPreviewImageLoader) || void 0 === s ? void 0 : s.loadPreviewImage(e)
            }))()
        }
        constructor(e) {
            var n;
            super(e), _define_property$N(this, "_hls", void 0), _define_property$N(this, "_hlsPreviewImageLoader", void 0), _define_property$N(this, "_hlsJsTracks", void 0), _define_property$N(this, "_keySystem", void 0), _define_property$N(this, "_license", void 0), _define_property$N(this, "_rtcTracker", void 0), _define_property$N(this, "_levels", void 0), _define_property$N(this, "_channelsByGroup", {}), _define_property$N(this, "_currentLevel", void 0), _define_property$N(this, "_licenseServerUrl", void 0), _define_property$N(this, "_unrecoverableError", void 0), _define_property$N(this, "_integratedTimelineDuration", void 0), this._rtcTracker = null == e || null === (n = e.playbackServices) || void 0 === n ? void 0 : n.getRTCStreamingTracker(), this._license = new License
        }
    }
    var Pn;

    function _define_property$M(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$d(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$d(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [String, "undefined" == typeof HlsUnresolvedUriData ? Object : HlsUnresolvedUriData]), _ts_metadata$e("design:returntype", Promise)], HlsJsVideoPlayer.prototype, "handleUnresolvedUriLoading", null), _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [String, Object]), _ts_metadata$e("design:returntype", void 0)], HlsJsVideoPlayer.prototype, "handleInterstitialUpdated", null), _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [String, Object]), _ts_metadata$e("design:returntype", void 0)], HlsJsVideoPlayer.prototype, "handleInterstitialStarted", null), _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [String, Object]), _ts_metadata$e("design:returntype", void 0)], HlsJsVideoPlayer.prototype, "handleInterstitialEnded", null), _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [void 0, void 0]), _ts_metadata$e("design:returntype", void 0)], HlsJsVideoPlayer.prototype, "handleLevelSwitched", null), _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [String, "undefined" == typeof HlsDaterangeUpdatedData ? Object : HlsDaterangeUpdatedData]), _ts_metadata$e("design:returntype", void 0)], HlsJsVideoPlayer.prototype, "handleDaterangeUpdated", null), _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [void 0, void 0]), _ts_metadata$e("design:returntype", void 0)], HlsJsVideoPlayer.prototype, "handleHlsError", null), _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [void 0, void 0]), _ts_metadata$e("design:returntype", Promise)], HlsJsVideoPlayer.prototype, "handleManifestParsed", null), _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [void 0, void 0]), _ts_metadata$e("design:returntype", void 0)], HlsJsVideoPlayer.prototype, "handleKeyRequestStarted", null), _ts_decorate$e([Bind(), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [void 0, void 0]), _ts_metadata$e("design:returntype", Promise)], HlsJsVideoPlayer.prototype, "handleLicenseChallengeCreated", null), _ts_decorate$e([AsyncDebounce(250), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [Number]), _ts_metadata$e("design:returntype", Promise)], HlsJsVideoPlayer.prototype, "seekToTime", null), _ts_decorate$e([(Pn = 250, (e, n, s) => {
        const d = function(e, n) {
            let s, d, p = 0;
            const resetState = () => {
                clearTimeout(d), d = 0, s = void 0
            };
            return function(...h) {
                const y = this;
                return new Promise((function(_, m) {
                    const v = Date.now();
                    v - p < n ? (s && (s.resolve(void 0), resetState()), s = {
                        resolve: _,
                        reject: m,
                        args: h
                    }, d = setTimeout(() => {
                        e.apply(y, s.args).then(s.resolve).catch(s.reject), resetState()
                    }, n - (v - p + 1))) : (resetState(), p = v, e.apply(y, h).then(_).catch(m))
                }))
            }
        }(s.value, Pn);
        s.value = d
    }), _ts_metadata$e("design:type", Function), _ts_metadata$e("design:paramtypes", [Number]), _ts_metadata$e("design:returntype", Promise)], HlsJsVideoPlayer.prototype, "loadPreviewImage", null);
    class ID3MetadataTrackManager {
        get activeMetadata() {
            return this._activeMetadata
        }
        get activeCues() {
            var e;
            const n = null === (e = this.metadataTrack) || void 0 === e ? void 0 : e.activeCues;
            return null != n ? Array.from(n) : []
        }
        get isDestroyed() {
            return this._isDestroyed
        }
        get tracks() {
            return void 0 !== this.metadataTrack ? [this.metadataTrack] : []
        }
        get currentTrack() {
            return this.metadataTrack
        }
        attach(e) {
            if (void 0 !== this.mediaElement && this.mediaElement !== e) throw new Error("MetadaTrackManager is already attached to a different HTMLMediaElement.");
            this.mediaElement !== e && (this.mediaElement = e, this.mediaElement.addEventListener("loadedmetadata", this.registerMetadataTrack), this.mediaElement.addEventListener("loadeddata", this.registerMetadataTrack))
        }
        detach() {
            void 0 !== this.mediaElement && (this.mediaElement.removeEventListener("loadedmetadata", this.registerMetadataTrack), this.mediaElement.removeEventListener("loadeddata", this.registerMetadataTrack), this.mediaElement = void 0), void 0 !== this.metadataTrack && (this.metadataTrack.removeEventListener("cuechange", this.onCueChange), this.metadataTrack = void 0)
        }
        registerMetadataTrack(e) {
            if (void 0 !== this.mediaElement)
                for (let s = 0; s < this.mediaElement.textTracks.length; s++) {
                    const e = this.mediaElement.textTracks[s];
                    if ("metadata" === e.kind) {
                        var n;
                        if (void 0 === this.metadataTrack) this.metadataTrack = e, this.metadataTrack.addEventListener("cuechange", this.onCueChange);
                        else cn.warning(`Skipping registering metadata TextTrack with id "${null!==(n=e.id)&&void 0!==n?n:"unknown"}"`);
                        break
                    }
                }
        }
        onCueChange(e) {
            if (cn.debug("Processing metadata cues"), void 0 === this.activeCues || this.activeCues.length <= 0) {
                var n;
                if (void 0 !== this.activeMetadata) null === (n = this.onchange) || void 0 === n || n.call(this);
                this._activeMetadata = void 0
            } else {
                const e = function(e) {
                    const n = {};
                    for (const p of e) {
                        if (!isTextTrackID3FrameCue(p) || void 0 === (null == p ? void 0 : p.value)) continue;
                        const e = p.value;
                        switch (e.key) {
                            case "TALB":
                                n.album = e.data;
                                break;
                            case "TIT2":
                                n.title = e.data;
                                break;
                            case "TPE1":
                                n.performer = e.data;
                                break;
                            case "WXXX":
                                var s, d;
                                if (n.links = null !== (s = n.links) && void 0 !== s ? s : [], !n.links.some(({
                                        url: n
                                    }) => n === e.data)) n.links.push({
                                    description: null !== (d = e.description) && void 0 !== d ? d : "",
                                    url: e.data
                                });
                                break;
                            case "PRIV":
                                {
                                    const s = e.owner || e.info;
                                    "com.apple.radio.ping.jingle" === s && (n.blob = parsePingBlob(e.data)),
                                    "com.apple.radio.adamid" === s && (n.storefrontAdamIds = parseStorefrontAdamIds(e.data));
                                    break
                                }
                        }
                    }
                    return new TimedMetadata(n)
                }(this.activeCues);
                var s;
                if (void 0 === this.activeMetadata || !e.equals(this.activeMetadata)) cn.debug("Track TimedMetadata changed", e), this._activeMetadata = e, null === (s = this.onchange) || void 0 === s || s.call(this, e)
            }
        }
        saveTrack() {}
        restoreSelectedTrack() {}
        destroy() {
            this._isDestroyed = !0, this.onchange = void 0, this.detach()
        }
        constructor(e) {
            _define_property$M(this, "_isDestroyed", !1), _define_property$M(this, "mediaElement", void 0), _define_property$M(this, "metadataTrack", void 0), _define_property$M(this, "_activeMetadata", void 0), _define_property$M(this, "onchange", void 0), this.onchange = null == e ? void 0 : e.onchange, void 0 !== (null == e ? void 0 : e.element) && this.attach(e.element)
        }
    }

    function asyncGeneratorStep$y(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$y(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$y(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$y(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$L(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$c(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$c(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    _ts_decorate$d([Bind(), _ts_metadata$d("design:type", Function), _ts_metadata$d("design:paramtypes", [Object]), _ts_metadata$d("design:returntype", void 0)], ID3MetadataTrackManager.prototype, "registerMetadataTrack", null), _ts_decorate$d([Bind(), _ts_metadata$d("design:type", Function), _ts_metadata$d("design:paramtypes", [Object]), _ts_metadata$d("design:returntype", void 0)], ID3MetadataTrackManager.prototype, "onCueChange", null);
    const kn = BooleanDevFlag.get("mk-hlsjs-item-preloading"),
        Tn = {
            keySystemGenericError: "keySystemGenericError"
        },
        En = new Set([MKError.Reason.DEVICE_LIMIT, MKError.Reason.GEO_BLOCK]),
        wn = {};
    wn[He.FAIRPLAY] = "fairplaystreaming", wn[He.PLAYREADY] = "playready", wn[He.WIDEVINE] = "widevine";
    const In = xe.createChild("hlsjs-audio"),
        On = JsonDevFlag.register("mk-hlsjs-config-overrides");
    class HlsJsAudioPlayer extends BasePlayer {
        loadPreviewImage() {
            return _async_to_generator$y((function*() {}))()
        }
        get _targetElement() {
            return this.mediaElement
        }
        preloadItem(e, n) {
            var s = this;
            return _async_to_generator$y((function*() {
                if (In.trace("preloadItem", e, n), !0 === kn) {
                    const d = generateAssetUrl(e, n);
                    In.debug(`Prefetching HLS source for item "${e.id}" with license URL "${d}"`), s.hls.prefetchSource(d, {
                        itemId: e.id
                    })
                }
            }))()
        }
        setPresentationMode(e) {
            return _async_to_generator$y((function*() {
                return Promise.resolve()
            }))()
        }
        get shouldDispatchErrors() {
            return !this.userInitiated || this._playbackDidStart
        }
        get currentPlayingDate() {
            var e;
            return null === (e = this.hls) || void 0 === e ? void 0 : e.playingDate
        }
        get isPlayingAtLiveEdge() {
            var e;
            const n = this.hls;
            return !(!n || !(null === (e = this.nowPlayingItem) || void 0 === e ? void 0 : e.isLinearStream)) && !!n.isPlayingAtLive
        }
        playItemFromEncryptedSource(n, s = !1, d = {}) {
            var p = this;
            return _async_to_generator$y((function*() {
                In.trace("HlsJsAudioPlayer.playItemFromEncryptedSource", n, d), p.playbackState !== e.PlaybackStates.stopped ? (In.debug("Playing Encrypted Item: " + mediaItemLogString(n)), n.playbackType = e.PlaybackType.encryptedFull, p.nowPlayingItem = n, n.state = ee.loading, p.userInitiated = s, yield p.playHlsStream(n.assetURL, n, d)) : In.debug("hlsjsAudioPlayer.playItemFromEncryptedSource aborting playback because player is stopped")
            }))()
        }
        initializeMediaElement() {
            var e = this;
            return _async_to_generator$y((function*() {
                const n = nextAvailableAudioElement();
                n.autoplay = !1, n.id = "apple-music-player", n.controls = !1, n.muted = !1, n.playbackRate = 1, n.preload = "metadata", n.volume = 1, e.mediaElement = n, document.body.appendChild(n), e.id3MetadataManager.attach(n), In.debug("initializedMediaElement", n)
            }))()
        }
        get seekableTimeRanges() {
            const e = this.hls;
            return e ? e.seekableTimeRanges : this.currentPlaybackDuration ? [{
                start: 0,
                end: this.currentPlaybackDuration
            }] : void 0
        }
        initializeExtension() {
            var e = this;
            return _async_to_generator$y((function*() {
                e._keySystem = yield findKeySystemPreference();
                try {
                    var n;
                    if (!qe.urls.hls) throw new Error("bag.urls.hls is not configured");
                    yield Promise.all([loadScript(qe.urls.hls), null === (n = e._rtcTracker) || void 0 === n ? void 0 : n.loadScript()])
                } catch (Rt) {
                    throw In.error("hlsjs-audio-player failed to load script " + qe.urls.hls, Rt), Rt
                }
            }))()
        }
        stopMediaElement() {
            var e = this,
                _superprop_get_stopMediaElement = () => super.stopMediaElement;
            return _async_to_generator$y((function*() {
                In.trace("HlsJsAudioPlayer.stopMediaElement()"), yield _superprop_get_stopMediaElement().call(e), e.destroy()
            }))()
        }
        destroy() {
            if (In.debug("HlsJsAudioPlayer.destroy()"), this.hls) {
                const e = this.hls;
                e.stopLoad();
                const n = e.Events;
                e.off(n.ERROR, this.handleHlsError), e.off(n.INTERNAL_ERROR, this.handleHlsError), e.off(n.MANIFEST_PARSED, this.handleManifestParsed), e.off(n.KEY_REQUEST_STARTED, this.handleKeyRequestStarted), e.off(n.LICENSE_CHALLENGE_CREATED, this.handleLicenseChallengeCreated), e.off(n.LEVEL_SWITCHED, this.handleLevelSwitched), e.destroy()
            }
            this.id3MetadataManager.destroy(), super.destroy(), asAsync(this._license.stop())
        }
        playHlsStream(e, n, s = {}) {
            var d = this;
            return _async_to_generator$y((function*() {
                In.trace("HlsJsAudioPlayer.playHlsStream()", e, n, s);
                const {
                    _keySystem: p
                } = d;
                if (!p) return;
                let h, y;
                d._unrecoverableError = void 0, In.debug("Initiating HLS.js player"), d.createHlsPlayer(), p === He.WIDEVINE && (In.debug("Setting Widevine specific HLS options"), h = "WIDEVINE_SOFTWARE", y = {
                    initDataTypes: ["cenc", "keyids"],
                    distinctiveIdentifier: "optional",
                    persistentState: "required"
                });
                const _ = {
                    subs: "accepts-css",
                    platformInfo: {
                        requiresCDMAttachOnStart: p !== He.NONE,
                        maxSecurityLevel: h,
                        keySystemConfig: y
                    },
                    appData: {
                        serviceName: qe.app.name
                    },
                    itemId: null == n ? void 0 : n.id
                };
                if (void 0 !== d._rtcTracker) {
                    const e = d._rtcTracker.prepareReportingAgent(n);
                    void 0 !== e && (In.debug("Adding RTC agent to loadSource options", e), _.appData.reportingAgent = e)
                }
                const m = d.startPlaybackSequence();
                return In.info("Loading source into HLS.js: " + e), In.debug("Calling loadSource with options", _), d.hls.loadSource(e, _, s.startTime), In.debug("Attaching HTMLMediaElement to HLS instance", d.mediaElement), d.hls.attachMedia(d.mediaElement), n && (d._licenseServerUrl = n.keyURLs["hls-key-server-url"], p === He.FAIRPLAY ? (In.info("Setting Protection Data URL for FairPlay: " + n.keyURLs["hls-key-cert-url"]), d.hls.setProtectionData({
                    fairplaystreaming: {
                        serverCertUrl: n.keyURLs["hls-key-cert-url"]
                    }
                })) : (In.info("Setting Protection Data URL for Widevine: " + n.keyURLs["widevine-cert-url"]), d.hls.setProtectionData({
                    widevine: {
                        serverCertUrl: n.keyURLs["widevine-cert-url"]
                    }
                }))), m
            }))()
        }
        createHlsPlayer() {
            In.trace("HlsJsAudioPlayer.createHlsPlayer()");
            const {
                _keySystem: e
            } = this, {
                os: n
            } = this.services.runtime, {
                Hls: s
            } = window, d = on.get(), p = {
                clearMediaKeysOnPromise: !1,
                debug: !!d,
                debugLevel: d,
                enableItemPreloading: !0 === kn,
                enablePerformanceLogging: !!d,
                enablePlayReadyKeySystem: !0,
                enableRtcReporting: void 0 !== this._rtcTracker,
                keySystemPreference: wn[e],
                useMediaKeySystemAccessFilter: !0,
                nativeControlsEnabled: n.isAndroid,
                enableID3Cues: !0
            };
            In.debug("Reading HLS.js option overrides from DevFlag"), (e => {
                const n = On.value;
                n && "object" == typeof n && Object.assign(e, n)
            })(p), In.debug("Constructing HLS instance", p);
            const h = new s(p);
            In.debug("Using HLS instance with ID " + h.sessionID, p), In.debug("Adding Event handlers for HLS instance"), h.on(s.Events.ERROR, this.handleHlsError), h.on(s.Events.INTERNAL_ERROR, this.handleHlsError), h.on(s.Events.MANIFEST_PARSED, this.handleManifestParsed), h.on(s.Events.KEY_REQUEST_STARTED, this.handleKeyRequestStarted), h.on(s.Events.LICENSE_CHALLENGE_CREATED, this.handleLicenseChallengeCreated), h.on(s.Events.LEVEL_SWITCHED, this.handleLevelSwitched), this.hls = h
        }
        handleLevelSwitched(e, n) {
            var s, d;
            const {
                level: p
            } = n;
            if (!p) return;
            const h = null === (s = this._levels) || void 0 === s ? void 0 : s.find(e => e.persistentId === p);
            if (!h || (null === (d = this._currentLevel) || void 0 === d ? void 0 : d.persistentId) === (null == h ? void 0 : h.persistentId)) return;
            this._currentLevel = h;
            const y = void 0 !== h.audioGroupId ? this._channelsByGroup[h.audioGroupId] : void 0;
            this._dispatcher.publish(ot.hlsLevelUpdated, {
                level: h,
                channels: y
            })
        }
        handleHlsError(e, n) {
            if (In.warn("HLS.js error", JSON.stringify(n)), this._unrecoverableError) return;
            let s = new MKError(MKError.Reason.UNSUPPORTED_ERROR, n.reason);
            s.data = n;
            const {
                keySystemGenericError: d
            } = Tn;
            if (n.details !== d) {
                if ("output-restricted" === n.reason && (s = new MKError(MKError.Reason.OUTPUT_RESTRICTED, n.reason)), n.fatal) {
                    if (this.hls.destroy(), !this.shouldDispatchErrors) throw s;
                    this._dispatcher.publish(st.mediaPlaybackError, s)
                }
            } else this._dispatcher.publish(d, s)
        }
        handleManifestParsed(e, n) {
            var s = this;
            return _async_to_generator$y((function*() {
                var e, d;
                let p;
                In.debug("handleManifestParsed", n), s._levels = null !== (e = n.levels) && void 0 !== e ? e : [], s.nowPlayingItem.state = ee.ready, s._channelsByGroup = (null !== (d = n.audioTracks) && void 0 !== d ? d : []).reduce((e, n) => (e[n.groupId] = n.channels, e), {});
                try {
                    yield s._playMedia()
                } catch (Rt) {
                    throw In.warn("error from media element, possibly non-fatal", Rt), Rt
                } finally {
                    p = yield s.finishPlaybackSequence()
                }
                return p
            }))()
        }
        handleKeyRequestStarted(e, n) {
            var s, d;
            In.trace("HlsJsAudioPlayer.handleKeyRequestStarted()", n);
            const p = null !== (d = null === (s = n.appItemIds) || void 0 === s ? void 0 : s[0]) && void 0 !== d ? d : "unknown";
            In.debug(`Generating key request for item ${p} with URI ${n.keyuri}`), this.hls.generateKeyRequest(n.keyuri, {})
        }
        handleLicenseChallengeCreated(n, s) {
            var d = this;
            return _async_to_generator$y((function*() {
                var n, p;
                In.trace("HlsJsAudioPlayer.handleLicenseChallengeCreated()", s);
                const h = null !== (p = null === (n = s.appItemIds) || void 0 === n ? void 0 : n[0]) && void 0 !== p ? p : "unknown";
                In.debug(`Handling License Challenge for item ${h} with URI ${s.keyuri}`);
                const y = d.nowPlayingItem;
                In.debug("Using MediaItem " + mediaItemLogString(d.nowPlayingItem));
                try {
                    var _;
                    const e = yield null === (_ = d._license) || void 0 === _ ? void 0 : _.start(d._licenseServerUrl, y, s, d._keySystem, d.userInitiated), n = {
                        statusCode: e.status
                    };
                    (null == e ? void 0 : e.license) && (d._keySystem === He.FAIRPLAY ? n.ckc = D(e.license) : n.license = D(e.license));
                    const p = e["renew-after"];
                    p && (n.renewalDate = new Date(Date.now() + 1e3 * p)), In.debug(`Passing License Challenge Response for ${s.keyuri} to HLS`, n), d.hls.setLicenseResponse(s.keyuri, n)
                } catch (Rt) {
                    if (d._unrecoverableError) return;
                    const p = Rt.data,
                        h = {};
                    void 0 !== (null == p ? void 0 : p.status) && (h.statusCode = +p.status), In.warn("Passing license response error to Hls.js", h), d.hls.setLicenseResponse(s.keyuri, h), En.has(Rt.name) && (d._unrecoverableError = Rt, d.resetDeferredPlay(), yield d.stop({
                        endReasonType: e.PlayActivityEndReasonType.FAILED_TO_LOAD,
                        userInitiated: d.userInitiated
                    })), d.onPlaybackLicenseError(Rt)
                }
            }))()
        }
        onPlaybackLicenseError(e) {
            this.resetDeferredPlay(), this._dispatcher.publish(Ye.playbackLicenseError, e)
        }
        seekToTime(e) {
            var n = this;
            return _async_to_generator$y((function*() {
                n.hls ? (In.debug("hlsjs-video: hls seekTo", e), n.hls.seekTo = e) : (In.debug("hlsjs-video: media element seek to", e), n._targetElement.currentTime = e)
            }))()
        }
        constructor(e) {
            var n;
            super(e), _define_property$L(this, "currentAudioTrack", void 0), _define_property$L(this, "currentTextTrack", void 0), _define_property$L(this, "textTracks", []), _define_property$L(this, "audioTracks", []), _define_property$L(this, "userInitiated", !1), _define_property$L(this, "mediaElement", void 0), _define_property$L(this, "mediaPlayerType", "hlsjs-audio"), _define_property$L(this, "hls", void 0), _define_property$L(this, "supportsPreviewImages", !1), _define_property$L(this, "extension", void 0), _define_property$L(this, "_keySystem", void 0), _define_property$L(this, "_license", void 0), _define_property$L(this, "_rtcTracker", void 0), _define_property$L(this, "_levels", void 0), _define_property$L(this, "_channelsByGroup", {}), _define_property$L(this, "_currentLevel", void 0), _define_property$L(this, "_licenseServerUrl", void 0), _define_property$L(this, "_unrecoverableError", void 0), _define_property$L(this, "id3MetadataManager", void 0), this._rtcTracker = null == e || null === (n = e.playbackServices) || void 0 === n ? void 0 : n.getRTCStreamingTracker(), this._license = new License, this.id3MetadataManager = new ID3MetadataTrackManager({
                onchange: e => {
                    var n;
                    const s = {
                        item: this.nowPlayingItem,
                        metadata: e,
                        position: this.currentPlaybackTime,
                        playingDate: this.currentPlayingDate
                    };
                    In.debug("Dispatching bufferTimedMetadataDidChange", s), null === (n = this._dispatcher) || void 0 === n || n.publish(Fi, s)
                }
            })
        }
    }
    _ts_decorate$c([Bind(), _ts_metadata$c("design:type", Function), _ts_metadata$c("design:paramtypes", [void 0, void 0]), _ts_metadata$c("design:returntype", void 0)], HlsJsAudioPlayer.prototype, "handleLevelSwitched", null), _ts_decorate$c([Bind(), _ts_metadata$c("design:type", Function), _ts_metadata$c("design:paramtypes", [void 0, void 0]), _ts_metadata$c("design:returntype", void 0)], HlsJsAudioPlayer.prototype, "handleHlsError", null), _ts_decorate$c([Bind(), _ts_metadata$c("design:type", Function), _ts_metadata$c("design:paramtypes", [void 0, void 0]), _ts_metadata$c("design:returntype", Promise)], HlsJsAudioPlayer.prototype, "handleManifestParsed", null), _ts_decorate$c([Bind(), _ts_metadata$c("design:type", Function), _ts_metadata$c("design:paramtypes", [Object, Object]), _ts_metadata$c("design:returntype", void 0)], HlsJsAudioPlayer.prototype, "handleKeyRequestStarted", null), _ts_decorate$c([Bind(), _ts_metadata$c("design:type", Function), _ts_metadata$c("design:paramtypes", [Object, "undefined" == typeof LicenseData ? Object : LicenseData]), _ts_metadata$c("design:returntype", Promise)], HlsJsAudioPlayer.prototype, "handleLicenseChallengeCreated", null), _ts_decorate$c([Bind(), _ts_metadata$c("design:type", Function), _ts_metadata$c("design:paramtypes", ["undefined" == typeof Error ? Object : Error]), _ts_metadata$c("design:returntype", void 0)], HlsJsAudioPlayer.prototype, "onPlaybackLicenseError", null), _ts_decorate$c([AsyncDebounce(250), _ts_metadata$c("design:type", Function), _ts_metadata$c("design:paramtypes", [Number]), _ts_metadata$c("design:returntype", Promise)], HlsJsAudioPlayer.prototype, "seekToTime", null), e.version = "3.2526.0";
    const Rn = e.version.split(".");
    Rn[0];
    const An = Rn[Rn.length - 1];
    var $n, Mn;
    Rn[0] = "3", Rn[Rn.length - 1] = An + "-prerelease.x", e.version = Rn.join("."), e.PlaybackActions = void 0, ($n = e.PlaybackActions || (e.PlaybackActions = {})).REPEAT = "REPEAT", $n.SHUFFLE = "SHUFFLE", $n.AUTOPLAY = "AUTOPLAY", e.PlaybackMode = void 0, (Mn = e.PlaybackMode || (e.PlaybackMode = {}))[Mn.PREVIEW_ONLY = 0] = "PREVIEW_ONLY", Mn[Mn.MIXED_CONTENT = 1] = "MIXED_CONTENT", Mn[Mn.FULL_PLAYBACK_ONLY = 2] = "FULL_PLAYBACK_ONLY";
    const Cn = {
        configured: "musickitconfigured",
        loaded: "musickitloaded",
        audioTrackAdded: st.audioTrackAdded,
        audioTrackChanged: st.audioTrackChanged,
        audioTrackRemoved: st.audioTrackRemoved,
        authorizationStatusDidChange: Ce.authorizationStatusDidChange,
        authorizationStatusWillChange: Ce.authorizationStatusWillChange,
        bufferedProgressDidChange: st.bufferedProgressDidChange,
        capabilitiesChanged: "capabilitiesChanged",
        autoplayEnabledDidChange: "autoplayEnabledDidChange",
        drmUnsupported: st.drmUnsupported,
        eligibleForSubscribeView: Ce.eligibleForSubscribeView,
        forcedTextTrackChanged: st.forcedTextTrackChanged,
        hlsDaterangeUpdated: st.hlsDaterangeUpdated,
        mediaCanPlay: st.mediaCanPlay,
        mediaElementCreated: st.mediaElementCreated,
        mediaItemStateDidChange: E.mediaItemStateDidChange,
        mediaItemStateWillChange: E.mediaItemStateWillChange,
        mediaPlaybackError: st.mediaPlaybackError,
        mediaSkipAvailable: "mediaSkipAvailable",
        mediaRollEntered: "mediaRollEntered",
        mediaUpNext: "mediaUpNext",
        metadataDidChange: st.metadataDidChange,
        nowPlayingItemDidChange: st.nowPlayingItemDidChange,
        nowPlayingItemWillChange: st.nowPlayingItemWillChange,
        playInitiated: "playInitiated",
        playbackBitrateDidChange: st.playbackBitrateDidChange,
        playbackDurationDidChange: st.playbackDurationDidChange,
        playbackProgressDidChange: st.playbackProgressDidChange,
        playbackRateDidChange: st.playbackRateDidChange,
        playbackStateDidChange: st.playbackStateDidChange,
        playbackStateWillChange: st.playbackStateWillChange,
        playbackTargetAvailableDidChange: st.playbackTargetAvailableDidChange,
        playbackTargetIsWirelessDidChange: st.playbackTargetIsWirelessDidChange,
        playbackTimeDidChange: st.playbackTimeDidChange,
        playbackVolumeDidChange: st.playbackVolumeDidChange,
        playerTypeDidChange: st.playerTypeDidChange,
        presentationModeDidChange: st.presentationModeDidChange,
        primaryPlayerDidChange: st.primaryPlayerDidChange,
        queueIsReady: "queueIsReady",
        queueItemsDidChange: "queueItemsDidChange",
        queueItemForStartPosition: "queueItemForStartPosition",
        queuePositionDidChange: "queuePositionDidChange",
        shuffleModeDidChange: "shuffleModeDidChange",
        repeatModeDidChange: "repeatModeDidChange",
        storefrontCountryCodeDidChange: Ce.storefrontCountryCodeDidChange,
        storefrontIdentifierDidChange: Ce.storefrontIdentifierDidChange,
        textTrackAdded: st.textTrackAdded,
        textTrackChanged: st.textTrackChanged,
        textTrackRemoved: st.textTrackRemoved,
        timedMetadataDidChange: st.timedMetadataDidChange,
        userTokenDidChange: Ce.userTokenDidChange,
        webComponentsLoaded: "musickitwebcomponentsloaded"
    };

    function asyncGeneratorStep$x(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$K(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_metadata$b(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    class SpanWatcher {
        startMonitor() {
            this.dispatcher.unsubscribe(Cn.playbackTimeDidChange, this.handleTimeChange), this.dispatcher.subscribe(Cn.playbackTimeDidChange, this.handleTimeChange)
        }
        stopMonitor() {
            this.dispatcher.unsubscribe(Cn.playbackTimeDidChange, this.handleTimeChange)
        }
        handleTimeChange(e, {
            currentPlaybackTime: n
        }) {
            var s, d = this;
            return (s = function*() {
                !Number.isFinite(n) || n < d.start || n > d.stop ? d.inWatchSpan = !1 : d.inWatchSpan || (d.allowMultiple || d.stopMonitor(), d.inWatchSpan = !0, yield d.callback(n, d))
            }, function() {
                var e = this,
                    n = arguments;
                return new Promise((function(d, p) {
                    var h = s.apply(e, n);

                    function _next(e) {
                        asyncGeneratorStep$x(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$x(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        constructor(e, n, s, d, p = !1) {
            _define_property$K(this, "dispatcher", void 0), _define_property$K(this, "callback", void 0), _define_property$K(this, "start", void 0), _define_property$K(this, "stop", void 0), _define_property$K(this, "allowMultiple", void 0), _define_property$K(this, "inWatchSpan", void 0), this.dispatcher = e, this.callback = n, this.start = s, this.stop = d, this.allowMultiple = p, this.inWatchSpan = !1
        }
    }

    function _define_property$J(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_metadata$a(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$b("design:type", Function), _ts_metadata$b("design:paramtypes", [void 0, void 0]), _ts_metadata$b("design:returntype", Promise)], SpanWatcher.prototype, "handleTimeChange", null);
    class PlaybackMonitor {
        activate() {
            this.isActive = !0, this.startMonitor()
        }
        deactivate() {
            this.isActive = !1, this.clearMonitor()
        }
        clearMonitor() {
            this.isMonitoring && (this.watchers.forEach(e => e.stopMonitor()), this.isMonitoring = !1)
        }
        shouldMonitor() {
            return this.isActive
        }
        startMonitor() {
            this.shouldMonitor() && (this.watchers.forEach(e => e.startMonitor()), this.isMonitoring = !0)
        }
        handleMediaItemChange() {
            this.isActive && (this.clearMonitor(), this.shouldMonitor() && this.startMonitor())
        }
        constructor(e) {
            _define_property$J(this, "isActive", !1), _define_property$J(this, "isMonitoring", !1), _define_property$J(this, "apiManager", void 0), _define_property$J(this, "dispatcher", void 0), _define_property$J(this, "playbackController", void 0), _define_property$J(this, "watchers", []), this.handlePlaybackThreshold = this.handlePlaybackThreshold.bind(this), this.playbackController = e.controller, this.dispatcher = e.services.dispatcher, this.dispatcher.subscribe(Cn.nowPlayingItemDidChange, this.handleMediaItemChange), this.apiManager = e.services.apiManager
        }
    }

    function asyncGeneratorStep$w(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$a("design:type", Function), _ts_metadata$a("design:paramtypes", []), _ts_metadata$a("design:returntype", void 0)], PlaybackMonitor.prototype, "handleMediaItemChange", null);
    class RollMonitor extends PlaybackMonitor {
        handlePlaybackThreshold(e, n) {
            var s, d = this;
            return (s = function*() {
                if (!d.rollMap.has(n)) return;
                const e = d.rollMap.get(n);
                d.dispatcher.publish(Cn.mediaRollEntered, e), d.rollMap.delete(n)
            }, function() {
                var e = this,
                    n = arguments;
                return new Promise((function(d, p) {
                    var h = s.apply(e, n);

                    function _next(e) {
                        asyncGeneratorStep$w(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$w(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        shouldMonitor() {
            if (!super.shouldMonitor()) return !1;
            return this.getRollMetadata().length > 0
        }
        startMonitor() {
            this.setupWatchers(this.getRollMetadata()), super.startMonitor()
        }
        getRollMetadata() {
            const e = this.playbackController.nowPlayingItem;
            return void 0 === e ? [] : function(e, n = ["pre-roll", "mid-roll", "post-roll"]) {
                if (void 0 === e.hlsMetadata) return [];
                const s = [];
                return n.forEach(n => {
                    const d = parseInt(e.hlsMetadata[n + ".count"], 10);
                    if (!isNaN(d))
                        for (let p = 0; p < d; p++) {
                            const d = `${n}.${p}`,
                                h = {
                                    index: p,
                                    type: n,
                                    skippable: "true" === e.hlsMetadata[d + ".skippable"],
                                    "adam-id": e.hlsMetadata[d + ".adam-id"],
                                    start: Math.round(parseFloat(e.hlsMetadata[d + ".start"])),
                                    duration: Math.round(parseFloat(e.hlsMetadata[d + ".duration"]))
                                },
                                y = d + ".dynamic-slot.data-set-id";
                            void 0 !== e.hlsMetadata[y] && (h["dynamic-id"] = e.hlsMetadata[y]), s.push(h)
                        }
                }), s
            }(e, ["pre-roll", "post-roll"])
        }
        setupWatchers(e) {
            const n = [];
            e.forEach(e => {
                const {
                    start: s,
                    duration: d
                } = e, p = new SpanWatcher(this.dispatcher, this.handlePlaybackThreshold, s, s + d);
                n.push(p), this.rollMap.set(p, e)
            }), this.watchers = n
        }
        constructor(e) {
            super(e),
                function(e, n, s) {
                    n in e ? Object.defineProperty(e, n, {
                        value: s,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[n] = s
                }(this, "rollMap", new Map)
        }
    }

    function asyncGeneratorStep$v(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }
    class SkipAvailable extends PlaybackMonitor {
        handlePlaybackThreshold(e, n) {
            var s, d = this;
            return (s = function*() {
                if (!d.skipMap.has(n)) return;
                const e = d.skipMap.get(n);
                d.dispatcher.publish(Cn.mediaSkipAvailable, e)
            }, function() {
                var e = this,
                    n = arguments;
                return new Promise((function(d, p) {
                    var h = s.apply(e, n);

                    function _next(e) {
                        asyncGeneratorStep$v(h, d, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$v(h, d, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        shouldMonitor() {
            if (!super.shouldMonitor()) return !1;
            return this.getNowPlayingMetadata().length > 0
        }
        startMonitor() {
            this.setupWatchers(this.getNowPlayingMetadata()), super.startMonitor()
        }
        getNowPlayingMetadata() {
            const e = this.playbackController.nowPlayingItem;
            return void 0 === e ? [] : function(e) {
                const n = parseInt(e.hlsMetadata["skip.count"], 10),
                    s = [];
                if (isNaN(n) || 0 === n) return s;
                for (let d = 0; d < n; d++) {
                    const n = {
                        start: parseFloat(e.hlsMetadata[`skip.${d}.start`]),
                        duration: parseFloat(e.hlsMetadata[`skip.${d}.duration`]),
                        target: parseFloat(e.hlsMetadata[`skip.${d}.target`]),
                        label: e.hlsMetadata[`skip.${d}.label`]
                    };
                    void 0 !== e.hlsMetadata[`skip.${d}.promo.enabled`] && (n.promo = {
                        enabled: "true" === e.hlsMetadata[`skip.${d}.promo.enabled`],
                        image: e.hlsMetadata[`skip.${d}.promo.image`],
                        "image-height": parseInt(e.hlsMetadata[`skip.${d}.promo.image-height`], 10),
                        "image-width": parseInt(e.hlsMetadata[`skip.${d}.promo.image-width`], 10),
                        genre: e.hlsMetadata[`skip.${d}.promo.genre`],
                        "release-year": parseInt(e.hlsMetadata[`skip.${d}.promo.release-year`], 10),
                        "rating-display-name": e.hlsMetadata[`skip.${d}.promo.rating-display-name`],
                        "rating-system": e.hlsMetadata[`skip.${d}.promo.rating-system`],
                        "canonical-id": e.hlsMetadata[`skip.${d}.promo.canonical-id`],
                        title: e.hlsMetadata[`skip.${d}.promo.title`],
                        "rating-tag": e.hlsMetadata[`skip.${d}.promo.rating-tag`],
                        "rating-rank": e.hlsMetadata[`skip.${d}.promo.rating-rank`],
                        "up-next": {
                            "is-added": "true" === e.hlsMetadata[`skip.${d}.promo.up-next.is-added`],
                            "add-label": e.hlsMetadata[`skip.${d}.promo.up-next.add-label`],
                            "added-label": e.hlsMetadata[`skip.${d}.promo.up-next.added-label`]
                        },
                        runtime: parseInt(e.hlsMetadata[`skip.${d}.promo.runtime`], 10)
                    }), s.push(n)
                }
                return s
            }(e)
        }
        setupWatchers(e) {
            const n = [];
            e.forEach(e => {
                const {
                    start: s,
                    target: d,
                    duration: p,
                    promo: h
                } = e, y = new SpanWatcher(this.dispatcher, this.handlePlaybackThreshold, s, h ? d : s + p, !0);
                n.push(y), this.skipMap.set(y, e)
            }), this.watchers = n
        }
        constructor(e) {
            super(e),
                function(e, n, s) {
                    n in e ? Object.defineProperty(e, n, {
                        value: s,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[n] = s
                }(this, "skipMap", new Map)
        }
    }

    function asyncGeneratorStep$u(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$G(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const hasContentCompletionThresholdData = e => !isNaN(getUpNextStart(e)) && !isNaN(getWatchedTime(e)),
        getUpNextStart = e => parseFloat(e.hlsMetadata["up-next.start"]),
        getWatchedTime = e => parseFloat(e.hlsMetadata["watched.time"]),
        Dn = (Ln = function*(e, n) {
            if (e.isUTS && e.assetURL) try {
                const s = generateAssetUrl(e, n),
                    d = yield Ji.fetchManifest(s);
                e.hlsMetadata = function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var s = null != arguments[n] ? arguments[n] : {},
                            d = Object.keys(s);
                        "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                            return Object.getOwnPropertyDescriptor(s, e).enumerable
                        })))), d.forEach((function(n) {
                            _define_property$G(e, n, s[n])
                        }))
                    }
                    return e
                }({}, e.hlsMetadata, function(e, n = {}) {
                    const s = /^(?:#EXT-X-SESSION-DATA:?)DATA-ID="([^"]+)".+VALUE="([^"]+)".*$/,
                        d = {};
                    for (const p of e.split("\n")) {
                        const e = p.match(s);
                        if (e) {
                            let s = e[1];
                            e[1].startsWith("com.apple.hls.") && !1 !== n.stripPrefix && (s = e[1].slice("com.apple.hls.".length));
                            const p = e[2];
                            d[s] = p
                        }
                    }
                    return d
                }(d.content))
            } catch (ce) {
                Ne.error(ce.message, ce)
            }
        }, xn = function() {
            var e = this,
                n = arguments;
            return new Promise((function(s, d) {
                var p = Ln.apply(e, n);

                function _next(e) {
                    asyncGeneratorStep$u(p, s, d, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$u(p, s, d, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }, function(e, n) {
            return xn.apply(this, arguments)
        });
    var Ln, xn, jn;

    function asyncGeneratorStep$t(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _ts_metadata$9(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    class UpNextMonitor extends PlaybackMonitor {
        handlePlaybackThreshold() {
            var e = this;
            return function(e) {
                return function() {
                    var n = this,
                        s = arguments;
                    return new Promise((function(d, p) {
                        var h = e.apply(n, s);

                        function _next(e) {
                            asyncGeneratorStep$t(h, d, p, _next, _throw, "next", e)
                        }

                        function _throw(e) {
                            asyncGeneratorStep$t(h, d, p, _next, _throw, "throw", e)
                        }
                        _next(void 0)
                    }))
                }
            }((function*() {
                e.dispatcher.publish(Cn.mediaUpNext)
            }))()
        }
        shouldMonitor() {
            if (!super.shouldMonitor()) return !1;
            const e = this.playbackController.nowPlayingItem;
            return void 0 !== e && hasContentCompletionThresholdData(e)
        }
        startMonitor() {
            this.setupWatchers(), super.startMonitor()
        }
        setupWatchers() {
            const e = this.playbackController.nowPlayingItem;
            e && hasContentCompletionThresholdData(e) && (this.watchers = [new SpanWatcher(this.dispatcher, this.handlePlaybackThreshold, Math.round(this.getStartTime(e)), Number.POSITIVE_INFINITY)])
        }
        getStartTime(e) {
            const n = getUpNextStart(e);
            return isNaN(n) ? getWatchedTime(e) : n
        }
        constructor(e) {
            super(e)
        }
    }

    function deprecationWarning(e, n = {}) {
        var s;
        const d = null !== (s = n.message) && void 0 !== s ? s : e + " has been deprecated",
            p = [];
        n.since && p.push("since: " + n.since), n.until && p.push("until: " + n.until), console.warn("Deprecation Warning: " + d + (p.length > 0 ? ` (${p.join(", ")})` : ""))
    }

    function _define_property$F(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$9("design:type", Function), _ts_metadata$9("design:paramtypes", []), _ts_metadata$9("design:returntype", Promise)], UpNextMonitor.prototype, "handlePlaybackThreshold", null), e.PlayerRepeatMode = void 0, (jn = e.PlayerRepeatMode || (e.PlayerRepeatMode = {}))[jn.none = 0] = "none", jn[jn.one = 1] = "one", jn[jn.all = 2] = "all";
    class BaseRepeatable {
        get repeatMode() {
            return 0
        }
        set repeatMode(e) {
            e !== this.repeatMode && Ne.warn("setting repeatMode is not supported in this playback method")
        }
        constructor() {
            _define_property$F(this, "canSetRepeatMode", !1)
        }
    }
    class Repeatable {
        get repeatMode() {
            return this._repeatMode
        }
        set repeatMode(n) {
            n in e.PlayerRepeatMode && n !== this._repeatMode && (this._repeatMode = n, this.dispatcher.publish(Cn.repeatModeDidChange, this._repeatMode))
        }
        constructor(e, n = 0) {
            _define_property$F(this, "canSetRepeatMode", !0), _define_property$F(this, "dispatcher", void 0), _define_property$F(this, "_repeatMode", void 0), this.dispatcher = e, this._repeatMode = n
        }
    }
    const Nn = getHlsJsCdnConfig(),
        Un = {
            app: {},
            autoplay: {
                maxQueueSizeForAutoplay: 50,
                maxQueueSizeInRequest: 10,
                maxUpcomingTracksToMaintain: 10
            },
            features: {
                xtrick: !0,
                isWeb: !0,
                bookmarking: !1,
                "seamless-audio-transitions": !0,
                "enhanced-hls": !1
            },
            urls: {
                hls: Nn.hls,
                rtc: Nn.rtc,
                mediaApi: "https://api.music.apple.com/v1",
                webPlayback: `https://${getCommerceHostname("play")}/WebObjects/MZPlay.woa/wa/webPlayback`
            }
        };

    function asyncGeneratorStep$s(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$s(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$s(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$s(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$E(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread_props$h(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    let Fn;
    class Store {
        get authorizationStatus() {
            return this.storekit.authorizationStatus
        }
        get cid() {
            return this.storekit.cid
        }
        get developerToken() {
            return this.storekit.developerToken
        }
        get hasAuthorized() {
            return this._hasAuthorized
        }
        get isAuthorized() {
            return this.storekit.hasAuthorized
        }
        get isRestricted() {
            return this.storekit.authorizationStatus === Ie.RESTRICTED
        }
        get isU13() {
            return this.storekit.isU13
        }
        get metricsClientId() {
            return this._metricsClientId
        }
        set metricsClientId(e) {
            this._metricsClientId = e
        }
        get musicUserToken() {
            return this.storekit.userToken
        }
        set musicUserToken(e) {
            this.storekit.userToken = e
        }
        set dynamicMusicUserToken(e) {
            this.storekit.dynamicUserToken = e
        }
        get realm() {
            return this.storekit.realm
        }
        set requestUserToken(e) {
            this._providedRequestUserToken = !0, this.storekit.requestUserToken = e
        }
        get restrictedEnabled() {
            return this.storekit.restrictedEnabled
        }
        set restrictedEnabled(e) {
            this.storekit.overrideRestrictEnabled(e)
        }
        get storefrontCountryCode() {
            var e;
            return this.isAuthorized ? this.storekit.storefrontCountryCode : null !== (e = this._defaultStorefrontCountryCode) && void 0 !== e ? e : this.storekit.storefrontCountryCode
        }
        get storefrontId() {
            return this._apiStorefrontId || this.storekit.storefrontCountryCode
        }
        set storefrontId(e) {
            e && (e = e.toLowerCase()), e !== this._apiStorefrontId && (this._apiStorefrontId = e, this.dispatcher.publish(ot.apiStorefrontChanged, {
                storefrontId: e
            }))
        }
        get subscribeURL() {
            return this.storekit.deeplinkURL({
                p: "subscribe"
            })
        }
        get subscribeFamilyURL() {
            return this.storekit.deeplinkURL({
                p: "subscribe-family"
            })
        }
        get subscribeIndividualURL() {
            return this.storekit.deeplinkURL({
                p: "subscribe-individual"
            })
        }
        get subscribeStudentURL() {
            return this.storekit.deeplinkURL({
                p: "subscribe-student"
            })
        }
        get userToken() {
            return this.musicUserToken
        }
        authorize() {
            var e = this;
            return _async_to_generator$s((function*() {
                if (e.storekit.userTokenIsValid) return e.storekit.userToken;
                let n;
                try {
                    n = yield e.storekit.requestUserToken()
                } catch (ce) {
                    try {
                        yield e.unauthorize()
                    } catch (Rt) {}
                    throw new MKError(MKError.Reason.AUTHORIZATION_ERROR, "Unauthorized")
                }
                return e._providedRequestUserToken && (e.storekit.userToken = n), e.storekit.userTokenIsValid ? (yield e.storekit.requestStorefrontCountryCode().catch(function() {
                    var n = _async_to_generator$s((function*(n) {
                        return yield e.unauthorize(), Promise.reject(n)
                    }));
                    return function(e) {
                        return n.apply(this, arguments)
                    }
                }()), n) : void 0
            }))()
        }
        unauthorize() {
            var e = this;
            return _async_to_generator$s((function*() {
                return e.storekit.revokeUserToken()
            }))()
        }
        constructor(n, s = {}) {
            var d, p;
            _define_property$E(this, "precache", void 0), _define_property$E(this, "storekit", void 0), _define_property$E(this, "dispatcher", void 0), _define_property$E(this, "_apiStorefrontId", void 0), _define_property$E(this, "_defaultStorefrontCountryCode", void 0), _define_property$E(this, "_hasAuthorized", !1), _define_property$E(this, "_metricsClientId", void 0), _define_property$E(this, "_providedRequestUserToken", !1), this.dispatcher = s.services.dispatcher, "precache" in s && (this.precache = s.precache), s.storefrontId && (this.storefrontId = s.storefrontId), this._defaultStorefrontCountryCode = s.storefrontCountryCode, ("affiliateToken" in s || "campaignToken" in s) && (s.linkParameters = _object_spread_props$h(function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$E(e, n, s[n])
                    }))
                }
                return e
            }({}, s.linkParameters || {}), {
                at: s.affiliateToken,
                ct: s.campaignToken
            })), this.storekit = new StoreKit(n, {
                apiBase: Un.urls.mediaApi,
                authenticateMethod: Un.features["legacy-authenticate-method"] ? "POST" : "GET",
                deeplink: s.linkParameters,
                disableAuthBridge: s.disableAuthBridge,
                iconURL: Un.app.icon,
                meParameters: s.meParameters,
                persist: s.persist,
                realm: s.realm || e.SKRealm.MUSIC,
                fetch: null == s || null === (p = s.services) || void 0 === p || null === (d = p.request) || void 0 === d ? void 0 : d.fetch
            }), this.storekit.addEventListener(Cn.authorizationStatusDidChange, e => {
                const {
                    authorizationStatus: n
                } = e;
                this._hasAuthorized = [Ie.AUTHORIZED, Ie.RESTRICTED].includes(n)
            })
        }
    }

    function formattedSeconds(e) {
        return {
            hours: Math.floor(e / 3600),
            minutes: Math.floor(e % 3600 / 60)
        }
    }

    function asyncGeneratorStep$r(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$r(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$r(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$r(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function hasAuthorization(e) {
        return void 0 === e && (e = Fn && Fn.storekit), void 0 !== e && e.hasAuthorized && e.userTokenIsValid
    }

    function hasMusicSubscription(e) {
        return _hasMusicSubscription.apply(this, arguments)
    }

    function _hasMusicSubscription() {
        return (_hasMusicSubscription = _async_to_generator$r((function*(e) {
            return void 0 === e && (e = Fn && Fn.storekit), e.hasMusicSubscription()
        }))).apply(this, arguments)
    }

    function _define_property$D(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function transform$8(e) {
        return function(e) {
            for (var n = 1; n < arguments.length; n++) {
                var s = null != arguments[n] ? arguments[n] : {},
                    d = Object.keys(s);
                "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(s, e).enumerable
                })))), d.forEach((function(n) {
                    _define_property$D(e, n, s[n])
                }))
            }
            return e
        }({
            attributes: {}
        }, transform$a({
            id: "metadata.itemId",
            type: "metadata.itemType",
            "attributes.contentRating": function() {
                var n;
                if (1 === (null == e || null === (n = e.metadata) || void 0 === n ? void 0 : n.isExplicit)) return "explicit"
            },
            "attributes.playParams": function() {
                var n, s, d;
                return 0 !== (null == e || null === (n = e.metadata) || void 0 === n ? void 0 : n.isPlayable) && {
                    id: null == e || null === (s = e.metadata) || void 0 === s ? void 0 : s.itemId,
                    kind: null == e || null === (d = e.metadata) || void 0 === d ? void 0 : d.itemType
                }
            },
            "container.id": "metadata.containerId",
            "container.name": "metadata.containerName",
            "container.type": "metadata.containerType"
        }, e))
    }

    function _define_property$C(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$o(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$C(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$g(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const Bn = {
        condition: () => !0,
        toOptions: (e, n, s) => [_object_spread_props$g(_object_spread$o({}, e), {
            context: s
        })]
    };

    function _define_property$B(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$n(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$B(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$f(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const Kn = {
        condition: e => {
            var n;
            return "stations" === e.type && (null === (n = e.attributes) || void 0 === n ? void 0 : n.isLive)
        },
        toOptions: (e, n, s) => [_object_spread_props$f(_object_spread$n({}, e), {
            context: s,
            container: {
                attributes: e.attributes,
                id: e.id,
                type: e.type,
                name: null == s ? void 0 : s.featureName
            }
        })]
    };

    function _define_property$A(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$m(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$A(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$e(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const Gn = {
            condition: function(e) {
                var n, s, d, p;
                return "stations" === e.type && "streaming" === (null === (n = e.attributes) || void 0 === n ? void 0 : n.kind) && "episode" === (null === (d = e.attributes) || void 0 === d || null === (s = d.streamingRadioSubType) || void 0 === s ? void 0 : s.toLowerCase()) && !1 === (null === (p = e.attributes) || void 0 === p ? void 0 : p.isLive)
            },
            toOptions: function(e, n, s) {
                var d, p;
                return [_object_spread_props$e(_object_spread$m({}, e), {
                    context: s,
                    container: {
                        attributes: e.attributes,
                        id: e.id,
                        type: e.type,
                        name: null == s ? void 0 : s.featureName,
                        stationHash: null === (p = e.attributes) || void 0 === p || null === (d = p.playParams) || void 0 === d ? void 0 : d.stationHash
                    }
                })]
            }
        },
        typeIs = (...e) => ({
            type: n
        }) => e.includes(n),
        withBagPrefix = e => {
            if (void 0 === e || "" === e) return;
            const {
                prefix: n
            } = Un;
            return n ? `${n}:${e}` : e
        };

    function _define_property$z(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread_props$d(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const getContainerName$1 = (e, n) => {
            var s, d;
            return null !== (d = null != n ? n : null == e || null === (s = e.container) || void 0 === s ? void 0 : s.name) && void 0 !== d ? d : ct.SONG
        },
        Vn = {
            toOptions: (e, n, s) => {
                const d = _object_spread_props$d(function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var s = null != arguments[n] ? arguments[n] : {},
                            d = Object.keys(s);
                        "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                            return Object.getOwnPropertyDescriptor(s, e).enumerable
                        })))), d.forEach((function(n) {
                            _define_property$z(e, n, s[n])
                        }))
                    }
                    return e
                }({
                    id: e.id
                }, n), {
                    name: withBagPrefix(getContainerName$1(e, null == s ? void 0 : s.featureName))
                });
                return [{
                    relationships: e.relationships,
                    attributes: e.attributes,
                    id: e.id,
                    type: e.type,
                    container: d,
                    context: s
                }]
            },
            condition: typeIs("songs", "library-songs", "music-videos")
        };

    function _define_property$y(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$k(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$y(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$c(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const parseAssets = ({
            type: e,
            attributes: {
                assetTokens: n
            }
        }) => e.includes("udio") ? (e => {
            if (void 0 === e) return;
            const [n] = Object.keys(e);
            return e[n]
        })(n) : (e => {
            if (void 0 === e) return;
            const n = Object.keys(e);
            return e[n[n.length - 1]]
        })(n),
        Hn = {
            condition: typeIs("uploaded-audios", "uploadedAudio", "uploaded-videos", "uploadedVideo"),
            toOptions: (e, n, s) => {
                var d, p;
                const h = _object_spread_props$c(_object_spread$k({}, e), {
                    context: s,
                    attributes: _object_spread_props$c(_object_spread$k({}, e.attributes), {
                        assetUrl: parseAssets(e),
                        playParams: null !== (p = null == e || null === (d = e.attributes) || void 0 === d ? void 0 : d.playParams) && void 0 !== p ? p : {
                            id: e.id,
                            kind: e.type
                        }
                    })
                });
                return void 0 !== n && (h.container = n), void 0 !== (null == s ? void 0 : s.featureName) && (h.container = _object_spread_props$c(_object_spread$k({}, h.container), {
                    name: null == s ? void 0 : s.featureName
                })), [h]
            }
        };
    const getFeatureName = (e, n) => {
        if (n) return n;
        const s = function(e = []) {
            return 0 !== e.length && e.filter(({
                attributes: e
            }) => !!e && (e.workName || e.movementName || e.movementCount || e.movementNumber)).length > 0
        }(e.relationships.tracks.data);
        return "albums" === e.type || "library-albums" === e.type ? s ? ct.ALBUM_CLASSICAL : ct.ALBUM : "playlists" === e.type || "library-playlists" === e.type ? s ? ct.PLAYLIST_CLASSICAL : ct.PLAYLIST : void 0
    };
    var qn;

    function _define_property$x(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$j(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$x(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$b(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const Wn = [{
            toOptions: (e, n, s) => {
                const d = {
                    attributes: e.attributes,
                    id: e.id,
                    type: e.type,
                    name: withBagPrefix(getFeatureName(e, null == s ? void 0 : s.featureName))
                };
                return e.relationships.tracks.data.map(e => ({
                    attributes: e.attributes,
                    id: e.id,
                    type: e.type,
                    container: d,
                    context: s
                }))
            },
            condition: (qn = "tracks", e => {
                var n, s;
                return !!(null === (s = e.relationships) || void 0 === s || null === (n = s[qn]) || void 0 === n ? void 0 : n.data)
            }),
            requiredRelationships: ["tracks"]
        }, Vn, Kn, Gn, Hn, {
            condition: typeIs("music-movies"),
            toOptions: (e, n, s) => {
                var d, p;
                const h = _object_spread_props$b(_object_spread$j({}, e), {
                    context: s,
                    attributes: _object_spread_props$b(_object_spread$j({}, e.attributes), {
                        playParams: null !== (p = null == e || null === (d = e.attributes) || void 0 === d ? void 0 : d.playParams) && void 0 !== p ? p : {
                            id: e.id,
                            kind: "musicMovie"
                        },
                        offers: void 0
                    })
                });
                return void 0 !== n && (h.container = n), void 0 !== (null == s ? void 0 : s.featureName) && (h.container = _object_spread_props$b(_object_spread$j({}, h.container), {
                    name: null == s ? void 0 : s.featureName
                })), [h]
            }
        }],
        transform = (e, n, s = {}) => {
            var d, p, h;
            n = null !== (p = null == n || null === (d = n.serialize) || void 0 === d ? void 0 : d.call(n).data) && void 0 !== p ? p : n;
            return (null !== (h = Wn.find(d => d.condition(e, n, s))) && void 0 !== h ? h : Bn).toOptions(e, n, s).map(e => new MediaItem(e))
        },
        zn = Wn.reduce((e, n) => {
            const s = n.requiredRelationships;
            return s && e.push(...s), e
        }, []),
        Yn = new Set(zn),
        isArrayOf = (e, n) => Array.isArray(e) && (0 === e.length || n(e[0])),
        isMediaAPIResource$1 = e => e && void 0 !== e.id && void 0 !== e.type,
        isMediaItem = e => e && void 0 !== e.id,
        isMPMediaItem = e => e && void 0 !== e.contentId && void 0 !== e.metadata && void 0 !== e.metadata.itemId && void 0 !== e.metadata.itemType,
        isQueueLoaded = e => e && e.loaded;

    function _define_property$w(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const Qn = Ge.linkChild(new Logger("queue")),
        descriptorToMediaItems = e => {
            if (!(e => e && e.items && Array.isArray(e.items))(e) && !isQueueLoaded(e)) return [];
            const n = isQueueLoaded(e) ? loadedDescriptorToMediaItem(e) : unloadedDescriptorToMediaItem(e);
            return n.forEach(n => n.context = function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$w(e, n, s[n])
                    }))
                }
                return e
            }({}, e.context, n.context)), n
        },
        unloadedDescriptorToMediaItem = ({
            items: e
        }) => isArrayOf(e, isMPMediaItem) ? e.map(e => new MediaItem(transform$8(e))) : isArrayOf(e, isMediaItem) ? e.map(e => new MediaItem(e)) : [],
        loadedDescriptorToMediaItem = e => {
            const n = [],
                {
                    loaded: s,
                    container: d,
                    context: p
                } = e;
            return void 0 === s ? [] : isArrayOf(s, isDataRecord) ? (s.forEach(e => {
                n.push(...dataRecordToMediaItems(e, d, p))
            }), n) : isArrayOf(s, isMediaAPIResource$1) ? (s.forEach(e => {
                n.push(...resourceToMediaItem(e, d, p))
            }), n) : isDataRecord(s) ? dataRecordToMediaItems(s, d, p) : isMediaAPIResource$1(s) ? resourceToMediaItem(s, d, p) : []
        },
        dataRecordToMediaItems = (e, n, s = {}) => {
            const {
                data: d
            } = e.serialize(!0, void 0, {
                includeRelationships: Yn,
                allowFullDuplicateSerializations: !0
            });
            return resourceToMediaItem(d, n, s)
        },
        resourceToMediaItem = (e, n, s = {}) => (Qn.trace("resourceToMediaItem()", e), transform(e, n, s));

    function _define_property$v(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    Ge.createChild("queue");
    class QueueItem {
        restrict() {
            return this.item.restrict()
        }
        constructor(e, n) {
            var s;
            _define_property$v(this, "isAutoplay", !1), _define_property$v(this, "item", void 0), this.item = e, this.isAutoplay = null !== (s = null == n ? void 0 : n.isAutoplay) && void 0 !== s && s
        }
    }

    function toQueueItems(e, n) {
        return e.map(e => new QueueItem(e, n))
    }

    function toMediaItems(e) {
        return e.map(e => e.item)
    }
    const {
        queueItemsDidChange: Jn,
        queuePositionDidChange: Xn
    } = Cn;
    class Queue {
        get isEmpty() {
            return 0 === this.length
        }
        set isRestricted(e) {
            var n;
            this._isRestricted = e;
            const s = null === (n = this.currentItem) || void 0 === n ? void 0 : n.id;
            this._isRestricted && !this.isEmpty && (this.removeQueueItems(e => e.item.isExplicitItem), this.isEmpty && this._dispatcher.publish(Cn.mediaPlaybackError, new MKError(MKError.Reason.CONTENT_RESTRICTED, "Content restricted")), s && (this.position = this._getStartItemPosition(s)))
        }
        get isRestricted() {
            return this._isRestricted
        }
        get appendTargetIndex() {
            let e = this.length;
            const n = this._queueItems.findIndex(e => e.isAutoplay);
            return -1 !== n && this.position < n && (e = n), e
        }
        get items() {
            return toMediaItems(this._queueItems)
        }
        get autoplayItems() {
            return toMediaItems(this._queueItems.filter(e => e.isAutoplay))
        }
        get unplayedAutoplayItems() {
            return toMediaItems(this._unplayedQueueItems.filter(e => e.isAutoplay))
        }
        get userAddedItems() {
            return toMediaItems(this._queueItems.filter(e => !e.isAutoplay))
        }
        get unplayedUserItems() {
            return toMediaItems(this._unplayedQueueItems.filter(e => !e.isAutoplay))
        }
        get playableItems() {
            return toMediaItems(this._queueItems.filter(e => canPlay(e.item, this.playbackMode)))
        }
        get unplayedPlayableItems() {
            return toMediaItems(this._unplayedQueueItems.filter(e => canPlay(e.item, this.playbackMode)))
        }
        get length() {
            return this._queueItems.length
        }
        get nextPlayableItem() {
            if (-1 !== this.nextPlayableItemIndex) return this.item(this.nextPlayableItemIndex)
        }
        get nextPlayableItemIndex() {
            return this._nextPlayableItemIndex = this.findPlayableIndexForward(), this._nextPlayableItemIndex
        }
        get position() {
            return this._position
        }
        set position(e) {
            this._updatePosition(e)
        }
        get isInitiated() {
            return this.position >= 0
        }
        get previousPlayableItem() {
            if (-1 !== this.previousPlayableItemIndex) return this.item(this.previousPlayableItemIndex)
        }
        get previousPlayableItemIndex() {
            return this.findPlayableIndexBackward()
        }
        removeQueueItems(e) {
            for (let n = this.length - 1; n >= 0; n--) e(this.queueItem(n), n) && this.spliceQueueItems(n, 1)
        }
        indexForItem(e) {
            return ("string" == typeof e ? this._itemIDs : this.items).indexOf(e)
        }
        item(e) {
            var n;
            return null === (n = this.queueItem(e)) || void 0 === n ? void 0 : n.item
        }
        get currentItem() {
            return this.item(this.position)
        }
        queueItem(e) {
            var n;
            return null === (n = this._queueItems) || void 0 === n ? void 0 : n[e]
        }
        updateItems(e) {
            this._queueItems = toQueueItems(e), this._reindex(), this._dispatcher.publish(Cn.queueItemsDidChange, this.items)
        }
        get currentQueueItem() {
            return this.queueItem(this.position)
        }
        remove(e) {
            if (deprecationWarning("remove", {
                    message: "The queue remove function has been deprecated"
                }), e === this.position) throw new MKError(MKError.Reason.INVALID_ARGUMENTS);
            this.splice(e, 1)
        }
        append(e = []) {
            return this.appendQueueItems(toQueueItems(e))
        }
        appendQueueItems(e = []) {
            this.spliceQueueItems(this.appendTargetIndex, 0, e)
        }
        splice(e, n, s = []) {
            return toMediaItems(this.spliceQueueItems(e, n, toQueueItems(s)))
        }
        spliceQueueItems(e, n, s = [], d = !0) {
            s = s.filter(e => isPlayable(null == e ? void 0 : e.item, this.playbackMode));
            const p = this._queueItems.splice(e, n, ...s);
            return this._itemIDs.splice(e, n, ...s.map(e => e.item.id)), d && (this._dispatcher.publish(ot.queueModified, {
                start: e,
                added: toMediaItems(s),
                removed: toMediaItems(p)
            }), this._dispatcher.publish(Jn, this.items)), p
        }
        clearAfterCurrent() {
            if (-1 === this.position) this.clear();
            else if (this.length > 0 && this.position + 1 < this.length) {
                const e = this.position + 1;
                this.splice(e, this.length)
            }
        }
        clear() {
            this.length > 0 && (this.splice(0, this.length), this.reset())
        }
        reset() {
            const e = this.position;
            this._position = -1, e >= 0 && this._dispatcher.publish(Xn, {
                oldPosition: e,
                position: this.position
            })
        }
        _isSameItems(e) {
            if (e.length !== this.length) return !1;
            const n = e.map(e => e.id).sort(),
                s = [...this._itemIDs].sort();
            let d, p;
            try {
                d = JSON.stringify(n), p = JSON.stringify(s)
            } catch (Rt) {
                return !1
            }
            return d === p
        }
        _reindex() {
            this._queueItems && (this._itemIDs = this._queueItems.map(e => e.item.id))
        }
        _updatePosition(e) {
            if (e === this._position) return;
            const n = this._position;
            this._position = e;
            const s = this.item(e);
            s && canPlay(s, this.playbackMode) || (this._position = this.findPlayableIndexForward(e)), this._position !== n && this._dispatcher.publish(Xn, {
                oldPosition: n,
                position: this._position
            })
        }
        findPlayableIndexForward(n = this.position) {
            var s;
            if (this.isEmpty) return -1;
            if (this.isInitiated && !indexInBounds([0, this.position], n)) return -1;
            const d = null === (s = this.repeatable) || void 0 === s ? void 0 : s.repeatMode;
            if (n < this.length)
                for (let e = n + 1; e < this.length; e++) {
                    if (canPlay(this.item(e), this.playbackMode)) return e
                }
            if (d === e.PlayerRepeatMode.all)
                for (let e = 0; e <= n; e++) {
                    if (canPlay(this.item(e), this.playbackMode)) return e
                }
            return -1
        }
        findPlayableIndexBackward(n = this.position) {
            var s;
            if (this.isEmpty) return -1;
            if (!indexInBounds([0, this.position], n)) return -1;
            const d = null === (s = this.repeatable) || void 0 === s ? void 0 : s.repeatMode;
            if (n > 0)
                for (let e = n - 1; e >= 0; e--) {
                    if (canPlay(this.item(e), this.playbackMode)) return e
                }
            if (d === e.PlayerRepeatMode.all)
                for (let e = this.length - 1; e >= n; e--) {
                    if (canPlay(this.item(e), this.playbackMode)) return e
                }
            return -1
        }
        get _unplayedQueueItems() {
            const e = this.position < 0 ? 0 : this.position;
            return this._queueItems.slice(e)
        }
        _getStartItemPosition(e) {
            if (void 0 === e) return -1;
            if ("object" == typeof e && "id" in e && (e = e.id), "string" == typeof e) return this.indexForItem(e);
            const n = parseInt("" + e, 10);
            return n >= 0 && n < this.length ? n : -1
        }
        constructor(n) {
            if (_define_property$v(this, "repeatable", void 0), _define_property$v(this, "hasAutoplayStation", !1), _define_property$v(this, "playbackMode", e.PlaybackMode.MIXED_CONTENT), _define_property$v(this, "_itemIDs", []), _define_property$v(this, "_queueItems", []), _define_property$v(this, "_isRestricted", !1), _define_property$v(this, "_nextPlayableItemIndex", -1), _define_property$v(this, "_position", -1), _define_property$v(this, "_dispatcher", void 0), this._dispatcher = n.services.dispatcher, this.playbackMode = n.playbackMode, !n.descriptor) return;
            const s = descriptorToMediaItems(n.descriptor).filter(e => isPlayable(e, this.playbackMode));
            this._queueItems = toQueueItems(s), this._reindex(), void 0 !== n.descriptor.startWith && (this.position = this._getStartItemPosition(n.descriptor.startWith))
        }
    }

    function isPlayable(n, s) {
        return n.isPlayable || s !== e.PlaybackMode.FULL_PLAYBACK_ONLY && void 0 !== n.previewURL
    }

    function canPlay(e, n) {
        return isPlayable(e, n) && ! function(e) {
            return e.isRestricted
        }(e) && ! function(e) {
            return e.isUnavailable
        }(e)
    }

    function indexInBounds(e, n) {
        return e[0] <= n && n <= e[1]
    }

    function _define_property$u(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function asyncGeneratorStep$q(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$q(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$q(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$q(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$t(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }! function(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$u(e, n, s[n])
            }))
        }
    }({}, {
        NEXT_ITEM: "NEXT"
    }, e.PlayActivityEndReasonType);
    const Zn = ["musicVideo"],
        eo = function() {
            var e = _async_to_generator$q((function*() {}));
            return function() {
                return e.apply(this, arguments)
            }
        }();
    class BaseSeekable {
        getSeekSeconds(e) {
            return {
                BACK: 0,
                FORWARD: 0
            }
        }
        seekBackward(e = eo) {
            Ne.warn("seekBackward is not supported in this playback method")
        }
        seekForward(e = eo) {
            Ne.warn("seekForward is not supported in this playback method")
        }
        seekToTime(e, n) {
            return _async_to_generator$q((function*() {
                Ne.warn("seekToTime is not supported in this playback method")
            }))()
        }
        constructor(e) {
            _define_property$t(this, "mediaItemPlayback", void 0), _define_property$t(this, "canSeek", void 0), this.mediaItemPlayback = e, this.canSeek = !1
        }
    }
    class Seekable {
        getSeekSeconds(e) {
            return (e => (null == e ? void 0 : e.isUTS) || Zn.includes(null == e ? void 0 : e.type) ? {
                FORWARD: 10,
                BACK: 10
            } : (null == e ? void 0 : e.isAOD) ? {
                FORWARD: 30,
                BACK: 30
            } : {
                FORWARD: 30,
                BACK: 15
            })(e)
        }
        seekBackward(e = this._seekToBeginning) {
            var n = this;
            return _async_to_generator$q((function*() {
                if (void 0 === n.mediaItemPlayback.nowPlayingItem) return void Ne.warn("Cannot seekBackward when nowPlayingItem is not yet set.");
                const s = n.mediaItemPlayback.currentPlaybackTime - n.getSeekSeconds(n.mediaItemPlayback.nowPlayingItem).BACK;
                s < 0 ? yield e.call(n): yield n.seekToTime(s, ut.Interval)
            }))()
        }
        seekForward(e = this._seekToEnd) {
            var n = this;
            return _async_to_generator$q((function*() {
                if (void 0 === n.mediaItemPlayback.nowPlayingItem) return void Ne.warn("Cannot seekForward when nowPlayingItem is not yet set.");
                const s = n.mediaItemPlayback.currentPlaybackTime + n.getSeekSeconds(n.mediaItemPlayback.nowPlayingItem).FORWARD;
                s > n.mediaItemPlayback.currentPlaybackDuration ? yield e.call(n): yield n.seekToTime(s, ut.Interval)
            }))()
        }
        seekToTime(e, n = ut.Manual) {
            var s = this;
            return _async_to_generator$q((function*() {
                if (void 0 === s.mediaItemPlayback.nowPlayingItem) return void Ne.warn("Cannot seekToTime when nowPlayingItem is not yet set.");
                const d = s.mediaItemPlayback.nowPlayingItem,
                    p = s.mediaItemPlayback.currentPlaybackTime,
                    h = s.mediaItemPlayback.currentPlayingDate,
                    y = Math.min(Math.max(0, e), s.mediaItemPlayback.currentPlaybackDuration);
                let _;
                if (d.isLinearStream && void 0 !== h) {
                    const e = 1e3 * (y - p);
                    _ = new Date(h.getTime() + e)
                }
                yield s.mediaItemPlayback.seekToTime(y, n), s._dispatcher.publish(ot.playbackSeek, {
                    item: d,
                    startPosition: p,
                    position: y,
                    playingDate: _,
                    startPlayingDate: h,
                    seekReasonType: n
                })
            }))()
        }
        _seekToBeginning() {
            var e = this;
            return _async_to_generator$q((function*() {
                yield e.seekToTime(0, ut.Interval)
            }))()
        }
        _seekToEnd() {
            var e = this;
            return _async_to_generator$q((function*() {
                yield e.seekToTime(e.mediaItemPlayback.currentPlaybackDuration, ut.Interval)
            }))()
        }
        constructor(e, n) {
            _define_property$t(this, "_dispatcher", void 0), _define_property$t(this, "mediaItemPlayback", void 0), _define_property$t(this, "canSeek", void 0), this._dispatcher = e, this.mediaItemPlayback = n, this.canSeek = !0
        }
    }
    const shuffleCollection = e => {
        const n = [...e],
            {
                length: s
            } = n;
        for (let d = 0; d < s; ++d) {
            const e = d + Math.floor(Math.random() * (s - d)),
                p = n[e];
            n[e] = n[d], n[d] = p
        }
        return n
    };

    function _define_property$s(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_metadata$8(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    var to;
    e.PlayerShuffleMode = void 0, (to = e.PlayerShuffleMode || (e.PlayerShuffleMode = {}))[to.off = 0] = "off", to[to.songs = 1] = "songs";
    const ro = "Shuffling is not supported in this playback method.";
    class BaseShuffler {
        set shuffle(e) {
            Ne.warn(ro)
        }
        get shuffleMode() {
            return 0
        }
        set shuffleMode(e) {
            Ne.warn(ro)
        }
        checkAndReshuffle(e) {
            Ne.warn(ro)
        }
        constructor() {
            _define_property$s(this, "canSetShuffleMode", !1), _define_property$s(this, "queue", void 0)
        }
    }
    class Shuffler {
        get queue() {
            return this._queue
        }
        set queue(e) {
            this._queue = e, this._unshuffledIDs = e.userAddedItems.map(e => e.id), this.checkAndReshuffle(!1)
        }
        queueModifiedHandler(e, n) {
            if (this._isSpliceFromShuffle) return void(this._isSpliceFromShuffle = !1);
            const {
                start: s,
                added: d,
                removed: p
            } = n;
            if (p.length > 0) {
                const e = p.map(e => e.id);
                this._unshuffledIDs = this._unshuffledIDs.filter(n => !e.includes(n))
            }
            d.length > 0 && this._unshuffledIDs.splice(s, 0, ...d.map(e => e.id))
        }
        set shuffle(e) {
            this.shuffleMode = e ? 1 : 0
        }
        get shuffleMode() {
            return this.mode
        }
        set shuffleMode(n) {
            n !== this.shuffleMode && n in e.PlayerShuffleMode && (Ne.debug(`mk: set shuffleMode from ${this.shuffleMode} to ${n}`), this.mode = n, 1 === this.mode ? this.shuffleQueue() : this.unshuffleQueue(), this.controller.nowPlayingItem && (this._queue.position = this._queue.indexForItem(this.controller.nowPlayingItem.id)), this.dispatcher.publish(Cn.shuffleModeDidChange, this.shuffleMode))
        }
        checkAndReshuffle(e = !1) {
            1 === this.shuffleMode && this.shuffleQueue(e)
        }
        shuffleQueue(e = !0) {
            const {
                userAddedItems: n
            } = this._queue;
            if (n.length <= 1) return n;
            const s = n.slice(0),
                d = this._queue.position > -1 ? s.splice(this._queue.position, 1) : [];
            let p = [];
            do {
                p = shuffleCollection(s)
            } while (s.length > 1 && arrayEquals(p, s));
            const h = [...d, ...p];
            this._isSpliceFromShuffle = !0, this._queue.spliceQueueItems(0, h.length, toQueueItems(h), e)
        }
        unshuffleQueue(e = !0) {
            let n = [];
            const s = this._unshuffledIDs.reduce((e, n, s) => (e[n] = s, e), {}),
                d = [];
            let p = 0;
            const h = this._queue.item(this._queue.position);
            this._queue.userAddedItems.forEach(e => {
                const y = s[e.id];
                void 0 === y && d.push(e), n[y] = e, e.id === (null == h ? void 0 : h.id) && (p = y)
            }), n = n.filter(Boolean);
            const y = n.concat(d);
            this._isSpliceFromShuffle = !0, this._queue.spliceQueueItems(0, y.length, toQueueItems(y), e), this._queue.position = p
        }
        constructor(e, {
            dispatcher: n
        }) {
            _define_property$s(this, "controller", void 0), _define_property$s(this, "canSetShuffleMode", void 0), _define_property$s(this, "dispatcher", void 0), _define_property$s(this, "mode", void 0), _define_property$s(this, "_queue", void 0), _define_property$s(this, "_unshuffledIDs", void 0), _define_property$s(this, "_isSpliceFromShuffle", void 0), this.controller = e, this.canSetShuffleMode = !0, this.mode = 0, this._unshuffledIDs = [], this._isSpliceFromShuffle = !1, this.dispatcher = n, this.dispatcher.subscribe(ot.queueModified, this.queueModifiedHandler), this._queue = e.queue
        }
    }

    function asyncGeneratorStep$p(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$p(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$p(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$p(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$r(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$g(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$r(e, n, s[n])
            }))
        }
        return e
    }

    function _ts_metadata$7(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    var io;
    ! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$8("design:type", Function), _ts_metadata$8("design:paramtypes", [String, Object]), _ts_metadata$8("design:returntype", void 0)], Shuffler.prototype, "queueModifiedHandler", null),
    function(e) {
        e.continuous = "continuous", e.serial = "serial"
    }(io || (io = {}));
    const {
        queueItemsDidChange: no
    } = Cn;
    class PlaybackController {
        get isActive() {
            return this._isActive
        }
        get isDestroyed() {
            return this._isDestroyed
        }
        updateAutoplay(e, n) {
            this.autoplayEnabled = n
        }
        constructContext(e, n) {
            let s = null == e ? void 0 : e.context;
            var d;
            return void 0 !== (null == e ? void 0 : e.featureName) && void 0 === (null == s ? void 0 : s.featureName) && (Ne.warn("featureName is deprecated, pass it inside context"), s || (s = {}), s.featureName = e.featureName), null !== (d = null != s ? s : n) && void 0 !== d ? d : {}
        }
        get context() {
            return this._context
        }
        get shuffler() {
            return this._shuffler
        }
        get continuous() {
            return this._continuous || this.hasAuthorization
        }
        set continuous(e) {
            this._continuous = e
        }
        get autoplayEnabled() {
            return this._autoplayEnabled
        }
        set autoplayEnabled(e) {
            this._autoplayEnabled = e
        }
        get previewOnly() {
            return this._mediaItemPlayback.previewOnly
        }
        get _dispatcher() {
            return this._services.dispatcher
        }
        get hasAuthorization() {
            return hasAuthorization(this.storekit)
        }
        get isPlaying() {
            return this._mediaItemPlayback.isPlaying
        }
        get isPrimaryPlayer() {
            return this._mediaItemPlayback.isPrimaryPlayer
        }
        set isPrimaryPlayer(e) {
            this._mediaItemPlayback.isPrimaryPlayer = e
        }
        get isReady() {
            return this._mediaItemPlayback.isReady
        }
        get _mediaItemPlayback() {
            return this._services.mediaItemPlayback
        }
        get nowPlayingItem() {
            return this._mediaItemPlayback.nowPlayingItem
        }
        get nowPlayingItemIndex() {
            return this.queue ? this.queue.position : -1
        }
        get playbackMode() {
            return this._playbackMode
        }
        set playbackMode(e) {
            this._playbackMode = e, this.queue && (this.queue.playbackMode = e)
        }
        get queue() {
            return this._queue
        }
        set queue(e) {
            this.setQueue(e)
        }
        get repeatMode() {
            return this._repeatable.repeatMode
        }
        set repeatMode(e) {
            this._repeatable.repeatMode = e
        }
        get seekSeconds() {
            const {
                nowPlayingItem: e
            } = this;
            if (void 0 !== e) return this._seekable.getSeekSeconds(e)
        }
        set shuffle(e) {
            this._shuffler.shuffle = e
        }
        get shuffleMode() {
            return this._shuffler.shuffleMode
        }
        set shuffleMode(e) {
            this._shuffler.shuffleMode = e
        }
        get storekit() {
            return this._storekit
        }
        set storekit(n) {
            if (n) {
                var s = this;
                n.addEventListener(Ce.authorizationStatusWillChange, function() {
                    var n = _async_to_generator$p((function*({
                        authorizationStatus: n,
                        newAuthorizationStatus: d
                    }) {
                        n > Ie.DENIED && d < Ie.RESTRICTED ? yield s.stop({
                            endReasonType: e.PlayActivityEndReasonType.PLAYBACK_SUSPENDED,
                            userInitiated: !1
                        }): yield s.stop({
                            userInitiated: !1
                        })
                    }));
                    return function(e) {
                        return n.apply(this, arguments)
                    }
                }()), this._storekit = n
            }
        }
        changeToMediaAtIndex(e = 0) {
            var n = this;
            return _async_to_generator$p((function*() {
                var s, d, p, h;
                yield n.stop();
                const y = null === (s = n.queue.item(e)) || void 0 === s ? void 0 : s.id,
                    _ = null === (p = n._mediaItemPlayback) || void 0 === p || null === (d = p.playOptions) || void 0 === d ? void 0 : d.get(y);
                let m = (null == _ ? void 0 : _.startTime) || 0;
                var v;
                n._dispatcher.publish(Cn.playInitiated, {
                    item: n.queue.item(e),
                    timestamp: null !== (v = null == _ || null === (h = _.meta) || void 0 === h ? void 0 : h.initiatedTimestamp) && void 0 !== v ? v : Date.now()
                });
                const g = yield n._changeToMediaAtIndex(e, {
                    userInitiated: !0
                });
                g && (g.id !== y && (m = 0), n._dispatcher.publish(ot.playbackPlay, {
                    item: g,
                    position: m,
                    playingDate: n._mediaItemPlayback.currentPlayingDate,
                    userInitiated: !0
                }))
            }))()
        }
        changeToMediaItem(e) {
            var n = this;
            return _async_to_generator$p((function*() {
                const s = n.queue.indexForItem(e);
                return -1 === s ? Promise.reject(new MKError(MKError.Reason.MEDIA_DESCRIPTOR)) : n.changeToMediaAtIndex(s)
            }))()
        }
        activate() {
            var e = this;
            return _async_to_generator$p((function*() {
                Ne.debug("PlaybackController.activate()"), e._isActive = !0, e._dispatcher.unsubscribe(Cn.playbackStateDidChange, e.onPlaybackStateDidChange), e._dispatcher.subscribe(Cn.playbackStateDidChange, e.onPlaybackStateDidChange), e._skipIntro.activate(), e._upNext.activate(), e._rollMonitor.activate()
            }))()
        }
        deactivate() {
            var e = this;
            return _async_to_generator$p((function*() {
                Ne.debug("PlaybackController.deactivate()"), e._isActive = !1, yield e.stop(), e._dispatcher.unsubscribe(Cn.playbackStateDidChange, e.onPlaybackStateDidChange), e._skipIntro.deactivate(), e._upNext.deactivate(), e._rollMonitor.deactivate()
            }))()
        }
        destroy() {
            var e = this;
            return _async_to_generator$p((function*() {
                e._isDestroyed = !0, yield e.deactivate(), e._dispatcher.unsubscribe(Cn.autoplayEnabledDidChange, e.updateAutoplay)
            }))()
        }
        pause(e) {
            var n = this;
            return _async_to_generator$p((function*() {
                return n._mediaItemPlayback.pause(e)
            }))()
        }
        play() {
            var e = this;
            return _async_to_generator$p((function*() {
                if (e.nowPlayingItem) return e._mediaItemPlayback.play();
                if (!e._queue || e._queue.isEmpty) return;
                if (e.nowPlayingItemIndex >= 0) return e.changeToMediaAtIndex(e.nowPlayingItemIndex);
                const {
                    queue: n
                } = e;
                return -1 !== n.nextPlayableItemIndex ? e.changeToMediaAtIndex(n.nextPlayableItemIndex) : void 0
            }))()
        }
        playSingleMediaItem(e, n) {
            var s = this;
            return _async_to_generator$p((function*() {
                yield Dn(e, n), s._dispatcher.publish(Cn.queueItemsDidChange, [e]);
                const d = yield s._mediaItemPlayback.startMediaItemPlayback(e, !0);
                if (d) {
                    var p;
                    const e = {
                        item: d,
                        position: null !== (p = s._mediaItemPlayback.currentPlaybackTime) && void 0 !== p ? p : 0,
                        playingDate: s._mediaItemPlayback.currentPlayingDate,
                        userInitiated: !0
                    };
                    Ne.debug("playSingleMediaItem: Dispatching DispatchTypes.playbackPlay event", e), s._dispatcher.publish(ot.playbackPlay, e)
                }
            }))()
        }
        onPlaybackStateDidChange(n, s) {
            var d = this;
            return _async_to_generator$p((function*() {
                s.state === e.PlaybackStates.ended && (d.continuous || d.repeatMode === e.PlayerRepeatMode.one) && (Ne.debug("controller detected track ended event, moving to next item."), d._dispatcher.publish(ot.applicationActivityIntent, {
                    endReasonType: e.PlayActivityEndReasonType.TRACK_SKIPPED_FORWARDS,
                    userInitiated: !1
                }), yield d._next())
            }))()
        }
        preload() {
            var e = this;
            return _async_to_generator$p((function*() {
                return e._mediaItemPlayback.preload()
            }))()
        }
        showPlaybackTargetPicker() {
            this._mediaItemPlayback.showPlaybackTargetPicker()
        }
        seekBackward() {
            var e = this;
            return _async_to_generator$p((function*() {
                return e._seekable.seekBackward()
            }))()
        }
        seekForward() {
            var e = this;
            return _async_to_generator$p((function*() {
                return e._seekable.seekForward(e.skipToNextItem.bind(e))
            }))()
        }
        skipToNextItem() {
            var e = this;
            return _async_to_generator$p((function*() {
                return e._next({
                    userInitiated: !0
                })
            }))()
        }
        skipToPreviousItem() {
            var e = this;
            return _async_to_generator$p((function*() {
                return e._previous({
                    userInitiated: !0
                })
            }))()
        }
        getNewSeeker() {
            return this._mediaItemPlayback.getNewSeeker()
        }
        seekToTime(e, n) {
            var s = this;
            return _async_to_generator$p((function*() {
                yield s._seekable.seekToTime(e, n)
            }))()
        }
        replaceQueue(e, n) {
            var s = this;
            return _async_to_generator$p((function*() {
                var d;
                if (yield s.extractGlobalValues(n), yield s._mediaItemPlayback.stop(), void 0 !== (null == n ? void 0 : n.context) && (s._context = n.context), s.setQueue(new Queue({
                        services: {
                            runtime: s._services.runtime,
                            request: s._services.request,
                            dispatcher: s._services.dispatcher
                        },
                        descriptor: {
                            loaded: e,
                            context: s.context,
                            startWith: null !== (d = null == n ? void 0 : n.startWith) && void 0 !== d ? d : null == n ? void 0 : n.startPosition
                        },
                        playbackMode: s.playbackMode
                    })), 0 === e.length) throw Ne.warn("No items (0) are playable for new queue"), new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "No playable items for queue");
                if (void 0 !== (null == n ? void 0 : n.shuffleMode) && (s.shuffleMode = n.shuffleMode), void 0 !== (null == n ? void 0 : n.repeatMode) && (s.repeatMode = n.repeatMode), function(e) {
                        return "number" == typeof e && !Number.isNaN(e)
                    }(null == n ? void 0 : n.startTime)) {
                    const e = s.queue.nextPlayableItem;
                    e && s._mediaItemPlayback.playOptions.set(e.id, {
                        startTime: null == n ? void 0 : n.startTime
                    })
                }
                return s._dispatcher.publish("queue.created", s.queue), s._dispatcher.publish("queue.ready", s.queue), s._dispatcher.publish(Cn.queueIsReady, s.queue.items), s.queue
            }))()
        }
        extractGlobalValues(e) {
            var n = this;
            return _async_to_generator$p((function*() {
                n._context = n.constructContext(e), void 0 !== (null == e ? void 0 : e.featureName) && e.context && (Ne.warn("featureName is deprecated, pass it inside context"), e.context.featureName = e.featureName)
            }))()
        }
        stop(e) {
            var n = this;
            return _async_to_generator$p((function*() {
                yield n._mediaItemPlayback.stop(e)
            }))()
        }
        _changeToMediaAtIndex(e = 0, n = {}) {
            var s = this;
            return _async_to_generator$p((function*() {
                if (s.queue.isEmpty) return;
                s.queue.position = e;
                const d = s.queue.item(s.queue.position);
                if (!d) return;
                var p;
                const h = yield s._mediaItemPlayback.startMediaItemPlayback(d, null !== (p = n.userInitiated) && void 0 !== p && p);
                if (h || d.state !== ee.unsupported) return h;
                yield s.skipToNextItem()
            }))()
        }
        _next(n = {}) {
            var s = this;
            return _async_to_generator$p((function*() {
                if (s.queue.isEmpty) return;
                const {
                    userInitiated: d = !1
                } = n;
                return s.repeatMode === e.PlayerRepeatMode.one && void 0 !== s.queue.currentItem ? (yield s.stop(_object_spread$g({
                    userInitiated: d
                }, n)), void(yield s.play())) : (!d && n.seamlessAudioTransition && (s._dispatcher.publish(ot.playbackStop, _object_spread$g({
                    userInitiated: d,
                    endReasonType: e.PlayActivityEndReasonType.NATURAL_END_OF_TRACK
                }, n)), n = {
                    userInitiated: n.userInitiated,
                    seamlessAudioTransition: !0
                }), s._nextAtIndex(s.queue.nextPlayableItemIndex, n))
            }))()
        }
        _nextAtIndex(n, s = {}) {
            var d = this;
            return _async_to_generator$p((function*() {
                if (d.queue.isEmpty) return;
                const {
                    _mediaItemPlayback: p
                } = d;
                var h;
                const y = null !== (h = s.userInitiated) && void 0 !== h && h;
                if (n < 0) return Ne.debug("controller/index._next no next item available, stopping playback"), yield d.stop({
                    userInitiated: y,
                    seamlessAudioTransition: s.seamlessAudioTransition
                }), void(p.playbackState = e.PlaybackStates.completed);
                const _ = d.isPlaying,
                    m = p.currentPlaybackTime,
                    v = yield d._changeToMediaAtIndex(n, {
                        userInitiated: y
                    });
                var g;
                return d._notifySkip(_, v, {
                    userInitiated: y,
                    seamlessAudioTransition: null !== (g = s.seamlessAudioTransition) && void 0 !== g && g,
                    position: m,
                    direction: e.PlayActivityEndReasonType.TRACK_SKIPPED_FORWARDS
                }), v
            }))()
        }
        _previous(n = {}) {
            var s = this;
            return _async_to_generator$p((function*() {
                if (s.queue.isEmpty) return;
                const {
                    userInitiated: d = !1
                } = n;
                if (s.repeatMode === e.PlayerRepeatMode.one && void 0 !== s.queue.currentItem) return yield s.stop({
                    endReasonType: e.PlayActivityEndReasonType.TRACK_SKIPPED_BACKWARDS,
                    userInitiated: d
                }), void(yield s.play());
                const p = s.queue.previousPlayableItemIndex;
                if (d && s.repeatMode === e.PlayerRepeatMode.none && void 0 !== s.nowPlayingItem && -1 === p) return yield s.stop({
                    endReasonType: e.PlayActivityEndReasonType.TRACK_SKIPPED_BACKWARDS,
                    userInitiated: !0
                }), void(yield s.play());
                if (-1 === p) return;
                const h = s.isPlaying,
                    y = s._mediaItemPlayback.currentPlaybackTime,
                    _ = yield s._changeToMediaAtIndex(p, {
                        userInitiated: d
                    });
                return s._notifySkip(h, _, {
                    userInitiated: d,
                    seamlessAudioTransition: !1,
                    direction: e.PlayActivityEndReasonType.TRACK_SKIPPED_BACKWARDS,
                    position: y
                }), _
            }))()
        }
        _notifySkip(n, s, d) {
            const {
                userInitiated: p,
                direction: h,
                position: y,
                seamlessAudioTransition: _ = !1
            } = d, m = this._dispatcher;
            _ ? (Ne.debug("seamlessAudioTransition transition, PAF play"), m.publish(ot.playbackPlay, {
                item: s,
                position: 0,
                endReasonType: e.PlayActivityEndReasonType.NATURAL_END_OF_TRACK
            })) : n ? s ? m.publish(ot.playbackSkip, {
                item: s,
                userInitiated: p,
                direction: h,
                position: y
            }) : m.publish(ot.playbackStop, {
                item: s,
                userInitiated: p,
                position: y
            }) : s && m.publish(ot.playbackPlay, _object_spread$g({
                item: s,
                playingDate: this._mediaItemPlayback.currentPlayingDate,
                position: 0
            }, p ? {
                endReasonType: e.PlayActivityEndReasonType.MANUALLY_SELECTED_PLAYBACK_OF_A_DIFF_ITEM
            } : {}))
        }
        setQueue(e) {
            return Ne.trace("PlaybackController.prepareQueue()"), this.hasAuthorization && (e.isRestricted = this.storekit.restrictedEnabled || !1), e.repeatable = this._repeatable, this._queue = e, this._shuffler.queue = this._queue, this._dispatcher.publish(no, e.items), e
        }
        constructor(e) {
            var n;
            _define_property$r(this, "_continuous", void 0), _define_property$r(this, "_context", {}), _define_property$r(this, "_autoplayEnabled", void 0), _define_property$r(this, "_playerOptions", void 0), _define_property$r(this, "_queue", void 0), _define_property$r(this, "_storekit", void 0), _define_property$r(this, "_repeatable", void 0), _define_property$r(this, "_shuffler", void 0), _define_property$r(this, "_seekable", void 0), _define_property$r(this, "_services", void 0), _define_property$r(this, "_rollMonitor", void 0), _define_property$r(this, "_skipIntro", void 0), _define_property$r(this, "_upNext", void 0), _define_property$r(this, "_playbackMode", void 0), _define_property$r(this, "_isActive", !1), _define_property$r(this, "_isDestroyed", !1), this.onPlaybackStateDidChange = this.onPlaybackStateDidChange.bind(this), this._autoplayEnabled = null !== (n = null == e ? void 0 : e.autoplayEnabled) && void 0 !== n && n, this._continuous = !1, this._services = e.services, this._playerOptions = e, this.storekit = e.storekit, this._skipIntro = new SkipAvailable({
                controller: this,
                services: e.services
            }), this._upNext = new UpNextMonitor({
                controller: this,
                services: e.services
            }), this._rollMonitor = new RollMonitor({
                controller: this,
                services: e.services
            }), this._shuffler = new BaseShuffler, this._seekable = new BaseSeekable(this._mediaItemPlayback), this._repeatable = new BaseRepeatable, this._dispatcher.subscribe(Cn.autoplayEnabledDidChange, this.updateAutoplay), this._playbackMode = e.playbackMode
        }
    }

    function _define_property$q(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$6(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$6(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }! function(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        h > 3 && y && Object.defineProperty(n, s, y)
    }([Bind(), _ts_metadata$7("design:type", Function), _ts_metadata$7("design:paramtypes", [String, Boolean]), _ts_metadata$7("design:returntype", void 0)], PlaybackController.prototype, "updateAutoplay", null);
    class MediaSessionManager {
        onCapabilitiesChanged() {
            this._resetHandlers(), this._setMediaSessionHandlers()
        }
        onNowPlayingItemDidChange(e, {
            item: n
        }) {
            this._setMediaSessionMetadata(n)
        }
        _setMediaSessionMetadata(e) {
            var n, s;
            this.session && "MediaMetadata" in window && e && (this.session.metadata = new window.MediaMetadata({
                title: e.title,
                artist: null !== (s = e.artistName) && void 0 !== s ? s : null === (n = e.attributes) || void 0 === n ? void 0 : n.showTitle,
                album: e.albumName,
                artwork: e.artwork ? [96, 128, 192, 256, 384, 512].map(n => ({
                    src: formatArtworkURL(e.artwork, n, n),
                    sizes: `${n}x${n}`,
                    type: "image/jpeg"
                })) : []
            }))
        }
        _setMediaSessionHandlers() {
            this.session && (this._resetHandlers(), this.session.setActionHandler("play", () => {
                var e;
                return null === (e = this.controller) || void 0 === e ? void 0 : e.play()
            }), this.capabilities.canPause ? this.session.setActionHandler("pause", () => {
                var e;
                return null === (e = this.controller) || void 0 === e ? void 0 : e.pause()
            }) : this.session.setActionHandler("pause", () => {
                var e;
                return null === (e = this.controller) || void 0 === e ? void 0 : e.stop()
            }), this.capabilities.canSeek && (this.session.setActionHandler("seekforward", () => {
                var e;
                return null === (e = this.controller) || void 0 === e ? void 0 : e.seekForward()
            }), this.session.setActionHandler("seekbackward", () => {
                var e;
                return null === (e = this.controller) || void 0 === e ? void 0 : e.seekBackward()
            })), this.capabilities.canSkipToNextItem && this.session.setActionHandler("nexttrack", () => {
                var e;
                return null === (e = this.controller) || void 0 === e ? void 0 : e.skipToNextItem()
            }), this.capabilities.canSkipToPreviousItem && this.session.setActionHandler("previoustrack", () => {
                var e;
                return null === (e = this.controller) || void 0 === e ? void 0 : e.skipToPreviousItem()
            }))
        }
        _resetHandlers() {
            this.session && (this.session.setActionHandler("play", void 0), this.session.setActionHandler("pause", void 0), this.session.setActionHandler("seekforward", void 0), this.session.setActionHandler("seekbackward", void 0), this.session.setActionHandler("nexttrack", void 0), this.session.setActionHandler("previoustrack", void 0))
        }
        constructor(e, n) {
            _define_property$q(this, "capabilities", void 0), _define_property$q(this, "dispatcher", void 0), _define_property$q(this, "controller", void 0), _define_property$q(this, "session", void 0), this.capabilities = e, this.dispatcher = n, this.session = navigator.mediaSession, this.session && (this.dispatcher.subscribe(Cn.nowPlayingItemDidChange, this.onNowPlayingItemDidChange), this.dispatcher.subscribe(Cn.capabilitiesChanged, this.onCapabilitiesChanged), this._setMediaSessionHandlers())
        }
    }

    function _define_property$p(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    var oo;
    _ts_decorate$6([Bind(), _ts_metadata$6("design:type", Function), _ts_metadata$6("design:paramtypes", []), _ts_metadata$6("design:returntype", void 0)], MediaSessionManager.prototype, "onCapabilitiesChanged", null), _ts_decorate$6([Bind(), _ts_metadata$6("design:type", Function), _ts_metadata$6("design:paramtypes", [void 0, void 0]), _ts_metadata$6("design:returntype", void 0)], MediaSessionManager.prototype, "onNowPlayingItemDidChange", null),
        function(e) {
            e[e.PAUSE = 0] = "PAUSE", e[e.EDIT_QUEUE = 1] = "EDIT_QUEUE", e[e.SEEK = 2] = "SEEK", e[e.REPEAT = 3] = "REPEAT", e[e.SHUFFLE = 4] = "SHUFFLE", e[e.SKIP_NEXT = 5] = "SKIP_NEXT", e[e.SKIP_PREVIOUS = 6] = "SKIP_PREVIOUS", e[e.SKIP_TO_ITEM = 7] = "SKIP_TO_ITEM", e[e.AUTOPLAY = 8] = "AUTOPLAY", e[e.VOLUME = 9] = "VOLUME"
        }(oo || (oo = {}));
    class Capabilities {
        set controller(e) {
            this._mediaSession.controller = e
        }
        updateChecker(e) {
            this._checkCapability !== e && (this._checkCapability = e, this._dispatcher.publish(Cn.capabilitiesChanged))
        }
        get canEditPlaybackQueue() {
            return this._checkCapability(1)
        }
        get canPause() {
            return this._checkCapability(0)
        }
        get canSeek() {
            return this._checkCapability(2)
        }
        get canSetRepeatMode() {
            return this._checkCapability(3)
        }
        get canSetShuffleMode() {
            return this._checkCapability(4)
        }
        get canSkipToNextItem() {
            return this._checkCapability(5)
        }
        get canSkipToMediaItem() {
            return this._checkCapability(7)
        }
        get canSkipToPreviousItem() {
            return this._checkCapability(6)
        }
        get canAutoplay() {
            return this._checkCapability(8)
        }
        get canSetVolume() {
            return this._checkCapability(9)
        }
        constructor(e) {
            _define_property$p(this, "_dispatcher", void 0), _define_property$p(this, "_checkCapability", void 0), _define_property$p(this, "_mediaSession", void 0), this._dispatcher = e, this._checkCapability = e => 9 === e, this._mediaSession = new MediaSessionManager(this, e)
        }
    }

    function asyncGeneratorStep$o(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$o(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$o(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$o(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$o(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$5(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$5(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    class ContinuousPlaybackController extends PlaybackController {
        get continuous() {
            return !0
        }
        set continuous(e) {
            if (!0 !== e) throw new MKError(MKError.Reason.UNSUPPORTED_ERROR, "Continuous playback cannot be disabled for station queues.")
        }
        get isLive() {
            return this._isLiveStation
        }
        set isLive(e) {
            e !== this._isLiveStation && (this._isLiveStation = e, this._dispatcher.publish(Cn.capabilitiesChanged))
        }
        get isTracksStation() {
            return this._isTracksStation
        }
        set isTracksStation(e) {
            e !== this._isTracksStation && (this._isTracksStation = e, this._dispatcher.publish(Cn.capabilitiesChanged))
        }
        changeToMediaItem(e) {
            return _async_to_generator$o((function*() {
                Ne.warn("changeToMediaItem is not supported for this type of playback")
            }))()
        }
        hasCapabilities(e) {
            switch (e) {
                case oo.VOLUME:
                    return !0;
                case oo.PAUSE:
                case oo.SKIP_NEXT:
                case oo.SKIP_PREVIOUS:
                case oo.SEEK:
                    return !this.isLive;
                case oo.SKIP_TO_ITEM:
                case oo.AUTOPLAY:
                case oo.EDIT_QUEUE:
                case oo.SHUFFLE:
                case oo.REPEAT:
                default:
                    return !1
            }
        }
        pause(e) {
            var n = this,
                _superprop_get_pause = () => super.pause;
            return _async_to_generator$o((function*() {
                if (!n.isLive) return _superprop_get_pause().call(n, e);
                Ne.warn("pause is not supported for this type of playback")
            }))()
        }
        skipToPreviousItem() {
            var e = this,
                _superprop_get_skipToPreviousItem = () => super.skipToPreviousItem;
            return _async_to_generator$o((function*() {
                if (!e.isLive) return _superprop_get_skipToPreviousItem().call(e);
                Ne.warn("skipToPreviousItem is not supported for this type of playback")
            }))()
        }
        replaceQueue(e, n) {
            var s = this,
                _superprop_get_replaceQueue = () => super.replaceQueue;
            return _async_to_generator$o((function*() {
                var d;
                const p = e[0];
                if (void 0 === p) throw new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "No Queue item");
                if (!isRadioStation(p)) throw new MKError(MKError.Reason.MEDIA_DESCRIPTOR, "Item is not a Radio Station");
                return s.station = p, s.isLive = !!(null == p ? void 0 : p.isLiveRadioStation) || !!(null == p || null === (d = p.attributes) || void 0 === d ? void 0 : d.isLive), s.isTracksStation = isTracksRadioStation(p), s._context = function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var s = null != arguments[n] ? arguments[n] : {},
                            d = Object.keys(s);
                        "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                            return Object.getOwnPropertyDescriptor(s, e).enumerable
                        })))), d.forEach((function(n) {
                            _define_property$o(e, n, s[n])
                        }))
                    }
                    return e
                }({
                    featureName: ct.STATION
                }, null == n ? void 0 : n.context), s._seekable = s.isLive ? new BaseSeekable(s._mediaItemPlayback) : new Seekable(s._dispatcher, s._mediaItemPlayback), s.isTracksStation ? e = yield s.loadNextTracks(s.station, {
                    context: s.context
                }): (e.length > 1 && Ne.warn(`Attempting to play multiple Live Radio Station items (${e.length})`), e = [p]), _superprop_get_replaceQueue().call(s, e, {
                    context: s.context
                })
            }))()
        }
        appendToQueue(e) {
            return _async_to_generator$o((function*() {
                throw new MKError(MKError.Reason.UNSUPPORTED_ERROR, "Appending to the Queue is not supported for this type of playback")
            }))()
        }
        insertInQueue(e, n) {
            return _async_to_generator$o((function*() {
                throw new MKError(MKError.Reason.UNSUPPORTED_ERROR, "Inserting into the Queue is not supported for this type of playback")
            }))()
        }
        prependToQueue(e, n) {
            return _async_to_generator$o((function*() {
                throw new MKError(MKError.Reason.UNSUPPORTED_ERROR, "Prepending to the Queue is not supported for this type of playback")
            }))()
        }
        clearQueue() {
            return _async_to_generator$o((function*() {
                throw new MKError(MKError.Reason.UNSUPPORTED_ERROR, "Clearing the Queue is not supported for this type of playback")
            }))()
        }
        getNewSeeker() {
            return this.hasCapabilities(oo.SEEK) ? super.getNewSeeker() : new UnsupportedSeeker
        }
        skipToNextItem() {
            var e = this,
                _superprop_get_skipToNextItem = () => super.skipToNextItem;
            return _async_to_generator$o((function*() {
                if (!e.isLive) return _superprop_get_skipToNextItem().call(e);
                Ne.warn("Method skipToNextItem is not supported for this type of playback")
            }))()
        }
        loadNextTracks(e, n) {
            var s = this;
            return _async_to_generator$o((function*() {
                if (0 === (null == n ? void 0 : n.limit)) return Ne.warn("Not loading next tracks, limit is set to zero (0)"), [];
                var d;
                Ne.debug("Loading tracks for station " + e.id);
                let p = yield s._services.itemLoader.loadStationNextTracks(e.id, {
                    container: null !== (d = null == n ? void 0 : n.container) && void 0 !== d ? d : e,
                    context: null == n ? void 0 : n.context,
                    limit: null == n ? void 0 : n.limit
                });
                var h;
                if (Ne.debug(`Loaded ${p.length} tracks for station ${e.id}`), 0 === p.length) throw Ne.warn("No track data is available for the current station", {
                    stationId: null === (h = s.station) || void 0 === h ? void 0 : h.id
                }), new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "No track data is available for the current station.");
                return "number" == typeof(null == n ? void 0 : n.limit) && n.limit > 0 && (p = p.slice(0, n.limit)), p
            }))()
        }
        queueNextTracks() {
            var e = this;
            return _async_to_generator$o((function*() {
                if (!e.isActive) return void Ne.debug("Not loading next tracks, controller is not active");
                if (void 0 === e.station || !e.isTracksStation) return void Ne.debug("Not loading next tracks, not a tracks radio station");
                if (e.queue.isEmpty) return void Ne.debug("Not loading next tracks, queue is empty");
                if (-1 !== e.queue.nextPlayableItemIndex) return void Ne.debug("Not loading next tracks, enough playable items in queue");
                const n = yield e.loadNextTracks(e.station, {
                    context: e.context,
                    limit: 1
                });
                n.length > 0 && (Ne.debug(`Queueing ${n.length} ${1===n.length?"track":"tracks"}`), e.queue.append(n))
            }))()
        }
        activate() {
            var e = this,
                _superprop_get_activate = () => super.activate;
            return _async_to_generator$o((function*() {
                yield _superprop_get_activate().call(e), e._dispatcher.subscribe(Cn.queuePositionDidChange, e.queueNextTracks), e.queueNextTracks()
            }))()
        }
        deactivate() {
            var e = this,
                _superprop_get_deactivate = () => super.deactivate;
            return _async_to_generator$o((function*() {
                yield _superprop_get_deactivate().call(e), e._dispatcher.unsubscribe(Cn.queuePositionDidChange, e.queueNextTracks)
            }))()
        }
        constructor(e) {
            super(e), _define_property$o(this, "type", io.continuous), _define_property$o(this, "_isLiveStation", !1), _define_property$o(this, "_isTracksStation", !1), _define_property$o(this, "station", void 0), this._continuous = !0
        }
    }

    function asyncGeneratorStep$n(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$n(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$4(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$4(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    _ts_decorate$5([Bind(), _ts_metadata$5("design:type", Function), _ts_metadata$5("design:paramtypes", [void 0 === oo ? Object : oo]), _ts_metadata$5("design:returntype", Boolean)], ContinuousPlaybackController.prototype, "hasCapabilities", null), _ts_decorate$5([Bind(), _ts_metadata$5("design:type", Function), _ts_metadata$5("design:paramtypes", []), _ts_metadata$5("design:returntype", Promise)], ContinuousPlaybackController.prototype, "queueNextTracks", null);
    class PercentageWatcher {
        startMonitor() {
            this.dispatcher.unsubscribe(Cn.playbackDurationDidChange, this.updateThreshold), this.dispatcher.unsubscribe(Cn.playbackTimeDidChange, this.handleTimeChange), this.dispatcher.subscribe(Cn.playbackDurationDidChange, this.updateThreshold), this.dispatcher.subscribe(Cn.playbackTimeDidChange, this.handleTimeChange)
        }
        stopMonitor() {
            this.dispatcher.unsubscribe(Cn.playbackDurationDidChange, this.updateThreshold), this.dispatcher.unsubscribe(Cn.playbackTimeDidChange, this.handleTimeChange), this.threshold = -1
        }
        handleTimeChange(e, {
            currentPlaybackDuration: n,
            currentPlaybackTime: s
        }) {
            var d = this;
            return function(e) {
                return function() {
                    var n = this,
                        s = arguments;
                    return new Promise((function(d, p) {
                        var h = e.apply(n, s);

                        function _next(e) {
                            asyncGeneratorStep$n(h, d, p, _next, _throw, "next", e)
                        }

                        function _throw(e) {
                            asyncGeneratorStep$n(h, d, p, _next, _throw, "throw", e)
                        }
                        _next(void 0)
                    }))
                }
            }((function*() {
                d.threshold < 0 && d.updateThreshold(e, {
                    duration: n
                }), s < d.threshold || (d.stopMonitor(), yield d.callback(s, d))
            }))()
        }
        updateThreshold(e, {
            duration: n
        }) {
            this.threshold = n * this.percentage
        }
        constructor(e, n, s) {
            _define_property$n(this, "dispatcher", void 0), _define_property$n(this, "callback", void 0), _define_property$n(this, "percentage", void 0), _define_property$n(this, "threshold", void 0), this.dispatcher = e, this.callback = n, this.percentage = s, this.threshold = -1
        }
    }

    function asyncGeneratorStep$m(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }
    _ts_decorate$4([Bind(), _ts_metadata$4("design:type", Function), _ts_metadata$4("design:paramtypes", [void 0, void 0]), _ts_metadata$4("design:returntype", Promise)], PercentageWatcher.prototype, "handleTimeChange", null), _ts_decorate$4([Bind(), _ts_metadata$4("design:type", Function), _ts_metadata$4("design:paramtypes", [void 0, void 0]), _ts_metadata$4("design:returntype", void 0)], PercentageWatcher.prototype, "updateThreshold", null);
    class Preloader extends PlaybackMonitor {
        handlePlaybackThreshold() {
            var e = this;
            return function(e) {
                return function() {
                    var n = this,
                        s = arguments;
                    return new Promise((function(d, p) {
                        var h = e.apply(n, s);

                        function _next(e) {
                            asyncGeneratorStep$m(h, d, p, _next, _throw, "next", e)
                        }

                        function _throw(e) {
                            asyncGeneratorStep$m(h, d, p, _next, _throw, "throw", e)
                        }
                        _next(void 0)
                    }))
                }
            }((function*() {
                yield e.playbackController.prepareToPlayNextItem()
            }))()
        }
        shouldMonitor() {
            if (!super.shouldMonitor()) return !1;
            if (!this.playbackController.hasAuthorization || this.playbackController.previewOnly) return !1;
            const e = this.getNextPlayableItem(),
                n = void 0 !== e;
            return this.isSeamlessAudioTransitionsEnabled ? n : n && !(null == e ? void 0 : e.isPreparedToPlay)
        }
        getNextPlayableItem() {
            return this.playbackController.queue.nextPlayableItem
        }
        constructor(e) {
            super(e),
                function(e, n, s) {
                    n in e ? Object.defineProperty(e, n, {
                        value: s,
                        enumerable: !0,
                        configurable: !0,
                        writable: !0
                    }) : e[n] = s
                }(this, "isSeamlessAudioTransitionsEnabled", !1), this.watchers = [new PercentageWatcher(this.dispatcher, this.handlePlaybackThreshold, .3)], this.isSeamlessAudioTransitionsEnabled = Un.features["seamless-audio-transitions"]
        }
    }

    function asyncGeneratorStep$l(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$l(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$l(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$l(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$l(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$e(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$l(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$a(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function _ts_decorate$3(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$3(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    class SerialPlaybackController extends PlaybackController {
        get autoplayStation() {
            return this._autoplayStation
        }
        get autoplayStarted() {
            return void 0 !== this._autoplayStation
        }
        get autoplayEnabled() {
            return this._autoplayEnabled
        }
        set autoplayEnabled(e) {
            this._autoplayEnabled = e, !0 === e ? this.startAutoplay() : this.stopAutoplay()
        }
        activate() {
            var e = this,
                _superprop_get_activate = () => super.activate;
            return _async_to_generator$l((function*() {
                yield _superprop_get_activate().call(e), e._preloader.activate(), e._dispatcher.subscribe(Cn.repeatModeDidChange, e.onRepeatModeChange), e._dispatcher.subscribe(Cn.queueItemsDidChange, e.onQueueChange), e._dispatcher.subscribe(Cn.queuePositionDidChange, e.onQueueChange), e._dispatcher.subscribe(Cn.nowPlayingItemDidChange, e.onQueueChange), e._dispatcher.subscribe(Ui, e.onSeamlessAudioTransition)
            }))()
        }
        deactivate() {
            var e = this,
                _superprop_get_deactivate = () => super.deactivate;
            return _async_to_generator$l((function*() {
                yield _superprop_get_deactivate().call(e), e._preloader.deactivate(), e._dispatcher.unsubscribe(Cn.repeatModeDidChange, e.onRepeatModeChange), e._dispatcher.unsubscribe(Cn.queueItemsDidChange, e.onQueueChange), e._dispatcher.unsubscribe(Cn.queuePositionDidChange, e.onQueueChange), e._dispatcher.unsubscribe(Cn.nowPlayingItemDidChange, e.onQueueChange), e._dispatcher.unsubscribe(Ui, e.onSeamlessAudioTransition), yield e.stopAutoplay()
            }))()
        }
        hasCapabilities(e) {
            switch (e) {
                case oo.EDIT_QUEUE:
                case oo.SKIP_NEXT:
                case oo.SKIP_TO_ITEM:
                case oo.AUTOPLAY:
                case oo.VOLUME:
                case oo.SKIP_PREVIOUS:
                    return !0;
                case oo.REPEAT:
                case oo.SHUFFLE:
                    var n, s;
                    return !(null === (s = this.queue) || void 0 === s || null === (n = s.currentQueueItem) || void 0 === n ? void 0 : n.isAutoplay);
                case oo.PAUSE:
                case oo.SEEK:
                    var d;
                    return !(null === (d = this.nowPlayingItem) || void 0 === d ? void 0 : d.isAssetScrubbingDisabled);
                default:
                    return !1
            }
        }
        onSeamlessAudioTransition(n, s) {
            var d = this;
            return _async_to_generator$l((function*() {
                Ne.trace("onSeamlessAudioTransition", s), d._next({
                    userInitiated: !1,
                    seamlessAudioTransition: !0,
                    endReasonType: e.PlayActivityEndReasonType.NATURAL_END_OF_TRACK,
                    position: s.previous.playbackDuration / 1e3,
                    isPlaying: !1
                })
            }))()
        }
        onRepeatModeChange() {
            var n = this;
            return _async_to_generator$l((function*() {
                n.repeatMode === e.PlayerRepeatMode.none ? (Ne.debug("Queueing Autoplay tracks after RepeatMode change"), yield n.queueAutoplayTracks()) : (Ne.debug("Removing Autoplay tracks after RepeatMode change"), n.queue.removeQueueItems((e, s) => s > n.queue.position && e.isAutoplay)), n.repeatMode !== e.PlayerRepeatMode.one && n.prepareToPlayNextItem()
            }))()
        }
        onQueueChange() {
            var e = this;
            return _async_to_generator$l((function*() {
                e.queue.isEmpty || (yield e.queueAutoplayTracks()), e.queue.isInitiated && e.prepareToPlayNextItem()
            }))()
        }
        prepareToPlayNextItem() {
            var e = this;
            return _async_to_generator$l((function*() {
                const n = e.queue.nextPlayableItem;
                if (n && e.queue.currentItem !== n && !n.isPreparedToPlay) try {
                    return Ne.debug("Preparing next MediaItem: " + mediaItemLogString(n), n), e._mediaItemPlayback.prepareToPlay(n)
                } catch (Rt) {
                    Ne.debug("next item failed to prepare for playbck -", Rt)
                }
            }))()
        }
        appendToQueue(e) {
            var n = this;
            return _async_to_generator$l((function*() {
                return n.queue.splice(n.queue.appendTargetIndex, 0, e), n.queue
            }))()
        }
        insertInQueue(e, n) {
            var s = this;
            return _async_to_generator$l((function*() {
                return s.queue.splice(n, 0, e), s.queue
            }))()
        }
        prependToQueue(e, n) {
            var s = this;
            return _async_to_generator$l((function*() {
                return !0 === (null == n ? void 0 : n.clear) && s.queue.clearAfterCurrent(), s.queue.splice(s.queue.position + 1, 0, e), s.queue
            }))()
        }
        clearQueue() {
            var e = this;
            return _async_to_generator$l((function*() {
                return e.queue.clear(), e.queue
            }))()
        }
        replaceQueue(e, n) {
            var s = this,
                _superprop_get_replaceQueue = () => super.replaceQueue;
            return _async_to_generator$l((function*() {
                const d = yield _superprop_get_replaceQueue().call(s, e, n);
                return yield s.stopAutoplay(), yield s.startAutoplay(), d
            }))()
        }
        stopAutoplay() {
            var e = this;
            return _async_to_generator$l((function*() {
                Ne.trace("SerialController.stopAutoplay()"), e._autoplayStation = void 0, e.queue.hasAutoplayStation = !1, Ne.debug("Removing unplayed Autoplay tracks from Queue"), e.queue.removeQueueItems((n, s) => s > e.queue.position && !0 === n.isAutoplay)
            }))()
        }
        startAutoplay() {
            var n = this;
            return _async_to_generator$l((function*() {
                var s;
                if (Ne.trace("SerialController.startAutoplay()"), !n.isActive) return void Ne.debug("Not starting autoplay, not active");
                if (!n.autoplayEnabled) return void Ne.debug("Not starting autoplay, not enabled");
                if (n.repeatMode !== e.PlayerRepeatMode.none) return void Ne.debug("Not starting autoplay, repeat mode is on");
                if (void 0 !== n.autoplayStation) return void Ne.debug("Autoplay station already created");
                if (n.loadingAutoplayStation) return void Ne.debug("Autoplay station already loading");
                const d = n.queue.items.slice(-n.maxTracksForAutoplayStation);
                if (0 === d.length) return void Ne.debug("No items in queue to start Autoplay station");
                n.loadingAutoplayStation = !0;
                const p = null === (s = n.queue.userAddedItems.slice(-1)) || void 0 === s ? void 0 : s.pop();
                let h, y;
                void 0 !== (null == p ? void 0 : p.container) && (h = {
                    id: p.container.id,
                    type: p.container.type
                });
                try {
                    Ne.info(`Creating Autoplay station with ${d.length} ${1===d.length?"item":"items"}`);
                    y = (yield n._services.itemLoader.createAutoplayStation(n.queue.items.slice(-n.maxTracksForAutoplayStation), {
                        container: h
                    })).station
                } catch (ce) {
                    Ne.warning("Unable to create Autoplay station: " + ce.message)
                }
                void 0 === y ? Ne.info("Unable to create Autoplay station: no server data") : Ne.info("Created Autoplay Station " + (null == y ? void 0 : y.id)), n._autoplayStation = y, n.queue.hasAutoplayStation = void 0 !== y, n.loadingAutoplayStation = !1, yield n.queueAutoplayTracks()
            }))()
        }
        queueAutoplayTracks(e) {
            var n = this;
            return _async_to_generator$l((function*() {
                var s, d;
                if (void 0 === n._autoplayStation) return void Ne.debug("Skipping loading Autoplay tracks, no autoplay station");
                if (0 === (null == e ? void 0 : e.limit)) return void Ne.warn("Skipping loading Autoplay tracks, track limit set to 0");
                if (n.queue.unplayedUserItems.length > n.autoplayQueueSizeThreshold) return void Ne.debug(`Skipping loading Autoplay tracks, more than ${n.autoplayQueueSizeThreshold} user added tracks in the queue `);
                if (n.loadingAutoplayTracks) return void Ne.debug("Skipping loading Autoplay tracks, already loading");
                const p = n.autoplayUpcomingTracksLimit - n.queue.unplayedAutoplayItems.length + ((null === (s = n.queue.currentQueueItem) || void 0 === s ? void 0 : s.isAutoplay) ? 1 : 0);
                if (p <= 0) return void Ne.debug(`Skipping loading Autoplay tracks, ${n.autoplayUpcomingTracksLimit} autoplay items already in the queue`);
                n.loadingAutoplayTracks = !0, Ne.debug(`Loading next tracks from Autoplay station ${n._autoplayStation.id} (amount: ${p})`);
                let h = yield n._services.itemLoader.loadStationNextTracks(n._autoplayStation.id, {
                    limit: p,
                    container: n._autoplayStation,
                    context: _object_spread_props$a(_object_spread$e({}, n.context), {
                        featureName: "now_playing",
                        reco_id: (null === (d = n.context.featureName) || void 0 === d ? void 0 : d.startsWith("listen-now")) ? void 0 : n.context.reco_id
                    })
                });
                "number" == typeof(null == e ? void 0 : e.limit) && e.limit > 0 && (h = h.slice(0, e.limit)), Ne.debug(`Queueing ${h.length} tracks from Autoplay station ${n._autoplayStation.id}`), n.queue.appendQueueItems(h.map(e => new QueueItem(e, {
                    isAutoplay: !0
                }))), n.loadingAutoplayTracks = !1
            }))()
        }
        _changeToMediaAtIndex(e = 0, n = {
            userInitiated: !1
        }) {
            var s = this,
                _superprop_get__changeToMediaAtIndex = () => super._changeToMediaAtIndex;
            return _async_to_generator$l((function*() {
                return yield _superprop_get__changeToMediaAtIndex().call(s, e, n)
            }))()
        }
        get shouldTransitionSeamlessly() {
            return this._isSeamlessAudioTransitionsEnabled && this.hasAuthorization && !this.previewOnly
        }
        constructor(e) {
            var n, s, d, p, h, y, _, m, v, g;
            super(e), _define_property$l(this, "type", io.serial), _define_property$l(this, "_preloader", void 0), _define_property$l(this, "_isSeamlessAudioTransitionsEnabled", void 0), _define_property$l(this, "autoplayQueueSizeThreshold", void 0), _define_property$l(this, "autoplayUpcomingTracksLimit", void 0), _define_property$l(this, "maxTracksForAutoplayStation", void 0), _define_property$l(this, "_autoplayStation", void 0), _define_property$l(this, "loadingAutoplayStation", !1), _define_property$l(this, "loadingAutoplayTracks", !1), this._queue = new Queue(e), this._repeatable = new Repeatable(this._dispatcher), this._seekable = new Seekable(this._dispatcher, this._mediaItemPlayback), this._shuffler = new Shuffler(this, {
                dispatcher: this._dispatcher
            }), this._isSeamlessAudioTransitionsEnabled = !!(null == e || null === (n = e.bag) || void 0 === n ? void 0 : n.features["seamless-audio-transitions"]), this.autoplayQueueSizeThreshold = null !== (m = null == e || null === (d = e.bag) || void 0 === d || null === (s = d.autoplay) || void 0 === s ? void 0 : s.maxQueueSizeForAutoplay) && void 0 !== m ? m : 50, this.autoplayUpcomingTracksLimit = null !== (v = null == e || null === (h = e.bag) || void 0 === h || null === (p = h.autoplay) || void 0 === p ? void 0 : p.maxUpcomingTracksToMaintain) && void 0 !== v ? v : 10, this.maxTracksForAutoplayStation = null !== (g = null == e || null === (_ = e.bag) || void 0 === _ || null === (y = _.autoplay) || void 0 === y ? void 0 : y.maxQueueSizeInRequest) && void 0 !== g ? g : 10;
            const b = {
                controller: this,
                services: e.services
            };
            this._preloader = new Preloader(b)
        }
    }

    function _define_property$k(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    _ts_decorate$3([Bind(), _ts_metadata$3("design:type", Function), _ts_metadata$3("design:paramtypes", [void 0 === oo ? Object : oo]), _ts_metadata$3("design:returntype", Boolean)], SerialPlaybackController.prototype, "hasCapabilities", null), _ts_decorate$3([Bind(), _ts_metadata$3("design:type", Function), _ts_metadata$3("design:paramtypes", [String, Object]), _ts_metadata$3("design:returntype", Promise)], SerialPlaybackController.prototype, "onSeamlessAudioTransition", null), _ts_decorate$3([Bind(), _ts_metadata$3("design:type", Function), _ts_metadata$3("design:paramtypes", []), _ts_metadata$3("design:returntype", Promise)], SerialPlaybackController.prototype, "onRepeatModeChange", null), _ts_decorate$3([Bind(), _ts_metadata$3("design:type", Function), _ts_metadata$3("design:paramtypes", []), _ts_metadata$3("design:returntype", Promise)], SerialPlaybackController.prototype, "onQueueChange", null), _ts_decorate$3([Bind(), _ts_metadata$3("design:type", Function), _ts_metadata$3("design:paramtypes", []), _ts_metadata$3("design:returntype", Promise)], SerialPlaybackController.prototype, "prepareToPlayNextItem", null);
    class MKDialog {
        static presentError(e) {
            const n = e.dialog;
            void 0 !== n ? MKDialog.serverDialog(n).present() : new MKDialog(e.message).present()
        }
        static serverDialog(e) {
            const n = new this(e.message, e.explanation);
            return e.okButtonAction && e.okButtonAction.url && (n._okButtonActionURL = e.okButtonAction.url), e.okButtonString && (n._okButtonString = e.okButtonString), e.cancelButtonString && (n._cancelButtonString = e.cancelButtonString), n
        }
        static clientDialog(e) {
            const n = new this(e.message, e.explanation);
            return e.okButtonAction && (n._okButtonAction = e.okButtonAction), e.cancelButtonAction && (n._cancelButtonAction = e.cancelButtonAction), e.okButtonString && (n._okButtonString = e.okButtonString), e.cancelButtonString && (n._cancelButtonString = e.cancelButtonString), n
        }
        get actions() {
            return this.cancelButton ? `<div id="mk-dialog-actions">${this.cancelButton}${this.okButton}</div>` : `<div id="mk-dialog-actions">${this.okButton}</div>`
        }
        get cancelButton() {
            if ("string" == typeof this._cancelButtonString) return `<button type="button">${this._cancelButtonString}</button>`
        }
        set cancelButton(e) {
            this._cancelButtonString = e
        }
        get explanation() {
            return `<p id="mk-dialog-explanation">${this._explanation}</p>`
        }
        get hasOKButtonAction() {
            return !!this._okButtonActionURL || !!this._okButtonAction
        }
        get message() {
            return `<h5 id="mk-dialog-title">${this._message}</h5>`
        }
        get okButton() {
            return this.hasOKButtonAction && this._okButtonActionURL ? `<button type="button" data-ok-action-url='${this._okButtonActionURL}'>${this._okButtonString}</button>` : `<button type="button">${this._okButtonString}</button>`
        }
        present() {
            const e = document.createDocumentFragment(),
                n = document.createElement("div");
            n.id = this.scrimId, e.appendChild(n);
            const s = document.createElement("div");
            s.id = this.id, s.classList.add("mk-dialog"), s.setAttribute("role", "alertDialog"), s.setAttribute("aria-modal", "true"), s.setAttribute("aria-labeledby", "mk-dialog-title"), s.setAttribute("aria-describedby", "mk-dialog-explanation");
            let d = `\n      <div id="mk-dialog-body">\n        ${this.message}\n        ${this.explanation}\n      </div>`;
            d = `\n      ${d}\n      ${this.actions}\n    `, s.innerHTML = d, e.appendChild(s), document.body.appendChild(e), document.querySelector(`#${s.id} #mk-dialog-actions *:first-child`).focus(), setTimeout(() => {
                document.querySelector(`#${s.id} #mk-dialog-actions *:first-child`).addEventListener("click", () => {
                    this._cancelButtonAction && this._cancelButtonAction(), s.parentElement.removeChild(s), n.parentElement.removeChild(n)
                }), this.hasOKButtonAction && (this._okButtonActionURL ? document.querySelector(`#${s.id} #mk-dialog-actions *:last-child`).addEventListener("click", e => {
                    window.open(e.target.dataset.okActionUrl, "_blank"), s.parentElement.removeChild(s), n.parentElement.removeChild(n)
                }) : this._okButtonAction && document.querySelector(`#${s.id} #mk-dialog-actions *:last-child`).addEventListener("click", e => {
                    this._okButtonAction(), s.parentElement.removeChild(s), n.parentElement.removeChild(n)
                }))
            })
        }
        _appendStyle(e) {
            const n = document.createElement("style");
            n.id = this.styleId, n.styleSheet ? n.styleSheet.cssText = e : n.innerHTML = e, document.body.appendChild(n)
        }
        constructor(e, n = "") {
            _define_property$k(this, "_message", void 0), _define_property$k(this, "_explanation", void 0), _define_property$k(this, "id", void 0), _define_property$k(this, "scrimId", void 0), _define_property$k(this, "styleId", void 0), _define_property$k(this, "_cancelButtonString", void 0), _define_property$k(this, "_cancelButtonAction", void 0), _define_property$k(this, "_okButtonAction", void 0), _define_property$k(this, "_okButtonActionURL", void 0), _define_property$k(this, "_okButtonString", void 0), this._message = e, this._explanation = n, this.id = "musickit-dialog", this.scrimId = this.id + "-scrim", this.styleId = this.id + "-style", this._okButtonString = "OK", [this.id, this.scrimId, this.styleId].forEach(e => {
                try {
                    const n = document.getElementById(e);
                    n.parentElement.removeChild(n)
                } catch (Rt) {}
            }), this._appendStyle("\n#musickit-dialog {\n  --mk-dialog-background: rgba(255, 255, 255, 1);\n  --mk-dialog-text: rgba(0, 0, 0, 0.95);\n  --mk-dialog-border: rgba(0, 0, 0, 0.07);\n  --mk-dialog-scrim: rgba(255, 255, 255, 0.8);\n  --mk-dialog-primary: rgba(0, 122, 255, 1);\n}\n\n@media (prefers-color-scheme: dark) {\n  #musickit-dialog {\n      --mk-dialog-background: rgba(30, 30, 30, 1);\n      --mk-dialog-text: rgba(255, 255, 255, 0.85);\n      --mk-dialog-border: rgba(255, 255, 255, 0.1);\n      --mk-dialog-scrim: rgba(38, 38, 38, 0.8);\n      --mk-dialog-primary: rgba(8, 132, 255, 1);\n  }\n}\n\n#musickit-dialog-scrim {\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  width: 100%;\n  height: 100%;\n  background: rgba(0, 0, 0, 0.35);\n}\n\n#musickit-dialog * {\n  -webkit-tap-highlight-color: transparent;\n  -webkit-touch-callout: none;\n  -ms-touch-action: none;\n  -webkit-user-select: none;\n  -moz-user-select: none;\n  -ms-user-select: none;\n  user-select: none;\n  font-family: -apple-system, SF UI Text, Helvetica Neue, Helvetica, sans-serif;\n  font-size: 15px;\n  line-height: 20px;\n}\n\n#musickit-dialog *:focus { outline: 0; }\n\n#musickit-dialog {\n  display: -webkit-box;\n  display: -moz-box;\n  display: -ms-flexbox;\n  display: -webkit-flex;\n  display: flex;\n  -webkit-flex-direction: column;\n  -moz-flex-direction: column;\n  flex-direction: column;\n  -webkit-justify-content: space-between;\n  -moz-justify-content: space-between;\n  justify-content: space-between;\n  min-width: 277px;\n  max-width: 290px;\n  min-height: 109px;\n  background: var(--mk-dialog-background);\n  box-shadow: 0px 0px 9px rgba(0, 0, 0, 0.18);\n  border-radius: 10px;\n  color: var(--mk-dialog-text);\n  position: fixed;\n  top: 50%;\n  left: 50%;\n  margin-left: -142px;\n  margin-top: -67px;\n  z-index: 9999999999999999999999999;\n}\n\n#musickit-dialog #mk-dialog-body {\n  display: -webkit-box;\n  display: -moz-box;\n  display: -ms-flexbox;\n  display: -webkit-flex;\n  display: flex;\n  -webkit-flex-direction: column;\n  -moz-flex-direction: column;\n  flex-direction: column;\n  flex-grow: 1;\n  -webkit-justify-content: space-evenly;\n  -moz-justify-content: space-evenly;\n  justify-content: space-evenly;\n  -webkit-align-items: stretch;\n  align-items: stretch;\n  padding: 10px 20px;\n  min-height: 74px;\n  text-align: center;\n}\n\n#musickit-dialog .mk-dialog h5 {\n  font-weight: 500;\n  line-height: 20px;\n  margin: 7px 0 0 0;\n  padding: 0;\n}\n\n#musickit-dialog .mk-dialog p {\n  margin: 0 0 7px 0;\n  padding: 0;\n  paddin-top: 3px;\n  line-height: 18px;\n  font-size: 13px;\n  font-weight: 300;\n}\n\n#musickit-dialog #mk-dialog-actions {\n  border-top: 1px solid var(--mk-dialog-border);\n  display: -webkit-box;\n  display: -moz-box;\n  display: -ms-flexbox;\n  display: -webkit-flex;\n  display: flex;\n  -webkit-flex-direction: row;\n  -moz-flex-direction: colrowumn;\n  flex-direction: row;\n  max-height: 41px;\n  min-height: 34px;\n  -webkit-justify-self: flex-end;\n  -moz-justify-self: flex-end;\n  justify-self: flex-end;\n}\n\n#musickit-dialog #mk-dialog-actions button {\n  flex-grow: 1;\n  border: 0;\n  background: none;\n  color: var(--mk-dialog-primary);\n  padding: 0;\n  margin: 0;\n  min-height: 34px;\n  height: 41px;\n  text-align: center;\n}\n\n#musickit-dialog #mk-dialog-actions *:nth-child(2) {\n  border-left: 1px solid var(--mk-dialog-border);\n  font-weight: 500;\n}\n")
        }
    }

    function _define_property$j(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$d(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$j(e, n, s[n])
            }))
        }
        return e
    }

    function transformStoreData(e) {
        const n = _object_spread$d({}, e),
            {
                href: s
            } = n;
        return void 0 !== s && (delete n.href, n.attributes = _object_spread$d({}, n.attributes, {
            href: s
        })), n
    }

    function _define_property$i(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const ao = ["extend", "include", "l", "platform", "views"];
    class LocalDataStore {
        get hasDataStore() {
            return this.enableDataStore && void 0 !== this._store
        }
        delete(e, n) {
            this.hasDataStore && this._store.remove(e, n)
        }
        read(e, n, s, d) {
            d || "function" != typeof s || (d = s, s = void 0);
            const p = {};
            let h = !1;
            if (s && (h = Object.keys(s).some(e => /^(fields|extend)/.test(e)), s.views && (p.views = s.views), s.include && (p.relationships = s.include)), this.hasDataStore && !h) {
                let d, h = [];
                if (s && (h = Object.keys(s).reduce((e, n) => (-1 === ao.indexOf(n) && e.push([n, s[n]]), e), h)), d = h && 1 === h.length ? this._store.query(h[0][0], h[0][1]) : this._store.peek(e, n, p), Array.isArray(d)) {
                    if (!s && d.length) return d
                } else if (d) return d
            }
            if ("function" == typeof d) return d()
        }
        write(e) {
            return this._prepareDataForDataStore(e, e => this._store.save(e))
        }
        parse(e) {
            return this._prepareDataForDataStore(e, e => this._store.populateDataRecords(e, {}))
        }
        _prepareDataForDataStore(e, n) {
            return this.hasDataStore ? Array.isArray(e) ? n({
                data: e
            }) : Object.keys(e).reduce((s, d) => {
                const p = e[d];
                return hasOwn(p, "data") && (s[d] = n({
                    data: p.data
                })), "meta" === d && (s[d] = e[d]), s
            }, {}) : e
        }
        constructor(e = {}) {
            _define_property$i(this, "_store", void 0), _define_property$i(this, "enableDataStore", !1);
            let n = !1;
            e.features && hasOwn(e.features, "api-data-store") && (this.enableDataStore = !!e.features["api-data-store"]), e.features && hasOwn(e.features, "disable-data-store-record-reuse") && (n = !!e.features["disable-data-store-record-reuse"]), this.enableDataStore && (this._store = e.store || new DataStore({
                shouldDisableRecordReuse: n
            }), this._store.mapping = transformStoreData)
        }
    }

    function rejectOnLast() {
        return Promise.reject("The last middleware in the stack should not call next")
    }

    function processMiddleware(e, ...n) {
        return e.length ? function createNextFunction([e, ...n]) {
            return (...s) => e(createNextFunction(n), ...s)
        }([...e, rejectOnLast])(...n) : Promise.reject("processMiddleware requires at mimimum one middleware function")
    }

    function parameterizeString(e, n) {
        return function(e) {
            try {
                return function recursiveTokenizeParameterizedString(e, n = []) {
                    if (e.startsWith("{{")) {
                        const s = e.indexOf("}}");
                        if (-1 === s) throw new Error("UNCLOSED_PARAMETER");
                        const d = {
                            type: 1,
                            value: e.slice(2, s)
                        };
                        return s + 2 < e.length ? recursiveTokenizeParameterizedString(e.slice(s + 2), [...n, d]) : [...n, d]
                    } {
                        const s = e.indexOf("{{");
                        return -1 === s ? [...n, {
                            type: 0,
                            value: e
                        }] : recursiveTokenizeParameterizedString(e.slice(s), [...n, {
                            type: 0,
                            value: e.slice(0, s)
                        }])
                    }
                }(e)
            } catch (ce) {
                if ("UNCLOSED_PARAMETER" === ce.message) throw new Error(`Unclosed parameter in path: "${e}"`);
                throw ce
            }
        }(e).map(e => {
            switch (e.type) {
                case 1:
                    return e.value in n ? encodeURIComponent("" + n[e.value]) : `{{${e.value}}}`;
                case 0:
                default:
                    return e.value
            }
        }).join("")
    }
    var so;

    function _define_property$h(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread_props$9(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function constructUrlMiddleware(e, n) {
        let s = n.url;
        var d;
        return s || (s = buildURL(n.baseUrl, n.path)), n.urlParameters && (s = parameterizeString(s, n.urlParameters)), e(_object_spread_props$9(function(e) {
            for (var n = 1; n < arguments.length; n++) {
                var s = null != arguments[n] ? arguments[n] : {},
                    d = Object.keys(s);
                "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(s, e).enumerable
                })))), d.forEach((function(n) {
                    _define_property$h(e, n, s[n])
                }))
            }
            return e
        }({}, n), {
            url: buildURL(s, null !== (d = n.queryParameters) && void 0 !== d ? d : {})
        }))
    }

    function asyncGeneratorStep$k(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$k(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$k(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$k(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function unwrapJSONFromResponse(e) {
        return _unwrapJSONFromResponse.apply(this, arguments)
    }

    function _unwrapJSONFromResponse() {
        return (_unwrapJSONFromResponse = _async_to_generator$k((function*(e) {
            try {
                return yield e.json()
            } catch (ce) {
                return
            }
        }))).apply(this, arguments)
    }

    function fetchMiddlewareFactory(e) {
        return n = _async_to_generator$k((function*(n, s) {
                const d = yield e(s.url, s.fetchOptions), p = {
                    request: s,
                    response: d,
                    data: yield unwrapJSONFromResponse(d)
                };
                if (!d.ok) throw MKError.responseError(d);
                return p
            })),
            function(e, s) {
                return n.apply(this, arguments)
            };
        var n
    }! function(e) {
        e[e.Static = 0] = "Static", e[e.Parameter = 1] = "Parameter"
    }(so || (so = {}));
    const co = fetchMiddlewareFactory("undefined" != typeof fetch ? fetch : () => {
        throw new Error("window.fetch is not defined")
    });

    function _define_property$g(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$b(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$g(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$8(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    var lo;
    ! function(e) {
        e.Replace = "REPLACE", e.Merge = "MERGE"
    }(lo || (lo = {}));
    const uo = ["url"];
    class APISession {
        get config() {
            return this._config
        }
        request(e, n = {}, s = {}) {
            var d;
            return processMiddleware(this.middlewareStack, _object_spread_props$8(_object_spread$b({}, this.config.defaultOptions, s), {
                baseUrl: this.config.url,
                path: e,
                fetchOptions: mergeFetchOptions(null === (d = this.config.defaultOptions) || void 0 === d ? void 0 : d.fetchOptions, s.fetchOptions),
                queryParameters: _object_spread$b({}, this.config.defaultQueryParameters, n),
                urlParameters: _object_spread$b({}, this.config.defaultUrlParameters, s.urlParameters)
            }))
        }
        reconfigure(e, n = "REPLACE") {
            "MERGE" === n && (e = deepmerge(this.config, e)), uo.forEach(n => {
                if (void 0 === e[n]) throw new Error(`Session requires a valid SessionConfig, missing "${n}"`)
            }), this._config = e, this.middlewareStack = this.createMiddlewareStack()
        }
        createMiddlewareStack() {
            return Array.isArray(this.config.middleware) ? [constructUrlMiddleware, ...this.config.middleware, this.makeFetchMiddleware()] : [constructUrlMiddleware, this.makeFetchMiddleware()]
        }
        makeFetchMiddleware() {
            return "function" == typeof this.config.fetchFunction ? fetchMiddlewareFactory(this.config.fetchFunction) : co
        }
        constructor(e) {
            _define_property$g(this, "_config", void 0), _define_property$g(this, "middlewareStack", void 0), this.reconfigure(e)
        }
    }

    function _object_without_properties(e, n) {
        if (null == e) return {};
        var s, d, p = function(e, n) {
            if (null == e) return {};
            var s, d, p = {},
                h = Object.keys(e);
            for (d = 0; d < h.length; d++) s = h[d], n.indexOf(s) >= 0 || (p[s] = e[s]);
            return p
        }(e, n);
        if (Object.getOwnPropertySymbols) {
            var h = Object.getOwnPropertySymbols(e);
            for (d = 0; d < h.length; d++) s = h[d], n.indexOf(s) >= 0 || Object.prototype.propertyIsEnumerable.call(e, s) && (p[s] = e[s])
        }
        return p
    }
    const po = {
        music: {
            url: "https://api.music.apple.com"
        }
    };
    class MediaAPIV3 {
        configure(e, n, s = lo.Merge) {
            this.storefrontId = n.storefrontId;
            const d = function(e) {
                let n = {};
                e.url && (n.url = e.url);
                e.storefrontId && (n.defaultUrlParameters = {
                    storefrontId: e.storefrontId
                });
                e.mediaUserToken && (n.defaultOptions = {
                    fetchOptions: {
                        headers: {
                            "Media-User-Token": e.mediaUserToken
                        }
                    }
                });
                e.developerToken && (n = deepmerge(n, {
                    defaultOptions: {
                        fetchOptions: {
                            headers: {
                                Authorization: "Bearer " + e.developerToken
                            }
                        }
                    }
                }));
                e.options && (n = deepmerge(n, e.options));
                return n
            }(n);
            if (this[e]) this[e].session.reconfigure(d, s);
            else {
                var p;
                const n = new APISession(d),
                    s = n.request.bind(n);
                s.session = n;
                const h = "undefined" != typeof process && "test" === (null === (p = process.env) || void 0 === p ? void 0 : p.NODE_ENV);
                Object.defineProperty(this, e, {
                    value: s,
                    writable: h,
                    enumerable: !0
                })
            }
        }
        constructor(e) {
            ! function(e, n, s) {
                n in e ? Object.defineProperty(e, n, {
                    value: s,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[n] = s
            }(this, "storefrontId", void 0);
            const {
                realmConfig: n
            } = e, s = _object_without_properties(e, ["realmConfig"]);
            for (const d in po) {
                let e = deepmerge(po[d], s);
                const p = null == n ? void 0 : n[d];
                p && (e = deepmerge(e, p)), this.configure(d, e)
            }
        }
    }

    function _define_property$e(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread_props$7(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    var ho, yo;
    ! function(e) {
        e[e.Global = 0] = "Global", e.Catalog = "catalog", e.Personalized = "me", e.Editorial = "editorial", e.Engagement = "engagement", e.Social = "social"
    }(ho || (ho = {})),
    function(e) {
        e.songs = "songs", e.albums = "albums", e.playlists = "playlists", e.stations = "stations", e["music-videos"] = "music-videos", e["library-music-videos"] = "library-music-videos", e["library-playlists"] = "library-playlists", e["library-songs"] = "library-songs"
    }(yo || (yo = {}));
    class API extends class extends class {
        clearCacheForRequest(e, n) {
            "object" == typeof e && (n = e, e = void 0), this.networkCache.removeItemsMatching(buildURL(this.url, null != e ? e : "", n))
        }
        request(e, n, s) {
            var d, p = this;
            return (d = function*() {
                s || "object" != typeof e || (s = n || {}, n = e, e = void 0);
                let d = {};
                "object" == typeof(s = _object_spread$M({
                    method: p.method,
                    headers: p.headers,
                    reload: !1
                }, p._fetchOptions, s)).queryParameters ? (d = s.queryParameters, delete s.queryParameters) : "GET" !== s.method && "DELETE" !== s.method || (d = n);
                const h = buildURL(p.url, null != e ? e : "", d),
                    {
                        method: y,
                        reload: _ = !1,
                        useRawResponse: m
                    } = s;
                if (s.headers = p.buildHeaders(s), delete s.reload, delete s.useRawResponse, "GET" === y && !_) {
                    const e = p.getCacheItem(h);
                    if (e) return Promise.resolve(e)
                }
                n && Object.keys(n).length && ("POST" === y || "PUT" === y) && (s.body = s.body || n, "application/x-www-form-urlencoded" === s.contentType ? (s.body = encodeQueryParameters(s.body), s.headers.set("Content-Type", "application/x-www-form-urlencoded")) : (s.body = JSON.stringify(s.body), s.headers.set("Content-Type", "application/json")));
                const v = yield p._fetchFunction(h, s);
                if (!v.ok) return Promise.reject(v);
                let g;
                try {
                    g = yield v.json()
                } catch (Rt) {
                    g = {}
                }
                if (g.errors) return Promise.reject(g.errors);
                const b = m ? g : g.results || g.data || g;
                if ("GET" === y) {
                    var S;
                    const e = null !== (S = getMaxAgeFromHeaders(v.headers)) && void 0 !== S ? S : p.ttl;
                    p.setCacheItem(h, b, e)
                }
                return b
            }, function() {
                var e = this,
                    n = arguments;
                return new Promise((function(s, p) {
                    var h = d.apply(e, n);

                    function _next(e) {
                        asyncGeneratorStep$1e(h, s, p, _next, _throw, "next", e)
                    }

                    function _throw(e) {
                        asyncGeneratorStep$1e(h, s, p, _next, _throw, "throw", e)
                    }
                    _next(void 0)
                }))
            })()
        }
        buildHeaders({
            headers: e,
            reload: n = !1
        } = {}) {
            void 0 === e && (e = this.headers);
            const s = (e => new e.constructor(e))(e);
            return n && s.set("Cache-Control", "no-cache"), s
        }
        getCacheItem(e) {
            const n = this.networkCache.storage,
                s = `${this.prefix}${this.prefix}cache-mut`,
                d = n.getItem(s) || null,
                p = this.headers.get("Music-User-Token") || this.headers.get("Media-User-Token") || null;
            return p !== d && (this.networkCache.clear(), null === p ? n.removeItem(s) : n.setItem(s, p)), this.networkCache.getItem(e)
        }
        setCacheItem(e, n, s = this.ttl) {
            this.networkCache.setItem(e, n, s)
        }
        clearNetworkCache() {
            this.networkCache.clear()
        }
        _key(e, n) {
            const s = function(e) {
                try {
                    const [n, s] = e.split("?", 2);
                    if (void 0 === s) return n;
                    const d = s.split("&").map(e => e.split("=", 2)),
                        p = [...Array(d.length).keys()];
                    p.sort((e, n) => {
                        const s = d[e],
                            p = d[n];
                        return s < p ? -1 : s > p ? 1 : e - n
                    });
                    const h = p.map(e => d[e]);
                    return `${n}?${h.map(([e,n])=>void 0!==n?`${e}=${n}`:e).join("&")}`
                } catch (Rt) {
                    return e
                }
            }(e).toLowerCase().replace(this.url, "");
            return `${this.prefix}${s.replace(/[^-_0-9a-z]{1,}/g,".")}`
        }
        constructor(e, n) {
            if (_define_property$1M(this, "url", void 0), _define_property$1M(this, "headers", void 0), _define_property$1M(this, "prefix", ""), _define_property$1M(this, "storage", void 0), _define_property$1M(this, "networkCache", void 0), _define_property$1M(this, "ttl", void 0), _define_property$1M(this, "method", "GET"), _define_property$1M(this, "_fetchOptions", void 0), _define_property$1M(this, "_fetchFunction", void 0), this.url = e, (n = n || {}).storage && n.underlyingStorage) throw new Error("only pass storage OR underlyingStorage in sessionOptions to URLSession");
            const s = n.underlyingStorage || {};
            if (this.storage = n.storage || new GenericStorage(s), this.networkCache = new NetworkCache({
                    storage: this.storage,
                    prefix: this.prefix,
                    cacheKeyFunction: this._key.bind(this)
                }), this.ttl = n.ttl || 3e5, this._fetchOptions = _object_spread$M({}, n.fetchOptions), "function" != typeof n.fetch && "function" != typeof fetch) throw new Error("window.fetch is not defined");
            var d;
            this._fetchFunction = null !== (d = n.fetch) && void 0 !== d ? d : fetch.bind(window), this.headers = this._fetchOptions.headers || new Headers, delete this._fetchOptions.headers
        }
    } {
        get developerToken() {
            return this._developerToken.token
        }
        constructor(e, n, s) {
            super(e, s), _define_property$1M(this, "userToken", void 0), _define_property$1M(this, "_developerToken", void 0), this._developerToken = new DeveloperToken(n), this.headers.set("Authorization", "Bearer " + this.developerToken), s = s || {}, this.userToken = s.userToken, this.userToken && this.headers.set("Media-User-Token", this.userToken)
        }
    } {
        constructor(e, n, s, d, p, h, y = {}, _) {
            super(e, n, _object_spread_props$7(function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$e(e, n, s[n])
                    }))
                }
                return e
            }({}, _), {
                userToken: d,
                storage: h
            })), _define_property$e(this, "_store", void 0), _define_property$e(this, "v3", void 0), _define_property$e(this, "storefrontId", Me.ID), _define_property$e(this, "defaultIncludePaginationMetadata", void 0), _define_property$e(this, "resourceRelatives", {
                artists: {
                    albums: {
                        include: "tracks"
                    },
                    playlists: {
                        include: "tracks"
                    },
                    songs: null
                }
            }), _define_property$e(this, "userStorefrontId", void 0), this.defaultIncludePaginationMetadata = y.features && hasOwn(y.features, "api-pagination-metadata"), this._store = new LocalDataStore(y), s && (this.storefrontId = s.toLowerCase()), d && p && (this.userStorefrontId = p.toLowerCase()), this.v3 = new MediaAPIV3({
                developerToken: n,
                mediaUserToken: d,
                storefrontId: s,
                realmConfig: {
                    music: {
                        url: e.replace(/\/v[0-9]+(\/)?$/, "")
                    }
                }
            })
        }
    }

    function asyncGeneratorStep$j(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$j(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$j(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$j(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$d(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    let _o;
    const fo = function() {
            var e = _async_to_generator$j((function*(e, n = !1) {
                if (_o && !n) {
                    if (void 0 === e.storefrontId || e.storefrontId === _o.storefrontId) return _o;
                    _o.clear()
                }
                return _o = new MediaAPIService(e.dispatcher), yield _o.configure(e), _o
            }));
            return function(n) {
                return e.apply(this, arguments)
            }
        }(),
        mo = {
            album: {
                isPlural: !1,
                apiMethod: "album",
                relationshipMethod: {
                    method: "albumRelationship",
                    relationship: "tracks"
                }
            },
            albums: {
                isPlural: !0,
                apiMethod: "albums"
            },
            musicVideo: {
                isPlural: !1,
                apiMethod: "musicVideo"
            },
            musicVideos: {
                isPlural: !0,
                apiMethod: "musicVideos"
            },
            musicMovie: {
                isPlural: !1,
                apiMethod: "musicMovie"
            },
            musicMovies: {
                isPlural: !0,
                apiMethod: "musicMovies"
            },
            playlist: {
                isPlural: !1,
                apiMethod: "playlist",
                relationshipMethod: {
                    method: "playlistRelationship",
                    relationship: "tracks"
                }
            },
            playlists: {
                isPlural: !0,
                apiMethod: "playlists"
            },
            song: {
                isPlural: !1,
                apiMethod: "song"
            },
            songs: {
                isPlural: !0,
                apiMethod: "songs"
            }
        };
    class MediaAPIService {
        get isConfigured() {
            return void 0 !== this._api
        }
        get api() {
            if (void 0 === this._api) throw new MKError(MKError.Reason.CONFIGURATION_ERROR, "The API cannot be accessed before it is configured.");
            return this._api
        }
        get storefrontId() {
            return this.store && this.store.storefrontId
        }
        configure(e) {
            var n = this;
            return _async_to_generator$j((function*() {
                void 0 !== e.store && (n.store = e.store, [Cn.authorizationStatusDidChange, Cn.userTokenDidChange, Cn.storefrontIdentifierDidChange, Cn.storefrontCountryCodeDidChange].forEach(e => {
                    n.store.storekit.addEventListener(e, () => n.resetAPI())
                }), n._initializeAPI(e))
            }))()
        }
        clear() {
            this.api && this.api.clearNetworkCache && this.api.clearNetworkCache()
        }
        getAPIForItem(e) {
            var n = this;
            return _async_to_generator$j((function*() {
                return isLibraryType(e) ? (yield n.store.authorize(), n.api.library || n.api) : n.api
            }))()
        }
        resetAPI() {
            var e = this;
            return _async_to_generator$j((function*() {
                e.clear(), e._initializeAPI()
            }))()
        }
        _initializeAPI(e) {
            if (void 0 !== (null == e ? void 0 : e.api)) return void(this._api = e.api);
            const n = e && e.store || this.store;
            if (void 0 === n) return;
            const s = Un.features["api-session-storage"] ? getSessionStorage() : void 0,
                d = e && e.storefrontId || n.storefrontId,
                p = new API(this.url, n.developerToken, d, n.storekit.userToken, n.storekit.storefrontCountryCode, s, Un, null == e ? void 0 : e.sessionOptions);
            this._api = p.v3
        }
        _updateStorefrontId(e) {
            var n = this;
            return _async_to_generator$j((function*() {
                n.api && e === n.api.storefrontId || (yield n.configure({
                    dispatcher: n._dispatcher,
                    store: n.store,
                    storefrontId: e
                }))
            }))()
        }
        constructor(e) {
            if (_define_property$d(this, "_dispatcher", void 0), _define_property$d(this, "namedQueueOptions", void 0), _define_property$d(this, "url", void 0), _define_property$d(this, "store", void 0), _define_property$d(this, "_api", void 0), this._dispatcher = e, !Un.urls.mediaApi) throw new Error("bag.urls.mediaApi is not configured");
            this.url = Un.urls.mediaApi, this.namedQueueOptions = mo;
            var n = this;
            this._dispatcher.subscribe(ot.apiStorefrontChanged, function() {
                var e = _async_to_generator$j((function*(e, {
                    storefrontId: s
                }) {
                    yield n._updateStorefrontId(s)
                }));
                return function(n, s) {
                    return e.apply(this, arguments)
                }
            }())
        }
    }

    function asyncGeneratorStep$i(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$i(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$i(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$i(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$c(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function configure$2(e) {
        return _configure$2.apply(this, arguments)
    }

    function _configure$2() {
        return (_configure$2 = _async_to_generator$i((function*(e) {
            const n = new UTSClientService;
            return yield n.configure(e), n
        }))).apply(this, arguments)
    }
    class UTSClientService {
        get isConfigured() {
            return void 0 !== this.api
        }
        configure(e) {
            var n = this;
            return _async_to_generator$i((function*() {
                n.api = e.api
            }))()
        }
        clear() {}
        getAPIForItem(e) {
            var n = this;
            return _async_to_generator$i((function*() {
                if (void 0 === n.api) throw new Error("UTS has not been configured");
                return n.api
            }))()
        }
        constructor() {
            _define_property$c(this, "api", void 0), _define_property$c(this, "namedQueueOptions", {}), _define_property$c(this, "url", "")
        }
    }
    var vo;

    function asyncGeneratorStep$h(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$b(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$9(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$b(e, n, s[n])
            }))
        }
        return e
    }! function(e) {
        e.MEDIA_API = "media-api", e.UTS_CLIENT = "uts-client"
    }(vo || (vo = {}));
    class APIServiceManager {
        get api() {
            return this.getApiByType(this._defaultAPI)
        }
        get apiService() {
            if (void 0 !== this._defaultAPI) return this._apisByType[this._defaultAPI];
            Ne.error("There is no API instance configured")
        }
        get mediaAPI() {
            return this.getApiByType(vo.MEDIA_API)
        }
        get utsClient() {
            return this.getApiByType(vo.UTS_CLIENT)
        }
        getApiByType(e) {
            let n;
            if (void 0 !== e && (n = this._apisByType[e]), void 0 === n || void 0 === n.api) throw new MKError(MKError.Reason.CONFIGURATION_ERROR, "There is no API instance configured for the requested type: " + e);
            return n.api
        }
        set defaultApiType(e) {
            this._defaultAPI = e
        }
        registerAPIService(e) {
            var n = this;
            return function(e) {
                return function() {
                    var n = this,
                        s = arguments;
                    return new Promise((function(d, p) {
                        var h = e.apply(n, s);

                        function _next(e) {
                            asyncGeneratorStep$h(h, d, p, _next, _throw, "next", e)
                        }

                        function _throw(e) {
                            asyncGeneratorStep$h(h, d, p, _next, _throw, "throw", e)
                        }
                        _next(void 0)
                    }))
                }
            }((function*() {
                const {
                    apiType: s,
                    options: d
                } = e, p = {
                    store: n.store,
                    dispatcher: n._dispatcher
                };
                void 0 === n._defaultAPI && (n._defaultAPI = s), s === vo.MEDIA_API ? n._apisByType[s] = yield fo.call(n, _object_spread$9({}, d, p)): s === vo.UTS_CLIENT && (n._apisByType[s] = yield configure$2.call(n, _object_spread$9({}, d, p)))
            }))()
        }
        constructor(e, n) {
            _define_property$b(this, "store", void 0), _define_property$b(this, "_dispatcher", void 0), _define_property$b(this, "_apisByType", void 0), _define_property$b(this, "_defaultAPI", void 0), this.store = e, this._dispatcher = n, this._apisByType = {}
        }
    }
    const go = {};

    function adaptAddEventListener(e, n, s, d = {}) {
        const {
            once: p
        } = d, h = function(e, n) {
            const s = getCallbacksForName(e),
                wrappedCallback = (e, s) => {
                    n(s)
                };
            return s.push([n, wrappedCallback]), wrappedCallback
        }(n, s);
        !0 === p ? e.subscribeOnce(n, h) : e.subscribe(n, h)
    }

    function getCallbacksForName(e) {
        let n = go[e];
        return n || (n = [], go[e] = n), n
    }

    function asyncGeneratorStep$g(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$g(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$g(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$g(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$a(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const bo = Ne.createChild("rtc");
    class RTCStreamingTracker {
        get isConfigured() {
            return void 0 !== this.instance
        }
        configure(e) {
            var n = this;
            return _async_to_generator$g((function*() {
                n.instance = e.instance
            }))()
        }
        handleEvent(e, n, s) {}
        loadScript() {
            return _async_to_generator$g((function*() {
                if (!Un.urls.rtc) throw new Error("bag.urls.rtc is not configured");
                yield loadScript(Un.urls.rtc)
            }))()
        }
        prepareReportingAgent(e) {
            this.clearReportingAgent();
            const {
                Sender: n,
                ClientName: s,
                ServiceName: d,
                ApplicationName: p,
                ReportingStoreBag: h,
                DeviceName: y
            } = window.rtc.RTCReportingAgentConfigKeys;
            e = null != e ? e : this.instance.nowPlayingItem;
            const _ = function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$a(e, n, s[n])
                    }))
                }
                return e
            }({
                firmwareVersion: this.generateBrowserVersion(),
                model: this.options.browserName
            }, this.getMediaIdentifiers(e));
            void 0 === this._storeBag && (this._storeBag = this.generateStoreBag());
            const m = {
                [n]: "HLSJS",
                [s]: this.options.clientName,
                [d]: this.options.serviceName,
                [p]: this.options.applicationName,
                [h]: this._storeBag,
                [y]: this.options.osVersion,
                userInfoDict: _
            };
            return bo.debug("RTC: creating reporting agent with config", m), this.reportingAgent = new window.rtc.RTCReportingAgent(m), bo.debug("RTC: created reporting agent", this.reportingAgent), this.reportingAgent
        }
        cleanup() {
            var e = this;
            return _async_to_generator$g((function*() {
                e.clearReportingAgent()
            }))()
        }
        getMediaIdentifiers(e) {
            const n = null == e ? void 0 : e.defaultPlayable;
            if (n) {
                var s;
                const e = {};
                return void 0 !== (null === (s = n.mediaMetrics) || void 0 === s ? void 0 : s.MediaIdentifier) && (e.MediaIdentifier = n.mediaMetrics.MediaIdentifier), void 0 !== n.channelId && (e.ContentProvider = n.channelId), e
            }
            return "musicVideo" === (null == e ? void 0 : e.type) ? {
                MediaIdentifier: "adamid=" + e.id
            } : (null == e ? void 0 : e.isLiveVideoStation) ? {
                MediaIdentifier: "raid=" + e.id
            } : void 0
        }
        clearReportingAgent() {
            void 0 !== this.reportingAgent && (this.reportingAgent.destroy(), bo.debug("RTC: called destroy on reporting agent", this.reportingAgent), this.reportingAgent = void 0)
        }
        generateBrowserVersion() {
            return this.options.browserMajorVersion ? `${this.options.browserMajorVersion}.${this.options.browserMinorVersion||0}` : "unknown"
        }
        generateStoreBag() {
            var e;
            const {
                storeBagURL: n,
                clientName: s,
                applicationName: d,
                serviceName: p,
                browserName: h
            } = this.options, y = {
                iTunesAppVersion: `${`${Un.app.name}-${Un.app.build}`}/${null===(e=this.instance)||void 0===e?void 0:e.version}`
            }, _ = new window.rtc.RTCStorebag.RTCReportingStoreBag(n, s, p, d, h, y);
            return bo.debug("RTC: created store bag", _), _
        }
        constructor(e) {
            _define_property$a(this, "options", void 0), _define_property$a(this, "reportingAgent", void 0), _define_property$a(this, "instance", void 0), _define_property$a(this, "currentMediaItem", void 0), _define_property$a(this, "_storeBag", void 0), _define_property$a(this, "requestedEvents", []), this.options = e
        }
    }

    function asyncGeneratorStep$f(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _define_property$9(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$2(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$2(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    class PlayActivityService {
        cleanup() {
            this.trackers.forEach(e => {
                var n;
                return null === (n = e.cleanup) || void 0 === n ? void 0 : n.call(e)
            }), this.clearIntention(), this.teardownListeners(), this.registeredEvents.clear()
        }
        configure(e) {
            var n = this;
            return function(e) {
                return function() {
                    var n = this,
                        s = arguments;
                    return new Promise((function(d, p) {
                        var h = e.apply(n, s);

                        function _next(e) {
                            asyncGeneratorStep$f(h, d, p, _next, _throw, "next", e)
                        }

                        function _throw(e) {
                            asyncGeneratorStep$f(h, d, p, _next, _throw, "throw", e)
                        }
                        _next(void 0)
                    }))
                }
            }((function*() {
                n.cleanup(), n.registeredEvents = function(e) {
                    const n = [];
                    for (const s of e) n.push(...s.requestedEvents);
                    return new Set(n)
                }(n.trackers), n.setupListeners();
                try {
                    yield Promise.all(n.trackers.map(n => n.configure(e)))
                } catch (Rt) {
                    Ne.error("Error configuring a play activity service", Rt)
                }
            }))()
        }
        getTrackerByType(e) {
            return this.trackers.find(n => n instanceof e)
        }
        handleEvent(e, n = {}) {
            const s = this.addIntention(e, n);
            e === ot.playerActivate && (s.flush = "boolean" == typeof n.isPlaying ? !n.isPlaying : void 0);
            for (const d of this.trackers) d.handleEvent(e, s, n.item)
        }
        addIntention(e, n) {
            if (![ot.playbackPause, ot.playbackStop].includes(e)) return n;
            const s = function(e) {
                for (var n = 1; n < arguments.length; n++) {
                    var s = null != arguments[n] ? arguments[n] : {},
                        d = Object.keys(s);
                    "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(s, e).enumerable
                    })))), d.forEach((function(n) {
                        _define_property$9(e, n, s[n])
                    }))
                }
                return e
            }({}, this.lastUserIntent, this.lastApplicationIntent, n);
            return this.clearIntention(), s
        }
        clearIntention() {
            this.lastUserIntent = void 0, this.lastApplicationIntent = void 0
        }
        recordApplicationIntent(e, n) {
            this.lastApplicationIntent = n
        }
        recordUserIntent(e, n) {
            this.lastUserIntent = n
        }
        setupListeners() {
            this.registeredEvents.forEach(e => {
                this.dispatcher.subscribe(e, this.handleEvent)
            }), this.dispatcher.subscribe(ot.userActivityIntent, this.recordUserIntent), this.dispatcher.subscribe(ot.applicationActivityIntent, this.recordApplicationIntent)
        }
        teardownListeners() {
            this.registeredEvents.forEach(e => {
                this.dispatcher.unsubscribe(e, this.handleEvent)
            }), this.dispatcher.unsubscribe(ot.userActivityIntent, this.recordUserIntent), this.dispatcher.unsubscribe(ot.applicationActivityIntent, this.recordApplicationIntent)
        }
        constructor(e, n) {
            _define_property$9(this, "dispatcher", void 0), _define_property$9(this, "trackers", void 0), _define_property$9(this, "registeredEvents", void 0), _define_property$9(this, "lastUserIntent", void 0), _define_property$9(this, "lastApplicationIntent", void 0), _define_property$9(this, "isConfigured", void 0), this.dispatcher = e, this.trackers = n, this.registeredEvents = new Set, this.isConfigured = !0
        }
    }

    function asyncGeneratorStep$e(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$e(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$e(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$e(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$8(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$6(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$8(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$6(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function fetchRadioStationAssets(e, n, s) {
        return _fetchRadioStationAssets.apply(this, arguments)
    }

    function _fetchRadioStationAssets() {
        return (_fetchRadioStationAssets = _async_to_generator$e((function*(e, n, s) {
            const d = new Headers({
                    Authorization: "Bearer " + n,
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    "X-Apple-Music-User-Token": "" + s
                }),
                p = encodeQueryParameters(_object_spread_props$6(_object_spread$6({}, e.playParams), {
                    keyFormat: "web"
                })),
                h = `${Un.urls.mediaApi}/play/assets?${p}`,
                y = yield fetch(h, {
                    method: "GET",
                    headers: d
                });
            if (500 === y.status) {
                const n = new MKError(MKError.Reason.SERVER_ERROR);
                throw n.data = e, n
            }
            if (403 === y.status) {
                let n;
                try {
                    var _;
                    n = yield y.json(), n = null == n || null === (_ = n.errors) || void 0 === _ ? void 0 : _[0]
                } catch (Rt) {}
                const s = "40303" === (null == n ? void 0 : n.code) ? MKError.Reason.SUBSCRIPTION_ERROR : MKError.Reason.ACCESS_DENIED;
                var m;
                const d = new MKError(s, null !== (m = null == n ? void 0 : n.title) && void 0 !== m ? m : null == n ? void 0 : n.detail);
                throw d.data = e, d
            }
            if (!y.ok) {
                const n = new MKError(MKError.Reason.CONTENT_UNAVAILABLE);
                throw n.data = e, n
            }
            const v = (yield y.json()).results;
            return Ne.debug(`media-item: loaded data from ${h}: ${JSON.stringify(v)}`), v
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$d(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$d(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$d(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$d(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function fetchMZPlayItem(e, n) {
        return _fetchMZPlayItem.apply(this, arguments)
    }

    function _fetchMZPlayItem() {
        return (_fetchMZPlayItem = _async_to_generator$d((function*(e, n) {
            const s = new Headers({
                    Authorization: "Bearer " + n.developerToken,
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    "X-Apple-Music-User-Token": "" + n.musicUserToken
                }),
                d = String(e.playParams.id),
                p = e.isLibraryItem ? Object.fromEntries([
                    ["purchaseAdamId", e.playParams.purchasedId],
                    ["subscriptionAdamId", S(d) ? d.slice(2) : e.playParams.catalogId],
                    ["universalLibraryId", isLibraryType(d) ? d : void 0]
                ].filter((e, n) => void 0 !== n)) : {
                    salableAdamId: d
                },
                h = yield fetch(n.endpoint, {
                    method: "POST",
                    body: JSON.stringify(p),
                    headers: s
                }), y = JSON.parse(yield h.text());
            if (void 0 === (null == y ? void 0 : y.songList) || 0 === y.songList.length) throw MKError.serverError(y, MKError.Reason.UNSUPPORTED_ERROR);
            return y.songList[0]
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$c(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$c(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$c(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$c(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function fetchPlaylistAssets(e) {
        return _fetchPlaylistAssets.apply(this, arguments)
    }

    function _fetchPlaylistAssets() {
        return (_fetchPlaylistAssets = _async_to_generator$c((function*(e) {
            let n;
            try {
                n = yield fetch(e)
            } catch (Rt) {
                throw new MKError(MKError.Reason.CONTENT_UNAVAILABLE)
            }
            const s = yield n.text(), d = /^#EXT-X-STREAM-INF:.*\s*\n(.*$)/gim;
            let p;
            const h = [];
            for (; p = d.exec(s);) {
                var y, _;
                let n = p[1];
                const s = p[0];
                var m;
                const d = null !== (m = null === (y = /CODECS=("(.*)")/.exec(s)) || void 0 === y ? void 0 : y[2]) && void 0 !== m ? m : "";
                var v;
                const g = null !== (v = null === (_ = /(?:[^\w-])BANDWIDTH=((\d+))/.exec(s)) || void 0 === _ ? void 0 : _[2]) && void 0 !== v ? v : 0;
                /^http(s)?:\/\//.test(n) || (n = joinURLPath([...splitURLPath(e).slice(0, -1), n])), h.push({
                    bandwidth: Number(g),
                    codec: d,
                    URL: n
                })
            }
            return h
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$b(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$b(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$b(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$b(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$7(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$5(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$7(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$5(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    _ts_decorate$2([Bind(), _ts_metadata$2("design:type", Function), _ts_metadata$2("design:paramtypes", [String, Object]), _ts_metadata$2("design:returntype", void 0)], PlayActivityService.prototype, "handleEvent", null), _ts_decorate$2([Bind(), _ts_metadata$2("design:type", Function), _ts_metadata$2("design:paramtypes", [String, "undefined" == typeof ActivityIntention ? Object : ActivityIntention]), _ts_metadata$2("design:returntype", void 0)], PlayActivityService.prototype, "recordApplicationIntent", null), _ts_decorate$2([Bind(), _ts_metadata$2("design:type", Function), _ts_metadata$2("design:paramtypes", [String, "undefined" == typeof ActivityIntention ? Object : ActivityIntention]), _ts_metadata$2("design:returntype", void 0)], PlayActivityService.prototype, "recordUserIntent", null), BooleanDevFlag.get("mk-hlsjs-live-radio");
    const So = BooleanDevFlag.get("mk-hlsjs-song-playback");

    function prepareMediaAPIItem(e, n) {
        return _prepareMediaAPIItem.apply(this, arguments)
    }

    function _prepareMediaAPIItem() {
        return (_prepareMediaAPIItem = _async_to_generator$b((function*(e, n) {
            const {
                mediaUserToken: s,
                developerToken: d
            } = n;
            if (void 0 === s) return Promise.reject(new MKError(MKError.Reason.AUTHORIZATION_ERROR, "Unable to prepare media item for play: missing MusicUserToken."));
            e.hasOffersHlsUrl ? yield prepareWithHLSOffers(e): e.isLiveVideoStation ? yield prepareLiveVideoStation(e, d, s): e.isLiveRadioStation ? yield prepareLiveRadioStation(e, d, s): e.isRadioEpisode ? yield prepareRadioStationEpisode(e, d, s): "musicVideo" === e.type || "musicMovie" === e.type ? yield prepareMusicVideo(e, d, s): "song" === e.type && So ? yield prepareCatalogSong(e, n): yield prepareMZPlayItem(e, d, s)
        }))).apply(this, arguments)
    }

    function prepareWithHLSOffers(e) {
        return _prepareWithHLSOffers.apply(this, arguments)
    }

    function _prepareWithHLSOffers() {
        return (_prepareWithHLSOffers = _async_to_generator$b((function*(e) {
            var n, s;
            const d = Un.urls.hlsOffersKeyUrls;
            if (!d) throw new MKError(MKError.Reason.CONTENT_UNSUPPORTED, "HLS OFFERS");
            var p;
            const h = null !== (p = null === (n = e.attributes) || void 0 === n ? void 0 : n.assetUrl) && void 0 !== p ? p : null === (s = e.attributes.offers) || void 0 === s ? void 0 : s[0].hlsUrl;
            updateItemPlaybackProperties(e, {
                assets: yield fetchPlaylistAssets(h), playlist: h, keyURLs: d
            })
        }))).apply(this, arguments)
    }

    function prepareRadioStationEpisode(e, n, s) {
        return _prepareRadioStationEpisode.apply(this, arguments)
    }

    function _prepareRadioStationEpisode() {
        return (_prepareRadioStationEpisode = _async_to_generator$b((function*(e, n, s) {
            const d = yield fetchRadioStationAssets(e, n, s);
            if (void 0 === d.assets || 0 === d.assets.length) throw new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "Missing RadioStation assets");
            const p = d.assets[0];
            d.assets.length > 1 && Ne.warn("RadioStation endpoint returned multiple assets"), Object.assign(e, {
                assetURL: p.url,
                keyURLs: {
                    "hls-key-cert-url": p.fairPlayKeyCertificateUrl,
                    "hls-key-server-url": p.keyServerUrl,
                    "widevine-cert-url": p.widevineKeyCertificateUrl
                }
            })
        }))).apply(this, arguments)
    }

    function prepareLiveVideoStation(e, n, s) {
        return _prepareLiveVideoStation.apply(this, arguments)
    }

    function _prepareLiveVideoStation() {
        return (_prepareLiveVideoStation = _async_to_generator$b((function*(e, n, s) {
            const d = yield fetchRadioStationAssets(e, n, s);
            if (void 0 === d.assets || 0 === d.assets.length) throw new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "Missing RadioStation assets");
            const p = d.assets[0];
            d.assets.length > 1 && Ne.warn("RadioStation endpoint returned multiple assets"), Object.assign(e, {
                assetURL: p.url,
                keyURLs: {
                    "hls-key-cert-url": p.fairPlayKeyCertificateUrl,
                    "hls-key-server-url": p.keyServerUrl,
                    "widevine-cert-url": p.widevineKeyCertificateUrl
                }
            })
        }))).apply(this, arguments)
    }

    function prepareLiveRadioStation(e, n, s) {
        return _prepareLiveRadioStation.apply(this, arguments)
    }

    function _prepareLiveRadioStation() {
        return (_prepareLiveRadioStation = _async_to_generator$b((function*(e, n, s) {
            const d = yield fetchRadioStationAssets(e, n, s);
            if (void 0 === d.assets || 0 === d.assets.length) throw new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "Missing Live Radio Station assets");
            const p = d.assets[0];
            d.assets.length > 1 && Ne.warn("RadioStation endpoint returned multiple assets"), updateItemPlaybackProperties(e, {
                playlist: p.url,
                keyURLs: {
                    "hls-key-cert-url": p.fairPlayKeyCertificateUrl,
                    "hls-key-server-url": p.keyServerUrl,
                    "widevine-cert-url": p.widevineKeyCertificateUrl
                }
            })
        }))).apply(this, arguments)
    }

    function prepareMusicVideo(e, n, s) {
        return _prepareMusicVideo.apply(this, arguments)
    }

    function _prepareMusicVideo() {
        return (_prepareMusicVideo = _async_to_generator$b((function*(e, n, s) {
            if (Ne.trace("prepareMusicVideo", e.playParams.id), !(yield hasMusicSubscription())) return;
            if (!Un.urls.webPlayback) throw new MKError(MKError.Reason.CONFIGURATION_ERROR, "bag.urls.webPlayback is not configured");
            const d = yield fetchMZPlayItem(e, {
                endpoint: Un.urls.webPlayback,
                developerToken: n,
                musicUserToken: s
            });
            updateItemPlaybackProperties(e, {
                songId: d.songId,
                playlist: d["hls-playlist-url"],
                keyURLs: {
                    "hls-key-cert-url": d["hls-key-cert-url"],
                    "hls-key-server-url": d["hls-key-server-url"],
                    "widevine-cert-url": d["widevine-cert-url"]
                }
            })
        }))).apply(this, arguments)
    }

    function prepareCatalogSong(e, n) {
        return _prepareCatalogSong.apply(this, arguments)
    }

    function _prepareCatalogSong() {
        return (_prepareCatalogSong = _async_to_generator$b((function*(e, n) {
            var s;
            const {
                request: d
            } = n.services;
            var p;
            const h = d.buildURL(Un.urls.mediaApi, "/play/assets", _object_spread_props$5(_object_spread$5({}, e.playParams), {
                    includeLicenseUrls: !0,
                    hlsEncryption: null !== (p = n.hlsEncryption) && void 0 !== p ? p : "CBC"
                })),
                y = d.buildHeaders({
                    Authorization: "Bearer " + n.developerToken,
                    "X-Apple-Music-User-Token": n.mediaUserToken
                }),
                {
                    results: _
                } = yield d.fetchJSON(d.buildRequest(h, {
                    headers: y
                }));
            if (void 0 === _ || (null === (s = _.assets) || void 0 === s ? void 0 : s.length) <= 0) throw new MKError(MKError.Reason.CONTENT_UNAVAILABLE);
            const m = _.assets[0];
            updateItemPlaybackProperties(e, {
                playlist: m.url,
                keyURLs: {
                    "hls-key-cert-url": m.fairPlayKeyCertificateUrl,
                    "hls-key-server-url": m.keyServerUrl,
                    "widevine-cert-url": m.widevineKeyCertificateUrl
                }
            })
        }))).apply(this, arguments)
    }

    function prepareMZPlayItem(e, n, s) {
        return _prepareMZPlayItem.apply(this, arguments)
    }

    function _prepareMZPlayItem() {
        return (_prepareMZPlayItem = _async_to_generator$b((function*(e, n, s) {
            if (Ne.trace("prepareItemWithMZPlay", e), !(yield hasMusicSubscription())) return;
            if (!Un.urls.webPlayback) throw new Error("bag.urls.webPlayback is not configured");
            const d = yield fetchMZPlayItem(e, {
                endpoint: Un.urls.webPlayback,
                developerToken: n,
                musicUserToken: s
            });
            updateItemPlaybackProperties(e, {
                songId: d.songId,
                keyURLs: {
                    "hls-key-cert-url": d["hls-key-cert-url"],
                    "hls-key-server-url": d["hls-key-server-url"],
                    "widevine-cert-url": d["widevine-cert-url"]
                },
                assets: d.assets
            })
        }))).apply(this, arguments)
    }

    function updateItemPlaybackProperties(e, n) {
        return void 0 !== n.songId && (e.songId = String(n.songId)), void 0 !== n.keyURLs && (e.keyURLs = n.keyURLs), void 0 !== n.playlist && (e.assetURL = String(n.playlist)), void 0 !== n.assets && (e.assets = n.assets), e
    }

    function asyncGeneratorStep$a(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$a(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$a(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$a(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function prepareToPlayMediaItem(e, n) {
        return _prepareToPlayMediaItem.apply(this, arguments)
    }

    function _prepareToPlayMediaItem() {
        return (_prepareToPlayMediaItem = _async_to_generator$a((function*(e, n) {
            if (Ne.debug("Preparing MediaItem for playback: " + mediaItemLogString(e), e.playParams), e.isPreparedToPlay) Ne.warn("MediaItem is already prepared to play: " + mediaItemLogString(e));
            else {
                if (e.state = ee.loading, e.isUTS) return Promise.reject(new MKError(MKError.Reason.UNSUPPORTED_ERROR, "Item was not prepared to play")); {
                    const {
                        userToken: s,
                        developerToken: d
                    } = n.services.apiManager.store;
                    yield prepareMediaAPIItem(e, {
                        mediaUserToken: s,
                        developerToken: d,
                        services: n.services
                    })
                }
            }
        }))).apply(this, arguments)
    }

    function shouldPlayPreview(e, n) {
        return _shouldPlayPreview.apply(this, arguments)
    }

    function _shouldPlayPreview() {
        return (_shouldPlayPreview = _async_to_generator$a((function*(e, n) {
            return !!e.previewURL && (!!n || !e.playRawAssetURL && (!(yield hasMusicSubscription()) || (!hasAuthorization() || !e.isPlayable || !supportsDrm())))
        }))).apply(this, arguments)
    }

    function _prepareForEncryptedPlayback() {
        return (_prepareForEncryptedPlayback = _async_to_generator$a((function*(e, n) {
            if (Ne.trace("prepareForEncryptedPlayback()", e), !e.isUTS && !hasAuthorization()) return Promise.reject(new MKError(MKError.Reason.AUTHORIZATION_ERROR, "Unable to prepare for playback."));
            try {
                yield prepareToPlayMediaItem(e, n)
            } catch (ce) {
                const {
                    apiManager: d
                } = n.services;
                if (ce.reason === MKError.Reason.AUTHORIZATION_ERROR) yield d.store.storekit.revokeUserToken();
                else if (ce.reason === MKError.Reason.TOKEN_EXPIRED) try {
                    return yield d.store.storekit.renewUserToken(), yield prepareToPlayMediaItem(e, n), e.playbackData = _playbackDataForItem(e, n), e
                } catch (Rt) {}
                if (ce) return Promise.reject(ce)
            }
            return e.playbackData = _playbackDataForItem(e, n), e
        }))).apply(this, arguments)
    }

    function _playbackDataForItem(n, s) {
        if (Ne.trace("_playbackDataForItem()", n), n.isCloudUpload) return n.assets[0];
        if ("musicVideo" !== n.type && !n.isLiveVideoStation) {
            if (!n.isLiveRadioStation) {
                const [e] = n.assets.filter(e => {
                    if (!("flavor" in e)) return !1;
                    const n = new RegExp(`\\d{1,2}\\:(c${(null===(d=window.WebKitMediaKeys)||void 0===d?void 0:d.isTypeSupported(et+".1_0",Qe.AVC1))?"bc":"tr"}p)(\\d{2,3})`, "i");
                    var d;
                    const p = n.test(e.flavor);
                    var h;
                    const y = null !== (h = e.flavor.match(n)) && void 0 !== h ? h : [];
                    return p && parseInt(y[2], 10) <= s.bitrate
                });
                return e
            } {
                var d;
                const p = n.assets.reduce((e, n) => {
                        const s = n.bandwidth;
                        return e[s] || (e[s] = []), e[s].push(n), e
                    }, {}),
                    h = Object.keys(p).sort((e, n) => parseInt(e, 10) - parseInt(n, 10)),
                    y = s.bitrate === e.PlaybackBitrate.STANDARD ? h[0] : h[h.length - 1];
                (null == p || null === (d = p[y]) || void 0 === d ? void 0 : d[0].URL) && (n.assetURL = p[y][0].URL)
            }
        }
    }

    function asyncGeneratorStep$9(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$9(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$9(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$9(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$6(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }
    const Po = xe.createChild("factory"),
        ko = BooleanDevFlag.register("mk-force-native-safari-video-player");

    function _contentRequiresHLSjs() {
        return (_contentRequiresHLSjs = _async_to_generator$9((function*(e) {
            var n, s, d;
            return !!(e.isLiveVideoStation || e.isLinearStream || (null === (d = e.defaultPlayable) || void 0 === d || null === (s = d.assets) || void 0 === s || null === (n = s.fpsKeyServerUrl) || void 0 === n ? void 0 : n.startsWith("https://linear.tv.apple.com"))) || (!!(e.isRadioStation || e.isLiveRadioStation || e.hasOffersHlsUrl || e.isRadioEpisode) || !0 === BooleanDevFlag.get("mk-hlsjs-song-playback"))
        }))).apply(this, arguments)
    }
    class Factory {
        get isDestroyed() {
            return this._isDestroyed
        }
        getPlayerForMediaItem(e) {
            var n = this;
            return _async_to_generator$9((function*() {
                if (Po.trace("Factory.getPlayerForMediaItem", e), function(e) {
                        return null != e && !isVideo(e)
                    }(e)) return n.createAudioPlayer(e, n.playerOptions);
                if (isVideo(e)) return n.createVideoPlayer(e, n.playerOptions);
                throw new Error("Unable to create player for MediaItem: " + (null == e ? void 0 : e.id))
            }))()
        }
        createAudioPlayer(e, n) {
            var s = this;
            return _async_to_generator$9((function*() {
                if (yield function(e) {
                        return _contentRequiresHLSjs.apply(this, arguments)
                    }(e)) {
                    Po.info("Creating HlsJsAudioPlayer required for content item");
                    const e = new HlsJsAudioPlayer(n);
                    return e.initialize(), e
                } {
                    const e = s.playerCache.get(AudioPlayer);
                    if (void 0 !== e && !e.isDestroyed) return Po.debug("Using cached AudioPlayer instance"), e;
                    Po.info("Creating AudioPlayer as a fall through");
                    const d = new AudioPlayer(n);
                    return d.initialize(), Po.debug("Caching AudioPlayer instance"), s.playerCache.set(AudioPlayer, d), d
                }
            }))()
        }
        createVideoPlayer(e, n) {
            return _async_to_generator$9((function*() {
                if (Po.debug("Creating VideoPlayer"), ko.enabled) {
                    Po.info("Creating NativeSafariVideoPlayer with mkForceSafariNativeVideoPlayer enabled");
                    const e = new NativeSafariVideoPlayer(n);
                    return e.initialize(), e
                }
                Po.info("Creating HLSjsVideoPlayer as the default");
                const e = new HlsJsVideoPlayer(n);
                return e.initialize(), e
            }))()
        }
        destroy() {
            this._isDestroyed = !0;
            for (const e of this.playerCache.values()) e.destroy();
            this.playerCache.clear()
        }
        constructor(e) {
            _define_property$6(this, "runtime", void 0), _define_property$6(this, "playerOptions", void 0), _define_property$6(this, "playerCache", new Map), _define_property$6(this, "_isDestroyed", !1), this.playerOptions = e, this.runtime = e.services.runtime
        }
    }

    function asyncGeneratorStep$8(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$8(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$8(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$8(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$5(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _ts_decorate$1(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata$1(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    const {
        playbackLicenseError: To
    } = Ye, {
        keySystemGenericError: Eo
    } = yn, wo = Ge.createChild("playback"), Io = function() {
        var e = _async_to_generator$8((function*(e, n) {
            var s, d;
            if (null === (d = e.container) || void 0 === d || null === (s = d.attributes) || void 0 === s ? void 0 : s.requiresSubscription) {
                if (!(yield n())) {
                    const n = new MKError(MKError.Reason.SUBSCRIPTION_ERROR);
                    throw n.data = e, n
                }
            }
        }));
        return function(n, s) {
            return e.apply(this, arguments)
        }
    }();
    let Oo = !1;
    class MediaItemPlayback {
        get isDestroyed() {
            return this._isDestroyed
        }
        get currentPlaybackTime() {
            return this._currentPlayer.currentPlaybackTime
        }
        get currentPlaybackTimeRemaining() {
            return this._currentPlayer.currentPlaybackTimeRemaining
        }
        get currentPlayingDate() {
            return this._currentPlayer.currentPlayingDate
        }
        get isPlayingAtLiveEdge() {
            return this._currentPlayer.isPlayingAtLiveEdge
        }
        get seekableTimeRanges() {
            return this._currentPlayer.seekableTimeRanges
        }
        get audioTracks() {
            return this._currentPlayer.audioTracks
        }
        get currentAudioTrack() {
            return this._currentPlayer.currentAudioTrack
        }
        set currentAudioTrack(e) {
            this._currentPlayer.currentAudioTrack = e
        }
        get currentPlaybackDuration() {
            return this._currentPlayer.currentPlaybackDuration
        }
        get currentBufferedProgress() {
            return this._currentPlayer.currentBufferedProgress
        }
        get currentPlaybackProgress() {
            return this._currentPlayer.currentPlaybackProgress
        }
        get currentTextTrack() {
            return this._currentPlayer.currentTextTrack
        }
        set currentTextTrack(e) {
            this._currentPlayer.currentTextTrack = e
        }
        get previewOnly() {
            return this._previewOnly
        }
        set previewOnly(e) {
            this._previewOnly = e
        }
        get isPlaying() {
            return this._currentPlayer.isPlaying
        }
        get isPrimaryPlayer() {
            return this._currentPlayer.isPrimaryPlayer
        }
        set isPrimaryPlayer(e) {
            this._currentPlayer.isPrimaryPlayer = e
        }
        get isReady() {
            return this._currentPlayer.isReady
        }
        get nowPlayingItem() {
            return this._currentPlayer.nowPlayingItem
        }
        get playbackRate() {
            return this._currentPlayer.playbackRate
        }
        set playbackRate(e) {
            this._updatePlayerState("playbackRate", e)
        }
        get defaultPlaybackRate() {
            return this._currentPlayer.defaultPlaybackRate
        }
        set defaultPlaybackRate(e) {
            this._updatePlayerState("defaultPlaybackRate", e)
        }
        get playbackState() {
            return this._currentPlayer.playbackState
        }
        set playbackState(e) {
            this._currentPlayer.setPlaybackState(e, this.nowPlayingItem)
        }
        get playbackTargetAvailable() {
            return this._currentPlayer.playbackTargetAvailable
        }
        get playbackTargetIsWireless() {
            return this._currentPlayer.playbackTargetIsWireless
        }
        get supportsPreviewImages() {
            return this._currentPlayer.supportsPreviewImages
        }
        get textTracks() {
            return this._currentPlayer.textTracks
        }
        get volume() {
            return this._currentPlayer.volume
        }
        set volume(e) {
            var n;
            this._currentPlayer.isDestroyed && (null === (n = this._dispatcher) || void 0 === n || n.publish(st.playbackVolumeDidChange, {}));
            this._updatePlayerState("volume", e)
        }
        clearNextManifest() {
            this._currentPlayer.clearNextManifest()
        }
        destroy() {
            var e, n;
            this._isDestroyed = !0, this._playerFactory.destroy(), null === (e = this._dispatcher) || void 0 === e || e.unsubscribe(To, this.onPlaybackLicenseError), null === (n = this._dispatcher) || void 0 === n || n.unsubscribe(Eo, this.onKeySystemGenericError)
        }
        exitFullscreen() {
            return this._currentPlayer.exitFullscreen()
        }
        loadPreviewImage(e) {
            var n = this;
            return _async_to_generator$8((function*() {
                return n._currentPlayer.loadPreviewImage(e)
            }))()
        }
        getNewSeeker() {
            return this._currentPlayer.newSeeker()
        }
        mute() {
            this._volumeAtMute = this.volume, this.volume = 0
        }
        pause(e) {
            var n = this;
            return _async_to_generator$8((function*() {
                return n._currentPlayer.pause(e)
            }))()
        }
        play() {
            var e = this;
            return _async_to_generator$8((function*() {
                return e._currentPlayer.play()
            }))()
        }
        preload() {
            var e = this;
            return _async_to_generator$8((function*() {
                return e._currentPlayer.preload()
            }))()
        }
        prepareToPlay(e) {
            var n = this;
            return _async_to_generator$8((function*() {
                if (wo.trace("MediaItemPlayback.prepareToPlay", e), function(e) {
                        return "podcast-episodes" === e.type && !e.keyURLs
                    }(e)) return void wo.info(`Not preparing MediaItem ${e.id} (${e.info}): free podcast episode`, e);
                if (yield shouldPlayPreview(e, n.previewOnly)) return void wo.info(`Not preparing MediaItem ${e.id} (${e.info}): preview playback only`, e);
                wo.info("Preparing MediaItem: " + mediaItemLogString(e), e);
                const s = yield n.prepareForEncryptedPlayback(e, {
                    bitrate: n._bitrateCalculator.bitrate
                });
                return wo.info(`Calling ${n._currentPlayer.constructor.name}.preloadItem for ${mediaItemLogString(e)}`), yield n._currentPlayer.preloadItem(e, n.playOptions.get(e.id)), s
            }))()
        }
        requestFullscreen(e) {
            return this._currentPlayer.requestFullscreen(e)
        }
        showPlaybackTargetPicker() {
            this._currentPlayer.showPlaybackTargetPicker()
        }
        seekToTime(e, n = ut.Manual) {
            var s = this;
            return _async_to_generator$8((function*() {
                yield s._currentPlayer.seekToTime(e, n)
            }))()
        }
        setPresentationMode(e) {
            var n = this;
            return _async_to_generator$8((function*() {
                return n._currentPlayer.setPresentationMode(e)
            }))()
        }
        startMediaItemPlayback(e, n = !1) {
            var s = this;
            return _async_to_generator$8((function*() {
                var d;
                wo.trace("MediaItemPlayback.startMediaItemPlayback", e), e.resetState(), ((e, n) => {
                    const {
                        os: s
                    } = n;
                    if (e.isLinearStream && ("ios" === s.name || "ipados" === s.name)) {
                        wo.warn("Cannot play linear stream on iOS or iPad");
                        const n = new MKError(MKError.Reason.CONTENT_UNSUPPORTED, "IOS LINEAR");
                        throw n.data = {
                            item: e
                        }, n
                    }
                })(e, s.services.runtime), ((e, n) => {
                    const {
                        isMSESupported: s,
                        isMMSSupported: d
                    } = n;
                    if (e.hasOffersHlsUrl && !s && !d) {
                        wo.warn("HLSjs is not supported");
                        const n = new MKError(MKError.Reason.CONTENT_UNSUPPORTED, "HLSjs Unsupported on Device");
                        throw n.data = {
                            item: e
                        }, n
                    }
                })(e, s.services.runtime), yield Io(e, s.hasMusicSubscription);
                const p = yield s._getPlayerForMediaItem(e);
                if (yield s.setCurrentPlayer(p), !(null === (d = s._currentPlayer) || void 0 === d ? void 0 : d.hasMediaElement)) return wo.warn(`MediaItemPlayback: Could not play media of type ${e.type}, marking item as unsupported and skipping.`), void e.notSupported();
                try {
                    const {
                        dispatcher: d
                    } = s.services;
                    e.beginMonitoringStateDidChange(e => d.publish(E.mediaItemStateDidChange, e)), e.beginMonitoringStateWillChange(e => d.publish(E.mediaItemStateWillChange, e));
                    const p = s.playOptions.get(e.id);
                    p && s.playOptions.delete(e.id);
                    const h = yield s._playAccordingToPlaybackType(e, n, p);
                    return s._currentPlayback = {
                        item: e,
                        userInitiated: n
                    }, h
                } catch (ce) {
                    throw e.updateFromLoadError(ce), wo.error(ce.message, ce), ce
                }
            }))()
        }
        _playAccordingToPlaybackType(e, n, s) {
            var d = this;
            return _async_to_generator$8((function*() {
                return wo.trace("MediaItemPlayback._playAccordingToPlaybackType()", e, s), (yield shouldPlayPreview(e, d._previewOnly)) ? d._playPreview(e, n) : function(e) {
                    return !!e.rawAssetUrl
                }(e) ? d._playRawAsset(e, n, s) : function(e) {
                    return isLive(e) && isStream$1(e) && void 0 !== e.attributes.stationProviderName && "Shoutcast" === e.attributes.streamingRadioSubType
                }(e) ? d._playBroadcastRadio(e, n) : ((e => {
                    if (!supportsDrm()) {
                        const n = new MKError(MKError.Reason.CONTENT_UNSUPPORTED, "NO DRM");
                        throw n.data = {
                            item: e
                        }, wo.warn("No DRM detected"), n
                    }
                })(e), d._playEncryptedFull(e, n, s))
            }))()
        }
        _playEncryptedFull(e, n, s) {
            var d = this;
            return _async_to_generator$8((function*() {
                if (wo.trace("MediaItemPlayback._playEncryptedFull()", e), !e || !e.isPlayable) return Promise.reject(new MKError(MKError.Reason.MEDIA_PLAYBACK, "Not Playable"));
                const p = d._currentPlayer;
                try {
                    wo.debug("Preparing Item for Encrypted Playback: " + mediaItemLogString(e), e), yield d.prepareForEncryptedPlayback(e, {
                        bitrate: d._bitrateCalculator.bitrate
                    })
                } catch (ce) {
                    return wo.error("prepareForEncryptedPlayback Error: userInitiated " + n), n ? (p.destroy(), Promise.reject(ce)) : (p.dispatch(st.mediaPlaybackError, ce), void p.destroy())
                }
                return wo.debug("Fetching Playlist Metadata for " + mediaItemLogString(e)), yield Dn(e, s), wo.debug("Initiating Encrypted Playback for " + mediaItemLogString(e), e), yield p.playItemFromEncryptedSource(e, n, s), e
            }))()
        }
        _playBroadcastRadio(n, s) {
            var d = this;
            return _async_to_generator$8((function*() {
                if (wo.debug("MediaItemPlayback: play broadcast radio", n), !qe.features["broadcast-radio"]) {
                    const e = new MKError(MKError.Reason.CONTENT_UNAVAILABLE);
                    throw e.data = n, e
                }
                const p = d._currentPlayer,
                    h = p.isPaused() && !s,
                    y = yield fetchRadioStationAssets(n, Si.developerToken, Si.musicUserToken), _ = y.assets[0];
                return n.playbackType = e.PlaybackType.unencryptedFull, n.trackInfo = y["track-info"], p.nowPlayingItem = n, yield p.playItemFromUnencryptedSource(_.url, h), n
            }))()
        }
        _playRawAsset(n, s, d) {
            var p = this;
            return _async_to_generator$8((function*() {
                wo.debug("MediaItemPlayback: play raw asset", n);
                const h = p._currentPlayer,
                    y = h.isPaused() && !s;
                return n.playbackType = e.PlaybackType.unencryptedFull, h.nowPlayingItem = n, yield h.playItemFromUnencryptedSource(n.rawAssetUrl, y, d), n
            }))()
        }
        _playPreview(n, s) {
            var d = this;
            return _async_to_generator$8((function*() {
                wo.debug("MediaItemPlayback: play preview", n);
                const p = d._currentPlayer,
                    h = p.isPaused() && !s;
                return supportsDrm() || p.dispatch(st.drmUnsupported, {
                    item: n
                }), n.playbackType = e.PlaybackType.preview, p.nowPlayingItem = n, yield p.playItemFromUnencryptedSource(n.previewURL, h), n
            }))()
        }
        stop(e) {
            var n = this;
            return _async_to_generator$8((function*() {
                yield n._currentPlayer.stop(e)
            }))()
        }
        unmute() {
            this.volume > 0 || (this.volume = this._volumeAtMute || 1, this._volumeAtMute = void 0)
        }
        _getPlayerForMediaItem(e) {
            var n = this;
            return _async_to_generator$8((function*() {
                wo.trace("MediaItemPlayback._getPlayerForMediaItem", e);
                const s = yield n._playerFactory.getPlayerForMediaItem(e);
                return wo.trace("Applying default player state", s, n.playerState), Object.assign(s, n.playerState), s
            }))()
        }
        setCurrentPlayer(e) {
            var n = this;
            return _async_to_generator$8((function*() {
                var s;
                n._currentPlayer !== e && (wo.debug("MediaItemPlayback: setting currentPlayer", e), yield n._currentPlayer.stop(), n._currentPlayer = e, null === (s = n._dispatcher) || void 0 === s || s.publish(st.playerTypeDidChange, {
                    player: e
                }))
            }))()
        }
        getCurrentPlayer() {
            return this._currentPlayer
        }
        onKeySystemGenericError(e, n) {
            var s = this;
            return _async_to_generator$8((function*() {
                var e;
                Oo ? null === (e = s._dispatcher) || void 0 === e || e.publish(st.mediaPlaybackError, n) : (Oo = !0, wo.warn("Retrying playback after keysystemGenericError"), yield s.restartPlayback())
            }))()
        }
        onPlaybackLicenseError(e, n) {
            var s = this;
            return _async_to_generator$8((function*() {
                var e;
                n.reason === MKError.Reason.PLAYREADY_CBC_ENCRYPTION_ERROR ? (wo.warn("MediaItemPlayback: PLAYREADY_CBC_ENCRYPTION_ERROR...retrying with different key system"), yield s.restartPlayback()) : null === (e = s._dispatcher) || void 0 === e || e.publish(st.mediaPlaybackError, n)
            }))()
        }
        restartPlayback() {
            var e = this;
            return _async_to_generator$8((function*() {
                yield e.stop();
                const {
                    _currentPlayback: n
                } = e;
                if (n) {
                    const {
                        item: s,
                        userInitiated: d
                    } = n;
                    s.resetState(), yield e.startMediaItemPlayback(s, d)
                }
            }))()
        }
        _updatePlayerState(e, n) {
            this.playerState[e] = n, this._currentPlayer[e] = n
        }
        constructor(e) {
            _define_property$5(this, "playerState", {
                defaultPlaybackRate: 1,
                playbackRate: 1,
                volume: 1
            }), _define_property$5(this, "playOptions", new Map), _define_property$5(this, "hasMusicSubscription", void 0), _define_property$5(this, "prepareForEncryptedPlayback", void 0), _define_property$5(this, "_currentPlayer", void 0), _define_property$5(this, "services", void 0), _define_property$5(this, "_dispatcher", void 0), _define_property$5(this, "_playerFactory", void 0), _define_property$5(this, "_previewOnly", !1), _define_property$5(this, "_volumeAtMute", void 0), _define_property$5(this, "_currentPlayback", void 0), _define_property$5(this, "_bitrateCalculator", void 0), _define_property$5(this, "_isDestroyed", !1);
            const {
                playbackServices: n
            } = e;
            var s;
            this.hasMusicSubscription = n.hasMusicSubscription, this.prepareForEncryptedPlayback = n.prepareForEncryptedPlayback,
                function(e) {
                    Si = e
                }(e.tokens), e.bag && (s = e.bag, Object.assign(qe, s)), this.services = e.services, this._dispatcher = e.services.dispatcher, this._bitrateCalculator = e.services.bitrateCalculator, this._playerFactory = new Factory(e), this._currentPlayer = new PlayerStub(e), this._dispatcher.subscribe(To, this.onPlaybackLicenseError), this._dispatcher.subscribe(Eo, this.onKeySystemGenericError)
        }
    }
    _ts_decorate$1([Bind(), _ts_metadata$1("design:type", Function), _ts_metadata$1("design:paramtypes", [void 0, void 0]), _ts_metadata$1("design:returntype", Promise)], MediaItemPlayback.prototype, "onKeySystemGenericError", null), _ts_decorate$1([Bind(), _ts_metadata$1("design:type", Function), _ts_metadata$1("design:paramtypes", [void 0, void 0]), _ts_metadata$1("design:returntype", Promise)], MediaItemPlayback.prototype, "onPlaybackLicenseError", null);
    const Ro = ["artist", "album", "audioBook", "episode", "librarySong", "movie", "musicMovie", "musicVideo", "playlist", "podcast", "podcastEpisode", "radioStation", "song", "station", "trailer", "tvEpisode", "uploadedAudio", "uploadedVideo"],
        Ao = ["artists", "albums", "audioBooks", "episodes", "librarySongs", "movies", "musicVideos", "musicMovies", "playlists", "podcasts", "podcastEpisodes", "radioStations", "songs", "stations", "trailers", "tvEpisodes", "uploadedVideos", "uploadedAudios"],
        $o = Ne.createChild("item-loader");

    function isMediaAPIResource(e) {
        return void 0 !== e && "string" == typeof e.id && "string" == typeof e.type && void 0 !== e.attributes
    }

    function convertToItemDescriptors(e) {
        if (Object.keys(e).reduce((function(e, n) {
                return "item" === n || "items" === n || "url" === n || "urls" === n || Ro.includes(n) || Ao.includes(n) ? e + 1 : e
            }), 0) > 1) throw new MKError(MKError.Reason.UNSUPPORTED_ERROR, "Using multiple media kinds is not supported");
        return function(e) {
            return null != e && void 0 !== e.item
        }(e) ? convertItemList([e.item]) : function(e) {
            return null != e && Array.isArray(e.items)
        }(e) ? convertItemList(e.items) : function(e) {
            return null != e && "string" == typeof e.url
        }(e) ? [convertURL(e.url)] : function(e) {
            return null != e && Array.isArray(e.urls)
        }(e) ? e.urls.map(e => convertURL(e)) : function(e) {
            let n;
            const s = [];
            for (const y of Object.keys(e)) {
                const d = translateMediaAPIResource(y);
                isNamedOptionKey(y) && (void 0 === n ? n = [d, e[y]] : s.push(y))
            }
            const [d, p] = null != n ? n : [];
            if (void 0 === d || void 0 === p) return [];
            s.length > 0 && $o.warn(`Found redundant named options besides ${d}: ${s.join(", ")}`);
            const h = singularizeMediaType(d);
            return Array.isArray(p) ? p.map(e => ({
                id: e,
                kind: h
            })) : [{
                id: p,
                kind: h
            }]
        }(e)
    }

    function convertItemList(e) {
        const n = [];
        for (const s of e) "string" == typeof s ? n.push(convertURL(s)) : s instanceof MediaItem ? n.push({
            id: s.id,
            kind: singularizeMediaType(s.type),
            item: s
        }) : isMediaAPIResource(s) ? n.push({
            id: s.id,
            kind: singularizeMediaType(s.type),
            data: s
        }) : n.push(s);
        return n
    }

    function convertURL(e) {
        if (! function(e) {
                return n.test(String(e))
            }(e)) throw new MKError(MKError.Reason.INVALID_ARGUMENTS, "Invalid media URL: " + e);
        const {
            contentId: s,
            kind: d
        } = parseMediaURL(e);
        if (void 0 === s) throw new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "Unable to resolve URL: " + e);
        const p = translateMediaAPIResource(d);
        if (void 0 === p || !Ro.includes(p) && !Ao.includes(p)) throw new MKError(MKError.Reason.CONTENT_UNSUPPORTED, "Unsupported Media Kind: " + p);
        return {
            id: s,
            kind: singularizeMediaType(p)
        }
    }

    function translateMediaAPIResource(e) {
        const n = singularizeMediaType(e);
        return "episode" === n ? "podcastEpisode" : "radio-station" === n ? "station" : e
    }

    function isNamedOptionKey(e) {
        return Ro.includes(e) || Ao.includes(e)
    }

    function asyncGeneratorStep$7(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$7(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$7(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$7(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$4(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$4(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$4(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$4(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    class MusicItemLoader {
        get isConfigured() {
            return void 0 !== this.developerToken
        }
        static create(e) {
            const n = new this(e);
            return n.configure(e), n
        }
        configure(e) {
            void 0 !== e.storefrontId && (this.storefrontId = e.storefrontId), void 0 !== e.developerToken && (this.developerToken = e.developerToken), void 0 !== e.musicUserToken && (this.musicUserToken = e.musicUserToken)
        }
        convertOptionsToItemDescriptors(e) {
            return convertToItemDescriptors(e)
        }
        buildRequest(e, n) {
            const s = new Headers(_object_spread_props$4(_object_spread$4({}, null == n ? void 0 : n.headers), {
                Authorization: "Bearer " + this.developerToken
            }));
            var d;
            void 0 !== this.musicUserToken && s.set("Music-User-Token", this.musicUserToken);
            const p = encodeQueryParameters(null !== (d = null == n ? void 0 : n.queryParams) && void 0 !== d ? d : "", {
                arrayFormat: "repeat",
                prefix: "?"
            });
            var h;
            const y = {
                method: null !== (h = null == n ? void 0 : n.method) && void 0 !== h ? h : "GET",
                headers: s
            };
            return void 0 !== (null == n ? void 0 : n.body) && (y.method = "POST", "string" == typeof n.body ? y.body = n.body : (y.body = JSON.stringify(n.body), s.has("Content-Type") || s.set("Content-Type", "application/json"))), new Request(buildURL("https://" + this.apiHost, e, p), y)
        }
        loadItems(e) {
            var n = this;
            return _async_to_generator$7((function*() {
                $o.trace("MusicItemLoader.loadItems()", e), $o.debug("Loading resources for options", e);
                const s = yield n.loadResources(_object_spread$4({}, e)), d = n.createItems(s, {
                    container: null == e ? void 0 : e.container,
                    context: null == e ? void 0 : e.context
                });
                return $o.debug(`Transformed ${s.length} resources into ${d.length} MediaItems`), d
            }))()
        }
        loadStation(e) {
            var n = this;
            return _async_to_generator$7((function*() {
                $o.debug("Loading Radio Station", e);
                const s = n.convertOptionsToItemDescriptors(e).find(e => "station" === e.kind);
                if (void 0 === s) return void $o.debug("No station descriptor found in options, returning undefined");
                return (yield n.loadItems({
                    restricted: e.restricted,
                    items: [s],
                    container: null == e ? void 0 : e.container,
                    context: null == e ? void 0 : e.context
                }))[0]
            }))()
        }
        loadStationNextTracks(e, n) {
            var s = this;
            return _async_to_generator$7((function*() {
                var d, p, h;
                const y = "string" == typeof e ? e : e.id,
                    _ = s.buildRequest("/v1/me/stations/next-tracks/" + y, {
                        queryParams: void 0 !== (null == n ? void 0 : n.limit) ? {
                            limit: n.limit
                        } : void 0,
                        method: "POST"
                    }),
                    m = yield s.fetchResources(_);
                var v, g, b;
                const S = {
                    id: null !== (v = null == n || null === (d = n.container) || void 0 === d ? void 0 : d.id) && void 0 !== v ? v : y,
                    type: "stations",
                    href: null !== (g = null == n || null === (p = n.container) || void 0 === p ? void 0 : p.href) && void 0 !== g ? g : `/v1/catalog/${s.storefrontId}/stations/${y}`,
                    attributes: null !== (b = null == n || null === (h = n.container) || void 0 === h ? void 0 : h.attributes) && void 0 !== b ? b : {}
                };
                var P;
                const k = null !== (P = null == n ? void 0 : n.context) && void 0 !== P ? P : {};
                return flattenAll(m.map(e => transform(e, S, k)))
            }))()
        }
        createAutoplayStation(e, n) {
            var s = this;
            return _async_to_generator$7((function*() {
                const d = [];
                for (let s = 0; s < e.length; s++) {
                    const p = e[s],
                        h = pluralizeMediaType(p instanceof MediaItem ? p.type : p.kind);
                    /(-?songs|artists?)$/.test(h) && d.push({
                        id: p.id,
                        type: isLibraryType(p.id) ? "library-songs" : "songs",
                        meta: void 0 !== (null == n ? void 0 : n.container) ? {
                            container: n.container
                        } : void 0
                    })
                }
                if (0 === d.length) throw $o.error("Unable to create AutoplayStation: No items to seed"), new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "Unable to create AutoplayStation: No items to seed");
                const p = s.buildRequest("/v1/me/stations/continuous", {
                        queryParams: {
                            "limit[results:tracks]": void 0 !== (null == n ? void 0 : n.limit) && n.limit > 1 ? n.limit : void 0,
                            with: !0 === (null == n ? void 0 : n.withTracks) ? ["tracks"] : void 0
                        },
                        method: "POST",
                        body: {
                            data: d
                        }
                    }),
                    {
                        errors: h,
                        results: y
                    } = yield s.services.request.fetchJSON(p);
                if (void 0 !== h && h.length > 0) {
                    $o.error("Unable to create AutoplayStation: Server Error");
                    const e = new MKError(MKError.Reason.CONTENT_UNSUPPORTED, "Unable to create AutoplayStation: Server Error");
                    throw e.data = {
                        errors: h
                    }, e
                }
                if (void 0 === (null == y ? void 0 : y.station)) throw $o.error("Unable to create AutoplayStation: No station returned from server"), new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "Unable to create AutoplayStation: No station returned from server");
                const _ = s.createItems(y.station, {
                    container: null == n ? void 0 : n.container,
                    context: null == n ? void 0 : n.context
                })[0];
                let m = [];
                return Array.isArray(y.tracks) && (m = s.createItems(y.tracks, {
                    container: _,
                    context: null == n ? void 0 : n.context
                })), {
                    station: _,
                    tracks: m
                }
            }))()
        }
        loadResources(e) {
            var n = this;
            return _async_to_generator$7((function*() {
                const s = convertToItemDescriptors(e),
                    d = function(e) {
                        const n = _object_spread$4({}, e);
                        if (void 0 === e) return n;
                        for (const s of ["extend", "include", "relate", "fields"])
                            if (void 0 !== n[s]) {
                                const d = e[s];
                                "string" == typeof d && (n[s] = d.split(/(?:,{1}?\s*|\s+)/))
                            }
                        return n
                    }(e.parameters),
                    p = new Map(s.map((e, n) => [e.id, {
                        position: n,
                        descriptor: e
                    }])),
                    h = function(e, n) {
                        const s = {};
                        for (const d of e) {
                            const e = n(d);
                            void 0 === s[e] && (s[e] = []), s[e].push(d)
                        }
                        return s
                    }(s, e => e.kind),
                    y = Object.entries(h),
                    _ = [],
                    m = [];
                for (const [S, P] of y) {
                    const s = [],
                        p = [],
                        h = [];
                    for (const e of P) void 0 !== e.item || void 0 !== e.data ? s.push(e) : (isLibraryType(e.id) ? h : p).push(e);
                    const y = [];
                    /^(?:playlists?|albums?)$/i.test(S) && y.push("tracks"), /^podcasts?$/i.test(S) && y.push("episodes");
                    const v = /^(?:playlists?|library-playlists?)$/i.test(S),
                        g = e.restricted ? "explicit" : void 0;
                    s.length > 0 && _.push(...s.map(e => {
                        var n;
                        return null !== (n = e.item) && void 0 !== n ? n : e.data
                    }));
                    const b = deepmerge(deepClone(d), {
                            include: y,
                            extend: v ? ["hasCollaboration"] : [],
                            restrict: g
                        }),
                        k = 16;
                    if (p.length > 0) {
                        const e = batchIds(p, k);
                        for (const s of e) m.push(n.buildRequest(`/v1/catalog/${n.storefrontId}/${dasherize(S)}s`, {
                            queryParams: _object_spread_props$4(_object_spread$4({}, b), {
                                ids: s
                            })
                        }))
                    }
                    if (h.length > 0)
                        if ("song" === S) {
                            const e = batchIds(h, k);
                            for (const s of e) m.push(n.buildRequest(`/v1/me/library/${dasherize(S)}s/`, {
                                queryParams: _object_spread_props$4(_object_spread$4({}, b), {
                                    ids: s
                                })
                            }))
                        } else
                            for (const e of h) m.push(n.buildRequest(`/v1/me/library/${dasherize(S)}s/${e.id}`, {
                                queryParams: b
                            }))
                }
                const v = yield Promise.all(m.map(e => n.fetchResources(e))), g = Array(p.size);
                for (const e of [..._, ...flattenAll(v)]) {
                    const n = p.get(e.id);
                    void 0 !== (null == n ? void 0 : n.position) && (g[n.position] = e)
                }
                const b = [];
                for (const {
                        position: e,
                        descriptor: n
                    } of p.values()) void 0 === g[e] && b.push(n);
                if (b.length > 0) {
                    const e = new MKError(MKError.Reason.NOT_FOUND, "One or more items could not be resolved: " + b.map(({
                        id: e
                    }) => e).join(", "));
                    throw e.data = b, e
                }
                return g
            }))()
        }
        loadPivots(e) {
            var n = this;
            return _async_to_generator$7((function*() {
                var s, d, p;
                const h = {
                    sessionId: e.sessionId,
                    seed: {},
                    offeredRounds: e.offeredRounds || []
                };
                var y;
                /-?songs$/.test(null === (s = e.seed) || void 0 === s ? void 0 : s.type) && (h.seed = {
                    id: e.seed.id,
                    type: isLibraryType(e.seed.id) ? "library-songs" : "songs"
                });
                const _ = n.buildRequest("/v1/me/recommendations/pivots", {
                        queryParams: {
                            limit: null !== (y = e.limit) && void 0 !== y ? y : "20",
                            types: "albums,stations,playlists",
                            with: "pivot-meta",
                            "format[resources]": "map",
                            "associate[albums]": "recommended-entry-tracks",
                            "associate[playlists]": "recommended-entry-tracks"
                        },
                        method: "POST",
                        body: h
                    }),
                    {
                        meta: m,
                        results: v,
                        resources: g
                    } = yield n.services.request.fetchJSON(_);
                if (0 === (null === (d = v.data) || void 0 === d ? void 0 : d.length)) {
                    const e = new MKError(MKError.Reason.NOT_FOUND, "No Pivots returned");
                    throw e.data = v, e
                }
                const b = [],
                    S = [];
                return null === (p = v.data) || void 0 === p || p.forEach(e => {
                    var s, d, p, h;
                    const y = null == g || null === (s = g[e.type]) || void 0 === s ? void 0 : s[e.id];
                    if (null == y || null === (d = y.meta) || void 0 === d ? void 0 : d.associations) {
                        var _, m, v;
                        const e = null == y || null === (v = y.meta) || void 0 === v || null === (m = v.associations) || void 0 === m || null === (_ = m["recommended-entry-tracks"]) || void 0 === _ ? void 0 : _.data[0];
                        var P, k;
                        if (e) S.push(...n.createItems(null !== (k = null == g || null === (P = g[null == e ? void 0 : e.type]) || void 0 === P ? void 0 : P[null == e ? void 0 : e.id]) && void 0 !== k ? k : [], {
                            container: y,
                            context: g
                        }))
                    }
                    b.push(...n.createItems(_object_spread_props$4(_object_spread$4({}, e, y), {
                        meta: _object_spread$4({}, e.meta, null == g || null === (h = g[e.type]) || void 0 === h || null === (p = h[e.id]) || void 0 === p ? void 0 : p.meta)
                    })))
                }), {
                    sessionId: null == m ? void 0 : m.sessionId,
                    pivots: b,
                    pivotQueueItems: S
                }
            }))()
        }
        fetchResources(e) {
            var n = this;
            return _async_to_generator$7((function*() {
                const s = yield n.services.request.fetchJSON(e);
                return Array.isArray(s.data) ? s.data : [s.data]
            }))()
        }
        createItems(e, n) {
            return flattenAll((e = Array.isArray(e) ? e : [e]).map(e => transform(e, null == n ? void 0 : n.container, null == n ? void 0 : n.context)))
        }
        constructor(e) {
            if (_define_property$4(this, "services", void 0), _define_property$4(this, "apiHost", void 0), _define_property$4(this, "storefrontId", "us"), _define_property$4(this, "developerToken", void 0), _define_property$4(this, "musicUserToken", void 0), this.services = e.services, this.apiHost = e.apiHost.replace(/^https?:[/]{0,2}/i, ""), isEmptyString(this.apiHost)) throw new MKError(MKError.Reason.CONFIGURATION_ERROR, "Invalid API Host for Item Loader")
        }
    }

    function batchIds(e, n) {
        return e.reduce((function(e, s, d) {
            const p = Math.floor(d / n);
            return void 0 === e[p] && (e[p] = []), e[p].push(s.id), e
        }), [])
    }

    function asyncGeneratorStep$6(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$6(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$6(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$6(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$3(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$3(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$3(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$3(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }

    function _ts_decorate(e, n, s, d) {
        var p, h = arguments.length,
            y = h < 3 ? n : null === d ? d = Object.getOwnPropertyDescriptor(n, s) : d;
        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) y = Reflect.decorate(e, n, s, d);
        else
            for (var _ = e.length - 1; _ >= 0; _--)(p = e[_]) && (y = (h < 3 ? p(y) : h > 3 ? p(n, s, y) : p(n, s)) || y);
        return h > 3 && y && Object.defineProperty(n, s, y), y
    }

    function _ts_metadata(e, n) {
        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(e, n)
    }
    const Mo = [MKError.Reason.CONTENT_EQUIVALENT, MKError.Reason.CONTENT_RESTRICTED, MKError.Reason.CONTENT_UNAVAILABLE, MKError.Reason.CONTENT_UNSUPPORTED, MKError.Reason.SERVER_ERROR, MKError.Reason.SUBSCRIPTION_ERROR, MKError.Reason.UNSUPPORTED_ERROR, MKError.Reason.USER_INTERACTION_REQUIRED],
        Co = JsonDevFlag.register("mk-bag-features-overrides");
    class MKInstance {
        get playbackController() {
            return this._playbackController
        }
        get developerToken() {
            return Fn.developerToken
        }
        get api() {
            return this._services.apiManager.api
        }
        get audioTracks() {
            return this._mediaItemPlayback.audioTracks
        }
        get authorizationStatus() {
            return Fn.authorizationStatus
        }
        get bitrate() {
            return this._services.bitrateCalculator.bitrate
        }
        set bitrate(e) {
            this._services.bitrateCalculator.bitrate = e
        }
        get browserSupportsPictureInPicture() {
            return detectPictureInPictureSupport()
        }
        get browserSupportsVideoDrm() {
            return supportsDrm()
        }
        get cid() {
            return (this.realm === e.SKRealm.TV || this.sourceType !== wt.MUSICKIT) && Fn.cid
        }
        get continuous() {
            var e, n;
            return null !== (n = null === (e = this._playbackController) || void 0 === e ? void 0 : e.continuous) && void 0 !== n && n
        }
        set continuous(e) {
            this.getPlaybackController().continuous = e
        }
        get autoplayEnabled() {
            return this._autoplayEnabled
        }
        set autoplayEnabled(n) {
            this.realm !== e.SKRealm.MUSIC && (n = !1), n !== this.autoplayEnabled && (this._autoplayEnabled = n, this._services.dispatcher.publish(Cn.autoplayEnabledDidChange, this.autoplayEnabled))
        }
        get currentAudioTrack() {
            return this._mediaItemPlayback.currentAudioTrack
        }
        set currentAudioTrack(e) {
            this._mediaItemPlayback.currentAudioTrack = e
        }
        get currentPlaybackDuration() {
            return this._mediaItemPlayback.currentPlaybackDuration
        }
        get currentPlaybackProgress() {
            return this._mediaItemPlayback.currentPlaybackProgress
        }
        get currentPlaybackTime() {
            return this._mediaItemPlayback.currentPlaybackTime
        }
        get currentPlaybackTimeRemaining() {
            return this._mediaItemPlayback.currentPlaybackTimeRemaining
        }
        get currentTextTrack() {
            return this._mediaItemPlayback.currentTextTrack
        }
        set currentTextTrack(e) {
            this._mediaItemPlayback.currentTextTrack = e
        }
        get isAuthorized() {
            return Fn.isAuthorized
        }
        get isPlaying() {
            var e, n;
            return null !== (n = null === (e = this._playbackController) || void 0 === e ? void 0 : e.isPlaying) && void 0 !== n && n
        }
        get isRestricted() {
            return Fn.isRestricted
        }
        get isU13() {
            return Fn.isU13
        }
        get metricsClientId() {
            return Fn.metricsClientId
        }
        set metricsClientId(e) {
            Fn.metricsClientId = e
        }
        get musicUserToken() {
            return Fn.musicUserToken
        }
        set musicUserToken(e) {
            e && Fn.musicUserToken === e || (Fn.musicUserToken = e)
        }
        get nowPlayingItem() {
            return this._mediaItemPlayback.nowPlayingItem
        }
        get nowPlayingItemIndex() {
            var e, n;
            return null !== (n = null === (e = this._playbackController) || void 0 === e ? void 0 : e.nowPlayingItemIndex) && void 0 !== n ? n : -1
        }
        get playbackMode() {
            return this._playbackMode
        }
        set playbackMode(n) {
            if (-1 === Object.values(e.PlaybackMode).indexOf(n)) return;
            const s = n === e.PlaybackMode.PREVIEW_ONLY,
                d = this._services.mediaItemPlayback;
            d && (d.previewOnly = s), this._playbackMode !== n && (this._playbackMode = n, void 0 !== this._playbackController && (this._playbackController.playbackMode = n))
        }
        get playbackRate() {
            return this._mediaItemPlayback.playbackRate
        }
        set playbackRate(e) {
            this._mediaItemPlayback.playbackRate = e
        }
        get defaultPlaybackRate() {
            return this._mediaItemPlayback.defaultPlaybackRate
        }
        set defaultPlaybackRate(e) {
            this._mediaItemPlayback.defaultPlaybackRate = e
        }
        get playbackState() {
            return this._mediaItemPlayback.playbackState
        }
        get playbackTargetAvailable() {
            return this._mediaItemPlayback.playbackTargetAvailable
        }
        get playbackTargetIsWireless() {
            return this._mediaItemPlayback.playbackTargetIsWireless
        }
        get previewOnly() {
            return this.playbackMode === e.PlaybackMode.PREVIEW_ONLY
        }
        set previewOnly(n) {
            this.playbackMode = n ? e.PlaybackMode.PREVIEW_ONLY : e.PlaybackMode.MIXED_CONTENT
        }
        get queue() {
            var e;
            return null === (e = this._playbackController) || void 0 === e ? void 0 : e.queue
        }
        get queueIsEmpty() {
            var e, n, s;
            return null === (s = null === (n = this._playbackController) || void 0 === n || null === (e = n.queue) || void 0 === e ? void 0 : e.isEmpty) || void 0 === s || s
        }
        get realm() {
            return Fn.realm
        }
        get repeatMode() {
            var n, s;
            return null !== (s = null === (n = this._playbackController) || void 0 === n ? void 0 : n.repeatMode) && void 0 !== s ? s : e.PlayerRepeatMode.none
        }
        set repeatMode(e) {
            this.getPlaybackController().repeatMode = e
        }
        set requestUserToken(e) {
            Fn.requestUserToken = e
        }
        get restrictedEnabled() {
            return Fn.restrictedEnabled
        }
        set restrictedEnabled(e) {
            Fn.restrictedEnabled = e
        }
        get supportsPreviewImages() {
            return this._mediaItemPlayback.supportsPreviewImages
        }
        get seekSeconds() {
            var e;
            return null === (e = this._playbackController) || void 0 === e ? void 0 : e.seekSeconds
        }
        get services() {
            return this._services
        }
        set shuffle(e) {
            this.getPlaybackController().shuffle = e
        }
        get shuffleMode() {
            var n, s;
            return null !== (s = null === (n = this._playbackController) || void 0 === n ? void 0 : n.shuffleMode) && void 0 !== s ? s : e.PlayerShuffleMode.off
        }
        set shuffleMode(e) {
            this.getPlaybackController().shuffleMode = e
        }
        get storefrontCountryCode() {
            return Fn.storefrontCountryCode
        }
        get subscribeURL() {
            return Fn.subscribeURL
        }
        get subscribeFamilyURL() {
            return Fn.subscribeFamilyURL
        }
        get subscribeIndividualURL() {
            return Fn.subscribeIndividualURL
        }
        get subscribeStudentURL() {
            return Fn.subscribeStudentURL
        }
        get textTracks() {
            return this._mediaItemPlayback.textTracks
        }
        get videoContainerElement() {
            return this.context.videoContainerElement
        }
        set videoContainerElement(e) {
            this.context.videoContainerElement = e
        }
        get volume() {
            return this._mediaItemPlayback.volume
        }
        set volume(e) {
            this._mediaItemPlayback.volume = e
        }
        get storefrontId() {
            return Fn.storefrontId
        }
        set storefrontId(e) {
            Fn.storefrontId = e
        }
        get _mediaItemPlayback() {
            return this._services.mediaItemPlayback
        }
        getPlaybackController() {
            if (Ge.trace("MKInstance.getPlaybackController()", this._playbackController), void 0 === this._playbackController) throw new MKError(MKError.Reason.INTERNAL_ERROR, "No PlaybackController active");
            return this._playbackController
        }
        setPlaybackController(e) {
            var n = this;
            return _async_to_generator$6((function*() {
                return Ge.trace("MKInstance.setPlaybackController()", e), n._playbackController === e || (void 0 !== n._playbackController && (yield n._playbackController.deactivate()), e.autoplayEnabled = n._autoplayEnabled, yield e.activate(), n.capabilities.controller = e, n.capabilities.updateChecker(e.hasCapabilities), n._playbackController = e), e
            }))()
        }
        addEventListener(e, n, s = {}) {
            adaptAddEventListener(this._services.dispatcher, e, n, s)
        }
        authorize() {
            var e = this;
            return _async_to_generator$6((function*() {
                return e.deferPlayback(), Fn.authorize()
            }))()
        }
        canAuthorize() {
            return supportsDrm() && !this.isAuthorized
        }
        canUnauthorize() {
            return supportsDrm() && this.isAuthorized
        }
        changeToMediaAtIndex(e) {
            var n = this;
            return _async_to_generator$6((function*() {
                n._isPlaybackSupported() && (yield n.validateAuthorization(), n.signalChangeItemIntent(), yield n.getPlaybackController().changeToMediaAtIndex(e))
            }))()
        }
        changeToMediaItem(e) {
            var n = this;
            return _async_to_generator$6((function*() {
                Ge.debug("instance.changeToMediaItem", e), n._isPlaybackSupported() && (yield n.validateAuthorization(), n.signalChangeItemIntent(), yield n.getPlaybackController().changeToMediaItem(e))
            }))()
        }
        changeUserStorefront(e) {
            var n = this;
            return _async_to_generator$6((function*() {
                n.storefrontId = e
            }))()
        }
        cleanup() {
            var n = this;
            return _async_to_generator$6((function*() {
                var s;
                null === (s = n._services.mediaItemPlayback) || void 0 === s || s.destroy(), n.signalIntent({
                    endReasonType: e.PlayActivityEndReasonType.EXITED_APPLICATION
                });
                const d = Object.keys(n.playbackControllers).map(e => n.playbackControllers[e].destroy());
                try {
                    yield Promise.all(d)
                } catch (Rt) {
                    Ge.error("Error cleaning up controller", Rt)
                }
                n._services.dispatcher.clear()
            }))()
        }
        configure(e) {
            var n = this;
            return _async_to_generator$6((function*() {
                return yield n.setPlaybackController(n.getPlaybackControllerByType(io.serial)), n._whenConfigured = n._configure(e), n._whenConfigured
            }))()
        }
        _configure(e) {
            var n = this;
            return _async_to_generator$6((function*() {
                yield Fn.storekit.whenAuthCompleted;
                const s = e.map(n._services.apiManager.registerAPIService, n._services.apiManager);
                yield Promise.all(s), yield n._configurePlayActivity(), n._initializeExternalEventPublishing()
            }))()
        }
        deferPlayback() {
            Ge.debug("deferPlayback", this._playbackController), deferPlayback()
        }
        me() {
            return _async_to_generator$6((function*() {
                try {
                    return yield Fn.storekit.me()
                } catch (Rt) {
                    return Promise.reject(new MKError(MKError.Reason.AUTHORIZATION_ERROR, "Unauthorized"))
                }
            }))()
        }
        hasMusicSubscription() {
            return hasMusicSubscription(Fn.storekit)
        }
        mute() {
            return this._mediaItemPlayback.mute()
        }
        pause(n) {
            var s = this;
            return _async_to_generator$6((function*() {
                if (s._isPlaybackSupported()) {
                    try {
                        s.signalIntent({
                            endReasonType: e.PlayActivityEndReasonType.PLAYBACK_MANUALLY_PAUSED
                        }), yield s.getPlaybackController().pause(n)
                    } catch (ce) {
                        s._handlePlaybackError(ce)
                    }
                    return Promise.resolve()
                }
            }))()
        }
        play() {
            var e = this;
            return _async_to_generator$6((function*() {
                if (Ge.debug("instance.play()"), e._isPlaybackSupported()) {
                    yield e.validateAuthorization();
                    try {
                        yield e.getPlaybackController().play()
                    } catch (ce) {
                        e._handlePlaybackError(ce)
                    }
                    return Promise.resolve()
                }
            }))()
        }
        playMediaItem(e, n) {
            var s = this;
            return _async_to_generator$6((function*() {
                var d, p;
                if (Ge.trace("MKInstance.playMediaItem()", e, n), (null == n ? void 0 : n.bingeWatching) || s.deferPlayback(), n = _object_spread$3({}, n), (null == e ? void 0 : e.playEvent) && !hasOwn(n, "startTime")) {
                    const {
                        playEvent: s
                    } = e;
                    s.isDone || void 0 === s.playCursorInSeconds || (n.startTime = s.playCursorInSeconds)
                }
                s.services.dispatcher.publish(Cn.playInitiated, {
                    item: e,
                    timestamp: null !== (p = null === (d = n.meta) || void 0 === d ? void 0 : d.initiatedTimestamp) && void 0 !== p ? p : Date.now()
                });
                try {
                    n && s._mediaItemPlayback.playOptions.set(e.id, n);
                    const d = yield s.getPlaybackController().playSingleMediaItem(e, n);
                    return s.services.dispatcher.publish(Cn.capabilitiesChanged), d
                } catch (ce) {
                    Ge.error("mk:playMediaItem error", ce), s._handlePlaybackError(ce)
                }
            }))()
        }
        removeEventListener(e, n) {
            ! function(e, n, s) {
                const d = getCallbacksForName(n);
                let p;
                for (let h = d.length - 1; h >= 0; h--) {
                    const [e, n] = d[h];
                    if (e === s) {
                        p = n, d.splice(h, 1);
                        break
                    }
                }
                p && e.unsubscribe(n, p)
            }(this._services.dispatcher, e, n)
        }
        exitFullscreen() {
            return this._mediaItemPlayback.exitFullscreen()
        }
        requestFullscreen(e) {
            return this._mediaItemPlayback.requestFullscreen(e)
        }
        loadPreviewImage(e) {
            var n = this;
            return _async_to_generator$6((function*() {
                return n._mediaItemPlayback.loadPreviewImage(e)
            }))()
        }
        getNewSeeker() {
            return this.getPlaybackController().getNewSeeker()
        }
        seekToTime(e, n = ut.Manual) {
            var s = this;
            return _async_to_generator$6((function*() {
                if (s._isPlaybackSupported()) {
                    yield s.validateAuthorization();
                    try {
                        yield s.getPlaybackController().seekToTime(e, n)
                    } catch (ce) {
                        s._handlePlaybackError(ce)
                    }
                    return Promise.resolve()
                }
            }))()
        }
        setPresentationMode(e) {
            var n = this;
            return _async_to_generator$6((function*() {
                return n._mediaItemPlayback.setPresentationMode(e)
            }))()
        }
        skipToNextItem() {
            var n = this;
            return _async_to_generator$6((function*() {
                if (n._isPlaybackSupported()) {
                    yield n.validateAuthorization(), n.signalIntent({
                        endReasonType: e.PlayActivityEndReasonType.TRACK_SKIPPED_FORWARDS,
                        direction: e.PlayActivityEndReasonType.TRACK_SKIPPED_FORWARDS
                    });
                    try {
                        yield n.getPlaybackController().skipToNextItem()
                    } catch (ce) {
                        n._handlePlaybackError(ce)
                    }
                }
            }))()
        }
        skipToPreviousItem() {
            var n = this;
            return _async_to_generator$6((function*() {
                if (n._isPlaybackSupported()) {
                    yield n.validateAuthorization(), n.signalIntent({
                        endReasonType: e.PlayActivityEndReasonType.TRACK_SKIPPED_BACKWARDS,
                        direction: e.PlayActivityEndReasonType.TRACK_SKIPPED_BACKWARDS
                    });
                    try {
                        yield n.getPlaybackController().skipToPreviousItem()
                    } catch (ce) {
                        n._handlePlaybackError(ce)
                    }
                }
            }))()
        }
        seekForward() {
            var n = this;
            return _async_to_generator$6((function*() {
                if (n._isPlaybackSupported()) {
                    yield n.validateAuthorization();
                    try {
                        n.signalIntent({
                            endReasonType: e.PlayActivityEndReasonType.TRACK_SKIPPED_FORWARDS,
                            direction: e.PlayActivityEndReasonType.TRACK_SKIPPED_FORWARDS
                        }), yield n.getPlaybackController().seekForward()
                    } catch (ce) {
                        n._handlePlaybackError(ce)
                    }
                }
            }))()
        }
        seekBackward() {
            var e = this;
            return _async_to_generator$6((function*() {
                if (e._isPlaybackSupported()) {
                    yield e.validateAuthorization();
                    try {
                        yield e.getPlaybackController().seekBackward()
                    } catch (ce) {
                        e._handlePlaybackError(ce)
                    }
                }
            }))()
        }
        showPlaybackTargetPicker() {
            this.getPlaybackController().showPlaybackTargetPicker()
        }
        stop(e) {
            var n = this;
            return _async_to_generator$6((function*() {
                if (n._isPlaybackSupported()) {
                    var s;
                    n.signalIntent({
                        endReasonType: null == e ? void 0 : e.endReasonType,
                        userInitiated: null === (s = null == e ? void 0 : e.userInitiated) || void 0 === s || s
                    });
                    try {
                        yield n.getPlaybackController().stop(e)
                    } catch (ce) {
                        n._handlePlaybackError(ce)
                    }
                }
            }))()
        }
        unauthorize() {
            return _async_to_generator$6((function*() {
                return Fn.unauthorize()
            }))()
        }
        unmute() {
            return this._mediaItemPlayback.unmute()
        }
        _createPlayerControllerOptions() {
            return {
                tokens: Fn,
                bag: Un,
                playbackServices: {
                    getRTCStreamingTracker: () => {
                        var e;
                        return null === (e = this._services.playActivity) || void 0 === e ? void 0 : e.getTrackerByType(RTCStreamingTracker)
                    },
                    hasMusicSubscription: hasMusicSubscription,
                    prepareForEncryptedPlayback: (e, n) => function(e, n) {
                        return _prepareForEncryptedPlayback.apply(this, arguments)
                    }(e, _object_spread_props$3(_object_spread$3({}, n), {
                        services: {
                            apiManager: this._services.apiManager,
                            request: this._services.request
                        }
                    }))
                },
                services: this._services,
                context: this.context,
                autoplayEnabled: this.autoplayEnabled,
                privateEnabled: this.privateEnabled,
                siriInitiated: this.siriInitiated,
                storekit: null == Fn ? void 0 : Fn.storekit,
                playbackMode: this.playbackMode
            }
        }
        getPlaybackControllerByType(e) {
            let n = this.playbackControllers[e];
            if (void 0 !== n) return n;
            switch (e) {
                case io.serial:
                    n = new SerialPlaybackController(this._createPlayerControllerOptions());
                    break;
                case io.continuous:
                    n = new ContinuousPlaybackController(this._createPlayerControllerOptions());
                    break;
                default:
                    throw new MKError(MKError.Reason.UNSUPPORTED_ERROR, "Unsupported controller requested: " + e)
            }
            return this.playbackControllers[e] = n, n
        }
        playbackControllerForItems(e) {
            const n = e[0];
            return (null == n ? void 0 : n.isRadioStation) && !(null == n ? void 0 : n.isRadioEpisode) ? this.getPlaybackControllerByType(io.continuous) : this.getPlaybackControllerByType(io.serial)
        }
        _handlePlaybackError(e) {
            if (Ge.error("mediaPlaybackError", e), MKError.isMKError(e) && Mo.includes(e.reason)) throw e;
            this._playbackErrorDialog && !this._services.runtime.isNodeEnvironment && MKDialog.presentError(e)
        }
        _initializeInternalEventHandling() {
            const {
                dispatcher: n,
                itemLoader: s
            } = this._services;
            Fn.storekit.addEventListener(Cn.userTokenDidChange, ({
                userToken: e
            }) => {
                this._whenConfigured && this._whenConfigured.then(() => this._configurePlayActivity().catch()).catch(), Ge.debug("Setting musicUserToken for MusicItemLoader: " + this.musicUserToken), null == s || s.configure({
                    musicUserToken: e
                })
            }), Fn.storekit.addEventListener(Cn.storefrontCountryCodeDidChange, (function({
                storefrontCountryCode: e
            }) {
                Ge.debug("Setting storefrontId for MusicItemLoader: " + e), null == s || s.configure({
                    storefrontId: e
                })
            })), n.subscribe(Cn.mediaPlaybackError, (e, n) => this._handlePlaybackError(n)), n.subscribe(Cn.playbackStateDidChange, (n, s) => {
                s.state === e.PlaybackStates.paused && (Ge.debug("mk: playbackStateDidChange callback - calling storekit.presentSubscribeViewForEligibleUsers"), Fn.storekit.presentSubscribeViewForEligibleUsers({
                    state: s.state,
                    item: this.nowPlayingItem
                }, !1))
            }), n.subscribe(Fi, (e, {
                metadata: s,
                item: d,
                position: p,
                playingDate: h
            }) => {
                if (s.blob) {
                    const e = {
                        item: null != d ? d : this.nowPlayingItem,
                        position: null != p ? p : this.currentPlaybackTime,
                        playingDate: null != h ? h : this.currentPlayingDate,
                        storefrontId: this.storefrontId.toUpperCase(),
                        metadata: s
                    };
                    Ge.debug('Dispatching TimedMetadata "ping"', e), n.publish(ot.timedMetadata, e)
                }
            })
        }
        _initializeExternalEventPublishing() {
            [Cn.authorizationStatusDidChange, Cn.storefrontCountryCodeDidChange, Cn.storefrontIdentifierDidChange, Cn.userTokenDidChange, Cn.eligibleForSubscribeView].forEach(e => {
                Fn.storekit.addEventListener(e, n => this._services.dispatcher.publish(e, n))
            }), this._services.dispatcher.subscribe(Fi, (e, {
                metadata: n
            }) => {
                Ge.debug("Dispatching TimedMetadata change", n), this._services.dispatcher.publish(Cn.timedMetadataDidChange, n)
            })
        }
        configureLogger(e) {
            var n;
            Ge.level === Be && (!0 === e.debug ? setRootLoggingLevel(w.DEBUG) : void 0 !== e.logLevel && setRootLoggingLevel(e.logLevel)), Ue.enabled && setConsoleOutput(Ue.enabled), void 0 !== Fe.value && applyLoggingLevels(Fe.value), void 0 !== e.logHandler && (n = e.logHandler, Ge.handlers.external = new CallbackHandler(n))
        }
        _configurePlayActivity() {
            var e = this;
            return _async_to_generator$6((function*() {
                void 0 !== e._services.playActivity && (yield e._services.playActivity.configure({
                    instance: e,
                    services: e._services
                }))
            }))()
        }
        _isPlaybackSupported() {
            return !this._services.runtime.isNodeEnvironment || (Ge.warn("Media playback is not supported in Node environments."), !1)
        }
        signalChangeItemIntent() {
            this.signalIntent({
                endReasonType: e.PlayActivityEndReasonType.MANUALLY_SELECTED_PLAYBACK_OF_A_DIFF_ITEM
            })
        }
        signalIntent(e) {
            this.services.dispatcher.publish(ot.userActivityIntent, _object_spread$3({
                userInitiated: !0
            }, e))
        }
        validateAuthorization(n = !1) {
            var s = this;
            return _async_to_generator$6((function*() {
                (n || s.playbackMode === e.PlaybackMode.FULL_PLAYBACK_ONLY) && (void 0 !== s._playbackController && s._playbackController.isReady && s._playbackController.isPlaying || (yield s.authorize()))
            }))()
        }
        constructor(n) {
            _define_property$3(this, "app", void 0), _define_property$3(this, "capabilities", void 0), _define_property$3(this, "context", void 0), _define_property$3(this, "_autoplayEnabled", !1), _define_property$3(this, "id", void 0), _define_property$3(this, "prefix", void 0), _define_property$3(this, "privateEnabled", !1), _define_property$3(this, "siriInitiated", !1), _define_property$3(this, "sourceType", wt.MUSICKIT), _define_property$3(this, "version", e.version), _define_property$3(this, "playbackActions", void 0), _define_property$3(this, "guid", void 0), _define_property$3(this, "_bag", Un), _define_property$3(this, "playbackControllers", {}), _define_property$3(this, "_playbackController", void 0), _define_property$3(this, "_queue", void 0), _define_property$3(this, "_services", void 0), _define_property$3(this, "_playbackErrorDialog", !0), _define_property$3(this, "_playbackMode", e.PlaybackMode.MIXED_CONTENT), _define_property$3(this, "_whenConfigured", void 0);
            const {
                developerToken: s
            } = n;
            if ("string" != typeof s || "" === s.trim()) throw new MKError(MKError.Reason.CONFIGURATION_ERROR, "Missing or empty developer token");
            Object.assign(Un.features, function(e = []) {
                const n = {};
                return e.forEach(e => {
                    "-" === e.charAt(0) ? (e = e.substr(1), n[e] = !1) : n[e] = !0
                }), n
            }(n.features));
            const d = Co.get();
            d && (Ge.warn("Overriding bag.features with", d), Un.features = _object_spread$3({}, Un.features, d)), Object.assign(Un.autoplay, n.autoplay), Object.assign(Un.app, n.app), Object.assign(Un.urls, n.urls), this.context = {};
            const p = n.services;
            this.capabilities = new Capabilities(p.dispatcher), "playbackActions" in n && (this.playbackActions = n.playbackActions), "guid" in n && (this.guid = n.guid);
            const h = new TimingAccuracy(!!Un.features["player-accurate-timing"]),
                y = new BitrateCalculator(p.dispatcher, n.bitrate),
                _ = function(e, n) {
                    return Fn = new Store(e, n), Fn
                }(s, n);
            this._services = {
                runtime: p.runtime,
                request: p.request,
                dispatcher: p.dispatcher,
                itemLoader: MusicItemLoader.create({
                    apiHost: "api.music.apple.com",
                    services: {
                        runtime: p.runtime,
                        request: p.request
                    },
                    storefrontId: null == _ ? void 0 : _.storefrontId,
                    developerToken: s,
                    musicUserToken: _.musicUserToken
                }),
                timing: h,
                bitrateCalculator: y
            }, void 0 !== n.playActivityAPI && (this._services.playActivity = new PlayActivityService(p.dispatcher, n.playActivityAPI)), n.services = this._services, this.configureLogger(n), this._services.apiManager = new APIServiceManager(_, p.dispatcher);
            const m = new MediaItemPlayback(this._createPlayerControllerOptions());
            this._services.mediaItemPlayback = m, n.sourceType && (this.sourceType = n.sourceType), this._initializeInternalEventHandling(), n.bitrate && (this.bitrate = n.bitrate), "prefix" in n && /^(?:web|preview)$/.test(n.prefix || "") && (this.prefix = Un.prefix = n.prefix), n.suppressErrorDialog && (this._playbackErrorDialog = !n.suppressErrorDialog), void 0 !== n.playbackMode && (this.playbackMode = n.playbackMode), "privateEnabled" in n && (this.privateEnabled = n.privateEnabled || !1), "siriInitiated" in n && (this.siriInitiated = n.siriInitiated || !1), this.id = generateUUID(), Ge.info("MusicKit JS Version: " + this.version), Ge.info("InstanceId", this.id), Ge.debug("Link Parameters", n.linkParameters), Un.app && Ge.debug("App", Un.app)
        }
    }

    function asyncGeneratorStep$5(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$5(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$5(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$5(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function dispatchDocumentEvent(e) {
        if (detectNodeEnvironment()) return;
        const n = new Event(e, {
            bubbles: !0,
            cancelable: !0
        });
        setTimeout(() => document.dispatchEvent(n))
    }

    function _loadWebComponents() {
        return (_loadWebComponents = _async_to_generator$5((function*() {
            var e;
            if (detectNodeEnvironment()) return;
            const n = findScript("musickit.js");
            if ("" !== (null == n || null === (e = n.dataset) || void 0 === e ? void 0 : e.webComponents)) return;
            const s = "noModule" in n,
                d = `components/musickit-components/musickit-components${s?".esm":""}.js`,
                p = "https:" + cdnBaseURL(d) + d,
                h = {};
            s && (h.type = "module"), n.hasAttribute("async") && (h.async = ""), n.hasAttribute("defer") && (h.defer = ""), yield loadScript(p, h), dispatchDocumentEvent(Cn.webComponentsLoaded)
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep$4(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$4(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$4(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$4(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$2(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$2(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$2(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$2(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    _ts_decorate([AsyncDebounce(250, {
        isImmediate: !0
    }), _ts_metadata("design:type", Function), _ts_metadata("design:paramtypes", ["undefined" == typeof ActivityNotificationOptions ? Object : ActivityNotificationOptions]), _ts_metadata("design:returntype", Promise)], MKInstance.prototype, "pause", null), _ts_decorate([AsyncDebounce(250, {
        isImmediate: !0
    }), _ts_metadata("design:type", Function), _ts_metadata("design:paramtypes", []), _ts_metadata("design:returntype", Promise)], MKInstance.prototype, "play", null), _ts_decorate([SerialAsync("skip"), _ts_metadata("design:type", Function), _ts_metadata("design:paramtypes", []), _ts_metadata("design:returntype", Promise)], MKInstance.prototype, "skipToNextItem", null), _ts_decorate([SerialAsync("skip"), _ts_metadata("design:type", Function), _ts_metadata("design:paramtypes", []), _ts_metadata("design:returntype", Promise)], MKInstance.prototype, "skipToPreviousItem", null), _ts_decorate([SerialAsync("seek"), _ts_metadata("design:type", Function), _ts_metadata("design:paramtypes", []), _ts_metadata("design:returntype", Promise)], MKInstance.prototype, "seekForward", null), _ts_decorate([SerialAsync("seek"), _ts_metadata("design:type", Function), _ts_metadata("design:paramtypes", []), _ts_metadata("design:returntype", Promise)], MKInstance.prototype, "seekBackward", null);
    const Do = "undefined" != typeof window && "undefined" != typeof document;
    let Lo = !1;
    const xo = [];

    function cleanupInstances() {
        return _cleanupInstances.apply(this, arguments)
    }

    function _cleanupInstances() {
        return (_cleanupInstances = _async_to_generator$4((function*() {
            const e = xo.map(e => e.cleanup());
            yield Promise.all(e), xo.splice(0, xo.length)
        }))).apply(this, arguments)
    }

    function configure$1(e) {
        return _configure$1.apply(this, arguments)
    }

    function _configure$1() {
        return (_configure$1 = _async_to_generator$4((function*(e, n = MKInstance, s) {
            if (!e) throw new MKError(MKError.Reason.INVALID_ARGUMENTS, "configuration required");
            const d = {};
            e.mergeQueryParams && Do && window.location && (d.linkParameters = _object_spread$2({}, e.linkParameters || {}, parseQueryParams(window.location.href)));
            const p = _object_spread$2({
                runtime: yield RuntimeEnvironment.detect(), dispatcher: new PubSub, request: new RequestManager
            }, null == e ? void 0 : e.services);
            yield findKeySystemPreference(p.runtime);
            const h = new n(_object_spread_props$2(_object_spread$2({}, e, d), {
                services: p
            }));
            return Lo || (yield cleanupInstances()), s && (yield s(h)), xo.push(h), dispatchDocumentEvent(Cn.configured), h
        }))).apply(this, arguments)
    }

    function getInstances() {
        return xo
    }
    Do && (asAsync(function() {
        return _loadWebComponents.apply(this, arguments)
    }()), dispatchDocumentEvent(Cn.loaded));
    const jo = ["uploadedVideo", "uploadedAudio", "uploaded-videos", "uploaded-audios"];

    function asyncGeneratorStep$3(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$3(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$3(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$3(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property$1(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread$1(e) {
        for (var n = 1; n < arguments.length; n++) {
            var s = null != arguments[n] ? arguments[n] : {},
                d = Object.keys(s);
            "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                return Object.getOwnPropertyDescriptor(s, e).enumerable
            })))), d.forEach((function(n) {
                _define_property$1(e, n, s[n])
            }))
        }
        return e
    }

    function _object_spread_props$1(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    const No = Ne.createChild("mpaf"),
        asCode = n => {
            switch (typeof n) {
                case "string":
                    return n;
                case "undefined":
                    return "undefined";
                default:
                    return "PlayActivityEndReasonType." + e.PlayActivityEndReasonType[n]
            }
        };
    class MPAFTracker {
        get requestedEvents() {
            return Array.from(this.dispatchTable.keys())
        }
        get isConfigured() {
            return void 0 !== this.instance
        }
        get activityTracker() {
            if (void 0 === this._activityTracker) throw new MKError(MKError.Reason.CONFIGURATION_ERROR, "Play Activity service was called before configuration.");
            return this._activityTracker
        }
        static create(e) {
            return _async_to_generator$3((function*() {
                const n = new MPAFTracker;
                return yield n.configure(e), n
            }))()
        }
        configure(e) {
            var n = this;
            return _async_to_generator$3((function*() {
                var s, d, p, h;
                n.instance = e.instance, n.services = e.services, n._activityTracker = (s = e.instance, d = {
                    runtime: e.services.runtime,
                    request: e.services.request
                }, new PlayActivity(s.developerToken, s.musicUserToken, s.storefrontCountryCode, {
                    app: {
                        build: Un.app.build,
                        name: null !== (h = Un.app.name) && void 0 !== h ? h : "",
                        version: Un.app.version,
                        bundleId: null === (p = Un.app) || void 0 === p ? void 0 : p.bundleId
                    },
                    fetch: d.request.fetch,
                    isQA: Uo.enabled,
                    logInfo: No.enabled,
                    sourceType: s.sourceType,
                    guid: s.guid,
                    userIsSubscribed: () => !(!s.isAuthorized || !Fn.storekit._getIsActiveSubscription.getCachedValue())
                }))
            }))()
        }
        handleEvent(e, n, s) {
            if (!this.shouldTrackPlayActivity(e, s)) return;
            const d = this.dispatchTable.get(e);
            void 0 !== d && "function" == typeof this[d] && this[d](s, n)
        }
        activate(e, n = {}) {
            var s = this;
            return _async_to_generator$3((function*() {
                No.debug("Activating MPAF tracker"), yield s.activityTracker.activate(n.flush), s.reportTimedMetadata.clear()
            }))()
        }
        exit(e, n = {}) {
            var s = this;
            return _async_to_generator$3((function*() {
                No.debug("PAF debug", `client.exit(${n.position})`), s.activityTracker.exit(n.position)
            }))()
        }
        pause(e, n = {}) {
            var s = this;
            return _async_to_generator$3((function*() {
                if (void 0 !== (null == e ? void 0 : e.id) && s.reportTimedMetadata.add(e.id), "number" == typeof n.endReasonType) return No.debug("PAF debug", `client.stop(${n.position}, ${n.endReasonType})`), s.activityTracker.stop(n.position, n.endReasonType);
                No.debug("PAF debug", `client.pause(${n.position})`), s.activityTracker.pause(n.position)
            }))()
        }
        play(e, n = {}) {
            var s = this;
            return _async_to_generator$3((function*() {
                const d = generateItemDescriptorForPAF(ot.playbackPlay, s.instance, e);
                isLiveRadioKind(e, "video") && (s.musicLiveVideoStartTime = Date.now()), No.debug("PAF debug", `client.play(${JSON.stringify(d)}, ${n.position})`), s.activityTracker.play(d, n.position), s.reportTimedMetadata.add(e.id)
            }))()
        }
        scrub(n, s = {}) {
            var d = this;
            return _async_to_generator$3((function*() {
                No.debug("PAF debug", `client.scrub(${s.position}, ${asCode(s.endReasonType)})`), d.activityTracker.scrub(s.position, s.endReasonType), void 0 !== n && s.endReasonType === e.PlayActivityEndReasonType.SCRUB_END && d.reportTimedMetadata.delete(n.id)
            }))()
        }
        seek(n, s = {}) {
            var d = this;
            return _async_to_generator$3((function*() {
                yield d.scrub(n, {
                    position: s.startPosition,
                    endReasonType: e.PlayActivityEndReasonType.SCRUB_BEGIN
                }), yield d.scrub(n, {
                    position: s.position,
                    endReasonType: e.PlayActivityEndReasonType.SCRUB_END
                })
            }))()
        }
        skip(e, n = {}) {
            var s = this;
            return _async_to_generator$3((function*() {
                const d = generateItemDescriptorForPAF(ot.playbackSkip, s.instance, e);
                No.debug("PAF debug", `client.skip(${JSON.stringify(d)}, ${asCode(n.direction)}, ${n.position})`);
                try {
                    yield s.activityTracker.skip(d, n.direction, n.position), s.reportTimedMetadata.add(e.id)
                } catch (Rt) {
                    if ("A play stop() method was called without a previous play() descriptor" !== Rt.message) return Promise.reject(Rt);
                    yield s.play(e, n)
                }
            }))()
        }
        stop(n, s = {}) {
            var d = this;
            return _async_to_generator$3((function*() {
                var p;
                (isLiveRadioKind(n, "video") ? (s.position = (Date.now() - d.musicLiveVideoStartTime) / 1e3, d.musicLiveVideoStartTime = 0) : (null == n ? void 0 : n.isLiveRadioStation) && s.position && (s.position = s.position - (s.startPosition || 0)), null == n ? void 0 : n.isLiveRadioStation) && (s.endReasonType = null !== (p = s.endReasonType) && void 0 !== p ? p : e.PlayActivityEndReasonType.PLAYBACK_MANUALLY_PAUSED);
                No.debug("PAF debug", `client.stop(${s.position}, ${asCode(s.endReasonType)})`), d.activityTracker.stop(s.position, s.endReasonType), void 0 !== (null == n ? void 0 : n.id) && d.reportTimedMetadata.delete(n.id)
            }))()
        }
        timedMetadata(n, s) {
            var d = this;
            return _async_to_generator$3((function*() {
                var p, h;
                if (void 0 === n || void 0 === s || void 0 === s.position || void 0 === (null === (p = s.metadata) || void 0 === p ? void 0 : p.blob)) return void No.warn("Missing data for TimedMetadata event", s, n);
                if (!n.isRadioStation) return No.debug(`Ignoring TimedMetadata at ${s.position}: Not a Radio Station`), void(d.activityTracker.timedMetadata = void 0);
                if (n.isLiveRadioStation) return No.debug(`Ignoring TimedMetadata at ${s.position}: Live Radio Station`), void(d.activityTracker.timedMetadata = void 0);
                const y = null === (h = s.metadata) || void 0 === h ? void 0 : h.blob,
                    _ = d.activityTracker.timedMetadata;
                d.reportTimedMetadata.has(n.id) ? void 0 === y && void 0 !== _ || compareUint8Array(y, _) ? No.debug(`Skipping TimedMetadata report at ${s.position}: unchanged`, shortHex(y)) : (No.debug("Reporting current TimedMetadata at " + s.position, shortHex(_)), d.activityTracker.pingTimedMetadata(s.position, _)) : (No.debug(`Skipping TimedMetadata report at ${s.position}: disabled for ${n.id} (${n.info})`, shortHex(y)), void 0 === d.activityTracker.timeline.last || d.activityTracker.timeline.last.eventType !== Pt.PLAY_START && d.activityTracker.timeline.last.endReasonType !== e.PlayActivityEndReasonType.SCRUB_END || d.reportTimedMetadata.add(n.id)), No.debug("Storing new TimedMetadata at " + s.position, shortHex(y)), d.activityTracker.timedMetadata = y
            }))()
        }
        shouldTrackPlayActivity(n, s) {
            const d = hasAuthorization(),
                p = !s || s.playbackType !== e.PlaybackType.preview,
                h = this.alwaysSendForActivityType(n),
                y = !s || s && this.mediaRequiresPlayActivity(s);
            return !(!d || !p || !h && !y)
        }
        alwaysSendForActivityType(e) {
            return e === ot.playerActivate || e === ot.playerExit
        }
        mediaRequiresPlayActivity(e) {
            return void 0 !== (n = e.type) && jo.includes(n) || -1 !== ["musicMovie", "musicVideo", "song", "radioStation"].indexOf(e.type);
            var n
        }
        constructor() {
            _define_property$1(this, "instance", void 0), _define_property$1(this, "services", void 0), _define_property$1(this, "_activityTracker", void 0), _define_property$1(this, "reportTimedMetadata", new Set), _define_property$1(this, "musicLiveVideoStartTime", 0), _define_property$1(this, "dispatchTable", new Map([
                [ot.playbackPlay, "play"],
                [ot.playbackPause, "pause"],
                [ot.playbackScrub, "scrub"],
                [ot.playbackSeek, "seek"],
                [ot.playbackSkip, "skip"],
                [ot.playbackStop, "stop"],
                [ot.playerActivate, "activate"],
                [ot.playerExit, "exit"],
                [ot.timedMetadata, "timedMetadata"]
            ]))
        }
    }

    function generateItemDescriptorForPAF(n, s, d) {
        const p = _object_spread_props$1(_object_spread$1({}, function(n, s, d) {
            if (void 0 === (null == d ? void 0 : d.playbackActions) || void 0 === s) return {};
            const p = {
                    [e.PlayerRepeatMode.all]: vt.REPEAT_ALL,
                    [e.PlayerRepeatMode.none]: vt.REPEAT_OFF,
                    [e.PlayerRepeatMode.one]: vt.REPEAT_ONE
                },
                h = {
                    [e.PlayerShuffleMode.off]: gt.SHUFFLE_OFF,
                    [e.PlayerShuffleMode.songs]: gt.SHUFFLE_ON
                };
            return {
                playMode() {
                    let n = vt.REPEAT_UNKNOWN,
                        s = gt.SHUFFLE_UNKNOWN,
                        y = bt.AUTO_UNKNOWN;
                    const {
                        playbackActions: _
                    } = d;
                    var m;
                    return _ && (_.includes(e.PlaybackActions.REPEAT) && (n = p[d.repeatMode]), _.includes(e.PlaybackActions.SHUFFLE) && (s = h[d.shuffleMode]), _.includes(e.PlaybackActions.AUTOPLAY) && (y = d.autoplayEnabled && void 0 !== d.queue ? (m = d.queue).hasAutoplayStation && m.items.some(e => {
                        const {
                            id: n,
                            type: s,
                            container: d
                        } = e;
                        if (d && "stations" === d.type && d.name === ct.RADIO) return !1;
                        let p = s;
                        return isLibraryType(n) && (p = p.startsWith("library-") ? p : "library-" + p),
                            function(e) {
                                return null !== e.match(/-?songs$/i)
                            }(normalizeMediaType(p))
                    }) ? bt.AUTO_ON : bt.AUTO_ON_CONTENT_UNSUPPORTED : bt.AUTO_OFF)), {
                        repeatPlayMode: n,
                        shufflePlayMode: s,
                        autoplayMode: y
                    }
                }
            }
        }(0, d, s), function(e, n) {
            var s;
            if (!typeRequiresItem(e)) return {};
            if (void 0 === n) return {};
            const d = null === (s = n.attributes) || void 0 === s ? void 0 : s.mediaKind;
            return _object_spread$1({}, void 0 !== d ? {
                mediaType: d
            } : {}, n.playParams)
        }(n, d), function(e, n) {
            if (!typeRequiresItem(e) || void 0 === n) return {};
            const {
                context: s = {}
            } = n;
            return {
                recoData: s.reco_id
            }
        }(n, d), function(e, n) {
            if (!typeRequiresItem(e) || void 0 === n) return {};
            const s = n.playbackDuration;
            if (!s) return {};
            return {
                duration: s / 1e3
            }
        }(n, d), function(e, n) {
            var s, d, p, h;
            const y = function(e, n) {
                    var s;
                    return itemIsRequired(e, n) && (null == n || null === (s = n.container) || void 0 === s ? void 0 : s.name) || null
                }(e, n),
                _ = itemIsRequired(e, n) ? _object_spread$1({}, null == n ? void 0 : n.container, null == n || null === (d = n.container) || void 0 === d || null === (s = d.attributes) || void 0 === s ? void 0 : s.playParams, (null == n || null === (h = n.container) || void 0 === h || null === (p = h.attributes) || void 0 === p ? void 0 : p.hasCollaboration) && {
                    isCollaborative: !0
                }) : null;
            if (null === y && null === _) return;
            return {
                container: cleanContainer(_object_spread$1({}, _, null !== y ? {
                    name: y
                } : {}))
            }
        }(n, d)), {
            trackInfo: null == d ? void 0 : d.trackInfo
        });
        return No.trace("PAF descriptor", p), p
    }
    const Uo = BooleanDevFlag.register("mk-use-paf-qa-endpoint");
    const typeRequiresItem = e => [ot.playbackPlay, ot.playbackSkip].includes(e),
        itemIsRequired = (e, n) => void 0 !== n && typeRequiresItem(e);

    function cleanContainer(e) {
        const n = _object_spread$1({}, e);
        return delete n.attributes, n
    }

    function shortHex(e, n = 12) {
        if (e instanceof Uint8Array && (e = toHexString(e)), "string" == typeof e) {
            const s = Math.floor(n / 2);
            return e.length > n ? e.slice(0, s) + "..." + e.slice(-s) : e
        }
        return "0x0000"
    }

    function asyncGeneratorStep$2(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$2(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$2(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$2(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function _define_property(e, n, s) {
        return n in e ? Object.defineProperty(e, n, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[n] = s, e
    }

    function _object_spread_props(e, n) {
        return n = null != n ? n : {}, Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : function(e, n) {
            var s = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var d = Object.getOwnPropertySymbols(e);
                n && (d = d.filter((function(n) {
                    return Object.getOwnPropertyDescriptor(e, n).enumerable
                }))), s.push.apply(s, d)
            }
            return s
        }(Object(n)).forEach((function(s) {
            Object.defineProperty(e, s, Object.getOwnPropertyDescriptor(n, s))
        })), e
    }
    class MusicKitInstance extends MKInstance {
        changeToMediaItem(e) {
            var n = this,
                _superprop_get_changeToMediaItem = () => super.changeToMediaItem;
            return _async_to_generator$2((function*() {
                return n.assertUserStorefront(), _superprop_get_changeToMediaItem().call(n, e)
            }))()
        }
        play() {
            var e = this,
                _superprop_get_play = () => super.play;
            return _async_to_generator$2((function*() {
                return e.assertUserStorefront(), _superprop_get_play().call(e)
            }))()
        }
        playMediaItem(e, n) {
            var s = this,
                _superprop_get_playMediaItem = () => super.playMediaItem;
            return _async_to_generator$2((function*() {
                if (s._isPlaybackSupported()) return s.assertUserStorefront(), _superprop_get_playMediaItem().call(s, e, n)
            }))()
        }
        setStationQueue(e) {
            var n = this;
            return _async_to_generator$2((function*() {
                if (Ge.debug("instance.setStationQueue()", e), n.assertUserStorefront(), !n._isPlaybackSupported()) return void Ge.warn("Playback is not supported");
                const s = n.services.itemLoader.convertOptionsToItemDescriptors(e);
                if (s.length < 1) throw new MKError(MKError.Reason.CONTENT_UNAVAILABLE, "Could not parse descriptors from options");
                let d = void 0;
                const p = s[0];
                if ("song" === p.kind || "artist" === p.kind) {
                    d = (yield n.services.itemLoader.createAutoplayStation([p], {
                        context: e.context,
                        withTracks: !1
                    })).station
                } else {
                    var h, y;
                    const s = yield n.loadItems(e);
                    if (!(null === (h = s[0]) || void 0 === h ? void 0 : h.isRadioStation) && !(null === (y = s[0]) || void 0 === y ? void 0 : y.isRadioEpisode)) throw new MKError(MKError.Reason.CONTENT_UNSUPPORTED, "Unsupported Radio Station type: " + s[0].type);
                    d = s[0]
                }
                return n.setQueue({
                    item: d,
                    shuffleMode: e.shuffleMode,
                    repeatMode: e.repeatMode,
                    startPlaying: e.startPlaying,
                    startTime: e.startTime,
                    startWith: e.startWith,
                    context: e.context,
                    parameters: e.parameters,
                    autoplay: e.autoplay
                })
            }))()
        }
        setQueue(e) {
            var n = this;
            return _async_to_generator$2((function*() {
                if (Ge.debug("instance.setQueue()", e), n.assertUserStorefront(), !n._isPlaybackSupported()) return void Ge.warn("Playback is not supported");
                n.signalChangeItemIntent(), n.deferPlayback();
                const s = yield n.loadItems(e), d = yield n.setPlaybackController(n.playbackControllerForItems(s)), p = yield d.replaceQueue(s, {
                    context: e.context || {},
                    shuffleMode: e.shuffleMode,
                    repeatMode: e.repeatMode,
                    startTime: e.startTime,
                    startWith: e.startWith
                });
                var h;
                return void 0 !== e.autoplay && deprecationWarning("autoplay", {
                    message: "autoplay has been deprecated, use startPlaying instead"
                }), !0 === (null !== (h = e.startPlaying) && void 0 !== h ? h : e.autoplay) && (yield n.play()), p
            }))()
        }
        assertUserStorefront() {
            const n = Fn.storekit.storefrontCountryCode,
                s = Fn.storefrontId,
                d = void 0 !== n && n !== s;
            if (this.realm === e.SKRealm.MUSIC && !this.previewOnly && !0 === d) throw new MKError(MKError.Reason.CONTENT_EQUIVALENT)
        }
        playNext(e, n) {
            var s = this;
            return _async_to_generator$2((function*() {
                var d, p;
                if (s._isPlaybackSupported()) return s.deferPlayback(), s.getPlaybackController().prependToQueue(yield s.loadItems(e), {
                    clear: null !== (p = null !== (d = null == e ? void 0 : e.clear) && void 0 !== d ? d : n) && void 0 !== p && p
                });
                Ge.warn("Playback is not supported")
            }))()
        }
        playLater(e) {
            var n = this;
            return _async_to_generator$2((function*() {
                if (n._isPlaybackSupported()) return n.deferPlayback(), n.getPlaybackController().appendToQueue(yield n.loadItems(e));
                Ge.warn("Playback is not supported")
            }))()
        }
        playAt(e, n) {
            var s = this;
            return _async_to_generator$2((function*() {
                if (s._isPlaybackSupported()) return s.deferPlayback(), s.getPlaybackController().insertInQueue(yield s.loadItems(n), e);
                Ge.warn("Playback is not supported")
            }))()
        }
        clearQueue() {
            var e = this;
            return _async_to_generator$2((function*() {
                var n;
                return e._mediaItemPlayback.clearNextManifest(), null === (n = e.playbackController) || void 0 === n ? void 0 : n.clearQueue()
            }))()
        }
        loadItems(e) {
            var n = this;
            return _async_to_generator$2((function*() {
                var s, d;
                return n.services.itemLoader.loadItems(_object_spread_props(function(e) {
                    for (var n = 1; n < arguments.length; n++) {
                        var s = null != arguments[n] ? arguments[n] : {},
                            d = Object.keys(s);
                        "function" == typeof Object.getOwnPropertySymbols && (d = d.concat(Object.getOwnPropertySymbols(s).filter((function(e) {
                            return Object.getOwnPropertyDescriptor(s, e).enumerable
                        })))), d.forEach((function(n) {
                            _define_property(e, n, s[n])
                        }))
                    }
                    return e
                }({}, e), {
                    restricted: null !== (d = null === (s = Fn.storekit) || void 0 === s ? void 0 : s.restrictedEnabled) && void 0 !== d && d
                }))
            }))()
        }
    }

    function asyncGeneratorStep$1(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator$1(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep$1(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep$1(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function loadLinksData() {
        return _loadLinksData.apply(this, arguments)
    }

    function _loadLinksData() {
        return (_loadLinksData = _async_to_generator$1((function*() {
            const e = [{
                feature: "album-song",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/albums?/(?:[^/]+/)?(?<album>\\d+)$",
                requiredQueryParams: {
                    i: "(?<identifier>\\d+)"
                },
                mediaAPI: {
                    resources: ["songs"]
                }
            }, {
                feature: "albums",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/albums?/(?:[^/]+/)?(?<identifier>\\d+)$",
                mediaAPI: {
                    resources: ["albums"]
                }
            }, {
                feature: "algo-stations",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/stations?/(?:[^/]+/)?(?<identifier>(?:ra|st).\\d+)",
                mediaAPI: {
                    resources: ["stations"]
                }
            }, {
                feature: "artist-default-playable-content",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/artists?/(?:[^/]+/)?(?<identifier>\\d+)$",
                mediaAPI: {
                    resources: ["artists", "default-playable-content"]
                }
            }, {
                feature: "genre-stations",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/genre-stations?",
                mediaAPI: {
                    resources: ["stations"],
                    parameterMapping: {
                        genres: "filter[genres]",
                        eras: "filter[eras]",
                        tags: "filter[tags]",
                        moods: "filter[moods]"
                    }
                }
            }, {
                feature: "library-albums",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/library/albums?/(?:[^/]+/)?(?<identifier>(?:l).[a-zA-Z0-9-]+)$",
                mediaAPI: {
                    resources: ["albums"]
                }
            }, {
                feature: "library-album-song",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/library/albums?/(?:[^/]+/)?(?<album>(?:l).[a-zA-Z0-9-]+)$",
                requiredQueryParams: {
                    i: "(?<identifier>i\\.[a-zA-Z0-9-]+)"
                },
                mediaAPI: {
                    resources: ["songs"]
                }
            }, {
                feature: "library-playlists",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/library/playlists?/(?:[^/]+/)?(?<identifier>(?:p).[a-zA-Z0-9-]+)$",
                mediaAPI: {
                    resources: ["playlists"]
                }
            }, {
                feature: "music-videos",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/music-videos?/(?:[^/]+/)?(?<identifier>\\d+)$",
                mediaAPI: {
                    resources: ["musicVideos"]
                }
            }, {
                feature: "personal-general-radio",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/stations?/me$",
                mediaAPI: {
                    resources: ["stations"],
                    parameters: {
                        "filter[identity]": "personal"
                    }
                }
            }, {
                feature: "personal-mixes",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/(?:personal-)?mix/(?:[^/]+/)?(?<identifier>mx.(?:\\d{1,2}|rp-\\d{4}))$",
                mediaAPI: {
                    resources: ["playlists"]
                }
            }, {
                feature: "playlists",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/playlists?/(?:[^/]+/)?(?<identifier>(?:pl).[a-zA-Z0-9-]+)$",
                mediaAPI: {
                    resources: ["playlists"]
                }
            }, {
                feature: "song",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/(?<storefront>\\w{2})/songs?/(?:[^/]+/)?(?<identifier>\\d+)$",
                mediaAPI: {
                    resources: ["songs"]
                }
            }, {
                feature: "steering-request",
                regex: "http(?:s)?://(?<realm>itunes|music).apple.com/me/stations?/change-station/?$",
                mediaAPI: {
                    resources: ["stations"]
                }
            }].map(e => (e.regex = new RegExp(e.regex), e.requiredQueryParams && (e.requiredQueryParams = Object.keys(e.requiredQueryParams).reduce((n, s) => (n[s] = new RegExp(e.requiredQueryParams[s]), n), {})), e));
            return Promise.resolve(e)
        }))).apply(this, arguments)
    }

    function meetsLinkRequirements(e, n, s = {}) {
        const [d] = e.split(/\?|\#|\&/), p = n.regex.test(d);
        return p && n.requiredQueryParams ? Object.keys(n.requiredQueryParams).every(e => {
            const d = s[e];
            return n.requiredQueryParams[e].test(d)
        }) : p
    }

    function filterLinks(e) {
        return _filterLinks.apply(this, arguments)
    }

    function _filterLinks() {
        return (_filterLinks = _async_to_generator$1((function*(e) {
            const n = yield loadLinksData(), s = parseQueryParams(e);
            return n.reduce((n, d) => {
                if (meetsLinkRequirements(e, d, s)) {
                    if (n.length > 0)
                        if (d.requiredQueryParams) n = n.filter(e => e.requiredQueryParams);
                        else if (n.some(e => e.requiredQueryParams)) return n;
                    d.requiredQueryParams ? d.mediaAPI.parameters = Object.keys(d.requiredQueryParams).reduce((e, n) => (e[n] = s[n], e), {}) : d.mediaAPI.parameterMapping && (d.mediaAPI.parameters = transform$a(d.mediaAPI.parameterMapping, s, !0)), n.push(d)
                }
                return n
            }, [])
        }))).apply(this, arguments)
    }

    function _resolveCanonical() {
        return (_resolveCanonical = _async_to_generator$1((function*(e) {
            return {
                results: {
                    links: yield filterLinks(e)
                },
                meta: {
                    originalUrl: e,
                    originalQueryParams: parseQueryParams(e)
                }
            }
        }))).apply(this, arguments)
    }

    function asyncGeneratorStep(e, n, s, d, p, h, y) {
        try {
            var _ = e[h](y),
                m = _.value
        } catch (ce) {
            return void s(ce)
        }
        _.done ? n(m) : Promise.resolve(m).then(d, p)
    }

    function _async_to_generator(e) {
        return function() {
            var n = this,
                s = arguments;
            return new Promise((function(d, p) {
                var h = e.apply(n, s);

                function _next(e) {
                    asyncGeneratorStep(h, d, p, _next, _throw, "next", e)
                }

                function _throw(e) {
                    asyncGeneratorStep(h, d, p, _next, _throw, "throw", e)
                }
                _next(void 0)
            }))
        }
    }

    function configure(e) {
        return _configure.apply(this, arguments)
    }

    function _configure() {
        return (_configure = _async_to_generator((function*(e) {
            Ge.linkChild(Ne), Ge.linkChild(xe), Ge.linkChild(Ee), Ge.linkChild(je), e.playActivityAPI = [new MPAFTracker];
            return yield configure$1(e, MusicKitInstance, function() {
                var n = _async_to_generator((function*(n) {
                    const s = {
                        apiType: vo.MEDIA_API,
                        options: {}
                    };
                    yield n.configure([s]), e.declarativeMarkup && "undefined" != typeof console && console.warn && console.warn("The declarativeMarkup configuration option has been removed in MusicKit JS V3")
                }));
                return function(e) {
                    return n.apply(this, arguments)
                }
            }())
        }))).apply(this, arguments)
    }
    if (Do) {
        const e = function() {
                function meta(e) {
                    if (detectNodeEnvironment()) return;
                    const n = document.head.querySelector(`meta[name=${e}]`);
                    return (null == n ? void 0 : n.content) || void 0
                }
                const e = meta("apple-music-developer-token") || meta("JWT"),
                    n = meta("apple-music-app-build") || meta("version"),
                    s = meta("apple-music-app-name"),
                    d = meta("apple-music-app-version");
                let p;
                return (e || n || s || d) && (p = {}, e && (p.developerToken = e), (n || s || d) && (p.app = {}, n && (p.app.build = n), s && (p.app.name = s), d && (p.app.version = d))), p
            }(),
            n = /interactive|complete|loaded/.test(document.readyState);
        e && e.developerToken && 0 === getInstances().length && (n ? asAsync(configure(e)) : document.addEventListener("DOMContentLoaded", () => configure(e)))
    }
    e.Events = Cn, e.MKError = MKError, e.MediaItem = MediaItem, e.VideoTypes = {
        movie: !0,
        musicVideo: !0,
        musicMovie: !0,
        trailer: !0,
        tvEpisode: !0,
        uploadedVideo: !0,
        "uploaded-videos": !0,
        "music-videos": !0,
        "music-movies": !0,
        "tv-episodes": !0,
        Bonus: !0,
        Extra: !0,
        Episode: !0,
        Movie: !0,
        Preview: !0,
        Promotional: !0,
        Season: !0,
        Show: !0,
        Vod: !0,
        EditorialVideoClip: !0,
        RealityVideo: !0,
        SportingEvent: !0,
        LiveService: !0
    }, e.configure = configure, e.enableMultipleInstances = function() {
        Lo = !0
    }, e.formatArtworkURL = formatArtworkURL, e.formatMediaTime = function(e, n = ":") {
        const {
            hours: s,
            minutes: d
        } = formattedSeconds(e);
        e = Math.floor(e % 3600 % 60);
        const p = [];
        return s ? (p.push("" + s), p.push(d < 10 ? "0" + d : "" + d)) : p.push("" + d), p.push(e < 10 ? "0" + e : "" + e), p.join(n)
    }, e.formattedMediaURL = formattedMediaURL, e.formattedMilliseconds = function(e) {
        return formattedSeconds(e / 1e3)
    }, e.formattedSeconds = formattedSeconds, e.generateEmbedCode = function(e, n = {
        height: "450",
        width: "660"
    }) {
        if (!s.test(e)) throw new Error("Invalid content url");
        var h;
        let y = null !== (h = n.height) && void 0 !== h ? h : "450";
        var _;
        let m = null !== (_ = n.width) && void 0 !== _ ? _ : "660";
        const {
            kind: v,
            isUTS: g
        } = formattedMediaURL(e), b = "post" === v || "musicVideo" === v || g;
        "song" === v || "episode" === v ? y = "175" : b && (y = "" + Math.round(.5625 * parseInt(m, 10))), y = ("" + y).replace(/(\d+)px/i, "$1"), m = ("" + m).replace(/^(\d+)(?!px)%?$/i, "$1px");
        const S = (b ? "width:" + m : "width:100%;" + (m ? "max-width:" + m : "")) + ";overflow:hidden;border-radius:10px;";
        return `<iframe ${[`allow="${p.join("; ")}"`,'frameborder="0"',y?`height="${y}"`:"",`style="${S}"`,`sandbox="${d.join(" ")}"`,`src="${e.replace(s,"https://embed.music.apple.com")}"`].join(" ")}></iframe>`
    }, e.getHlsJsCdnConfig = getHlsJsCdnConfig, e.getInstance = function(e) {
        if (0 !== xo.length) return void 0 === e ? xo[xo.length - 1] : xo.find(n => n.id === e)
    }, e.getInstances = getInstances, e.getPlayerType = function(e) {
        var n, s;
        return (null == e ? void 0 : e.isUTS) || ye.includes(null == e ? void 0 : e.type) ? "video" : null !== (s = null == e || null === (n = e.attributes) || void 0 === n ? void 0 : n.mediaKind) && void 0 !== s ? s : "audio"
    }, e.resolveCanonical = function(e) {
        return _resolveCanonical.apply(this, arguments)
    }, Object.defineProperty(e, "__esModule", {
        value: !0
    })
}));